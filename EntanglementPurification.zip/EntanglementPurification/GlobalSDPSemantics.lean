import EntanglementPurification.GlobalSDP
import QIT.Core.Map.ChoiCharacterization
import QIT.Channels.Diamond

/-!
# Semantic bridge for the global CPTN Choi SDP

This file proves that the matrix feasibility predicate used by the global
SDP is exactly Lean-QIT's operational predicate for completely positive,
trace-nonincreasing maps.  The transpose below is forced by Lean-QIT's
input-first Choi convention and its expansion in matrix units.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

/-- In Lean-QIT's input-first Choi convention, the trace of a map output is
the trace pairing with the transpose of the output partial trace of its Choi
matrix. -/
theorem trace_map_eq_trace_mul_partialTraceB_choi_transpose
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    (Phi : MatrixMap x y) (X : CMatrix x) :
    (Phi X).trace =
      (X * (QIT.partialTraceB (a := x) (b := y)
        (MatrixMap.choi Phi)).transpose).trace := by
  rw [MatrixMap.trace_map_eq_sum_single]
  simp_rw [← MatrixMap.partialTraceB_choi_apply]
  simp [Matrix.trace, Matrix.mul_apply]

/-- The Choi output-partial-trace inequality implies trace nonincrease. -/
theorem traceNonincreasing_of_partialTraceB_choi_le_one
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    (Phi : MatrixMap x y)
    (hpartial :
      QIT.partialTraceB (a := x) (b := y) (MatrixMap.choi Phi) ≤ 1) :
    MatrixMap.IsTraceNonincreasing Phi := by
  intro X hX
  have htranspose :
      (QIT.partialTraceB (a := x) (b := y)
        (MatrixMap.choi Phi)).transpose ≤ (1 : CMatrix x) := by
    rw [Matrix.le_iff] at hpartial ⊢
    have h := hpartial.transpose
    simpa using h
  have hle :=
    QIT.cMatrix_trace_mul_le_of_le_posSemidef_left hX htranspose
  rw [← trace_map_eq_trace_mul_partialTraceB_choi_transpose] at hle
  simpa using hle

/-- For a completely positive map, trace nonincrease forces the Choi
output-partial-trace inequality. -/
theorem partialTraceB_choi_le_one_of_traceNonincreasing
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    (Phi : MatrixMap x y) (hCP : MatrixMap.IsCompletelyPositive Phi)
    (hTNI : MatrixMap.IsTraceNonincreasing Phi) :
    QIT.partialTraceB (a := x) (b := y) (MatrixMap.choi Phi) ≤ 1 := by
  let A : CMatrix x :=
    QIT.partialTraceB (a := x) (b := y) (MatrixMap.choi Phi)
  have hA : A.PosSemidef := by
    exact QIT.partialTraceB_posSemidef hCP
  have hE_le : A.transpose ≤ (1 : CMatrix x) := by
    rw [Matrix.le_iff]
    have hHerm : ((1 : CMatrix x) - A.transpose).IsHermitian :=
      Matrix.isHermitian_one.sub hA.transpose.isHermitian
    refine (QIT.cMatrix_posSemidef_iff_trace_mul_posSemidef_re_nonneg hHerm).2 ?_
    intro X hX
    have hle := hTNI X hX
    rw [trace_map_eq_trace_mul_partialTraceB_choi_transpose] at hle
    have htrace :
        ((((1 : CMatrix x) - A.transpose) * X).trace).re =
          X.trace.re - ((X * A.transpose).trace).re := by
      simp only [Matrix.sub_mul, Matrix.one_mul, Matrix.trace_sub, Complex.sub_re]
      rw [Matrix.trace_mul_comm]
    rw [htrace]
    exact sub_nonneg.mpr hle
  rw [Matrix.le_iff] at hE_le ⊢
  have htranspose := hE_le.transpose
  simpa [A] using htranspose

/-- Exact semantic identification of the paper's Choi SDP feasible set with
Lean-QIT completely positive trace-nonincreasing maps. -/
theorem isGlobalCPTNChoi_iff_traceNonincreasingCP
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    (J : CMatrix (Prod x y)) :
    IsGlobalCPTNChoi J ↔
      MatrixMap.TraceNonincreasingCP (MatrixMap.ofChoiMatrix J) := by
  constructor
  · intro hJ
    refine
      { completelyPositive := MatrixMap.ofChoiMatrix_isCompletelyPositive hJ.1
        traceNonincreasing := ?_ }
    apply traceNonincreasing_of_partialTraceB_choi_le_one
    rw [MatrixMap.choi_ofChoiMatrix]
    exact hJ.2
  · intro hPhi
    constructor
    · have hcp := hPhi.completelyPositive
      rw [MatrixMap.IsCompletelyPositive, MatrixMap.choi_ofChoiMatrix] at hcp
      exact hcp
    · have hpartial := partialTraceB_choi_le_one_of_traceNonincreasing
        (MatrixMap.ofChoiMatrix J) hPhi.completelyPositive
          hPhi.traceNonincreasing
      rw [MatrixMap.choi_ofChoiMatrix] at hpartial
      exact hpartial

end

end EntanglementPurification
