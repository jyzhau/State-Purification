import EntanglementPurification.CompressedPPTIsometryExtension
import EntanglementPurification.PaddedSchmidtIsometry
import EntanglementPurification.PhysicalOperationalEq986
import EntanglementPurification.PureVectorConjugation
import EntanglementPurification.FiniteKaramata
import EntanglementPurification.ShannonCollisionBound
import EntanglementPurification.ShannonCollisionEquality
import EntanglementPurification.SchmidtEntropyBridge
import QIT.States.MaximallyEntangled
import Mathlib.Tactic

/-!
# Operational necessity for an arbitrary finite pure resource

The only operational hypothesis in this file is an already constructed
`PhysicalPPTInstrument`; no LOCC-to-PPT theorem is assumed.  An arbitrary
finite bipartite pure resource is put into ordered Schmidt form, its compressed
certificate is pulled back to those coordinates, and three zero coordinates
are appended before invoking the Appendix-B signed-Schmidt converse.
-/

namespace EntanglementPurification

open QIT

noncomputable section

universe u v

variable {ra : Type u} {rb : Type v}
  [Fintype ra] [DecidableEq ra]
  [Fintype rb] [DecidableEq rb]

/-- The canonical two-dimensional EPR vector used in the rigidity endpoint. -/
def standardEPR : PureVector (Fin 2 × Fin 2) :=
  PureVector.maximallyEntangled (Equiv.refl (Fin 2))

/-- The positive two-point Schmidt vector is the canonical EPR vector. -/
theorem orderedPositiveSchmidtResource_twoPoint_eq_standardEPR :
    orderedPositiveSchmidtResource (twoPointComparison 0)
        (twoPointComparison_isOrderedProbability 0) = standardEPR := by
  apply PureVector.ext_amp
  funext x
  rcases x with ⟨i, j⟩
  by_cases hij : i = j
  · subst j
    fin_cases i <;>
      simp [orderedPositiveSchmidtResource, orderedPositiveSchmidtAmp,
        twoPointComparison, standardEPR, PureVector.maximallyEntangled_amp]
  · simp [orderedPositiveSchmidtResource, orderedPositiveSchmidtAmp,
      twoPointComparison, standardEPR, PureVector.maximallyEntangled_amp, hij]

/-- Applying a composite reference isometry is sequential application. -/
theorem referenceIsometry_comp_applyPureVector
    {s : Type*} {a : Type*} {b : Type*} {c : Type*}
    [Fintype s] [DecidableEq s]
    [Fintype a] [DecidableEq a]
    [Fintype b] [DecidableEq b]
    [Fintype c] [DecidableEq c]
    (W : ReferenceIsometry b c) (V : ReferenceIsometry a b)
    (psi : PureVector (a × s)) :
    (W.comp V).applyPureVector psi =
      W.applyPureVector (V.applyPureVector psi) := by
  apply PureVector.ext_amp
  funext x
  rcases x with ⟨i, j⟩
  simp [ReferenceIsometry.comp, ReferenceIsometry.applyPureVector_amp,
    ReferenceIsometry.applyAmp, Matrix.mul_apply, Matrix.mulVec, dotProduct,
    Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro k hk
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro l hl
  ring

/-- Right-factor version of `comp_applyPureVector`. -/
theorem referenceIsometry_comp_applyPureVectorRight
    {s : Type*} {a : Type*} {b : Type*} {c : Type*}
    [Fintype s] [DecidableEq s]
    [Fintype a] [DecidableEq a]
    [Fintype b] [DecidableEq b]
    [Fintype c] [DecidableEq c]
    (W : ReferenceIsometry b c) (V : ReferenceIsometry a b)
    (psi : PureVector (s × a)) :
    (W.comp V).applyPureVectorRight psi =
      W.applyPureVectorRight (V.applyPureVectorRight psi) := by
  apply PureVector.ext_amp
  funext x
  rcases x with ⟨i, j⟩
  simp [ReferenceIsometry.comp, ReferenceIsometry.applyPureVectorRight_amp,
    ReferenceIsometry.applyAmpRight, Matrix.mul_apply, Matrix.mulVec,
    dotProduct, Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro k hk
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro l hl
  ring

/-- Isometries acting on opposite tensor factors commute. -/
theorem referenceIsometry_applyPureVector_applyPureVectorRight_comm
    {a : Type*} {b : Type*} {c : Type*} {d : Type*}
    [Fintype a] [DecidableEq a]
    [Fintype b] [DecidableEq b]
    [Fintype c] [DecidableEq c]
    [Fintype d] [DecidableEq d]
    (VA : ReferenceIsometry a c) (VB : ReferenceIsometry b d)
    (psi : PureVector (a × b)) :
    VA.applyPureVector (VB.applyPureVectorRight psi) =
      VB.applyPureVectorRight (VA.applyPureVector psi) := by
  apply PureVector.ext_amp
  funext x
  rcases x with ⟨i, j⟩
  simp [ReferenceIsometry.applyPureVector_amp,
    ReferenceIsometry.applyPureVectorRight_amp,
    ReferenceIsometry.applyAmp, ReferenceIsometry.applyAmpRight,
    Matrix.mulVec, dotProduct, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro k hk
  apply Finset.sum_congr rfl
  intro l hl
  ring

/-- Composition law for a pair of local isometries. -/
theorem referenceIsometry_localComp_applyPureVector
    {a₀ : Type*} {b₀ : Type*} {a₁ : Type*} {b₁ : Type*}
    {a₂ : Type*} {b₂ : Type*}
    [Fintype a₀] [DecidableEq a₀]
    [Fintype b₀] [DecidableEq b₀]
    [Fintype a₁] [DecidableEq a₁]
    [Fintype b₁] [DecidableEq b₁]
    [Fintype a₂] [DecidableEq a₂]
    [Fintype b₂] [DecidableEq b₂]
    (WA : ReferenceIsometry a₁ a₂) (WB : ReferenceIsometry b₁ b₂)
    (VA : ReferenceIsometry a₀ a₁) (VB : ReferenceIsometry b₀ b₁)
    (psi : PureVector (a₀ × b₀)) :
    (WA.comp VA).applyPureVector
        ((WB.comp VB).applyPureVectorRight psi) =
      WA.applyPureVector
        (WB.applyPureVectorRight
          (VA.applyPureVector (VB.applyPureVectorRight psi))) := by
  rw [referenceIsometry_comp_applyPureVector,
    referenceIsometry_comp_applyPureVectorRight]
  rw [referenceIsometry_applyPureVector_applyPureVectorRight_comm VA WB]

@[simp]
theorem conjugatePureVector_involutive
    {a : Type*} [Fintype a] [DecidableEq a]
    (psi : PureVector a) :
    conjugatePureVector (conjugatePureVector psi) = psi := by
  apply PureVector.ext_amp
  funext i
  simp [conjugatePureVector]

@[simp]
theorem conjugatePureVector_standardEPR :
    conjugatePureVector standardEPR = standardEPR := by
  apply PureVector.ext_amp
  funext x
  by_cases h : x.1 = x.2
  · simp [conjugatePureVector, standardEPR,
      PureVector.maximallyEntangled_amp, h]
  · simp [conjugatePureVector, standardEPR,
      PureVector.maximallyEntangled_amp, h]

/-- Coordinatewise conjugation conjugates both local isometries. -/
theorem conjugatePureVector_localIsometries
    {sA : Type*} {sB : Type*} {rA : Type*} {rB : Type*}
    [Fintype sA] [DecidableEq sA]
    [Fintype sB] [DecidableEq sB]
    [Fintype rA] [DecidableEq rA]
    [Fintype rB] [DecidableEq rB]
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (psi : PureVector (sA × sB)) :
    conjugatePureVector
        (VA.applyPureVector (VB.applyPureVectorRight psi)) =
      (conjugateReferenceIsometry VA).applyPureVector
        ((conjugateReferenceIsometry VB).applyPureVectorRight
          (conjugatePureVector psi)) := by
  apply PureVector.ext_amp
  funext x
  rcases x with ⟨i, j⟩
  simp [conjugatePureVector, conjugateReferenceIsometry,
    ReferenceIsometry.applyPureVector_amp,
    ReferenceIsometry.applyPureVectorRight_amp,
    ReferenceIsometry.applyAmp, ReferenceIsometry.applyAmpRight,
    Matrix.mulVec, dotProduct, star_sum, star_mul]
  apply Finset.sum_congr rfl
  intro k hk
  rw [mul_comm]
  congr 1
  apply Finset.sum_congr rfl
  intro l hl
  ring

/-- If three-zero padding of an ordered Schmidt vector is the two-point
spectrum, then the corresponding positive Schmidt vector is an isometric
embedding of the standard two-dimensional EPR vector. -/
theorem orderedPositiveSchmidtResource_eq_localEPR_of_zeroPad_eq_twoPoint
    {n : ℕ} (p : Fin n → ℝ) (hp : IsOrderedProbability p)
    (htwo : zeroPad 3 p = twoPointComparison (n + 1)) :
    ∃ V : ReferenceIsometry (Fin 2) (Fin n),
      orderedPositiveSchmidtResource p hp =
        V.applyPureVector (V.applyPureVectorRight standardEPR) := by
  have hn : 2 ≤ n := by
    by_contra hn
    have hnlt : n < 2 := Nat.lt_of_not_ge hn
    interval_cases n
    · have htotal := hp.2.2
      simp at htotal
    · have htotal : p 0 = 1 := by
        simpa using hp.2.2
      have hfirst := congrFun htwo (Fin.castAdd 3 (0 : Fin 1))
      have hp0 : p 0 = 1 / 2 := by
        simpa [zeroPad, twoPointComparison] using hfirst
      linarith
  obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le hn
  let i0 : Fin (2 + k) := ⟨0, by omega⟩
  let i1 : Fin (2 + k) := ⟨1, by omega⟩
  have hi01 : i0 ≠ i1 := by
    intro h
    have := congrArg Fin.val h
    simp [i0, i1] at this
  have hp0 : p i0 = 1 / 2 := by
    have h := congrFun htwo (Fin.castAdd 3 i0)
    norm_num [zeroPad, twoPointComparison, i0] at h ⊢
    exact h
  have hp1 : p i1 = 1 / 2 := by
    have h := congrFun htwo (Fin.castAdd 3 i1)
    simp only [zeroPad, Fin.append_left] at h
    norm_num [twoPointComparison, i1] at h ⊢
    exact h
  have htotal : ∑ i, p i = 1 :=
    (FiniteSchmidtData.sum_univ_eq_sum_ofFn p).trans hp.2.2
  have htail : ∀ i, i ≠ i0 → i ≠ i1 → p i = 0 := by
    intro i hi0 hi1
    have hsubset :
        (∑ j ∈ ({i0, i1, i} : Finset (Fin (2 + k))), p j) ≤
          ∑ j, p j := by
      apply Finset.sum_le_sum_of_subset_of_nonneg
      · simp
      · intro j hj hjnot
        exact hp.2.1 j
    have hpi_le : p i0 + p i1 + p i ≤ 1 := by
      rw [htotal] at hsubset
      simpa [hi0, hi1, hi01, Ne.symm hi0, Ne.symm hi1,
        Ne.symm hi01, add_assoc] using hsubset
    rw [hp0, hp1] at hpi_le
    exact le_antisymm (by linarith) (hp.2.1 i)
  have hpEq : p = zeroPad k (twoPointComparison 0) := by
    funext i
    cases i using Fin.addCases with
    | left i =>
        fin_cases i
        · have hcast : Fin.castAdd k (0 : Fin 2) = i0 := by
            apply Fin.ext
            rfl
          simpa [zeroPad, twoPointComparison, hcast] using hp0
        · have hcast : Fin.castAdd k (1 : Fin 2) = i1 := by
            apply Fin.ext
            rfl
          simpa [zeroPad, twoPointComparison, hcast] using hp1
    | right i =>
        have hi0 : Fin.natAdd 2 i ≠ i0 := by
          intro h
          have := congrArg Fin.val h
          simp [i0] at this
        have hi1 : Fin.natAdd 2 i ≠ i1 := by
          intro h
          have := congrArg Fin.val h
          simp [i1] at this
          omega
        simpa [zeroPad, twoPointComparison] using
          htail (Fin.natAdd 2 i) hi0 hi1
  let V : ReferenceIsometry (Fin 2) (Fin (2 + k)) :=
    zeroPadReferenceIsometry 2 k
  refine ⟨V, ?_⟩
  calc
    orderedPositiveSchmidtResource p hp =
        orderedPositiveSchmidtResource (zeroPad k (twoPointComparison 0))
          (zeroPad_isOrderedProbability k (twoPointComparison 0)
            (twoPointComparison_isOrderedProbability 0)) := by
      subst p
      rfl
    _ = V.applyPureVector
          (V.applyPureVectorRight
            (orderedPositiveSchmidtResource (twoPointComparison 0)
              (twoPointComparison_isOrderedProbability 0))) := by
      symm
      simpa [V] using
        zeroPadReferenceIsometry_apply_orderedPositiveSchmidtResource
          k (twoPointComparison 0)
            (twoPointComparison_isOrderedProbability 0)
    _ = V.applyPureVector (V.applyPureVectorRight standardEPR) := by
      rw [orderedPositiveSchmidtResource_twoPoint_eq_standardEPR]

/-- A paper-facing certificate saying that `probabilities` are genuine
Schmidt probabilities of `resource` (up to coordinatewise conjugation and
local isometries), while `zeroPad 3 probabilities` satisfies all spectral
conclusions of the operational converse. -/
structure ArbitraryPureOperationalNecessityCertificate
    (resource : PureVector (ra × rb)) where
  n : ℕ
  probabilities : Fin n → ℝ
  isOrdered : IsOrderedProbability probabilities
  left : ReferenceIsometry (Fin n) ra
  right : ReferenceIsometry (Fin n) rb
  schmidtForm :
    conjugatePureVector resource =
      left.applyPureVector
        (right.applyPureVectorRight
          (orderedPositiveSchmidtResource probabilities isOrdered))
  head_le_two_thirds : (zeroPad 3 probabilities) 0 ≤ 2 / 3
  majorizationBranches :
    (((zeroPad 3 probabilities) 0 ≤ 1 / 2 →
        PrefixMajorizedBy (zeroPad 3 probabilities)
          (twoPointComparison (n + 1))) ∧
      (1 / 2 < (zeroPad 3 probabilities) 0 →
        zStar ((zeroPad 3 probabilities) 0) ≤
            tailFromTwo (zeroPad 3 probabilities) ∧
        2 * ((zeroPad 3 probabilities) 0 - 1 / 2) ^ 2 <
            tailFromTwo (zeroPad 3 probabilities) ∧
        PrefixMajorizedBy (zeroPad 3 probabilities)
          (threePointComparison n ((zeroPad 3 probabilities) 0)
            (zStar ((zeroPad 3 probabilities) 0)))))
  majorization :
    PrefixMajorizedBy (zeroPad 3 probabilities)
      (paperComparisonSpectrum n ((zeroPad 3 probabilities) 0))
  collision_le_half :
    collisionProbability (zeroPad 3 probabilities) ≤ 1 / 2
  one_le_collisionEntropy :
    1 ≤ collisionEntropyBits (zeroPad 3 probabilities)
  entropy_eq :
    resource.entanglementEntropy =
      shannonEntropyBits (zeroPad 3 probabilities)
  one_le_entanglementEntropy : 1 ≤ resource.entanglementEntropy

/-- Exact operational attainment by an arbitrary finite-dimensional pure
resource produces the complete ordered spectral certificate used in the
paper.  Padding by three zeros uniformly covers Schmidt ranks `0`, `1`, and
`2`; no lower bound on either local dimension is assumed. -/
theorem physicalOperationalAttainment_arbitraryPure_certificate
    {d : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (resource : PureVector (ra × rb))
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le resource =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) :
    Nonempty (ArbitraryPureOperationalNecessityCertificate resource) := by
  rcases exists_orderedPositiveSchmidtIsometryWitness
      (conjugatePureVector resource) with ⟨n, ⟨W⟩⟩
  let pPad : Fin (n + 3) → ℝ := zeroPad 3 W.probabilities
  let hpPad : IsOrderedProbability pPad :=
    zeroPad_isOrderedProbability 3 W.probabilities W.isOrdered
  have hsdpeq :
      globalSDPObjective
          (globalPaperEq986PerformanceOperator hd nu gamma)
          (pureResourceInsert (conjugatePureVector resource).amp
            (MatrixMap.choi (M.instrument.branch true))) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma := by
    rw [physicalPaperOperationalAverageAcceptedGain_eq_globalSDPObjective]
      at hattains
    simpa [conjugatePureVector] using hattains
  let ambientData : CompressedPPTInstrumentData d ra rb :=
    physicalInstrumentTwirlGlobalOptimalCompressedData
      M hd nu hgamma0 hgamma1 (conjugatePureVector resource) hsdpeq
  have hambientResource :
      ambientData.resource = conjugatePureVector resource := by
    exact physicalInstrumentTwirlGlobalOptimalCompressedData_resource
      M hd nu hgamma0 hgamma1 (conjugatePureVector resource) hsdpeq
  let smallData : CompressedPPTInstrumentData d (Fin n) (Fin n) :=
    ambientData.pullbackLocalIsometries
      (orderedPositiveSchmidtResource W.probabilities W.isOrdered)
      W.left W.right (hambientResource.trans W.eq_localIsometries)
  let padV : ReferenceIsometry (Fin n) (Fin (n + 3)) :=
    zeroPadReferenceIsometry n 3
  let paddedData : CompressedPPTInstrumentData d
      (Fin (n + 3)) (Fin (n + 3)) :=
    smallData.pushforwardLocalIsometries padV padV
  have hpaddedResource :
      paddedData.resource = orderedPositiveSchmidtResource pPad hpPad := by
    calc
      paddedData.resource =
          padV.applyPureVector
            (padV.applyPureVectorRight smallData.resource) := by
        rfl
      _ = padV.applyPureVector
            (padV.applyPureVectorRight
              (orderedPositiveSchmidtResource W.probabilities W.isOrdered)) := by
        rfl
      _ = orderedPositiveSchmidtResource pPad hpPad := by
        simpa [pPad, hpPad, padV] using
          zeroPadReferenceIsometry_apply_orderedPositiveSchmidtResource
            3 W.probabilities W.isOrdered
  let signedData : CompressedPPTInstrumentData d
      (Fin (n + 3)) (Fin (n + 3)) :=
    paddedData.pullbackLocalIsometries
      (ambientSignedSchmidtResource pPad hpPad)
      (signedSchmidtPhase n)
      (ReferenceIsometry.ofEquiv (Equiv.refl (Fin (n + 3))))
      (hpaddedResource.trans
        (signedSchmidtPhase_apply_ambientSignedSchmidtResource pPad hpPad).symm)
  have hmajor :=
    signedData.implies_schmidt_majorization hd pPad hpPad (by rfl)
  have hcollision : collisionProbability pPad ≤ 1 / 2 :=
    signedData.implies_collisionProbability_le_half hd pPad hpPad (by rfl)
  have hcollisionEntropy : 1 ≤ collisionEntropyBits pPad :=
    one_le_collisionEntropyBits_of_orderedProbability_of_collisionProbability_le_half
      hpPad hcollision
  have hmajorUnified :
      PrefixMajorizedBy pPad
        (paperComparisonSpectrum n (pPad 0)) :=
    prefixMajorizedBy_paperComparisonSpectrum_of_branches
      hmajor.2.1 (fun hx => (hmajor.2.2 hx).2.2)
  have hconjugateSmallEntropy :
      (conjugatePureVector resource).entanglementEntropy =
        (orderedPositiveSchmidtResource W.probabilities
          W.isOrdered).entanglementEntropy := by
    calc
      (conjugatePureVector resource).entanglementEntropy =
          (W.left.applyPureVector
            (W.right.applyPureVectorRight
              (orderedPositiveSchmidtResource W.probabilities
                W.isOrdered))).entanglementEntropy :=
        congrArg PureVector.entanglementEntropy W.eq_localIsometries
      _ = (orderedPositiveSchmidtResource W.probabilities
          W.isOrdered).entanglementEntropy := by
        rw [entanglementEntropy_applyPureVector,
          entanglementEntropy_applyPureVectorRight]
  have hpaddedSmallEntropy :
      (orderedPositiveSchmidtResource pPad hpPad).entanglementEntropy =
        (orderedPositiveSchmidtResource W.probabilities
          W.isOrdered).entanglementEntropy := by
    rw [← zeroPadReferenceIsometry_apply_orderedPositiveSchmidtResource
      3 W.probabilities W.isOrdered]
    rw [entanglementEntropy_applyPureVector,
      entanglementEntropy_applyPureVectorRight]
  have hsignedPaddedEntropy :
      (ambientSignedSchmidtResource pPad hpPad).entanglementEntropy =
        (orderedPositiveSchmidtResource pPad hpPad).entanglementEntropy := by
    rw [← signedSchmidtPhase_apply_ambientSignedSchmidtResource pPad hpPad]
    rw [entanglementEntropy_applyPureVector,
      entanglementEntropy_applyPureVectorRight]
  have hresourceEntropy :
      resource.entanglementEntropy = shannonEntropyBits pPad := by
    calc
      resource.entanglementEntropy =
          (conjugatePureVector resource).entanglementEntropy := by
        rw [conjugatePureVector_entanglementEntropy]
      _ = (orderedPositiveSchmidtResource W.probabilities
          W.isOrdered).entanglementEntropy := hconjugateSmallEntropy
      _ = (orderedPositiveSchmidtResource pPad hpPad).entanglementEntropy :=
        hpaddedSmallEntropy.symm
      _ = (ambientSignedSchmidtResource pPad hpPad).entanglementEntropy :=
        hsignedPaddedEntropy.symm
      _ = shannonEntropyBits pPad := by
        simpa [shannonEntropyBits] using
          ambientSignedSchmidtResource_entanglementEntropy pPad hpPad
  have honeShannon : 1 ≤ shannonEntropyBits pPad :=
    one_le_shannonEntropyBits_of_orderedProbability_of_collisionProbability_le_half
      hpPad hcollision
  have honeEntropy : 1 ≤ resource.entanglementEntropy := by
    rw [hresourceEntropy]
    exact honeShannon
  exact ⟨
    { n := n
      probabilities := W.probabilities
      isOrdered := W.isOrdered
      left := W.left
      right := W.right
      schmidtForm := W.eq_localIsometries
      head_le_two_thirds := by simpa [pPad] using hmajor.1
      majorizationBranches := by simpa [pPad] using hmajor.2
      majorization := by simpa [pPad] using hmajorUnified
      collision_le_half := by simpa [pPad] using hcollision
      one_le_collisionEntropy := by simpa [pPad] using hcollisionEntropy
      entropy_eq := by simpa [pPad] using hresourceEntropy
      one_le_entanglementEntropy := honeEntropy }⟩

/-- The principal scalar endpoint: any arbitrary finite pure resource attaining
the global optimum through a physical PPT instrument has at least one ebit. -/
theorem physicalOperationalAttainment_arbitraryPure_implies_one_le_entanglementEntropy
    {d : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (resource : PureVector (ra × rb))
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le resource =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) :
    1 ≤ resource.entanglementEntropy := by
  rcases physicalOperationalAttainment_arbitraryPure_certificate
      M hd nu hgamma0 hgamma1 resource hattains with ⟨C⟩
  exact C.one_le_entanglementEntropy

/-- Equality rigidity with no externally supplied Schmidt witness: if an
arbitrary finite pure resource attains the operational optimum with exactly
one ebit, then the original (not merely coordinatewise-conjugated) vector is
the image of the standard two-dimensional EPR vector under two local
isometries. -/
theorem physicalOperationalAttainment_arbitraryPure_entanglement_eq_one_implies_localEPR
    {d : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (resource : PureVector (ra × rb))
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le resource =
        globalOptimalGain ((d : ℝ) ^ 2) gamma)
    (hentropy : resource.entanglementEntropy = 1) :
    ∃ VA : ReferenceIsometry (Fin 2) ra,
      ∃ VB : ReferenceIsometry (Fin 2) rb,
        resource =
          VA.applyPureVector (VB.applyPureVectorRight standardEPR) := by
  rcases physicalOperationalAttainment_arbitraryPure_certificate
      M hd nu hgamma0 hgamma1 resource hattains with ⟨C⟩
  let pPad : Fin (C.n + 3) → ℝ := zeroPad 3 C.probabilities
  let hpPad : IsOrderedProbability pPad :=
    zeroPad_isOrderedProbability 3 C.probabilities C.isOrdered
  have hShannon : shannonEntropyBits pPad = 1 := by
    calc
      shannonEntropyBits pPad = resource.entanglementEntropy := by
        simpa [pPad] using C.entropy_eq.symm
      _ = 1 := hentropy
  have htwo : pPad = twoPointComparison (C.n + 1) :=
    orderedProbability_eq_twoPoint_of_collision_le_half_of_shannon_eq_one
      hpPad (by simpa [pPad] using C.collision_le_half) hShannon
  have htwoRaw :
      zeroPad 3 C.probabilities = twoPointComparison (C.n + 1) := by
    simpa [pPad] using htwo
  rcases
      orderedPositiveSchmidtResource_eq_localEPR_of_zeroPad_eq_twoPoint
        C.probabilities C.isOrdered htwoRaw with
    ⟨V, hpositive⟩
  let VAconj : ReferenceIsometry (Fin 2) ra := C.left.comp V
  let VBconj : ReferenceIsometry (Fin 2) rb := C.right.comp V
  have hconjugateResource :
      conjugatePureVector resource =
        VAconj.applyPureVector
          (VBconj.applyPureVectorRight standardEPR) := by
    calc
      conjugatePureVector resource =
          C.left.applyPureVector
            (C.right.applyPureVectorRight
              (orderedPositiveSchmidtResource C.probabilities
                C.isOrdered)) := C.schmidtForm
      _ = C.left.applyPureVector
            (C.right.applyPureVectorRight
              (V.applyPureVector (V.applyPureVectorRight standardEPR))) :=
        congrArg
          (fun phi => C.left.applyPureVector
            (C.right.applyPureVectorRight phi)) hpositive
      _ = VAconj.applyPureVector
            (VBconj.applyPureVectorRight standardEPR) := by
        symm
        simpa [VAconj, VBconj] using
          referenceIsometry_localComp_applyPureVector
            C.left C.right V V standardEPR
  refine ⟨conjugateReferenceIsometry VAconj,
    conjugateReferenceIsometry VBconj, ?_⟩
  calc
    resource = conjugatePureVector (conjugatePureVector resource) :=
      (conjugatePureVector_involutive resource).symm
    _ = conjugatePureVector
          (VAconj.applyPureVector
            (VBconj.applyPureVectorRight standardEPR)) :=
      congrArg conjugatePureVector hconjugateResource
    _ = (conjugateReferenceIsometry VAconj).applyPureVector
          ((conjugateReferenceIsometry VBconj).applyPureVectorRight
            (conjugatePureVector standardEPR)) :=
      conjugatePureVector_localIsometries VAconj VBconj standardEPR
    _ = (conjugateReferenceIsometry VAconj).applyPureVector
          ((conjugateReferenceIsometry VBconj).applyPureVectorRight
            standardEPR) := by
      rw [conjugatePureVector_standardEPR]

end

end EntanglementPurification
