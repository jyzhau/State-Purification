import EntanglementPurification.GlobalOperationalEq986
import EntanglementPurification.PureResourceOperationalMap
import EntanglementPurification.PhysicalInstrumentTwirlSchmidtConverse

/-!
# Operational equation 986 for a physical PPT instrument

This module preloads the success branch of a `PhysicalPPTInstrument` with a
normalized pure assisting resource and connects the resulting operational map
to the Haar-averaged equation-986 objective.

For a general complex resource amplitude, the input-first Choi convention
produces `pureResourceInsert (fun i => star resource.amp i)`.  The signed
Schmidt-coordinate resource used in the Appendix has real amplitudes, so the
coordinatewise star disappears there and the operational statement connects
literally to the existing Appendix converse.
-/

namespace EntanglementPurification

open QIT

noncomputable section

universe u v w z

variable {a : Type u} {b : Type v} {ra : Type w} {rb : Type z}
  [Fintype a] [DecidableEq a]
  [Fintype b] [DecidableEq b]
  [Fintype ra] [DecidableEq ra]
  [Fintype rb] [DecidableEq rb]

/-- The operational success map after preloading a normalized pure resource. -/
def physicalSuccessInducedMap
    (M : PhysicalPPTInstrument a b ra rb)
    (resource : PureVector (ra × rb)) :
    MatrixMap ((a × b) × (a × b)) (a × b) :=
  inducedByPureResource (M.instrument.branch true) resource

/-- Preloading a pure resource preserves complete positivity and
trace-nonincreasingness of the success branch. -/
theorem physicalSuccessInducedMap_traceNonincreasingCP
    (M : PhysicalPPTInstrument a b ra rb)
    (resource : PureVector (ra × rb)) :
    MatrixMap.TraceNonincreasingCP
      (physicalSuccessInducedMap M resource) := by
  exact inducedByPureResource_traceNonincreasingCP
    (M.instrument.branch true) resource
      (M.instrument.branchTraceNonincreasingCP true)

/-- Haar-averaged accepted fidelity gain of the physical success branch after
preloading an arbitrary normalized pure resource. -/
def physicalPaperOperationalAverageAcceptedGain
    {d : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d)) (gamma : ℝ)
    (hgamma0 : 0 ≤ gamma) (hgamma1 : gamma ≤ 1)
    (resource : PureVector (ra × rb)) : ℝ :=
  globalPaperOperationalAverageAcceptedGain hd nu gamma hgamma0 hgamma1
    (physicalSuccessInducedMap M resource)
    (physicalSuccessInducedMap_traceNonincreasingCP M resource)

/-- The operational average is equation 986 evaluated on the genuinely
induced map.  The coordinatewise star is forced by the input-first Choi
convention and is retained for arbitrary complex resources. -/
theorem physicalPaperOperationalAverageAcceptedGain_eq_globalSDPObjective
    {d : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d)) (gamma : ℝ)
    (hgamma0 : 0 ≤ gamma) (hgamma1 : gamma ≤ 1)
    (resource : PureVector (ra × rb)) :
    physicalPaperOperationalAverageAcceptedGain M hd nu gamma hgamma0 hgamma1 resource =
      globalSDPObjective (globalPaperEq986PerformanceOperator hd nu gamma)
        (pureResourceInsert (fun i => star (resource.amp i))
          (MatrixMap.choi (M.instrument.branch true))) := by
  rw [physicalPaperOperationalAverageAcceptedGain,
    globalPaperOperationalAverageAcceptedGain_eq_globalSDPObjective,
    physicalSuccessInducedMap,
    choi_inducedByPureResource]

/-- Universal operational upper bound for every physical PPT instrument
success branch and every normalized pure assisting resource. -/
theorem physicalPaperOperationalAverageAcceptedGain_le_globalOptimalGain
    {d : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d)) {gamma : ℝ}
    (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (resource : PureVector (ra × rb)) :
    physicalPaperOperationalAverageAcceptedGain M hd nu gamma
        hgamma0.le hgamma1.le resource ≤
      globalOptimalGain ((d : ℝ) ^ 2) gamma := by
  exact globalPaperOperationalAverageAcceptedGain_le_globalOptimalGain
    hd nu hgamma0 hgamma1 (physicalSuccessInducedMap M resource)
      (physicalSuccessInducedMap_traceNonincreasingCP M resource)

/-- Exact operational equality occurs precisely when the induced success map
is the unique global optimizer. -/
theorem physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_iff
    {d : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d)) {gamma : ℝ}
    (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (resource : PureVector (ra × rb)) :
    (physicalPaperOperationalAverageAcceptedGain M hd nu gamma
        hgamma0.le hgamma1.le resource =
      globalOptimalGain ((d : ℝ) ^ 2) gamma) ↔
      physicalSuccessInducedMap M resource =
        MatrixMap.ofChoiMatrix
          (globalOptimalChoi (x := GlobalPaperIndex d)) := by
  exact globalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_iff
    hd nu hgamma0 hgamma1 (physicalSuccessInducedMap M resource)
      (physicalSuccessInducedMap_traceNonincreasingCP M resource)

/-- The Appendix's signed Schmidt-coordinate resource has real amplitudes, so
coordinatewise complex conjugation fixes it exactly. -/
@[simp]
theorem star_ambientSignedSchmidtResource_amp
    {m : ℕ} (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p) :
    (fun i => star ((ambientSignedSchmidtResource p hp).amp i)) =
      (ambientSignedSchmidtResource p hp).amp := by
  funext ij
  rcases ij with ⟨i, j⟩
  by_cases hij : i = j
  · subst j
    by_cases hi0 : i = 0 <;>
      simp [ambientSignedSchmidtResource, ambientSignedSchmidtAmp, hi0]
  · simp [ambientSignedSchmidtResource, ambientSignedSchmidtAmp, hij]

/-- For the Appendix's signed Schmidt resource, the operational average is
literally the existing `pureResourceInsert resource.amp` objective. -/
theorem physicalPaperOperationalAverageAcceptedGain_ambientSignedSchmidtResource_eq_globalSDPObjective
    {d m : ℕ}
    (M : PhysicalPPTInstrument
      (Fin d) (Fin d) (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d)) (gamma : ℝ)
    (hgamma0 : 0 ≤ gamma) (hgamma1 : gamma ≤ 1)
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p) :
    physicalPaperOperationalAverageAcceptedGain M hd nu gamma hgamma0 hgamma1
        (ambientSignedSchmidtResource p hp) =
      globalSDPObjective (globalPaperEq986PerformanceOperator hd nu gamma)
        (pureResourceInsert (ambientSignedSchmidtResource p hp).amp
          (MatrixMap.choi (M.instrument.branch true))) := by
  rw [physicalPaperOperationalAverageAcceptedGain_eq_globalSDPObjective,
    star_ambientSignedSchmidtResource_amp]

/-- Exact operational attainment by a signed Schmidt-coordinate resource
forces the Appendix's complete majorization conclusion. -/
theorem physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_schmidt_majorization
    {d m : ℕ}
    (M : PhysicalPPTInstrument
      (Fin d) (Fin d) (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le (ambientSignedSchmidtResource p hp) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) :
    p 0 ≤ 2 / 3 ∧
      (p 0 ≤ 1 / 2 →
        PrefixMajorizedBy p (twoPointComparison (m + 1))) ∧
      (1 / 2 < p 0 →
        zStar (p 0) ≤ tailFromTwo p ∧
        2 * (p 0 - 1 / 2) ^ 2 < tailFromTwo p ∧
        PrefixMajorizedBy p
          (threePointComparison m (p 0) (zStar (p 0)))) := by
  apply physicalInstrumentTwirlGlobalOptimal_implies_schmidt_majorization
    M hd nu hgamma0 hgamma1 p hp
  rw [← physicalPaperOperationalAverageAcceptedGain_ambientSignedSchmidtResource_eq_globalSDPObjective]
  exact hattains

/-- Exact operational attainment by a signed Schmidt-coordinate resource
forces collision probability at most one half. -/
theorem physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_collisionProbability_le_half
    {d m : ℕ}
    (M : PhysicalPPTInstrument
      (Fin d) (Fin d) (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le (ambientSignedSchmidtResource p hp) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) :
    collisionProbability p ≤ 1 / 2 := by
  apply physicalInstrumentTwirlGlobalOptimal_implies_collisionProbability_le_half
    M hd nu hgamma0 hgamma1 p hp
  rw [← physicalPaperOperationalAverageAcceptedGain_ambientSignedSchmidtResource_eq_globalSDPObjective]
  exact hattains

end

end EntanglementPurification
