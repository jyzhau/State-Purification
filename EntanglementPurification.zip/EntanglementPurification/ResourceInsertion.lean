import EntanglementPurification.GlobalEq986Optimality

/-!
# Pure-resource insertion for input-first Choi matrices

This file begins the upstream PPT-instrument block of main.tex.
An uninserted branch has Choi index ((h × r) × y), where r is the
assisting-resource input.  Inserting a pure resource vector eta : r → ℂ
is the compression V_etaᴴ S V_eta.  This is the matrix form of
equation eq:resource_insertion_convention.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {h r y : Type*}
  [Fintype h] [Fintype r] [Fintype y]
  [DecidableEq h] [DecidableEq r] [DecidableEq y]

/-- The embedding |q⟩ ↦ |q⟩ ⊗ |eta⟩ in the Choi input,
leaving the output index unchanged. -/
def pureResourceChoiEmbedding (eta : r → ℂ) :
    Matrix ((h × r) × y) (h × y) ℂ :=
  fun p q =>
    if p.1.1 = q.1 then
      if p.2 = q.2 then eta p.1.2 else 0
    else 0

/-- Insert a pure assisting resource into an input-first Choi matrix. -/
def pureResourceInsert (eta : r → ℂ)
    (S : CMatrix ((h × r) × y)) : CMatrix (h × y) :=
  Matrix.conjTranspose
      (pureResourceChoiEmbedding (h := h) (y := y) eta) * S *
    pureResourceChoiEmbedding (h := h) (y := y) eta

/-- The finite resource vector has squared norm one. -/
def IsNormalizedResourceVector (eta : r → ℂ) : Prop :=
  ∑ a : r, star (eta a) * eta a = 1

/-- A Lean-QIT pure vector satisfies the normalization used for insertion. -/
theorem PureVector.isNormalizedResourceVector (eta : PureVector r) :
    IsNormalizedResourceVector eta.amp := by
  rw [IsNormalizedResourceVector]
  have h := eta.trace_rankOne_eq_one
  simpa [rankOneMatrix_trace, dotProduct, mul_comm] using h

/-- Entrywise form of the resource-insertion convention.  The coefficient
star (eta a) * eta b is the (a,b) entry of the transpose of
the rank-one resource matrix. -/
theorem pureResourceInsert_apply
    (eta : r → ℂ) (S : CMatrix ((h × r) × y))
    (p q : h × y) :
    pureResourceInsert eta S p q =
      ∑ a : r, ∑ b : r,
        star (eta a) * S ((p.1, a), p.2) ((q.1, b), q.2) * eta b := by
  simp [pureResourceInsert, pureResourceChoiEmbedding, Matrix.mul_apply,
    Matrix.conjTranspose_apply, Fintype.sum_prod_type, apply_ite,
    Finset.sum_mul]
  rw [Finset.sum_comm]

/-- Resource insertion is additive in the uninserted branch. -/
theorem pureResourceInsert_add
    (eta : r → ℂ) (S F : CMatrix ((h × r) × y)) :
    pureResourceInsert eta (S + F) =
      pureResourceInsert eta S + pureResourceInsert eta F := by
  simp [pureResourceInsert, Matrix.mul_add, Matrix.add_mul]

/-- Taking the output trace commutes with pure-resource insertion.  The right
side is the same resource sandwich applied to the uninserted input marginal. -/
theorem partialTraceB_pureResourceInsert_apply
    (eta : r → ℂ) (S : CMatrix ((h × r) × y)) (i j : h) :
    QIT.partialTraceB (a := h) (b := y) (pureResourceInsert eta S) i j =
      ∑ a : r, ∑ b : r,
        star (eta a) *
          QIT.partialTraceB (a := h × r) (b := y) S (i, a) (j, b) *
          eta b := by
  simp only [QIT.partialTraceB]
  simp_rw [pureResourceInsert_apply, Finset.mul_sum, Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro a ha
  rw [Finset.sum_comm]

/-- Matrix-level success/failure instrument before the assisting resource is
inserted.  The PPT constraints are added in a later module; this record captures
the positivity and full trace-preservation conditions common to both. -/
def IsChoiSuccessFailurePair
    (S F : CMatrix ((h × r) × y)) : Prop :=
  S.PosSemidef ∧ F.PosSemidef ∧
    QIT.partialTraceB (a := h × r) (b := y) (S + F) = 1

/-- A normalized resource contracts the full instrument trace identity to the
trace identity on the physical input. -/
theorem partialTraceB_inserted_success_add_failure_eq_one
    (eta : r → ℂ) (heta : IsNormalizedResourceVector eta)
    {S F : CMatrix ((h × r) × y)}
    (htrace :
      QIT.partialTraceB (a := h × r) (b := y) (S + F) = 1) :
    QIT.partialTraceB (a := h) (b := y) (pureResourceInsert eta S) +
        QIT.partialTraceB (a := h) (b := y) (pureResourceInsert eta F) =
      1 := by
  rw [← QIT.partialTraceB_add, ← pureResourceInsert_add]
  ext i j
  rw [partialTraceB_pureResourceInsert_apply, htrace]
  by_cases hij : i = j
  · subst j
    simp [Matrix.one_apply, IsNormalizedResourceVector] at heta ⊢
    exact heta
  · simp [hij]

/-- Pure-resource insertion preserves positive semidefiniteness. -/
theorem pureResourceInsert_posSemidef
    (eta : r → ℂ) {S : CMatrix ((h × r) × y)}
    (hS : S.PosSemidef) :
    (pureResourceInsert eta S).PosSemidef := by
  simpa [pureResourceInsert] using
    hS.conjTranspose_mul_mul_same
      (pureResourceChoiEmbedding (h := h) (y := y) eta)

/-- The inserted success branch is a feasible CP trace-nonincreasing Choi
matrix whenever it belongs to a normalized success/failure instrument. -/
theorem isGlobalCPTNChoi_pureResourceInsert_success
    (eta : r → ℂ) (heta : IsNormalizedResourceVector eta)
    {S F : CMatrix ((h × r) × y)}
    (hpair : IsChoiSuccessFailurePair S F) :
    IsGlobalCPTNChoi (pureResourceInsert eta S) := by
  constructor
  · exact pureResourceInsert_posSemidef eta hpair.1
  · rw [Matrix.le_iff]
    have hFpos :
        (QIT.partialTraceB (a := h) (b := y)
          (pureResourceInsert eta F)).PosSemidef :=
      QIT.partialTraceB_posSemidef
        (pureResourceInsert_posSemidef eta hpair.2.1)
    have hsum :=
      partialTraceB_inserted_success_add_failure_eq_one
        eta heta hpair.2.2
    have hdiff :
        (1 : CMatrix h) -
            QIT.partialTraceB (a := h) (b := y)
              (pureResourceInsert eta S) =
          QIT.partialTraceB (a := h) (b := y)
            (pureResourceInsert eta F) := by
      rw [← hsum]
      abel
    rw [hdiff]
    exact hFpos

/-- Equation eq:gd_inserted_global_optimizer: exact attainment by an
uninserted success/failure pair forces its inserted success branch to be the
unique global optimizer.  This is the first bridge from task C into the PPT
resource converse. -/
theorem globalPaperEq986_optimality_fixes_pureResourceInsertedSuccess
    {d : ℕ} (hd : 2 ≤ d)
    (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    {r : Type*} [Fintype r] [DecidableEq r]
    (eta : r → ℂ) (heta : IsNormalizedResourceVector eta)
    {S F : CMatrix
      ((((GlobalPaperIndex d × GlobalPaperIndex d) × r) ×
        GlobalPaperIndex d))}
    (hpair : IsChoiSuccessFailurePair S F)
    (hattains :
      globalSDPObjective
          (globalPaperEq986PerformanceOperator hd nu gamma)
          (pureResourceInsert eta S) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) :
    pureResourceInsert eta S =
      globalOptimalChoi (x := GlobalPaperIndex d) := by
  have hfeasible :
      IsGlobalCPTNChoi (pureResourceInsert eta S) :=
    isGlobalCPTNChoi_pureResourceInsert_success eta heta hpair
  exact
    ((globalPaperEq986_optimal_and_unique
      hd nu hgamma0 hgamma1).2.2.2
        (pureResourceInsert eta S) hfeasible).mp hattains

end

end EntanglementPurification
