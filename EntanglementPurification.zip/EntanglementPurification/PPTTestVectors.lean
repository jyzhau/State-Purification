import EntanglementPurification.PPTPartialTranspose

/-!
# Sparse vectors used in the compressed PPT tests

The paper writes normalized superpositions and then multiplies their quadratic
forms by two.  Here the corresponding unnormalized two-point vectors are used,
so the square roots cancel before any order argument is performed.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

/-- A coordinate basis vector. -/
def coordinateBasisVector {ι : Type*} [DecidableEq ι] (i : ι) : ι → ℂ :=
  Pi.single i 1

/-- A two-coordinate vector, written linearly so coinciding coordinates also
have the expected additive meaning. -/
def twoPointVector {ι : Type*} [DecidableEq ι]
    (i j : ι) (a b : ℂ) : ι → ℂ :=
  a • coordinateBasisVector i + b • coordinateBasisVector j

/-- Complex matrix quadratic form in coordinates. -/
def matrixQuadratic {ι : Type*} [Fintype ι]
    (M : CMatrix ι) (v : ι → ℂ) : ℂ :=
  dotProduct (star v) (M.mulVec v)

/-- A PSD matrix has a nonnegative real quadratic form. -/
theorem matrixQuadratic_re_nonneg
    {ι : Type*} [Fintype ι] {M : CMatrix ι}
    (hM : M.PosSemidef) (v : ι → ℂ) :
    0 ≤ (matrixQuadratic M v).re := by
  exact (Complex.nonneg_iff.mp (hM.dotProduct_mulVec_nonneg v)).1

/-- A quadratic form on coordinate basis vectors is the corresponding matrix
entry. -/
@[simp]
theorem basis_matrix_element
    {ι : Type*} [Fintype ι] [DecidableEq ι]
    (M : CMatrix ι) (i j : ι) :
    dotProduct (star (coordinateBasisVector i))
        (M.mulVec (coordinateBasisVector j)) = M i j := by
  simp [coordinateBasisVector, dotProduct, Matrix.mulVec, Pi.single_apply]

/-- Exact expansion of a quadratic form on a two-coordinate vector. -/
theorem matrixQuadratic_twoPoint
    {ι : Type*} [Fintype ι] [DecidableEq ι]
    (M : CMatrix ι) (i j : ι) (a b : ℂ) :
    matrixQuadratic M (twoPointVector i j a b) =
      star a * M i i * a + star a * M i j * b +
      star b * M j i * a + star b * M j j * b := by
  simp [matrixQuadratic, twoPointVector, Matrix.mulVec_add,
    Matrix.mulVec_smul, add_dotProduct, dotProduct_add,
    smul_dotProduct, dotProduct_smul]
  ring

/-- The unnormalized multiplicity antisymmetric test, supported on +- and -+.
Its quadratic form equals twice that of the normalized vector in the paper. -/
def singlePPTTestVector
    {ra rb : Type*} [DecidableEq ra] [DecidableEq rb]
    (u : ra × rb) :
    (LocalMultiplicitySector × (ra × rb)) → ℂ :=
  twoPointVector (sectorPM, u) (sectorMP, u) 1 (-1)

/-- Equation eq:resource_block_partial_transpose_expansion specialized to the
single-vector PPT test. -/
theorem singlePPTTestVector_quadratic
    {ra rb : Type*}
    [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]
    (K : CMatrix (LocalMultiplicitySector × (ra × rb))) (u : ra × rb) :
    matrixQuadratic (sectorResourcePartialTransposeB K)
        (singlePPTTestVector u) =
      resourceSectorBlock K sectorPM sectorPM u u +
      resourceSectorBlock K sectorMP sectorMP u u -
      resourceSectorBlock K sectorPP sectorMM u u -
      resourceSectorBlock K sectorMM sectorPP u u := by
  unfold singlePPTTestVector
  rw [matrixQuadratic_twoPoint]
  rcases u with ⟨a, b⟩
  simp [sectorPP, sectorPM, sectorMP, sectorMM, resourceSectorBlock]
  ring

/-- The unnormalized Bell-sign resource vector |a0,b1> + sign |a1,b0>.
For sign equal to plus or minus one, its quadratic form is twice the normalized
Bell-state form. -/
def resourceBellSignVector
    {ra rb : Type*} [DecidableEq ra] [DecidableEq rb]
    (sign : ℂ) (a0 a1 : ra) (b0 b1 : rb) : (ra × rb) → ℂ :=
  twoPointVector (a0, b1) (a1, b0) 1 sign

/-- Resource partial transpose turns the Bell off-diagonal entries into the
00/11 coherence entries. -/
theorem resourceBellSignVector_partialTransposeB_quadratic
    {ra rb : Type*}
    [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]
    (X : CMatrix (ra × rb)) (sign : ℂ)
    (hsign : star sign = sign) (hsq : sign * sign = 1)
    (a0 a1 : ra) (b0 b1 : rb) :
    matrixQuadratic (QIT.partialTransposeB X)
        (resourceBellSignVector sign a0 a1 b0 b1) =
      X (a0, b1) (a0, b1) + X (a1, b0) (a1, b0) +
      sign * X (a0, b0) (a1, b1) +
      sign * X (a1, b1) (a0, b0) := by
  unfold resourceBellSignVector
  rw [matrixQuadratic_twoPoint]
  simp [hsign]
  have hlast :
      sign * X (a1, b0) (a1, b0) * sign = X (a1, b0) (a1, b0) := by
    calc
      sign * X (a1, b0) (a1, b0) * sign =
          (sign * sign) * X (a1, b0) (a1, b0) := by ring
      _ = X (a1, b0) (a1, b0) := by rw [hsq]; simp
  rw [hlast]
  ring

/-- A four-coordinate vector used to expand the pairwise PPT tests without
square roots. -/
def fourPointVector {ι : Type*} [DecidableEq ι]
    (i j k l : ι) (a b c d : ℂ) : ι → ℂ :=
  a • coordinateBasisVector i + b • coordinateBasisVector j +
  c • coordinateBasisVector k + d • coordinateBasisVector l

/-- Product of the two unnormalized plus-sign test vectors. -/
def pairPPTTestVectorPlus
    {ra rb : Type*} [DecidableEq ra] [DecidableEq rb]
    (a0 a1 : ra) (b0 b1 : rb) :
    (LocalMultiplicitySector × (ra × rb)) → ℂ :=
  fourPointVector
    (sectorPM, (a0, b1)) (sectorPM, (a1, b0))
    (sectorMP, (a0, b1)) (sectorMP, (a1, b0))
    1 1 1 1

/-- Product of the two unnormalized minus-sign test vectors. -/
def pairPPTTestVectorMinus
    {ra rb : Type*} [DecidableEq ra] [DecidableEq rb]
    (a0 a1 : ra) (b0 b1 : rb) :
    (LocalMultiplicitySector × (ra × rb)) → ℂ :=
  fourPointVector
    (sectorPM, (a0, b1)) (sectorPM, (a1, b0))
    (sectorMP, (a0, b1)) (sectorMP, (a1, b0))
    1 (-1) (-1) 1

/-- Sum of the two pairwise success-test quadratic forms.  This is the sparse
coordinate version of equations eq:pairwise_ppt_single_sign_quadratic_form and
eq:bell_resource_partial_transpose_sign_sums. -/
theorem pairPPTTestVectors_quadratic_sum
    {ra rb : Type*}
    [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]
    (K : CMatrix (LocalMultiplicitySector × (ra × rb)))
    (a0 a1 : ra) (b0 b1 : rb) :
    matrixQuadratic (sectorResourcePartialTransposeB K)
          (pairPPTTestVectorPlus a0 a1 b0 b1) +
        matrixQuadratic (sectorResourcePartialTransposeB K)
          (pairPPTTestVectorMinus a0 a1 b0 b1) =
      2 * (
        (resourceSectorBlock K sectorPM sectorPM +
            resourceSectorBlock K sectorMP sectorMP)
          (a0, b1) (a0, b1) +
        (resourceSectorBlock K sectorPM sectorPM +
            resourceSectorBlock K sectorMP sectorMP)
          (a1, b0) (a1, b0) +
        (resourceSectorBlock K sectorPP sectorMM +
            resourceSectorBlock K sectorMM sectorPP)
          (a0, b0) (a1, b1) +
        (resourceSectorBlock K sectorPP sectorMM +
            resourceSectorBlock K sectorMM sectorPP)
          (a1, b1) (a0, b0)) := by
  simp [pairPPTTestVectorPlus, pairPPTTestVectorMinus, fourPointVector,
    matrixQuadratic, Matrix.mulVec_add,
    Matrix.mulVec_neg, add_dotProduct, dotProduct_add,
    neg_dotProduct, dotProduct_neg,
    sectorPP, sectorPM, sectorMP, sectorMM, resourceSectorBlock]
  ring

end

end EntanglementPurification
