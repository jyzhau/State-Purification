import EntanglementPurification.PhysicalBranchOutputTrace
import EntanglementPurification.JointContractionSchur
import QIT.States.Schatten

/-!
# Local-unitary invariance after tracing out the physical outputs

The physical branch representation acts on each local three-leg space as
`bar U ⊗ bar U ⊗ U`.  After tracing out the two output legs `A' B'`, the
ordinary output actions `U ⊗ V` disappear and the remaining matrix is exactly
invariant under the product two-copy input action

`(bar U ⊗ bar U) ⊗ (bar V ⊗ bar V) ⊗ I_R`.

No positivity assumption is used in this file.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b r : Type*}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

/-- The product two-copy input representation left after tracing out `A' B'`:
`(bar U ⊗ bar U) ⊗ (bar V ⊗ bar V) ⊗ I_R`. -/
def outputInputProductTwoCopyRepresentation
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    CMatrix (JointContractionInputResourceIndex a b r) :=
  Matrix.kronecker
    (Matrix.kronecker
      (Matrix.kronecker
        (localEntrywiseConjugate U)
        (localEntrywiseConjugate U))
      (Matrix.kronecker
        (localEntrywiseConjugate V)
        (localEntrywiseConjugate V)))
    (1 : CMatrix r)

/-- Exact product-local-unitary invariance predicate for a physical branch
after its two output registers have been traced out. -/
def IsOutputInputProductTwoCopyInvariant
    (T : CMatrix (JointContractionInputResourceIndex a b r)) : Prop :=
  ∀ (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ),
    outputInputProductTwoCopyRepresentation (r := r) U V * T *
        Matrix.conjTranspose
          (outputInputProductTwoCopyRepresentation (r := r) U V) =
      T

/-- After regrouping the physical index into input/resource and output
factors, the physical representation factors exactly as the retained
two-copy representation tensored with `U ⊗ V` on `A' B'`. -/
theorem reindex_jointContractionPhysicalRepresentation_outputGrouping
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    (Matrix.reindexAlgEquiv ℂ ℂ
      (jointPhysicalOutputGroupingEquiv (a := a) (b := b) (r := r)))
        (jointContractionPhysicalRepresentation (r := r) U V) =
      Matrix.kronecker
        (outputInputProductTwoCopyRepresentation (r := r) U V)
        (Matrix.kronecker (U : CMatrix a) (V : CMatrix b)) := by
  ext p q
  rcases p with ⟨⟨⟨⟨iA₁, iA₂⟩, ⟨iB₁, iB₂⟩⟩, u⟩, ⟨iAout, iBout⟩⟩
  rcases q with ⟨⟨⟨⟨kA₁, kA₂⟩, ⟨kB₁, kB₂⟩⟩, v⟩, ⟨kAout, kBout⟩⟩
  simp [Matrix.reindexAlgEquiv_apply, Matrix.reindex_apply,
    jointPhysicalOutputGroupingEquiv,
    jointContractionPhysicalRepresentation,
    outputInputProductTwoCopyRepresentation,
    localMixedSchurRepresentation, Matrix.kronecker, Matrix.one_apply]
  ring_nf

/-- The retained two-copy representation, bundled as a unitary matrix. -/
private def outputInputProductTwoCopyUnitary
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    Matrix.unitaryGroup (JointContractionInputResourceIndex a b r) ℂ := by
  let hU : localEntrywiseConjugate U ∈ Matrix.unitaryGroup a ℂ := by
    change (↑(Matrix.UnitaryGroup.map_star U) : CMatrix a) ∈
      Matrix.unitaryGroup a ℂ
    exact SetLike.coe_mem (Matrix.UnitaryGroup.map_star U)
  let hV : localEntrywiseConjugate V ∈ Matrix.unitaryGroup b ℂ := by
    change (↑(Matrix.UnitaryGroup.map_star V) : CMatrix b) ∈
      Matrix.unitaryGroup b ℂ
    exact SetLike.coe_mem (Matrix.UnitaryGroup.map_star V)
  let hOne : (1 : CMatrix r) ∈ Matrix.unitaryGroup r ℂ :=
    SetLike.coe_mem (1 : Matrix.unitaryGroup r ℂ)
  exact ⟨outputInputProductTwoCopyRepresentation (r := r) U V,
    Matrix.kronecker_mem_unitary
      (Matrix.kronecker_mem_unitary
        (Matrix.kronecker_mem_unitary hU hU)
        (Matrix.kronecker_mem_unitary hV hV))
      hOne⟩

/-- The discarded-output action `U ⊗ V`, bundled as a unitary matrix. -/
private def physicalOutputProductUnitary
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    Matrix.unitaryGroup (a × b) ℂ :=
  ⟨Matrix.kronecker (U : CMatrix a) (V : CMatrix b),
    Matrix.kronecker_mem_unitary (SetLike.coe_mem U) (SetLike.coe_mem V)⟩

/-- Physical branch invariance descends through `Tr_{A'B'}` to exact
product two-copy input invariance.  This is the representation-theoretic
input needed by the four output-trace sector decomposition. -/
theorem physicalBranchOutputTrace_isOutputInputProductTwoCopyInvariant
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K) :
    IsOutputInputProductTwoCopyInvariant (physicalBranchOutputTrace K) := by
  intro U V
  let e := jointPhysicalOutputGroupingEquiv (a := a) (b := b) (r := r)
  let E := Matrix.reindexAlgEquiv ℂ ℂ e
  let X : CMatrix
      (JointContractionInputResourceIndex a b r × (a × b)) := E K
  let P := outputInputProductTwoCopyRepresentation (r := r) U V
  let Q := Matrix.kronecker (U : CMatrix a) (V : CMatrix b)
  let Punit := outputInputProductTwoCopyUnitary (r := r) U V
  let Qunit := physicalOutputProductUnitary U V
  have hGrouped :
      Matrix.kronecker P Q * X *
          Matrix.conjTranspose (Matrix.kronecker P Q) = X := by
    have h := congrArg E (hInvariant U V)
    have hFactor :=
      reindex_jointContractionPhysicalRepresentation_outputGrouping
        (r := r) U V
    change E
        (jointContractionPhysicalRepresentation (r := r) U V * K *
          Matrix.conjTranspose
            (jointContractionPhysicalRepresentation (r := r) U V)) =
      E K at h
    simp only [map_mul] at h
    change
      E (jointContractionPhysicalRepresentation (r := r) U V) * X *
          E (Matrix.conjTranspose
            (jointContractionPhysicalRepresentation (r := r) U V)) =
        X at h
    have hAdjoint :
        E (Matrix.conjTranspose
            (jointContractionPhysicalRepresentation (r := r) U V)) =
          Matrix.conjTranspose
            (E (jointContractionPhysicalRepresentation (r := r) U V)) := by
      rfl
    rw [hAdjoint, hFactor] at h
    exact h
  have hPunit : (↑Punit : CMatrix
      (JointContractionInputResourceIndex a b r)) = P := by
    rfl
  have hQunit : (↑Qunit : CMatrix (a × b)) = Q := by
    rfl
  have hPunitInv :
      (↑(Punit⁻¹) : CMatrix
          (JointContractionInputResourceIndex a b r)) =
        Matrix.conjTranspose P := by
    simp [hPunit, Matrix.star_eq_conjTranspose]
  have hQunitInv :
      (↑(Qunit⁻¹) : CMatrix (a × b)) =
        Matrix.conjTranspose Q := by
    simp [hQunit, Matrix.star_eq_conjTranspose]
  have hTrace := QIT.partialTraceB_local_unitary_conj
    (a := JointContractionInputResourceIndex a b r) (b := a × b)
    X Punit⁻¹ Qunit⁻¹
  rw [hPunitInv, hQunitInv] at hTrace
  simp only [Matrix.star_eq_conjTranspose,
    Matrix.conjTranspose_conjTranspose] at hTrace
  have hRight :
      Matrix.kronecker (Matrix.conjTranspose P)
          (Matrix.conjTranspose Q) =
        Matrix.conjTranspose (Matrix.kronecker P Q) := by
    ext ⟨i, j⟩ ⟨k, l⟩
    simp [Matrix.conjTranspose_apply, Matrix.kronecker,
      Matrix.kroneckerMap_apply]
  have hLeft :
      Matrix.conjTranspose
          (Matrix.kronecker (Matrix.conjTranspose P)
            (Matrix.conjTranspose Q)) =
        Matrix.kronecker P Q := by
    rw [hRight, Matrix.conjTranspose_conjTranspose]
  rw [hLeft, hRight, hGrouped] at hTrace
  change P * QIT.partialTraceB X * Matrix.conjTranspose P =
    QIT.partialTraceB X
  exact hTrace.symm

/-- Because entrywise conjugation is an involution on the unitary group, the
preceding predicate also gives invariance under the ordinary product action
`(U ⊗ U) ⊗ (V ⊗ V) ⊗ I_R`. -/
theorem IsOutputInputProductTwoCopyInvariant.ordinary
    {T : CMatrix (JointContractionInputResourceIndex a b r)}
    (hT : IsOutputInputProductTwoCopyInvariant T)
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    Matrix.kronecker
        (Matrix.kronecker
          (Matrix.kronecker (U : CMatrix a) (U : CMatrix a))
          (Matrix.kronecker (V : CMatrix b) (V : CMatrix b)))
        (1 : CMatrix r) * T *
      Matrix.conjTranspose
        (Matrix.kronecker
          (Matrix.kronecker
            (Matrix.kronecker (U : CMatrix a) (U : CMatrix a))
            (Matrix.kronecker (V : CMatrix b) (V : CMatrix b)))
          (1 : CMatrix r)) =
      T := by
  simpa [outputInputProductTwoCopyRepresentation] using
    hT (Matrix.UnitaryGroup.map_star U) (Matrix.UnitaryGroup.map_star V)

end

end EntanglementPurification
