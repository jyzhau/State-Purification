import EntanglementPurification.PhysicalOperationalEq986
import EntanglementPurification.ShannonCollisionBound
import EntanglementPurification.ShannonCollisionEquality
import EntanglementPurification.SchmidtEntropyBridge

/-!
# Operational one-ebit entropy converse

Exact operational attainment by the Appendix's signed Schmidt-coordinate
resource forces at least one bit of Shannon entropy.  The second endpoint uses
the separately verified marginal-spectrum bridge, so its conclusion is the
actual Lean-QIT pure-state entanglement entropy rather than merely an auxiliary
function of the Schmidt probabilities.
-/

namespace EntanglementPurification

open QIT

noncomputable section

/-- Exact operational attainment forces at least one bit of collision
entropy `H₂` in the resource's ordered Schmidt spectrum. -/
theorem physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_one_le_collisionEntropyBits
    {d m : ℕ}
    (M : PhysicalPPTInstrument
      (Fin d) (Fin d) (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le (ambientSignedSchmidtResource p hp) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) :
    1 ≤ collisionEntropyBits p := by
  apply
    one_le_collisionEntropyBits_of_orderedProbability_of_collisionProbability_le_half hp
  exact
    physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_collisionProbability_le_half
      M hd nu hgamma0 hgamma1 p hp hattains

/-- Exact operational attainment forces at least one bit of Shannon entropy
in the resource's ordered Schmidt spectrum. -/
theorem physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_one_le_shannonEntropyBits
    {d m : ℕ}
    (M : PhysicalPPTInstrument
      (Fin d) (Fin d) (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le (ambientSignedSchmidtResource p hp) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) :
    1 ≤ shannonEntropyBits p := by
  apply
    one_le_shannonEntropyBits_of_orderedProbability_of_collisionProbability_le_half hp
  exact
    physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_collisionProbability_le_half
      M hd nu hgamma0 hgamma1 p hp hattains

/-- Paper-facing one-ebit necessity endpoint: exact operational attainment
forces the assisting pure state's actual entanglement entropy to be at least
one bit. -/
theorem physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_one_le_entanglementEntropy
    {d m : ℕ}
    (M : PhysicalPPTInstrument
      (Fin d) (Fin d) (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le (ambientSignedSchmidtResource p hp) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) :
    1 ≤ (ambientSignedSchmidtResource p hp).entanglementEntropy := by
  rw [ambientSignedSchmidtResource_entanglementEntropy]
  simpa [shannonEntropyBits] using
    physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_one_le_shannonEntropyBits
      M hd nu hgamma0 hgamma1 p hp hattains

/-- Equality rigidity at the one-ebit threshold: if an exactly attaining
signed-Schmidt resource has entanglement entropy exactly one, then its ordered
Schmidt spectrum is precisely `(1/2, 1/2, 0, ...)`. -/
theorem physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_entanglementEntropy_eq_one_implies_twoPointSchmidtSpectrum
    {d m : ℕ}
    (M : PhysicalPPTInstrument
      (Fin d) (Fin d) (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le (ambientSignedSchmidtResource p hp) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma)
    (hentropy :
      (ambientSignedSchmidtResource p hp).entanglementEntropy = 1) :
    p = twoPointComparison (m + 1) := by
  apply
    orderedProbability_eq_twoPoint_of_collision_le_half_of_shannon_eq_one hp
  · exact
      physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_collisionProbability_le_half
        M hd nu hgamma0 hgamma1 p hp hattains
  · rw [ambientSignedSchmidtResource_entanglementEntropy] at hentropy
    simpa [shannonEntropyBits] using hentropy

/-- Quantitative strictness on the large-head branch: an exactly attaining
signed-Schmidt resource whose largest Schmidt weight is strictly larger than
one half has strictly more than one ebit of entanglement.  This consequence
uses the already verified Shannon--collision equality rigidity and therefore
does not depend on a separate general Karamata theorem. -/
theorem physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_one_lt_entanglementEntropy_of_head_gt_half
    {d m : ℕ}
    (M : PhysicalPPTInstrument
      (Fin d) (Fin d) (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le (ambientSignedSchmidtResource p hp) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma)
    (hhead : (1 / 2 : ℝ) < p 0) :
    1 < (ambientSignedSchmidtResource p hp).entanglementEntropy := by
  have hlower :
      1 ≤ (ambientSignedSchmidtResource p hp).entanglementEntropy :=
    physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_one_le_entanglementEntropy
      M hd nu hgamma0 hgamma1 p hp hattains
  by_contra hnot
  have hupper :
      (ambientSignedSchmidtResource p hp).entanglementEntropy ≤ 1 :=
    le_of_not_gt hnot
  have heq :
      (ambientSignedSchmidtResource p hp).entanglementEntropy = 1 :=
    le_antisymm hupper hlower
  have hspectrum :=
    physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_entanglementEntropy_eq_one_implies_twoPointSchmidtSpectrum
      M hd nu hgamma0 hgamma1 p hp hattains heq
  have hzero := congrFun hspectrum (0 : Fin (m + 3))
  simp [twoPointComparison] at hzero
  linarith

end

end EntanglementPurification
