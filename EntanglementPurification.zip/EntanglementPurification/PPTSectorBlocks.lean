import EntanglementPurification.ResourceInsertion
import EntanglementPurification.ResourceProjection

/-!
# Four local multiplicity sectors with a resource register

This is the finite matrix layer used by the local mixed-Schur/PPT argument in
main.tex.  It deliberately models only the four sectors needed in this paper:
++,+-,-+,--.  The representation-theoretic reduction from physical branches
to these blocks is proved separately.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

/-- Symmetric/antisymmetric local contraction label. -/
inductive LocalParity where
  | plus
  | minus
deriving DecidableEq, Fintype, Repr

/-- Explicit sum over the two local parity labels. -/
theorem sum_localParity (f : LocalParity → ℂ) :
    (∑ x : LocalParity, f x) = f .plus + f .minus := by
  rw [show (Finset.univ : Finset LocalParity) = {.plus, .minus} by
    ext x
    cases x <;> simp]
  simp

/-- Alice and Bob local contraction labels, ordered as a pair. -/
abbrev LocalMultiplicitySector := LocalParity × LocalParity

def sectorPP : LocalMultiplicitySector := (.plus, .plus)
def sectorPM : LocalMultiplicitySector := (.plus, .minus)
def sectorMP : LocalMultiplicitySector := (.minus, .plus)
def sectorMM : LocalMultiplicitySector := (.minus, .minus)

variable {r : Type*} [Fintype r] [DecidableEq r]

/-- The resource-valued (z,w) block of a four-sector matrix. -/
def resourceSectorBlock
    (K : CMatrix (LocalMultiplicitySector × r))
    (z w : LocalMultiplicitySector) : CMatrix r :=
  fun i j => K (z, i) (w, j)

/-- A diagonal resource block of a PSD sector matrix is PSD. -/
theorem resourceSectorBlock_diag_posSemidef
    {K : CMatrix (LocalMultiplicitySector × r)}
    (hK : K.PosSemidef) (z : LocalMultiplicitySector) :
    (resourceSectorBlock K z z).PosSemidef := by
  simpa [resourceSectorBlock, Matrix.submatrix] using
    hK.submatrix (fun i : r => (z, i))

/-- Embed a multiplicity vector with a fixed resource vector. -/
def sectorResourceEmbedding (eta : r → ℂ) :
    Matrix (LocalMultiplicitySector × r) LocalMultiplicitySector ℂ :=
  fun p z => if p.1 = z then eta p.2 else 0

/-- Product vector w tensor eta in the sector/resource coordinates. -/
def sectorResourceProductVector
    (w : LocalMultiplicitySector → ℂ) (eta : r → ℂ) :
    LocalMultiplicitySector × r → ℂ :=
  fun p => w p.1 * eta p.2

/-- The resource embedding sends a multiplicity vector to its product with the
resource vector. -/
theorem sectorResourceEmbedding_mulVec
    (eta : r → ℂ) (w : LocalMultiplicitySector → ℂ) :
    Matrix.mulVec (sectorResourceEmbedding eta) w =
      sectorResourceProductVector w eta := by
  funext p
  simp [Matrix.mulVec, dotProduct, sectorResourceEmbedding,
    sectorResourceProductVector, mul_comm]

/-- Insert the resource vector into a four-sector matrix. -/
def insertPureResourceBlock (eta : r → ℂ)
    (K : CMatrix (LocalMultiplicitySector × r)) :
    CMatrix LocalMultiplicitySector :=
  Matrix.conjTranspose (sectorResourceEmbedding eta) * K *
    sectorResourceEmbedding eta

/-- Resource insertion preserves every multiplicity quadratic form: the
inserted form on w is the original form on w tensor eta. -/
theorem insertPureResourceBlock_quadratic
    (eta : r → ℂ) (K : CMatrix (LocalMultiplicitySector × r))
    (w : LocalMultiplicitySector → ℂ) :
    dotProduct (star w)
        (Matrix.mulVec (insertPureResourceBlock eta K) w) =
      dotProduct (star (sectorResourceProductVector w eta))
        (Matrix.mulVec K (sectorResourceProductVector w eta)) := by
  rw [insertPureResourceBlock]
  rw [← Matrix.mulVec_mulVec]
  rw [← Matrix.mulVec_mulVec]
  rw [Matrix.dotProduct_mulVec]
  rw [← Matrix.star_mulVec]
  rw [sectorResourceEmbedding_mulVec]

/-- If an inserted multiplicity quadratic form vanishes, positivity of the
uninserted matrix forces the corresponding product vector into its kernel. -/
theorem psd_inserted_quadratic_zero_product_kernel
    {K : CMatrix (LocalMultiplicitySector × r)} (hK : K.PosSemidef)
    (eta : r → ℂ) (w : LocalMultiplicitySector → ℂ)
    (hzero :
      dotProduct (star w)
        (Matrix.mulVec (insertPureResourceBlock eta K) w) = 0) :
    Matrix.mulVec K (sectorResourceProductVector w eta) = 0 := by
  apply (hK.dotProduct_mulVec_zero_iff
    (sectorResourceProductVector w eta)).mp
  rw [← insertPureResourceBlock_quadratic]
  exact hzero

/-- Entrywise resource sandwich of a sector block. -/
theorem insertPureResourceBlock_apply
    (eta : r → ℂ) (K : CMatrix (LocalMultiplicitySector × r))
    (z w : LocalMultiplicitySector) :
    insertPureResourceBlock eta K z w =
      ∑ i : r, ∑ j : r,
        star (eta i) * resourceSectorBlock K z w i j * eta j := by
  simp [insertPureResourceBlock, sectorResourceEmbedding,
    resourceSectorBlock, Matrix.mul_apply, Matrix.conjTranspose_apply,
    Fintype.sum_prod_type, apply_ite, Finset.sum_mul]
  rw [Finset.sum_comm]

/-- Resource insertion preserves PSD at the four-sector level. -/
theorem insertPureResourceBlock_posSemidef
    (eta : r → ℂ) {K : CMatrix (LocalMultiplicitySector × r)}
    (hK : K.PosSemidef) :
    (insertPureResourceBlock eta K).PosSemidef := by
  simpa [insertPureResourceBlock] using
    hK.conjTranspose_mul_mul_same (sectorResourceEmbedding eta)

/-- The inserted diagonal entry is the usual PSD quadratic form of the
corresponding resource block. -/
theorem insertPureResourceBlock_diag_eq_dotProduct
    (eta : r → ℂ) (K : CMatrix (LocalMultiplicitySector × r))
    (z : LocalMultiplicitySector) :
    insertPureResourceBlock eta K z z =
      dotProduct (star eta)
        (Matrix.mulVec (resourceSectorBlock K z z) eta) := by
  rw [insertPureResourceBlock_apply]
  simp [dotProduct, Matrix.mulVec, Finset.mul_sum, mul_assoc]

/-- A resource vector supported in one multiplicity sector. -/
def sectorSupportedResourceVector
    (z : LocalMultiplicitySector) (eta : r → ℂ) :
    LocalMultiplicitySector × r → ℂ :=
  fun p => if p.1 = z then eta p.2 else 0

/-- The inserted diagonal entry is also the quadratic form of the full sector
matrix on the corresponding supported vector. -/
theorem insertPureResourceBlock_diag_eq_supported_quadratic
    (eta : r → ℂ) (K : CMatrix (LocalMultiplicitySector × r))
    (z : LocalMultiplicitySector) :
    insertPureResourceBlock eta K z z =
      dotProduct (star (sectorSupportedResourceVector z eta))
        (Matrix.mulVec K (sectorSupportedResourceVector z eta)) := by
  rw [insertPureResourceBlock_apply]
  simp [dotProduct, Matrix.mulVec, sectorSupportedResourceVector,
    resourceSectorBlock, Fintype.sum_prod_type, apply_ite,
    Finset.mul_sum, mul_assoc]

/-- For a PSD sector matrix, a zero inserted diagonal entry places the whole
sector-supported resource vector in the kernel. -/
theorem psd_zero_inserted_diagonal_supported_kernel
    {K : CMatrix (LocalMultiplicitySector × r)} (hK : K.PosSemidef)
    (eta : r → ℂ) (z : LocalMultiplicitySector)
    (hzero : insertPureResourceBlock eta K z z = 0) :
    Matrix.mulVec K (sectorSupportedResourceVector z eta) = 0 := by
  apply (hK.dotProduct_mulVec_zero_iff
    (sectorSupportedResourceVector z eta)).mp
  rw [← insertPureResourceBlock_diag_eq_supported_quadratic]
  exact hzero

/-- Consequently every block in the column of a zero inserted diagonal
annihilates the inserted resource vector. -/
theorem resourceSectorBlock_mulVec_eq_zero_of_inserted_diag_eq_zero
    {K : CMatrix (LocalMultiplicitySector × r)} (hK : K.PosSemidef)
    (eta : r → ℂ) (z w : LocalMultiplicitySector)
    (hzero : insertPureResourceBlock eta K z z = 0) :
    Matrix.mulVec (resourceSectorBlock K w z) eta = 0 := by
  have hkernel :=
    psd_zero_inserted_diagonal_supported_kernel hK eta z hzero
  funext j
  have hj := congrFun hkernel (w, j)
  simpa [Matrix.mulVec, dotProduct, resourceSectorBlock,
    sectorSupportedResourceVector, Fintype.sum_prod_type, apply_ite] using hj

/-- Hermiticity exchanges the two resource-valued sector indices. -/
theorem resourceSectorBlock_conjTranspose
    {K : CMatrix (LocalMultiplicitySector × r)}
    (hK : K.IsHermitian) (z w : LocalMultiplicitySector) :
    Matrix.conjTranspose (resourceSectorBlock K z w) =
      resourceSectorBlock K w z := by
  ext i j
  have hij := congrFun (congrFun hK.eq (w, i)) (z, j)
  simpa [resourceSectorBlock, Matrix.conjTranspose_apply] using hij

/-- Saturating a PSD upper bound on a normalized vector forces an eigenvector
relation.  This is the kernel argument used for the ++ and -- diagonal blocks. -/
theorem psd_upper_saturation_mulVec
    (eta : r → ℂ) (heta : IsNormalizedResourceVector eta)
    {A : CMatrix r} {c : ℝ}
    (hupper : A ≤ c • (1 : CMatrix r))
    (hsat : dotProduct (star eta) (Matrix.mulVec A eta) = (c : ℂ)) :
    Matrix.mulVec A eta = (c : ℂ) • eta := by
  have hdiff : (c • (1 : CMatrix r) - A).PosSemidef :=
    Matrix.le_iff.mp hupper
  have hnorm : dotProduct (star eta) eta = 1 := by
    simpa [IsNormalizedResourceVector, dotProduct] using heta
  have hzero :
      dotProduct (star eta)
        (Matrix.mulVec (c • (1 : CMatrix r) - A) eta) = 0 := by
    simp [Matrix.sub_mulVec, Matrix.smul_mulVec, Matrix.one_mulVec,
      dotProduct_sub, dotProduct_smul, hnorm, hsat, Complex.real_smul]
  have hkernel := (hdiff.dotProduct_mulVec_zero_iff eta).mp hzero
  have hsub : (c : ℂ) • eta - Matrix.mulVec A eta = 0 := by
    simpa [Matrix.sub_mulVec, Matrix.smul_mulVec, Matrix.one_mulVec,
      Complex.real_smul] using hkernel
  exact (sub_eq_zero.mp hsub).symm

/-- The local contraction normalizations from main.tex. -/
def localContractionAlpha (d : ℕ) : ℝ := ((d : ℝ) + 1) / 2
def localContractionBeta (d : ℕ) : ℝ := ((d : ℝ) - 1) / 2

/-- The multiplicity vector v_d = alpha |++⟩ + beta |--⟩. -/
def localOptimalMultiplicityVector (d : ℕ) :
    LocalMultiplicitySector → ℂ
  | (.plus, .plus) => localContractionAlpha d
  | (.minus, .minus) => localContractionBeta d
  | _ => 0

/-- The multiplicity direction beta |++> - alpha |--> orthogonal to v_d. -/
def localOptimalOrthogonalMultiplicityVector (d : ℕ) :
    LocalMultiplicitySector → ℂ
  | (.plus, .plus) => localContractionBeta d
  | (.minus, .minus) => -(localContractionAlpha d)
  | _ => 0

/-- The two distinguished multiplicity directions are orthogonal. -/
theorem localOptimalMultiplicityVector_dot_orthogonal (d : ℕ) :
    dotProduct (star (localOptimalMultiplicityVector d))
      (localOptimalOrthogonalMultiplicityVector d) = 0 := by
  rw [dotProduct, Fintype.sum_prod_type, sum_localParity]
  simp_rw [sum_localParity]
  simp [localOptimalMultiplicityVector,
    localOptimalOrthogonalMultiplicityVector]
  ring

/-- Exact insertion of the standard rank-one block forces the orthogonal
multiplicity direction tensored with eta into the kernel of K. -/
theorem inserted_optimal_orthogonal_product_kernel
    (d : ℕ) (eta : r → ℂ)
    {K : CMatrix (LocalMultiplicitySector × r)} (hK : K.PosSemidef)
    (hinsert :
      insertPureResourceBlock eta K =
        rankOneMatrix (localOptimalMultiplicityVector d)) :
    Matrix.mulVec K
        (sectorResourceProductVector
          (localOptimalOrthogonalMultiplicityVector d) eta) = 0 := by
  apply psd_inserted_quadratic_zero_product_kernel hK eta
    (localOptimalOrthogonalMultiplicityVector d)
  rw [hinsert, rankOneMatrix_mulVec_eq_dotProduct_smul,
    localOptimalMultiplicityVector_dot_orthogonal]
  simp

/-- Coordinate expansion of K on the orthogonal product vector. -/
theorem mulVec_localOptimalOrthogonalProduct_apply
    (d : ℕ) (eta : r → ℂ)
    (K : CMatrix (LocalMultiplicitySector × r))
    (z : LocalMultiplicitySector) (i : r) :
    Matrix.mulVec K
        (sectorResourceProductVector
          (localOptimalOrthogonalMultiplicityVector d) eta) (z, i) =
      (localContractionBeta d : ℂ) *
          Matrix.mulVec (resourceSectorBlock K z sectorPP) eta i -
        (localContractionAlpha d : ℂ) *
          Matrix.mulVec (resourceSectorBlock K z sectorMM) eta i := by
  simp only [Matrix.mulVec, dotProduct]
  rw [Fintype.sum_prod_type, Fintype.sum_prod_type, sum_localParity]
  simp_rw [sum_localParity]
  simp [sectorResourceProductVector, resourceSectorBlock,
    localOptimalOrthogonalMultiplicityVector, sectorPP, sectorMM]
  rw [Finset.mul_sum, Finset.mul_sum]
  have hplus :
      (∑ x : r, K (z, i) ((.plus, .plus), x) *
          ((localContractionBeta d : ℂ) * eta x)) =
        ∑ x : r, (localContractionBeta d : ℂ) *
          (K (z, i) ((.plus, .plus), x) * eta x) := by
    apply Finset.sum_congr rfl
    intro x hx
    ring
  have hminus :
      (∑ x : r, K (z, i) ((.minus, .minus), x) *
          ((localContractionAlpha d : ℂ) * eta x)) =
        ∑ x : r, (localContractionAlpha d : ℂ) *
          (K (z, i) ((.minus, .minus), x) * eta x) := by
    apply Finset.sum_congr rfl
    intro x hx
    ring
  rw [hplus, hminus]
  rfl

/-- Projecting the orthogonal-kernel equation onto the ++ and -- rows gives
the two block relations used to fix the off-diagonal actions. -/
theorem inserted_optimal_kernel_projected_block_relations
    (d : ℕ) (eta : r → ℂ)
    {K : CMatrix (LocalMultiplicitySector × r)} (hK : K.PosSemidef)
    (hinsert :
      insertPureResourceBlock eta K =
        rankOneMatrix (localOptimalMultiplicityVector d)) :
    (localContractionBeta d : ℂ) •
          Matrix.mulVec (resourceSectorBlock K sectorPP sectorPP) eta -
        (localContractionAlpha d : ℂ) •
          Matrix.mulVec (resourceSectorBlock K sectorPP sectorMM) eta = 0 ∧
      (localContractionBeta d : ℂ) •
          Matrix.mulVec (resourceSectorBlock K sectorMM sectorPP) eta -
        (localContractionAlpha d : ℂ) •
          Matrix.mulVec (resourceSectorBlock K sectorMM sectorMM) eta = 0 := by
  have hkernel := inserted_optimal_orthogonal_product_kernel d eta hK hinsert
  constructor <;> funext i
  · have hi := congrFun hkernel (sectorPP, i)
    rw [mulVec_localOptimalOrthogonalProduct_apply] at hi
    simpa [Pi.smul_apply] using hi
  · have hi := congrFun hkernel (sectorMM, i)
    rw [mulVec_localOptimalOrthogonalProduct_apply] at hi
    simpa [Pi.smul_apply] using hi

/-- The inserted standard block fixes all six entries used by the PPT effect
certificate. -/
theorem inserted_optimal_block_entries
    (d : ℕ) (eta : r → ℂ)
    (K : CMatrix (LocalMultiplicitySector × r))
    (hinsert :
      insertPureResourceBlock eta K =
        rankOneMatrix (localOptimalMultiplicityVector d)) :
    insertPureResourceBlock eta K sectorPP sectorPP =
        ((localContractionAlpha d) ^ 2 : ℂ) ∧
      insertPureResourceBlock eta K sectorPM sectorPM = 0 ∧
      insertPureResourceBlock eta K sectorMP sectorMP = 0 ∧
      insertPureResourceBlock eta K sectorMM sectorMM =
        ((localContractionBeta d) ^ 2 : ℂ) ∧
      insertPureResourceBlock eta K sectorPP sectorMM =
        ((localContractionAlpha d * localContractionBeta d : ℝ) : ℂ) ∧
      insertPureResourceBlock eta K sectorMM sectorPP =
        ((localContractionAlpha d * localContractionBeta d : ℝ) : ℂ) := by
  rw [hinsert]
  simp [rankOneMatrix_apply, localOptimalMultiplicityVector,
    sectorPP, sectorPM, sectorMP, sectorMM, pow_two, mul_comm]

/-- Exact insertion, together with the output-trace diagonal upper bounds,
forces the four diagonal resource blocks to act on eta exactly as in
eq:forced_diagonal_block_actions. -/
theorem inserted_optimal_forces_diagonal_block_actions
    (d : ℕ) (eta : r → ℂ) (heta : IsNormalizedResourceVector eta)
    {K : CMatrix (LocalMultiplicitySector × r)} (hK : K.PosSemidef)
    (hinsert :
      insertPureResourceBlock eta K =
        rankOneMatrix (localOptimalMultiplicityVector d))
    (hPPupper :
      resourceSectorBlock K sectorPP sectorPP ≤
        (localContractionAlpha d) ^ 2 • (1 : CMatrix r))
    (hMMupper :
      resourceSectorBlock K sectorMM sectorMM ≤
        (localContractionBeta d) ^ 2 • (1 : CMatrix r)) :
    Matrix.mulVec (resourceSectorBlock K sectorPM sectorPM) eta = 0 ∧
      Matrix.mulVec (resourceSectorBlock K sectorMP sectorMP) eta = 0 ∧
      Matrix.mulVec (resourceSectorBlock K sectorPP sectorPP) eta =
        (((localContractionAlpha d) ^ 2 : ℝ) : ℂ) • eta ∧
      Matrix.mulVec (resourceSectorBlock K sectorMM sectorMM) eta =
        (((localContractionBeta d) ^ 2 : ℝ) : ℂ) • eta := by
  rcases inserted_optimal_block_entries d eta K hinsert with
    ⟨hpp, hpm, hmp, hmm, hcross, hcross'⟩
  have hPMaction :=
    resourceSectorBlock_mulVec_eq_zero_of_inserted_diag_eq_zero
      hK eta sectorPM sectorPM hpm
  have hMPaction :=
    resourceSectorBlock_mulVec_eq_zero_of_inserted_diag_eq_zero
      hK eta sectorMP sectorMP hmp
  have hPPsat :
      dotProduct (star eta)
          (Matrix.mulVec (resourceSectorBlock K sectorPP sectorPP) eta) =
        (((localContractionAlpha d) ^ 2 : ℝ) : ℂ) := by
    rw [← insertPureResourceBlock_diag_eq_dotProduct]
    simpa using hpp
  have hMMsat :
      dotProduct (star eta)
          (Matrix.mulVec (resourceSectorBlock K sectorMM sectorMM) eta) =
        (((localContractionBeta d) ^ 2 : ℝ) : ℂ) := by
    rw [← insertPureResourceBlock_diag_eq_dotProduct]
    simpa using hmm
  exact ⟨hPMaction, hMPaction,
    psd_upper_saturation_mulVec eta heta hPPupper hPPsat,
    psd_upper_saturation_mulVec eta heta hMMupper hMMsat⟩

/-- Equation `eq:forced_offdiagonal_block_actions`.  Exact insertion and the
diagonal trace bounds first put the orthogonal multiplicity direction in the
kernel of `K`; since `d ≥ 2`, both local contraction constants are nonzero and
the two projected kernel equations can be cancelled. -/
theorem inserted_optimal_forces_off_diagonal_block_actions
    (d : ℕ) (hd : 2 ≤ d)
    (eta : r → ℂ) (heta : IsNormalizedResourceVector eta)
    {K : CMatrix (LocalMultiplicitySector × r)} (hK : K.PosSemidef)
    (hinsert : insertPureResourceBlock eta K =
      rankOneMatrix (localOptimalMultiplicityVector d))
    (hPPupper : resourceSectorBlock K sectorPP sectorPP ≤
      (localContractionAlpha d) ^ 2 • (1 : CMatrix r))
    (hMMupper : resourceSectorBlock K sectorMM sectorMM ≤
      (localContractionBeta d) ^ 2 • (1 : CMatrix r)) :
    Matrix.mulVec (resourceSectorBlock K sectorPP sectorMM) eta =
        (((localContractionAlpha d * localContractionBeta d : ℝ) : ℂ) • eta) ∧
      Matrix.mulVec (resourceSectorBlock K sectorMM sectorPP) eta =
        (((localContractionAlpha d * localContractionBeta d : ℝ) : ℂ) • eta) := by
  rcases inserted_optimal_forces_diagonal_block_actions
      d eta heta hK hinsert hPPupper hMMupper with
    ⟨_, _, hPPaction, hMMaction⟩
  rcases inserted_optimal_kernel_projected_block_relations
      d eta hK hinsert with
    ⟨hPPrelation, hMMrelation⟩
  have halphaR : 0 < localContractionAlpha d := by
    unfold localContractionAlpha
    positivity
  have hdR : (1 : ℝ) < (d : ℝ) := by exact_mod_cast hd
  have hbetaR : 0 < localContractionBeta d := by
    unfold localContractionBeta
    positivity
  have halphaC : (localContractionAlpha d : ℂ) ≠ 0 := by
    exact_mod_cast ne_of_gt halphaR
  have hbetaC : (localContractionBeta d : ℂ) ≠ 0 := by
    exact_mod_cast ne_of_gt hbetaR
  constructor
  · have heq :
        (localContractionAlpha d : ℂ) •
              Matrix.mulVec (resourceSectorBlock K sectorPP sectorMM) eta =
          (localContractionBeta d : ℂ) •
              ((((localContractionAlpha d) ^ 2 : ℝ) : ℂ) • eta) := by
      rw [hPPaction] at hPPrelation
      exact (sub_eq_zero.mp hPPrelation).symm
    apply smul_right_injective (r → ℂ) halphaC
    calc
      (localContractionAlpha d : ℂ) •
            Matrix.mulVec (resourceSectorBlock K sectorPP sectorMM) eta =
          (localContractionBeta d : ℂ) •
            ((((localContractionAlpha d) ^ 2 : ℝ) : ℂ) • eta) := heq
      _ = (localContractionAlpha d : ℂ) •
            (((localContractionAlpha d * localContractionBeta d : ℝ) : ℂ) • eta) := by
          simp only [smul_smul]
          congr 1
          push_cast
          ring
  · have heq :
        (localContractionBeta d : ℂ) •
              Matrix.mulVec (resourceSectorBlock K sectorMM sectorPP) eta =
          (localContractionAlpha d : ℂ) •
              ((((localContractionBeta d) ^ 2 : ℝ) : ℂ) • eta) := by
      rw [hMMaction] at hMMrelation
      exact sub_eq_zero.mp hMMrelation
    apply smul_right_injective (r → ℂ) hbetaC
    calc
      (localContractionBeta d : ℂ) •
            Matrix.mulVec (resourceSectorBlock K sectorMM sectorPP) eta =
          (localContractionAlpha d : ℂ) •
            ((((localContractionBeta d) ^ 2 : ℝ) : ℂ) • eta) := heq
      _ = (localContractionBeta d : ℂ) •
            (((localContractionAlpha d * localContractionBeta d : ℝ) : ℂ) • eta) := by
          simp only [smul_smul]
          congr 1
          push_cast
          ring

/-- Equation `eq:forced_offdiagonal_block_decompositions`.  Both cross blocks
split into their forced rank-one action on `eta` plus their compression to
`eta`'s orthogonal complement. -/
theorem inserted_optimal_forces_off_diagonal_block_decompositions
    (d : ℕ) (hd : 2 ≤ d) (eta : PureVector r)
    {K : CMatrix (LocalMultiplicitySector × r)} (hK : K.PosSemidef)
    (hinsert : insertPureResourceBlock eta.amp K =
      rankOneMatrix (localOptimalMultiplicityVector d))
    (hPPupper : resourceSectorBlock K sectorPP sectorPP ≤
      (localContractionAlpha d) ^ 2 • (1 : CMatrix r))
    (hMMupper : resourceSectorBlock K sectorMM sectorMM ≤
      (localContractionBeta d) ^ 2 • (1 : CMatrix r)) :
    resourceSectorBlock K sectorPP sectorMM =
        (((localContractionAlpha d * localContractionBeta d : ℝ) : ℂ) •
          rankOneMatrix eta.amp) +
        pureVectorPerpProjection eta *
          resourceSectorBlock K sectorPP sectorMM *
          pureVectorPerpProjection eta ∧
      resourceSectorBlock K sectorMM sectorPP =
        (((localContractionAlpha d * localContractionBeta d : ℝ) : ℂ) •
          rankOneMatrix eta.amp) +
        pureVectorPerpProjection eta *
          resourceSectorBlock K sectorMM sectorPP *
          pureVectorPerpProjection eta := by
  rcases inserted_optimal_forces_off_diagonal_block_actions
      d hd eta.amp
        (EntanglementPurification.PureVector.isNormalizedResourceVector eta)
        hK hinsert
        hPPupper hMMupper with ⟨hC, hCstar⟩
  have hAdjC :
      Matrix.conjTranspose (resourceSectorBlock K sectorPP sectorMM) =
        resourceSectorBlock K sectorMM sectorPP :=
    resourceSectorBlock_conjTranspose hK.isHermitian sectorPP sectorMM
  have hAdjCstar :
      Matrix.conjTranspose (resourceSectorBlock K sectorMM sectorPP) =
        resourceSectorBlock K sectorPP sectorMM :=
    resourceSectorBlock_conjTranspose hK.isHermitian sectorMM sectorPP
  constructor
  · apply matrix_eq_eigen_rankOne_add_perp_compression eta
      (resourceSectorBlock K sectorPP sectorMM)
      (localContractionAlpha d * localContractionBeta d) hC
    rw [hAdjC]
    exact hCstar
  · apply matrix_eq_eigen_rankOne_add_perp_compression eta
      (resourceSectorBlock K sectorMM sectorPP)
      (localContractionAlpha d * localContractionBeta d) hCstar
    rw [hAdjCstar]
    exact hC

end

end EntanglementPurification
