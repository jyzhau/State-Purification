import EntanglementPurification.GlobalOperationalStates
import EntanglementPurification.GlobalEq986Optimality
import EntanglementPurification.OperationalFidelityGain
import EntanglementPurification.PhysicalLocalTwirlObjective

/-!
# Operational meaning of the global equation-986 objective

This module connects the accepted, subnormalized pure-target fidelity gain to
the paper's pointwise equation-986 Choi objective.  The baseline is not inserted
as a precomputed scalar: it is definitionally the squared fidelity between the
Haar-orbit target state and its noisy single-copy input.  Only afterwards is
that state fidelity proved equal to `globalNoiseFidelity`.

The pointwise identity is then integrated against normalized unitary Haar
measure.  Finally, the existing finite-dimensional SDP theorem supplies the
paper-dimension upper bound and the exact equality condition.
-/

namespace EntanglementPurification

open QIT
open MeasureTheory
open scoped Matrix.Norms.L2Operator

noncomputable section

universe u

local instance globalOperationalEq986CMatrixContinuousENorm
    {i : Type u} [Fintype i] [DecidableEq i] : ContinuousENorm (CMatrix i) :=
  SeminormedAddGroup.toContinuousENorm

variable {x : Type u} [Fintype x] [DecidableEq x] [Nonempty x]

/-- Operational accepted gain at one Haar-orbit point.  Its baseline is
literally the target/noisy-input squared fidelity, rather than a scalar formula
substituted in advance. -/
def globalOperationalAcceptedGainAt
    (nu : PureVector x) (gamma : ℝ)
    (U : Matrix.unitaryGroup x ℂ)
    (hgamma0 : 0 ≤ gamma) (hgamma1 : gamma ≤ 1)
    (Phi : MatrixMap (x × x) x)
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) : ℝ :=
  acceptedPureTargetGain
    (globalDepolarizedOrbitPairState nu gamma U hgamma0 hgamma1)
    Phi hPhi
    (globalHaarOrbitPureVector nu U)
    ((globalHaarOrbitPureVector nu U).state.squaredFidelity
      (globalDepolarizedOrbitState nu gamma U hgamma0 hgamma1))

/-- The operational gain at a fixed Haar point is exactly the pointwise
equation-986 Choi objective. -/
theorem globalOperationalAcceptedGainAt_eq_globalSDPObjective
    (nu : PureVector x) (gamma : ℝ)
    (U : Matrix.unitaryGroup x ℂ)
    (hgamma0 : 0 ≤ gamma) (hgamma1 : gamma ≤ 1)
    (Phi : MatrixMap (x × x) x)
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) :
    globalOperationalAcceptedGainAt nu gamma U hgamma0 hgamma1 Phi hPhi =
      globalSDPObjective (globalEq986Integrand nu gamma U)
        (MatrixMap.choi Phi) := by
  rw [globalOperationalAcceptedGainAt,
    globalHaarOrbitPureVector_squaredFidelity_globalDepolarizedOrbitState,
    acceptedPureTargetGain_eq_globalSDPObjective_choi]
  simp only [globalDepolarizedOrbitPairState_matrix,
    globalHaarOrbitPureVector_state_matrix]
  rfl

/-- Haar-average of the operational accepted gain. -/
def globalOperationalAverageAcceptedGain
    (nu : PureVector x) (gamma : ℝ)
    (hgamma0 : 0 ≤ gamma) (hgamma1 : gamma ≤ 1)
    (Phi : MatrixMap (x × x) x)
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) : ℝ :=
  ∫ U : Matrix.unitaryGroup x ℂ,
    globalOperationalAcceptedGainAt nu gamma U hgamma0 hgamma1 Phi hPhi
      ∂unitaryHaarMeasure (a := x)

private noncomputable def globalSDPObjectiveCLM
    {i : Type u} [Fintype i] [DecidableEq i]
    (J : CMatrix i) : CMatrix i →L[ℝ] ℝ :=
  Complex.reCLM.comp (LinearMap.toContinuousLinearMap ({
    toFun := fun M : CMatrix i => (M * J).trace
    map_add' := by intro M N; simp [Matrix.add_mul, Matrix.trace_add]
    map_smul' := by intro c M; simp [Matrix.trace_smul]
  } : CMatrix i →ₗ[ℂ] ℂ))

private theorem globalSDPObjective_integral
    {α : Type*} [MeasurableSpace α] {μ : Measure α}
    {i : Type u} [Fintype i] [DecidableEq i]
    (J : CMatrix i) {f : α → CMatrix i} (hf : Integrable f μ) :
    globalSDPObjective (∫ z, f z ∂μ) J =
      ∫ z, globalSDPObjective (f z) J ∂μ := by
  simpa [globalSDPObjective, globalSDPObjectiveCLM] using
    ((globalSDPObjectiveCLM J).integral_comp_comm hf).symm

theorem globalOperationalAverageAcceptedGain_eq_globalSDPObjective
    (nu : PureVector x) (gamma : ℝ)
    (hgamma0 : 0 ≤ gamma) (hgamma1 : gamma ≤ 1)
    (Phi : MatrixMap (x × x) x)
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) :
    globalOperationalAverageAcceptedGain nu gamma hgamma0 hgamma1 Phi hPhi =
      globalSDPObjective (globalEq986PerformanceOperator nu gamma) (MatrixMap.choi Phi) := by
  unfold globalOperationalAverageAcceptedGain
  calc
    (∫ U : Matrix.unitaryGroup x ℂ,
        globalOperationalAcceptedGainAt nu gamma U hgamma0 hgamma1 Phi hPhi
          ∂unitaryHaarMeasure (a := x)) =
        ∫ U : Matrix.unitaryGroup x ℂ,
          globalSDPObjective (globalEq986Integrand nu gamma U) (MatrixMap.choi Phi)
            ∂unitaryHaarMeasure (a := x) := by
      apply integral_congr_ae
      filter_upwards [] with U
      exact globalOperationalAcceptedGainAt_eq_globalSDPObjective
        nu gamma U hgamma0 hgamma1 Phi hPhi
    _ = globalSDPObjective
          (∫ U : Matrix.unitaryGroup x ℂ,
            globalEq986Integrand nu gamma U ∂unitaryHaarMeasure (a := x))
          (MatrixMap.choi Phi) :=
      (globalSDPObjective_integral (MatrixMap.choi Phi)
        (globalEq986Integrand_integrable nu gamma)).symm
    _ = globalSDPObjective (globalEq986PerformanceOperator nu gamma)
          (MatrixMap.choi Phi) := rfl

def globalPaperOperationalAverageAcceptedGain
    {d : ℕ} (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d)) (gamma : ℝ)
    (hgamma0 : 0 ≤ gamma) (hgamma1 : gamma ≤ 1)
    (Phi : MatrixMap (GlobalPaperIndex d × GlobalPaperIndex d) (GlobalPaperIndex d))
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) : ℝ := by
  letI : Nonempty (GlobalPaperIndex d) := globalPaperIndexNonempty hd
  exact globalOperationalAverageAcceptedGain nu gamma hgamma0 hgamma1 Phi hPhi

theorem globalPaperOperationalAverageAcceptedGain_eq_globalSDPObjective
    {d : ℕ} (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d)) (gamma : ℝ)
    (hgamma0 : 0 ≤ gamma) (hgamma1 : gamma ≤ 1)
    (Phi : MatrixMap (GlobalPaperIndex d × GlobalPaperIndex d) (GlobalPaperIndex d))
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) :
    globalPaperOperationalAverageAcceptedGain hd nu gamma hgamma0 hgamma1 Phi hPhi =
      globalSDPObjective (globalPaperEq986PerformanceOperator hd nu gamma) (MatrixMap.choi Phi) := by
  letI : Nonempty (GlobalPaperIndex d) := globalPaperIndexNonempty hd
  exact globalOperationalAverageAcceptedGain_eq_globalSDPObjective nu gamma hgamma0 hgamma1 Phi hPhi

theorem globalPaperOperationalAverageAcceptedGain_le_globalOptimalGain
    {d : ℕ} (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d)) {gamma : ℝ}
    (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (Phi : MatrixMap (GlobalPaperIndex d × GlobalPaperIndex d) (GlobalPaperIndex d))
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) :
    globalPaperOperationalAverageAcceptedGain hd nu gamma hgamma0.le hgamma1.le Phi hPhi ≤
      globalOptimalGain ((d : ℝ) ^ 2) gamma := by
  rw [globalPaperOperationalAverageAcceptedGain_eq_globalSDPObjective]
  exact (globalPaperEq986_map_optimal_and_unique hd nu hgamma0 hgamma1).2.2.1 Phi hPhi

theorem globalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_iff
    {d : ℕ} (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d)) {gamma : ℝ}
    (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (Phi : MatrixMap (GlobalPaperIndex d × GlobalPaperIndex d) (GlobalPaperIndex d))
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) :
    (globalPaperOperationalAverageAcceptedGain hd nu gamma hgamma0.le hgamma1.le Phi hPhi =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) ↔
      Phi = MatrixMap.ofChoiMatrix (globalOptimalChoi (x := GlobalPaperIndex d)) := by
  rw [globalPaperOperationalAverageAcceptedGain_eq_globalSDPObjective]
  exact (globalPaperEq986_map_optimal_and_unique hd nu hgamma0 hgamma1).2.2.2 Phi hPhi

end

end EntanglementPurification
