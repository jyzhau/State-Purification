import EntanglementPurification.LocalContractionOutputTrace
import EntanglementPurification.OutputTraceSectors
import EntanglementPurification.PhysicalBranchOutputTrace

/-!
# Output trace of the joint contraction block

This module connects the normalized one-side contraction identities to the
physical joint branch.  The main elementary identity says that tracing the
two output legs of

`(W_s W_t†) ⊗ (W_u W_v†) ⊗ Y`

factorizes into the product of the two one-side output traces, tensored with
the untouched resource operator `Y`.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b r : Type*}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

/-- Tracing `A'B'` from a physical contraction matrix element factorizes into
the two local output traces and the unchanged resource matrix. -/
theorem physicalBranchOutputTrace_jointResourceContractionPhysicalElement
    (sA tA sB tB : LocalParity) (Y : CMatrix r) :
    physicalBranchOutputTrace
        (jointResourceContractionPhysicalElement
          (a := a) (b := b) sA tA sB tB Y) =
      Matrix.kronecker
        (Matrix.kronecker
          (QIT.partialTraceB (a := a × a) (b := a)
            (localWByParity sA *
              Matrix.conjTranspose (localWByParity tA)))
          (QIT.partialTraceB (a := b × b) (b := b)
            (localWByParity sB *
              Matrix.conjTranspose (localWByParity tB))))
        Y := by
  ext p q
  rcases p with ⟨⟨iA, iB⟩, u⟩
  rcases q with ⟨⟨kA, kB⟩, v⟩
  simp [jointResourceContractionPhysicalElement, Matrix.kronecker,
    QIT.partialTraceB, Matrix.mul_apply, Matrix.conjTranspose_apply,
    Finset.mul_sum, mul_comm, mul_left_comm]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro _ _
  rw [Finset.sum_comm]

/-- Every Schur-factorized contraction-coordinate operator is the finite sum
of its sixteen resource-valued parity matrix units. -/
theorem jointSchurKronecker_eq_sum_resourceElements
    (L : CMatrix (LocalMultiplicitySector × r)) :
    Matrix.kronecker L (1 : CMatrix (a × b)) =
      ∑ z : LocalMultiplicitySector, ∑ w : LocalMultiplicitySector,
        jointResourceContractionCoordinateElement
          (a := a) (b := b) z.1 w.1 z.2 w.2
          (resourceSectorBlock L z w) := by
  ext p q
  rcases p with ⟨⟨⟨sA, sB⟩, i⟩, ⟨u, v⟩⟩
  rcases q with ⟨⟨⟨tA, tB⟩, k⟩, ⟨w, x⟩⟩
  simp only [Fintype.sum_prod_type, sum_localParity,
    jointResourceContractionCoordinateElement_apply,
    resourceSectorBlock, Matrix.sum_apply]
  cases sA <;> cases sB <;> cases tA <;> cases tB <;>
    simp [Matrix.kronecker, Matrix.one_apply]

/-- Real one-side coefficient multiplying the input parity projector after
the output trace. -/
def localContractionOutputTraceRealScale
    (x : Type*) [Fintype x] (s : LocalParity) : ℝ :=
  match s with
  | .plus => 2 / ((Fintype.card x : ℝ) + 1)
  | .minus => 2 / ((Fintype.card x : ℝ) - 1)

/-- The complex-valued local coefficient used by the matrix identity is the
canonical complex embedding of its real Loewner-order scale. -/
theorem localContractionOutputTraceCoefficient_eq_realScale
    (s : LocalParity) :
    localContractionOutputTraceCoefficient (x := a) s =
      (localContractionOutputTraceRealScale a s : ℂ) := by
  cases s <;> rfl

/-- Product coefficient for a joint plus/minus sector. Alice and Bob are kept
at independent dimensions; the equal-dimension paper formula is a corollary
below. -/
def jointContractionOutputTraceRealScale
    (a b : Type*) [Fintype a] [Fintype b]
    (z : LocalMultiplicitySector) : ℝ :=
  localContractionOutputTraceRealScale a z.1 *
    localContractionOutputTraceRealScale b z.2

/-- Exact output trace of one physical contraction matrix unit. Both local
cross terms vanish, and a diagonal term lands in its matching product input
sector with the dimension-dependent real scale. -/
theorem physicalBranchOutputTrace_jointResourceContractionPhysicalElement_eq_sector
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (sA tA sB tB : LocalParity) (Y : CMatrix r) :
    physicalBranchOutputTrace
        (jointResourceContractionPhysicalElement
          (a := a) (b := b) sA tA sB tB Y) =
      if sA = tA ∧ sB = tB then
        (jointContractionOutputTraceRealScale a b (sA, sB)) •
          Matrix.kronecker
            (jointInputSectorProjector (a := a) (b := b) (sA, sB)) Y
      else 0 := by
  rw [physicalBranchOutputTrace_jointResourceContractionPhysicalElement]
  rw [partialTraceB_localWByParity_mul_conjTranspose sA tA
      (fun _ _ => hcardA),
    partialTraceB_localWByParity_mul_conjTranspose sB tB
      (fun _ _ => hcardB)]
  by_cases hA : sA = tA <;> by_cases hB : sB = tB
  · subst tA
    subst tB
    ext p q
    simp [jointContractionOutputTraceRealScale,
      jointInputSectorProjector,
      localContractionOutputTraceCoefficient_eq_realScale,
      Matrix.kronecker, Complex.real_smul, mul_comm,
      mul_left_comm]
  · simp [hA, hB, Matrix.kronecker]
  · simp [hA, hB, Matrix.kronecker]
  · simp [hA, hB, Matrix.kronecker]

/-- The physical output trace is additive. -/
theorem physicalBranchOutputTrace_add
    (K L : CMatrix (JointContractionPhysicalIndex a b r)) :
    physicalBranchOutputTrace (K + L) =
      physicalBranchOutputTrace K + physicalBranchOutputTrace L := by
  ext p q
  rcases p with ⟨⟨iA, iB⟩, u⟩
  rcases q with ⟨⟨kA, kB⟩, v⟩
  simp [physicalBranchOutputTrace_apply, Finset.sum_add_distrib]

/-- The contraction embedding is additive. -/
theorem jointContractionEmbedding_add
    (Q R : CMatrix (JointContractionCoordinateIndex a b r)) :
    jointContractionEmbedding (Q + R) =
      jointContractionEmbedding Q + jointContractionEmbedding R := by
  simp [jointContractionEmbedding, Matrix.mul_add, Matrix.add_mul]

/-- The physical output trace commutes with a finite sum. -/
theorem physicalBranchOutputTrace_sum
    {ι : Type*} [Fintype ι]
    (f : ι → CMatrix (JointContractionPhysicalIndex a b r)) :
    physicalBranchOutputTrace (∑ i, f i) =
      ∑ i, physicalBranchOutputTrace (f i) := by
  classical
  induction (Finset.univ : Finset ι) using Finset.induction_on with
  | empty =>
      ext p q
      rcases p with ⟨⟨iA, iB⟩, u⟩
      rcases q with ⟨⟨kA, kB⟩, v⟩
      simp [physicalBranchOutputTrace_apply]
  | @insert i s hi ih =>
      rw [Finset.sum_insert hi, Finset.sum_insert hi,
        physicalBranchOutputTrace_add, ih]

/-- The contraction embedding commutes with a finite sum. -/
theorem jointContractionEmbedding_sum
    {ι : Type*} [Fintype ι]
    (f : ι → CMatrix (JointContractionCoordinateIndex a b r)) :
    jointContractionEmbedding (∑ i, f i) =
      ∑ i, jointContractionEmbedding (f i) := by
  classical
  induction (Finset.univ : Finset ι) using Finset.induction_on with
  | empty => simp [jointContractionEmbedding]
  | @insert i s hi ih =>
      rw [Finset.sum_insert hi, Finset.sum_insert hi,
        jointContractionEmbedding_add, ih]

/-- Equation eq:local_contraction_output_trace_sector_expansion for an
arbitrary (possibly unequal-dimensional) Alice/Bob contraction coefficient.
Only diagonal multiplicity blocks survive the output trace. -/
theorem jointContractionEmbedding_schur_outputTrace_sectorExpansion
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (L : CMatrix (LocalMultiplicitySector × r)) :
    physicalBranchOutputTrace
        (jointContractionEmbedding
          (Matrix.kronecker L (1 : CMatrix (a × b)))) =
      ∑ z : LocalMultiplicitySector,
        (jointContractionOutputTraceRealScale a b z) •
          Matrix.kronecker
            (jointInputSectorProjector (a := a) (b := b) z)
            (resourceSectorBlock L z z) := by
  rw [jointSchurKronecker_eq_sum_resourceElements,
    jointContractionEmbedding_sum, physicalBranchOutputTrace_sum]
  simp_rw [jointContractionEmbedding_sum, physicalBranchOutputTrace_sum,
    jointContractionEmbedding_resourceElement,
    physicalBranchOutputTrace_jointResourceContractionPhysicalElement_eq_sector
      hcardA hcardB]
  apply Finset.sum_congr rfl
  intro z _
  rw [Finset.sum_eq_single z]
  · rcases z with ⟨sA, sB⟩
    simp
  · intro w _ hwz
    rcases z with ⟨sA, sB⟩
    rcases w with ⟨tA, tB⟩
    by_cases hA : sA = tA <;> by_cases hB : sB = tB <;>
      simp_all
  · simp

/-- Extracting one sector from the Schur-factorized contraction contribution
returns exactly the corresponding diagonal resource block multiplied by the
joint local output-trace scale. -/
theorem outputTraceSectorCoefficient_jointContractionEmbedding_schur
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (L : CMatrix (LocalMultiplicitySector × r))
    (z : LocalMultiplicitySector) :
    outputTraceSectorCoefficient
        (physicalBranchOutputTrace
          (jointContractionEmbedding
            (Matrix.kronecker L (1 : CMatrix (a × b))))) z =
      (jointContractionOutputTraceRealScale a b z) •
        resourceSectorBlock L z z := by
  rw [jointContractionEmbedding_schur_outputTrace_sectorExpansion
    hcardA hcardB, outputTraceSectorCoefficient_sum]
  simp_rw [show ∀ w : LocalMultiplicitySector,
      (jointContractionOutputTraceRealScale a b w) •
          Matrix.kronecker
            (jointInputSectorProjector (a := a) (b := b) w)
            (resourceSectorBlock L w w) =
        ((jointContractionOutputTraceRealScale a b w : ℂ)) •
          Matrix.kronecker
            (jointInputSectorProjector (a := a) (b := b) w)
            (resourceSectorBlock L w w) by
      intro w
      ext p q
      simp [Complex.real_smul]]
  simp_rw [outputTraceSectorCoefficient_smul]
  rw [Finset.sum_eq_single z]
  · rw [outputTraceSectorCoefficient_kronecker_self hcardA hcardB]
    ext i j
    simp [Complex.real_smul]
  · intro w _ hwz
    rw [outputTraceSectorCoefficient_kronecker_of_ne]
    · simp
    · exact Ne.symm hwz
  · simp

end

end EntanglementPurification
