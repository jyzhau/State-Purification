import QIT.Information.Entropy.Log2Lemmas
import Mathlib.Tactic

/-!
# An exact entropy counterexample

This file checks, without numerical approximation, the elementary properties
of the spectrum (2/3, 1/4, 1/12). Its collision probability is strictly
larger than 1/2, while its Shannon entropy is strictly larger than one bit.
-/

namespace EntanglementPurification

noncomputable section

/-- The spectrum (2/3, 1/4, 1/12) is nonnegative, nonincreasing, and sums
to one. -/
theorem exactEntropyCounterexample_isProbability :
    (0 : Real) ≤ 1 / 12 ∧
      (1 / 12 : Real) ≤ 1 / 4 ∧
      (1 / 4 : Real) ≤ 2 / 3 ∧
      (2 / 3 : Real) + 1 / 4 + 1 / 12 = 1 := by
  norm_num

/-- The collision probability (purity) is exactly 37/72. -/
theorem exactEntropyCounterexample_purity :
    (2 / 3 : Real) ^ 2 + (1 / 4 : Real) ^ 2 + (1 / 12 : Real) ^ 2 = 37 / 72 := by
  norm_num

/-- In particular, the spectrum purity is strictly larger than 1/2. -/
theorem exactEntropyCounterexample_purity_gt_half :
    (1 / 2 : Real) <
      (2 / 3 : Real) ^ 2 + (1 / 4 : Real) ^ 2 + (1 / 12 : Real) ^ 2 := by
  rw [exactEntropyCounterexample_purity]
  norm_num

/-- Exact evaluation of the Shannon entropy in bits. -/
theorem exactEntropyCounterexample_shannonEntropy :
    -((2 / 3 : Real) * QIT.log2 (2 / 3) +
        (1 / 4 : Real) * QIT.log2 (1 / 4) +
        (1 / 12 : Real) * QIT.log2 (1 / 12)) =
      (3 / 4 : Real) * QIT.log2 3 := by
  have hlogTwoThirds : QIT.log2 (2 / 3 : Real) = 1 - QIT.log2 3 := by
    rw [show (2 / 3 : Real) = 2 * (1 / 3) by ring]
    rw [QIT.log2_mul (by norm_num) (by norm_num), QIT.log2_one_div,
      QIT.log2_two]
    ring
  have hlogFour : QIT.log2 (4 : Real) = 2 := by
    rw [show (4 : Real) = 2 * 2 by norm_num,
      QIT.log2_mul (by norm_num) (by norm_num), QIT.log2_two]
    norm_num
  have hlogQuarter : QIT.log2 (1 / 4 : Real) = -2 := by
    rw [QIT.log2_one_div, hlogFour]
  have hlogTwelve : QIT.log2 (12 : Real) = QIT.log2 3 + 2 := by
    rw [show (12 : Real) = 3 * 4 by norm_num,
      QIT.log2_mul (by norm_num) (by norm_num), hlogFour]
  have hlogTwelfth : QIT.log2 (1 / 12 : Real) = -QIT.log2 3 - 2 := by
    rw [QIT.log2_one_div, hlogTwelve]
    ring
  rw [hlogTwoThirds, hlogQuarter, hlogTwelfth]
  ring

/-- The exact logarithmic inequality needed for the entropy bound follows
from the integer inequality 2^4 < 3^3. -/
theorem four_thirds_lt_log2_three :
    (4 / 3 : Real) < QIT.log2 3 := by
  have hlogPowers : Real.log ((2 : Real) ^ 4) < Real.log ((3 : Real) ^ 3) := by
    exact Real.log_lt_log (by positivity) (by norm_num)
  rw [Real.log_pow, Real.log_pow] at hlogPowers
  norm_num at hlogPowers
  have hlogTwoPos : 0 < Real.log 2 := Real.log_pos (by norm_num)
  unfold QIT.log2
  rw [lt_div_iff₀ hlogTwoPos]
  nlinarith

/-- The Shannon entropy is strictly larger than one bit. -/
theorem exactEntropyCounterexample_shannonEntropy_gt_one :
    (1 : Real) <
      -((2 / 3 : Real) * QIT.log2 (2 / 3) +
        (1 / 4 : Real) * QIT.log2 (1 / 4) +
        (1 / 12 : Real) * QIT.log2 (1 / 12)) := by
  rw [exactEntropyCounterexample_shannonEntropy]
  nlinarith [four_thirds_lt_log2_three]

end

end EntanglementPurification
