import EntanglementPurification.LocalContractionCoordinates

/-!
# One-side output traces of the local contraction maps

This file formalizes the one-side identities in `main.tex:2503--2527` and
`main.tex:2615--2619`.  The third leg of `LocalMixedSchurSpace x` is the
output register `X'`; tracing it out leaves the two input copies `X₁ X₂`.

The dimension assumption is needed only for the normalized odd diagonal
block, whose coefficient contains `Fintype.card x - 1`.  The two cross terms
vanish without a dimension assumption.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {x : Type*} [Fintype x] [DecidableEq x]

/-- Antisymmetric projector on the two-copy input space. -/
def localInputPairPAsym : CMatrix (x × x) :=
  (1 / 2 : ℂ) • ((1 : CMatrix (x × x)) - globalInputPairSwap)

/-- The antisymmetric projector is the orthogonal complement of the
symmetric projector. -/
theorem localInputPairPAsym_eq_one_sub_globalInputPairPSym :
    localInputPairPAsym (x := x) =
      (1 : CMatrix (x × x)) - globalInputPairPSym := by
  simp only [localInputPairPAsym, globalInputPairPSym]
  module

/-- The two-copy antisymmetric matrix is idempotent. -/
theorem localInputPairPAsym_idempotent :
    localInputPairPAsym (x := x) * localInputPairPAsym =
      localInputPairPAsym := by
  rw [localInputPairPAsym_eq_one_sub_globalInputPairPSym]
  noncomm_ring [globalInputPairPSym_idempotent (x := x)]

/-- The two-copy antisymmetric projector is Hermitian. -/
theorem localInputPairPAsym_isHermitian :
    (localInputPairPAsym (x := x)).IsHermitian := by
  have hswap := globalInputPairSwap_isHermitian (x := x)
  rw [Matrix.IsHermitian] at hswap
  rw [Matrix.IsHermitian, localInputPairPAsym, Matrix.conjTranspose_smul,
    Matrix.conjTranspose_sub, hswap]
  norm_num

/-- The two-copy antisymmetric projector is positive semidefinite. -/
theorem localInputPairPAsym_posSemidef :
    (localInputPairPAsym (x := x)).PosSemidef := by
  have hpos :=
    Matrix.posSemidef_conjTranspose_mul_self
      (localInputPairPAsym (x := x))
  rw [localInputPairPAsym_isHermitian (x := x),
    localInputPairPAsym_idempotent (x := x)] at hpos
  exact hpos

/-- Every entry of the antisymmetric input projector is real. -/
@[simp]
theorem star_localInputPairPAsym_apply (p q : x × x) :
    star (localInputPairPAsym (x := x) p q) =
      localInputPairPAsym p q := by
  simp [localInputPairPAsym, globalInputPairSwap, Matrix.one_apply]

/-- The symmetric and antisymmetric input projectors resolve the identity. -/
theorem globalInputPairPSym_add_localInputPairPAsym :
    globalInputPairPSym (x := x) + localInputPairPAsym = 1 := by
  simp only [globalInputPairPSym, localInputPairPAsym]
  module

/-- The symmetric and antisymmetric input projectors are orthogonal. -/
theorem globalInputPairPSym_mul_localInputPairPAsym :
    globalInputPairPSym (x := x) * localInputPairPAsym = 0 := by
  rw [localInputPairPAsym_eq_one_sub_globalInputPairPSym]
  noncomm_ring [globalInputPairPSym_idempotent (x := x)]

/-- Exact dimension/trace of the two-copy antisymmetric projector. -/
theorem localInputPairPAsym_trace :
    (localInputPairPAsym (x := x)).trace =
      (Fintype.card x : ℂ) * ((Fintype.card x : ℂ) - 1) / 2 := by
  rw [localInputPairPAsym, Matrix.trace_smul, Matrix.trace_sub,
    Matrix.trace_one, globalInputPairSwap_trace]
  simp only [Fintype.card_prod]
  push_cast
  ring

/-- Output trace of the unnormalized odd contraction product. -/
private theorem partialTraceB_globalGammaMinus_mul_conjTranspose :
    QIT.partialTraceB (a := x × x) (b := x)
        (globalGammaMinus * Matrix.conjTranspose globalGammaMinus) =
      (2 : ℂ) • ((1 : CMatrix (x × x)) - globalInputPairSwap) := by
  simp only [globalGammaMinus, Matrix.conjTranspose_sub, Matrix.sub_mul,
    Matrix.mul_sub, QIT.partialTraceB_sub]
  rw [partialTraceB_globalGamma2_mul_conjTranspose,
    partialTraceB_globalGamma2_mul_globalGamma1_conjTranspose,
    partialTraceB_globalGamma1_mul_globalGamma2_conjTranspose,
    partialTraceB_globalGamma1_mul_conjTranspose]
  module

/-- Output trace of the first unnormalized even/odd cross product. -/
private theorem partialTraceB_globalGammaPlus_mul_globalGammaMinus_conjTranspose :
    QIT.partialTraceB (a := x × x) (b := x)
        (globalGammaPlus * Matrix.conjTranspose globalGammaMinus) = 0 := by
  simp only [globalGammaPlus, globalGammaMinus, Matrix.conjTranspose_sub,
    Matrix.add_mul, Matrix.mul_sub, QIT.partialTraceB_add,
    QIT.partialTraceB_sub]
  rw [partialTraceB_globalGamma1_mul_globalGamma2_conjTranspose,
    partialTraceB_globalGamma1_mul_conjTranspose,
    partialTraceB_globalGamma2_mul_conjTranspose,
    partialTraceB_globalGamma2_mul_globalGamma1_conjTranspose]
  module

/-- Output trace of the reverse unnormalized odd/even cross product. -/
private theorem partialTraceB_globalGammaMinus_mul_globalGammaPlus_conjTranspose :
    QIT.partialTraceB (a := x × x) (b := x)
        (globalGammaMinus * Matrix.conjTranspose globalGammaPlus) = 0 := by
  simp only [globalGammaPlus, globalGammaMinus, Matrix.conjTranspose_add,
    Matrix.sub_mul, Matrix.mul_add, QIT.partialTraceB_add,
    QIT.partialTraceB_sub]
  rw [partialTraceB_globalGamma2_mul_conjTranspose,
    partialTraceB_globalGamma2_mul_globalGamma1_conjTranspose,
    partialTraceB_globalGamma1_mul_conjTranspose,
    partialTraceB_globalGamma1_mul_globalGamma2_conjTranspose]
  module

/-- The `++` one-side identity:
`Tr_{X'}[W₊ W₊†] = 2/(card x + 1) P_sym`. -/
theorem partialTraceB_localWPlus_mul_conjTranspose :
    QIT.partialTraceB (a := x × x) (b := x)
        (localWPlus * Matrix.conjTranspose localWPlus) =
      ((2 / ((Fintype.card x : ℝ) + 1) : ℝ) : ℂ) •
        globalInputPairPSym := by
  exact partialTraceB_globalPWPlus

/-- The `--` one-side identity:
`Tr_{X'}[W₋ W₋†] = 2/(card x - 1) P_asym`. -/
theorem partialTraceB_localWMinus_mul_conjTranspose
    (hcard : 2 ≤ Fintype.card x) :
    QIT.partialTraceB (a := x × x) (b := x)
        (localWMinus * Matrix.conjTranspose localWMinus) =
      ((2 / ((Fintype.card x : ℝ) - 1) : ℝ) : ℂ) •
        localInputPairPAsym := by
  rw [show localWMinus (x := x) * Matrix.conjTranspose localWMinus =
      globalPWMinus by rfl]
  rw [globalPWMinus_eq_scaledGammaMinus hcard]
  change
    QIT.partialTraceB (a := x × x) (b := x)
        (((1 / (2 * ((Fintype.card x : ℝ) - 1)) : ℝ) : ℂ) •
          (globalGammaMinus * Matrix.conjTranspose globalGammaMinus)) = _
  rw [QIT.partialTraceB_smul,
    partialTraceB_globalGammaMinus_mul_conjTranspose]
  simp only [localInputPairPAsym, smul_smul]
  have hdenom : (Fintype.card x : ℝ) - 1 ≠ 0 := by
    have hcardReal : (1 : ℝ) < Fintype.card x := by exact_mod_cast hcard
    linarith
  congr 1
  push_cast
  field_simp [hdenom]

/-- The `+-` one-side cross identity vanishes, with no dimension assumption. -/
theorem partialTraceB_localWPlus_mul_localWMinus_conjTranspose :
    QIT.partialTraceB (a := x × x) (b := x)
        (localWPlus * Matrix.conjTranspose localWMinus) = 0 := by
  let c : ℝ :=
    (1 / Real.sqrt (2 * ((Fintype.card x : ℝ) - 1))) *
      (1 / Real.sqrt (2 * ((Fintype.card x : ℝ) + 1)))
  have hmatrix :
      localWPlus (x := x) * Matrix.conjTranspose localWMinus =
        (c : ℂ) •
          (globalGammaPlus * Matrix.conjTranspose globalGammaMinus) := by
    dsimp only [c]
    simp only [localWPlus, localWMinus, globalWPlus, globalWMinus,
      Matrix.conjTranspose_smul, star_trivial, Matrix.smul_mul,
      Matrix.mul_smul, smul_smul]
    ext p q
    simp [Complex.real_smul]
  rw [hmatrix, QIT.partialTraceB_smul,
    partialTraceB_globalGammaPlus_mul_globalGammaMinus_conjTranspose,
    smul_zero]

/-- The `-+` one-side cross identity vanishes, with no dimension assumption. -/
theorem partialTraceB_localWMinus_mul_localWPlus_conjTranspose :
    QIT.partialTraceB (a := x × x) (b := x)
        (localWMinus * Matrix.conjTranspose localWPlus) = 0 := by
  let c : ℝ :=
    (1 / Real.sqrt (2 * ((Fintype.card x : ℝ) + 1))) *
      (1 / Real.sqrt (2 * ((Fintype.card x : ℝ) - 1)))
  have hmatrix :
      localWMinus (x := x) * Matrix.conjTranspose localWPlus =
        (c : ℂ) •
          (globalGammaMinus * Matrix.conjTranspose globalGammaPlus) := by
    dsimp only [c]
    simp only [localWPlus, localWMinus, globalWPlus, globalWMinus,
      Matrix.conjTranspose_smul, star_trivial, Matrix.smul_mul,
      Matrix.mul_smul, smul_smul]
    ext p q
    simp [Complex.real_smul]
  rw [hmatrix, QIT.partialTraceB_smul,
    partialTraceB_globalGammaMinus_mul_globalGammaPlus_conjTranspose,
    smul_zero]

/-- Select the two-input projector belonging to a local parity. -/
def localInputPairProjector (s : LocalParity) : CMatrix (x × x) :=
  match s with
  | .plus => globalInputPairPSym
  | .minus => localInputPairPAsym

/-- The coefficient multiplying the input projector after tracing out `X'`. -/
def localContractionOutputTraceCoefficient (s : LocalParity) : ℂ :=
  match s with
  | .plus => ((2 / ((Fintype.card x : ℝ) + 1) : ℝ) : ℂ)
  | .minus => ((2 / ((Fintype.card x : ℝ) - 1) : ℝ) : ℂ)

/-- Unified one-side output-trace identity.  Its hypothesis is inhabited only
in the `s = t = minus` case, exactly where the odd normalizer has denominator
`card x - 1`. -/
theorem partialTraceB_localWByParity_mul_conjTranspose
    (s t : LocalParity)
    (hminus : s = .minus → t = .minus → 2 ≤ Fintype.card x) :
    QIT.partialTraceB (a := x × x) (b := x)
        (localWByParity s * Matrix.conjTranspose (localWByParity t)) =
      if s = t then
        localContractionOutputTraceCoefficient (x := x) s •
          localInputPairProjector (x := x) s
      else 0 := by
  cases s <;> cases t
  · simpa [localWByParity, localContractionOutputTraceCoefficient,
      localInputPairProjector] using
      (partialTraceB_localWPlus_mul_conjTranspose (x := x))
  · simpa [localWByParity] using
      (partialTraceB_localWPlus_mul_localWMinus_conjTranspose (x := x))
  · simpa [localWByParity] using
      (partialTraceB_localWMinus_mul_localWPlus_conjTranspose (x := x))
  · have hcard := hminus rfl rfl
    simpa [localWByParity, localContractionOutputTraceCoefficient,
      localInputPairProjector] using
      (partialTraceB_localWMinus_mul_conjTranspose (x := x) hcard)

end

end EntanglementPurification
