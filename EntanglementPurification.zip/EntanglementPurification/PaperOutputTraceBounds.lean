import EntanglementPurification.PhysicalBranchOutputTraceCertificate
import EntanglementPurification.PPTCompressedInstrument

/-!
# Equal-dimension paper form of the output-trace lower bounds

The physical Lean layer permits different finite dimensions on Alice and Bob.
The paper instead assumes both equal to one integer d.  This module proves
that the general product scale specializes exactly to the alpha/beta scale
already used by the downstream compressed-instrument argument.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b r : Type*}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

/-- Under the paper's equal local-dimension assumption, the general Alice/Bob
product coefficient is exactly localSectorTraceScale. -/
theorem jointContractionOutputTraceRealScale_eq_localSectorTraceScale
    (hcardA : 2 ≤ Fintype.card a)
    (hcardEq : Fintype.card b = Fintype.card a)
    (z : LocalMultiplicitySector) :
    jointContractionOutputTraceRealScale a b z =
      localSectorTraceScale (Fintype.card a) z := by
  have hd : (1 : ℝ) < Fintype.card a := by
    exact_mod_cast (lt_of_lt_of_le (by norm_num : 1 < 2) hcardA)
  have hplus : (Fintype.card a : ℝ) + 1 ≠ 0 := by positivity
  have hminus : (Fintype.card a : ℝ) - 1 ≠ 0 :=
    ne_of_gt (sub_pos.mpr hd)
  rcases z with ⟨sA, sB⟩
  cases sA <;> cases sB <;>
    simp [jointContractionOutputTraceRealScale,
      localContractionOutputTraceRealScale, localSectorTraceScale,
      localContractionAlpha, localContractionBeta, hcardEq] <;>
    field_simp [hplus, hminus]

/-- Equal-dimension paper notation for the sectorwise lower bound. -/
theorem physicalInvariant_outputTrace_sectorCoefficient_lowerBound_paper
    [Nonempty a] [Nonempty b]
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (hcardEq : Fintype.card b = Fintype.card a)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K)
    (hK : K.PosSemidef) (z : LocalMultiplicitySector) :
    localSectorTraceScale (Fintype.card a) z •
        resourceSectorBlock (jointContractionSchurCoefficient K) z z ≤
      outputTraceSectorCoefficient (physicalBranchOutputTrace K) z := by
  rw [← jointContractionOutputTraceRealScale_eq_localSectorTraceScale
    hcardA hcardEq z]
  exact physicalInvariant_outputTrace_sectorCoefficient_lowerBound
    hcardA hcardB hInvariant hK z

/-- The four inequalities displayed in
eq:branch_sector_trace_lower_bounds, returned in the paper's order
++,+-,-+,--. -/
theorem physicalInvariant_outputTrace_fourSectorCoefficient_lowerBounds_paper
    [Nonempty a] [Nonempty b]
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (hcardEq : Fintype.card b = Fintype.card a)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K)
    (hK : K.PosSemidef) :
    localSectorTraceScale (Fintype.card a) sectorPP •
          resourceSectorBlock (jointContractionSchurCoefficient K)
            sectorPP sectorPP ≤
        outputTraceSectorCoefficient (physicalBranchOutputTrace K) sectorPP ∧
      localSectorTraceScale (Fintype.card a) sectorPM •
          resourceSectorBlock (jointContractionSchurCoefficient K)
            sectorPM sectorPM ≤
        outputTraceSectorCoefficient (physicalBranchOutputTrace K) sectorPM ∧
      localSectorTraceScale (Fintype.card a) sectorMP •
          resourceSectorBlock (jointContractionSchurCoefficient K)
            sectorMP sectorMP ≤
        outputTraceSectorCoefficient (physicalBranchOutputTrace K) sectorMP ∧
      localSectorTraceScale (Fintype.card a) sectorMM •
          resourceSectorBlock (jointContractionSchurCoefficient K)
            sectorMM sectorMM ≤
        outputTraceSectorCoefficient (physicalBranchOutputTrace K) sectorMM := by
  exact ⟨
    physicalInvariant_outputTrace_sectorCoefficient_lowerBound_paper
      hcardA hcardB hcardEq hInvariant hK sectorPP,
    physicalInvariant_outputTrace_sectorCoefficient_lowerBound_paper
      hcardA hcardB hcardEq hInvariant hK sectorPM,
    physicalInvariant_outputTrace_sectorCoefficient_lowerBound_paper
      hcardA hcardB hcardEq hInvariant hK sectorMP,
    physicalInvariant_outputTrace_sectorCoefficient_lowerBound_paper
      hcardA hcardB hcardEq hInvariant hK sectorMM⟩

end

end EntanglementPurification
