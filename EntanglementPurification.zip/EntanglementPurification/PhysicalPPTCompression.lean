import EntanglementPurification.JointContractionCompression
import EntanglementPurification.PPTPartialTranspose
import Mathlib.Tactic

/-!
# Physical Bob partial transpose and contraction compression

This file formalizes the basis-sensitive interface in
`lem:mixed_schur_ppt_interface` of `main.tex`.  The physical branch index is
stored as

`((H_A × H_B) × (R_A × R_B))`,

whereas `QIT.partialTransposeB` expects the Alice/Bob grouping.  We therefore
record that regrouping explicitly.  The same is done on the contraction
coordinates.  Since the contraction isometry has real entries in the fixed
bases used in the paper, pulling back commutes with Bob partial transpose.

No PPT compatibility statement is assumed as a field: all identities below
are proved entrywise from the concrete contraction maps.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b ra rb : Type*}
  [Fintype a] [Fintype b] [Fintype ra] [Fintype rb]
  [DecidableEq a] [DecidableEq b] [DecidableEq ra] [DecidableEq rb]

/-- Regroup the physical index into the actual Alice/Bob tensor cut:
`(H_A × R_A) × (H_B × R_B)`. -/
def jointPhysicalBobGroupingEquiv :
    JointContractionPhysicalIndex a b (ra × rb) ≃
      ((LocalMixedSchurSpace a × ra) × (LocalMixedSchurSpace b × rb)) where
  toFun p := ((p.1.1, p.2.1), (p.1.2, p.2.2))
  invFun p := ((p.1.1, p.2.1), (p.1.2, p.2.2))
  left_inv _ := rfl
  right_inv _ := rfl

/-- Simultaneously exchange the Bob parts of two physical basis indices.  This
is the finite reindexing used in the matrix-element proof of partial-transpose
compatibility. -/
def jointPhysicalBobPairSwap :
    (JointContractionPhysicalIndex a b (ra × rb) ×
      JointContractionPhysicalIndex a b (ra × rb)) ≃
    (JointContractionPhysicalIndex a b (ra × rb) ×
      JointContractionPhysicalIndex a b (ra × rb)) where
  toFun p :=
    ((((p.1.1.1, p.2.1.2), (p.1.2.1, p.2.2.2))),
      (((p.2.1.1, p.1.1.2), (p.2.2.1, p.1.2.2))))
  invFun p :=
    ((((p.1.1.1, p.2.1.2), (p.1.2.1, p.2.2.2))),
      (((p.2.1.1, p.1.1.2), (p.2.2.1, p.1.2.2))))
  left_inv _ := rfl
  right_inv _ := rfl

/-- Physical fixed-basis partial transpose on `B₁ B₂ B' Bᵣ`. -/
def physicalBranchPartialTransposeB
    (K : CMatrix (JointContractionPhysicalIndex a b (ra × rb))) :
    CMatrix (JointContractionPhysicalIndex a b (ra × rb)) :=
  (Matrix.reindexAlgEquiv ℂ ℂ
      (jointPhysicalBobGroupingEquiv
        (a := a) (b := b) (ra := ra) (rb := rb)).symm)
    (QIT.partialTransposeB
      ((Matrix.reindexAlgEquiv ℂ ℂ
          (jointPhysicalBobGroupingEquiv
            (a := a) (b := b) (ra := ra) (rb := rb))) K))

/-- Entrywise physical Bob partial transpose. -/
@[simp]
theorem physicalBranchPartialTransposeB_apply
    (K : CMatrix (JointContractionPhysicalIndex a b (ra × rb)))
    (uA vA : LocalMixedSchurSpace a)
    (uB vB : LocalMixedSchurSpace b)
    (i k : ra) (j l : rb) :
    physicalBranchPartialTransposeB K
        ((uA, uB), (i, j)) ((vA, vB), (k, l)) =
      K ((uA, vB), (i, l)) ((vA, uB), (k, j)) := by
  simp [physicalBranchPartialTransposeB, Matrix.reindexAlgEquiv_apply,
    Matrix.reindex_apply, jointPhysicalBobGroupingEquiv]

/-- Regroup contraction coordinates into the Alice/Bob tensor cut:
`((M_A × R_A) × A) × ((M_B × R_B) × B)`. -/
def jointCoordinateBobGroupingEquiv :
    JointContractionCoordinateIndex a b (ra × rb) ≃
      (((LocalParity × ra) × a) × ((LocalParity × rb) × b)) where
  toFun p := (((p.1.1.1, p.1.2.1), p.2.1),
    ((p.1.1.2, p.1.2.2), p.2.2))
  invFun p := (((p.1.1.1, p.2.1.1), (p.1.1.2, p.2.1.2)),
    (p.1.2, p.2.2))
  left_inv _ := rfl
  right_inv _ := rfl

/-- Bob partial transpose on the full contraction-coordinate space.  It
transposes the Bob parity, Bob resource, and the remaining Bob coordinate. -/
def jointCoordinatePartialTransposeB
    (Q : CMatrix (JointContractionCoordinateIndex a b (ra × rb))) :
    CMatrix (JointContractionCoordinateIndex a b (ra × rb)) :=
  (Matrix.reindexAlgEquiv ℂ ℂ
      (jointCoordinateBobGroupingEquiv
        (a := a) (b := b) (ra := ra) (rb := rb)).symm)
    (QIT.partialTransposeB
      ((Matrix.reindexAlgEquiv ℂ ℂ
          (jointCoordinateBobGroupingEquiv
            (a := a) (b := b) (ra := ra) (rb := rb))) Q))

/-- Entrywise contraction-coordinate Bob partial transpose. -/
@[simp]
theorem jointCoordinatePartialTransposeB_apply
    (Q : CMatrix (JointContractionCoordinateIndex a b (ra × rb)))
    (sA sB tA tB : LocalParity)
    (i k : ra) (j l : rb) (u w : a) (v x : b) :
    jointCoordinatePartialTransposeB Q
        (((sA, sB), (i, j)), (u, v))
        (((tA, tB), (k, l)), (w, x)) =
      Q (((sA, tB), (i, l)), (u, x))
        (((tA, sB), (k, j)), (w, v)) := by
  simp [jointCoordinatePartialTransposeB, Matrix.reindexAlgEquiv_apply,
    Matrix.reindex_apply, jointCoordinateBobGroupingEquiv]

/-- Every entry of the local contraction maps is real in the fixed basis. -/
theorem star_localWByParity_apply
    (s : LocalParity) (p : LocalMixedSchurSpace a) (i : a) :
    star (localWByParity s p i) = localWByParity s p i := by
  cases s
  · simp only [localWByParity, globalWPlus, Matrix.smul_apply,
      star_smul, star_trivial]
    congr 1
    simp only [globalGammaPlus, globalGamma1, globalGamma2,
      Matrix.add_apply]
    split_ifs <;> simp
  · simp only [localWByParity, globalWMinus, Matrix.smul_apply,
      star_smul, star_trivial]
    congr 1
    simp only [globalGammaMinus, globalGamma1, globalGamma2,
      Matrix.sub_apply]
    split_ifs <;> simp

omit [Fintype ra] [Fintype rb] in
/-- Every entry of the joint resource-extended contraction isometry is real. -/
theorem star_jointContractionIsometry_apply
    (p : JointContractionPhysicalIndex a b (ra × rb))
    (q : JointContractionCoordinateIndex a b (ra × rb)) :
    star (jointContractionIsometry p q) = jointContractionIsometry p q := by
  rcases p with ⟨⟨uA, uB⟩, ⟨i, j⟩⟩
  rcases q with ⟨⟨⟨sA, sB⟩, ⟨k, l⟩⟩, ⟨x, y⟩⟩
  rw [jointContractionIsometry_apply]
  change
    star (localWByParity sA uA x * localWByParity sB uB y *
      (if (i, j) = (k, l) then 1 else 0)) = _
  simp only [star_mul, star_localWByParity_apply]
  change _ = localWByParity sA uA x * localWByParity sB uB y * _
  by_cases h : (i, j) = (k, l) <;> simp [h, mul_comm]

/-- Entrywise double-sum formula for contraction pullback. -/
theorem jointContractionPullback_apply
    (K : CMatrix (JointContractionPhysicalIndex a b (ra × rb)))
    (p q : JointContractionCoordinateIndex a b (ra × rb)) :
    jointContractionPullback K p q =
      ∑ x, ∑ y,
        star (jointContractionIsometry x p) * K x y *
          jointContractionIsometry y q := by
  simp [jointContractionPullback, Matrix.mul_apply,
    Matrix.conjTranspose_apply, Finset.sum_mul]
  rw [Finset.sum_comm]

/-- Pullback by the real contraction isometry commutes with physical Bob
partial transpose.  This is the basis-level identity preceding
`eq:mixed_schur_ppt_contraction_block`. -/
theorem jointContractionPullback_physicalBranchPartialTransposeB
    (K : CMatrix (JointContractionPhysicalIndex a b (ra × rb))) :
    jointContractionPullback (physicalBranchPartialTransposeB K) =
      jointCoordinatePartialTransposeB (jointContractionPullback K) := by
  ext p q
  rcases p with ⟨⟨⟨sA, sB⟩, ⟨i, j⟩⟩, ⟨u, v⟩⟩
  rcases q with ⟨⟨⟨tA, tB⟩, ⟨k, l⟩⟩, ⟨w, x⟩⟩
  rw [jointContractionPullback_apply,
    jointCoordinatePartialTransposeB_apply,
    jointContractionPullback_apply]
  let P := JointContractionPhysicalIndex a b (ra × rb)
  let f : P × P → ℂ := fun z =>
    star (jointContractionIsometry z.1
      (((sA, sB), (i, j)), (u, v))) *
      physicalBranchPartialTransposeB K z.1 z.2 *
      jointContractionIsometry z.2
        (((tA, tB), (k, l)), (w, x))
  let g : P × P → ℂ := fun z =>
    star (jointContractionIsometry z.1
      (((sA, tB), (i, l)), (u, x))) * K z.1 z.2 *
      jointContractionIsometry z.2
        (((tA, sB), (k, j)), (w, v))
  change (∑ x : P, ∑ y : P, f (x, y)) =
    ∑ x : P, ∑ y : P, g (x, y)
  calc
    (∑ x : P, ∑ y : P, f (x, y)) = ∑ z : P × P, f z := by
      exact (Fintype.sum_prod_type f).symm
    _ = ∑ z : P × P, g z := by
      refine Fintype.sum_equiv
        (jointPhysicalBobPairSwap
          (a := a) (b := b) (ra := ra) (rb := rb)) f g ?_
      intro z
      rcases z with
        ⟨⟨⟨uA, uB⟩, ⟨iA, iB⟩⟩, ⟨⟨vA, vB⟩, ⟨kA, kB⟩⟩⟩
      simp only [f, g, jointPhysicalBobPairSwap]
      rw [physicalBranchPartialTransposeB_apply,
        star_jointContractionIsometry_apply,
        star_jointContractionIsometry_apply]
      simp only [jointContractionIsometry_apply, Prod.mk.injEq]
      by_cases hiA : iA = i <;>
        by_cases hiB : iB = j <;>
          by_cases hkA : kA = k <;>
            by_cases hkB : kB = l <;>
              simp [hiA, hiB, hkA, hkB]
      ring
    _ = ∑ x : P, ∑ y : P, g (x, y) := by
      exact Fintype.sum_prod_type g

/-- Partial transposition of a Schur block transposes precisely its Bob
multiplicity/resource coefficient; the identity on `A × B` is unchanged. -/
theorem jointCoordinatePartialTransposeB_kronecker_one
    (L : CMatrix (LocalMultiplicitySector × (ra × rb))) :
    jointCoordinatePartialTransposeB
        (Matrix.kronecker L (1 : CMatrix (a × b))) =
      Matrix.kronecker (sectorResourcePartialTransposeB L)
        (1 : CMatrix (a × b)) := by
  ext p q
  rcases p with ⟨⟨⟨sA, sB⟩, ⟨i, j⟩⟩, ⟨u, v⟩⟩
  rcases q with ⟨⟨⟨tA, tB⟩, ⟨k, l⟩⟩, ⟨w, x⟩⟩
  simp only [jointCoordinatePartialTransposeB_apply]
  by_cases huw : u = w <;> by_cases hvx : v = x <;>
    simp [huw, hvx, eq_comm]

/-- Exact physical-to-sector form of
`eq:mixed_schur_ppt_contraction_block`: once the untransposed pullback has
Schur coefficient `L`, the pullback of the physical Bob partial transpose has
coefficient `L^{T_{M_B}T_{B_r}}`. -/
theorem jointContractionPullback_partialTransposeB_eq_sectorBlock
    (K : CMatrix (JointContractionPhysicalIndex a b (ra × rb)))
    (L : CMatrix (LocalMultiplicitySector × (ra × rb)))
    (hSchur : jointContractionPullback K =
      Matrix.kronecker L (1 : CMatrix (a × b))) :
    jointContractionPullback (physicalBranchPartialTransposeB K) =
      Matrix.kronecker (sectorResourcePartialTransposeB L)
        (1 : CMatrix (a × b)) := by
  rw [jointContractionPullback_physicalBranchPartialTransposeB, hSchur,
    jointCoordinatePartialTransposeB_kronecker_one]

omit [Fintype a] [Fintype b] [Fintype ra] [Fintype rb]
    [DecidableEq ra] [DecidableEq rb] in
/-- Positivity of `L ⊗ I` implies positivity of `L`, by compressing to any
fixed basis vector of the identity factor. -/
theorem posSemidef_of_kronecker_one_posSemidef
    {L : CMatrix (LocalMultiplicitySector × (ra × rb))}
    (u : a) (v : b)
    (h : (Matrix.kronecker L (1 : CMatrix (a × b))).PosSemidef) :
    L.PosSemidef := by
  have hsub := h.submatrix
    (fun z : LocalMultiplicitySector × (ra × rb) => (z, (u, v)))
  simpa [Matrix.submatrix, Matrix.kronecker, Matrix.one_apply] using hsub

/-- Physical positivity descends to the Schur coefficient; this is derived
from pullback positivity and the exact coefficient equation. -/
theorem schurCoefficient_posSemidef_of_physical
    (K : CMatrix (JointContractionPhysicalIndex a b (ra × rb)))
    (L : CMatrix (LocalMultiplicitySector × (ra × rb)))
    (u : a) (v : b) (hK : K.PosSemidef)
    (hSchur : jointContractionPullback K =
      Matrix.kronecker L (1 : CMatrix (a × b))) :
    L.PosSemidef := by
  have hpull := jointContractionPullback_posSemidef hK
  rw [hSchur] at hpull
  exact posSemidef_of_kronecker_one_posSemidef u v hpull

/-- Physical Bob-PPT positivity descends to positivity of the compressed
Bob partial transpose. -/
theorem sectorPartialTranspose_posSemidef_of_physical
    (K : CMatrix (JointContractionPhysicalIndex a b (ra × rb)))
    (L : CMatrix (LocalMultiplicitySector × (ra × rb)))
    (u : a) (v : b)
    (hKppt : (physicalBranchPartialTransposeB K).PosSemidef)
    (hSchur : jointContractionPullback K =
      Matrix.kronecker L (1 : CMatrix (a × b))) :
    (sectorResourcePartialTransposeB L).PosSemidef := by
  have hpull := jointContractionPullback_posSemidef hKppt
  rw [jointContractionPullback_partialTransposeB_eq_sectorBlock K L hSchur]
    at hpull
  exact posSemidef_of_kronecker_one_posSemidef u v hpull

/-- A positive physical branch satisfying the physical Bob-PPT constraint
therefore yields the compressed `BranchPPT` predicate. -/
theorem branchPPT_of_physical
    (K : CMatrix (JointContractionPhysicalIndex a b (ra × rb)))
    (L : CMatrix (LocalMultiplicitySector × (ra × rb)))
    (u : a) (v : b)
    (hK : K.PosSemidef)
    (hKppt : (physicalBranchPartialTransposeB K).PosSemidef)
    (hSchur : jointContractionPullback K =
      Matrix.kronecker L (1 : CMatrix (a × b))) :
    BranchPPT L := by
  exact ⟨schurCoefficient_posSemidef_of_physical K L u v hK hSchur,
    sectorPartialTranspose_posSemidef_of_physical K L u v hKppt hSchur⟩

end

end EntanglementPurification
