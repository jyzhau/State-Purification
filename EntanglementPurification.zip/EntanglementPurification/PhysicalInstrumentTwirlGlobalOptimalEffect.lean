import EntanglementPurification.PhysicalInstrumentOptimality
import EntanglementPurification.PhysicalLocalTwirlFeasibility
import EntanglementPurification.PhysicalLocalTwirlResource
import EntanglementPurification.PhysicalGlobalOptimizerLocalInvariant
import EntanglementPurification.PhysicalOptimalOutputZeros
import EntanglementPurification.GlobalOptimalLocalBlock
import EntanglementPurification.PhysicalOutputInstrumentEffect

/-!
# The canonical effect after twirling a globally optimal physical instrument

This file first applies the genuine independent Alice/Bob Haar twirl to both
branches of an operational physical PPT instrument.  The twirl supplies local
invariance while preserving positivity, physical Bob-PPT, and branch
completeness.  Exact global attainment is then transported through the twirl
and used to derive the optimal local contraction block and the two vanishing
mixed output sectors.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {d : ℕ} {ra rb : Type*}
  [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]

/-- A trace-normalized pure vector cannot be indexed by an empty type. -/
private theorem nonempty_of_pureVector
    {r : Type*} [Fintype r] [DecidableEq r]
    (resource : PureVector r) : Nonempty r := by
  classical
  by_contra h
  haveI : IsEmpty r := not_nonempty_iff.mp h
  simpa [Matrix.trace] using resource.trace_rankOne_eq_one

/-- Once resource insertion of a physical branch is the inserted global
optimizer, its canonical local contraction block is the paper's rank-one
optimizer.  In the public construction below the displayed equality is
derived from exact attainment and the fixed-point theorem for the twirl. -/
private theorem insertedBlock_eq_localOptimal_of_physicalInserted
    [Nonempty (Fin d)]
    {K : CMatrix
      (JointContractionPhysicalIndex (Fin d) (Fin d) (ra × rb))}
    (hd : 2 ≤ d)
    (resource : PureVector (ra × rb))
    (hInserted :
      physicalPureResourceInsert resource.amp K =
        physicalInsertedChoiMatrix
          (globalOptimalChoi (x := GlobalPaperIndex d))) :
    insertPureResourceBlock resource.amp
        (jointContractionSchurCoefficient K) =
      rankOneMatrix (localOptimalMultiplicityVector d) := by
  calc
    insertPureResourceBlock resource.amp
        (jointContractionSchurCoefficient K) =
      jointContractionUnassistedCoefficient
        (physicalPureResourceInsert resource.amp K) := by
          exact
            (jointContractionUnassistedCoefficient_physicalPureResourceInsert
              resource.amp K).symm
    _ = jointContractionUnassistedCoefficient
        (physicalInsertedChoiMatrix
          (globalOptimalChoi (x := GlobalPaperIndex d))) := by
          rw [hInserted]
    _ = rankOneMatrix (localOptimalMultiplicityVector d) := by
      simpa using
        (globalOptimizer_localBlock
          (a := Fin d) (b := Fin d) (by simpa using hd) (by simp))

/-- Internal assembly step after exact resource insertion has been transported
through the local twirl.  All feasibility facts come from the operational
instrument's twirl certificate, and the optimal block and mixed-sector zeros
are derived from `hInserted`. -/
private def twirledGlobalOptimalCompressedData_of_physicalInserted
    [Nonempty (Fin d)] [Nonempty ra] [Nonempty rb]
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d)
    (resource : PureVector (ra × rb))
    (hInserted :
      physicalPureResourceInsert resource.amp M.twirledSuccess =
        physicalInsertedChoiMatrix
          (globalOptimalChoi (x := GlobalPaperIndex d))) :
    CompressedPPTInstrumentData (Fintype.card (Fin d)) ra rb := by
  let feasibility := M.localTwirl_feasibilityCertificate
  have hinserted :
      insertPureResourceBlock resource.amp
          (jointContractionSchurCoefficient M.twirledSuccess) =
        rankOneMatrix (localOptimalMultiplicityVector d) :=
    insertedBlock_eq_localOptimal_of_physicalInserted hd resource hInserted
  have hzeroMixed :=
    outputTrace_mixedSector_quadratics_zero_of_physicalInserted_globalOptimalChoi
      (a := Fin d) (b := Fin d) (r := ra × rb)
      (by simpa using hd) (by simpa using hd) resource.amp
      feasibility.success_invariant hInserted
  exact
    physicalOutputCompressedData
      (by simpa using hd) (by simpa using hd) (by simp) resource
        feasibility.success_invariant
        feasibility.success_posSemidef feasibility.failure_posSemidef
        feasibility.success_ppt feasibility.failure_ppt
        feasibility.outputTrace_complete (by simpa using hinserted)
        hzeroMixed.1 hzeroMixed.2

private def castCompressedPPTInstrumentDataDimension
    {d₁ d₂ : ℕ} (h : d₁ = d₂)
    (data : CompressedPPTInstrumentData d₁ ra rb) :
    CompressedPPTInstrumentData d₂ ra rb := h ▸ data

@[simp] private theorem castCompressedPPTInstrumentDataDimension_resource
    {d₁ d₂ : ℕ} (h : d₁ = d₂)
    (data : CompressedPPTInstrumentData d₁ ra rb) :
    (castCompressedPPTInstrumentDataDimension h data).resource =
      data.resource := by
  cases h
  rfl

/-- Canonical compressed data obtained by applying the genuine local Haar
twirl to both branches of an operational physical PPT instrument which
exactly attains the exposed global optimum.

No invariance premise is required: the twirl produces it.  Positivity,
physical Bob-PPT, and branch completeness are preserved by the twirl, while
the global optimizer's fixed-point property transports exact resource
insertion through the average.  The optimal local block and both mixed-sector
zeros are then consequences rather than constructor arguments. -/
def physicalInstrumentTwirlGlobalOptimalCompressedData
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d)
    (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (resource : PureVector (ra × rb))
    (hattains :
      globalSDPObjective
          (globalPaperEq986PerformanceOperator hd nu gamma)
          (pureResourceInsert resource.amp
            (MatrixMap.choi (M.instrument.branch true))) =
        globalOptimalGain ((d : ℕ) ^ 2) gamma) :
    CompressedPPTInstrumentData d ra rb := by
  letI : Nonempty (Fin d) := Fin.pos_iff_nonempty.mp (by omega)
  let resourceIndex : ra × rb :=
    Classical.choice (nonempty_of_pureVector resource)
  letI : Nonempty ra := ⟨resourceIndex.1⟩
  letI : Nonempty rb := ⟨resourceIndex.2⟩
  have hraw :
      pureResourceInsert resource.amp
          (MatrixMap.choi (M.instrument.branch true)) =
        globalOptimalChoi (x := GlobalPaperIndex d) :=
    M.insertedSuccess_eq_globalOptimalChoi
      hd nu hgamma0 hgamma1 resource hattains
  have hRawInserted :
      physicalPureResourceInsert resource.amp M.success =
        physicalInsertedChoiMatrix
          (globalOptimalChoi (x := GlobalPaperIndex d)) := by
    change physicalPureResourceInsert resource.amp
        (physicalInstrumentChoi (M.instrument.branch true)) = _
    rw [physicalPureResourceInsert_physicalInstrumentChoi, hraw]
  have hTwirledInserted :
      physicalPureResourceInsert resource.amp M.twirledSuccess =
        physicalInsertedChoiMatrix
          (globalOptimalChoi (x := GlobalPaperIndex d)) := by
    change physicalPureResourceInsert resource.amp
        (physicalLocalTwirl M.success) = _
    rw [physicalPureResourceInsert_physicalLocalTwirl, hRawInserted,
      physicalLocalUnassistedTwirl_globalOptimalChoi_fixed]
  exact castCompressedPPTInstrumentDataDimension (by simp)
    (twirledGlobalOptimalCompressedData_of_physicalInserted
      M hd resource hTwirledInserted)

/-- The canonical compressed-data constructor retains the supplied resource.

This projection lemma hides the harmless transport across
`Fintype.card (Fin d) = d` performed by the internal assembly step. -/
@[simp] theorem physicalInstrumentTwirlGlobalOptimalCompressedData_resource
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d)
    (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (resource : PureVector (ra × rb))
    (hattains :
      globalSDPObjective
          (globalPaperEq986PerformanceOperator hd nu gamma)
          (pureResourceInsert resource.amp
            (MatrixMap.choi (M.instrument.branch true))) =
        globalOptimalGain ((d : ℕ) ^ 2) gamma) :
    (physicalInstrumentTwirlGlobalOptimalCompressedData
      M hd nu hgamma0 hgamma1 resource hattains).resource = resource := by
  simp [physicalInstrumentTwirlGlobalOptimalCompressedData,
    twirledGlobalOptimalCompressedData_of_physicalInserted,
    physicalOutputCompressedData]

/-- The auxiliary matrix canonically extracted after twirling an exactly
globally optimal operational physical PPT instrument is an effect. -/
theorem physicalInstrumentTwirlGlobalOptimalCompressedData_auxiliaryEffect_isEffect
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d)
    (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (resource : PureVector (ra × rb))
    (hattains :
      globalSDPObjective
          (globalPaperEq986PerformanceOperator hd nu gamma)
          (pureResourceInsert resource.amp
            (MatrixMap.choi (M.instrument.branch true))) =
        globalOptimalGain ((d : ℕ) ^ 2) gamma) :
    IsEffectMatrix
      (physicalInstrumentTwirlGlobalOptimalCompressedData
        M hd nu hgamma0 hgamma1 resource hattains).auxiliaryEffect := by
  exact
    (physicalInstrumentTwirlGlobalOptimalCompressedData
      M hd nu hgamma0 hgamma1 resource hattains).auxiliaryEffect_isEffect hd

end

end EntanglementPurification
