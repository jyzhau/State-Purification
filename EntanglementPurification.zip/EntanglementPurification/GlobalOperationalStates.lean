import EntanglementPurification.GlobalEq986Performance
import QIT.States.Geometry.FidelityConcavity
import QIT.States.Geometry.PureTargetFidelity
import QIT.States.Geometry.PurifiedDistance
import QIT.States.MaximallyMixed

/-!
# Operational states for the global depolarizing problem

This module realizes the matrices used in the paper's global Haar performance
operator as normalized QIT states.  It packages the Haar-orbit target, the
depolarized single-copy input, its target fidelity, and the two-copy product
state appearing in equation 986.
-/

namespace EntanglementPurification

open QIT

noncomputable section

universe u

variable {x : Type u} [Fintype x] [DecidableEq x] [Nonempty x]

/-- The normalized pure vector `U |nu>` on the global Haar orbit. -/
def globalHaarOrbitPureVector (nu : PureVector x)
    (U : Matrix.unitaryGroup x ℂ) : PureVector x where
  amp := (U : CMatrix x).mulVec nu.amp
  trace_rankOne_eq_one := by
    rw [rankOneMatrix_mulVec_eq_mul_rankOneMatrix_mul_conjTranspose]
    rw [Matrix.trace_mul_cycle]
    have hU :
        Matrix.conjTranspose (U : CMatrix x) * (U : CMatrix x) = 1 := by
      simpa [Matrix.star_eq_conjTranspose] using Unitary.coe_star_mul_self U
    rw [hU, Matrix.one_mul]
    exact nu.trace_rankOne_eq_one

omit [Nonempty x] in
/-- The density matrix of `U |nu>` is the Haar-orbit rank-one matrix used in
the equation-986 integrand. -/
@[simp] theorem globalHaarOrbitPureVector_state_matrix
    (nu : PureVector x) (U : Matrix.unitaryGroup x ℂ) :
    (globalHaarOrbitPureVector nu U).state.matrix =
      globalHaarOrbitPureMatrix nu U := by
  simp [globalHaarOrbitPureVector, globalHaarOrbitPureMatrix,
    rankOneMatrix_mulVec_eq_mul_rankOneMatrix_mul_conjTranspose,
    Matrix.star_eq_conjTranspose]

/-- The paper's single-copy depolarizing output
`(1 - gamma) U|nu><nu|U† + gamma I / D`, as a normalized state. -/
def globalDepolarizedOrbitState (nu : PureVector x) (gamma : ℝ)
    (U : Matrix.unitaryGroup x ℂ) (hgamma0 : 0 ≤ gamma)
    (hgamma1 : gamma ≤ 1) : State x :=
  State.convexCombination (1 - gamma)
    (globalHaarOrbitPureVector nu U).state (State.maximallyMixed x)
    (sub_nonneg.mpr hgamma1) (by linarith)

/-- Matrix realization of the normalized depolarized orbit state. -/
@[simp] theorem globalDepolarizedOrbitState_matrix
    (nu : PureVector x) (gamma : ℝ) (U : Matrix.unitaryGroup x ℂ)
    (hgamma0 : 0 ≤ gamma) (hgamma1 : gamma ≤ 1) :
    (globalDepolarizedOrbitState nu gamma U hgamma0 hgamma1).matrix =
      globalDepolarizedOrbitMatrix nu gamma U := by
  unfold globalDepolarizedOrbitMatrix
  rw [← globalHaarOrbitPureVector_state_matrix]
  ext i j
  simp [globalDepolarizedOrbitState,
    State.convexCombination, State.maximallyMixed, Complex.real_smul,
    div_eq_mul_inv]
  ring

/-- The squared fidelity between the Haar-orbit target and its depolarized
input is `1 - gamma + gamma / D`, as stated after the noise-channel equation. -/
theorem globalHaarOrbitPureVector_squaredFidelity_globalDepolarizedOrbitState
    (nu : PureVector x) (gamma : ℝ) (U : Matrix.unitaryGroup x ℂ)
    (hgamma0 : 0 ≤ gamma) (hgamma1 : gamma ≤ 1) :
    (globalHaarOrbitPureVector nu U).state.squaredFidelity
        (globalDepolarizedOrbitState nu gamma U hgamma0 hgamma1) =
      globalNoiseFidelity (Fintype.card x : ℝ) gamma := by
  rw [State.squaredFidelity_comm_of_uhlmann,
    State.squaredFidelity_pure_right_eq_trace,
    globalDepolarizedOrbitState_matrix,
    globalDepolarizedOrbitMatrix,
    ← globalHaarOrbitPureVector_state_matrix]
  let psi := globalHaarOrbitPureVector nu U
  change
    ((((1 - gamma) : ℝ) • psi.state.matrix +
      (gamma / (Fintype.card x : ℝ)) • (1 : CMatrix x)) *
        psi.state.matrix).trace.re =
      globalNoiseFidelity (Fintype.card x : ℝ) gamma
  rw [Matrix.add_mul, Matrix.smul_mul, Matrix.smul_mul,
    psi.state_matrix_mul_self, Matrix.one_mul,
    Matrix.trace_add, Matrix.trace_smul, Matrix.trace_smul,
    psi.state.trace_eq_one]
  simp [globalNoiseFidelity]

/-- The IID two-copy noisy input state used by the equation-986 performance
operator. -/
def globalDepolarizedOrbitPairState (nu : PureVector x) (gamma : ℝ)
    (U : Matrix.unitaryGroup x ℂ) (hgamma0 : 0 ≤ gamma)
    (hgamma1 : gamma ≤ 1) : State (x × x) :=
  (globalDepolarizedOrbitState nu gamma U hgamma0 hgamma1).prod
    (globalDepolarizedOrbitState nu gamma U hgamma0 hgamma1)

/-- The two-copy noisy state is represented by the Kronecker square of the
paper's single-copy noisy matrix. -/
@[simp] theorem globalDepolarizedOrbitPairState_matrix
    (nu : PureVector x) (gamma : ℝ) (U : Matrix.unitaryGroup x ℂ)
    (hgamma0 : 0 ≤ gamma) (hgamma1 : gamma ≤ 1) :
    (globalDepolarizedOrbitPairState nu gamma U hgamma0 hgamma1).matrix =
      Matrix.kronecker (globalDepolarizedOrbitMatrix nu gamma U)
        (globalDepolarizedOrbitMatrix nu gamma U) := by
  simp [globalDepolarizedOrbitPairState, State.prod]

end

end EntanglementPurification
