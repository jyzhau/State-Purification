import EntanglementPurification.GlobalSDPRigidity
import QIT.Symmetry.DeFinetti.RennerProjectors
import QIT.Util.CMatrixCLM
import Mathlib.Tactic

/-!
# Pure-state Haar orbit moments for the global CPTN SDP

The performance operator in `main.tex` uses the first three moments of the
unitarily invariant pure-state ensemble.  This file proves the corresponding
finite-dimensional matrix identity for every tensor power `n`, and then records
the paper-facing specializations `n = 1, 2, 3`.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder Matrix.Norms.L2Operator NNReal
open MeasureTheory

noncomputable section

/-- The `n`-copy moment of the unitary Haar orbit of an arbitrary normalized
pure vector.  The integrand is the rank-one projector onto `(U ν)^{⊗ n}`. -/
def pureHaarOrbitMoment
    {a : Type*} [Fintype a] [DecidableEq a] [Nonempty a]
    (n : ℕ) (ν : PureVector a) : CMatrix (TensorPower a n) :=
  ∫ U : Matrix.unitaryGroup a ℂ,
    rennerMIIDProjectorZero (a := a) n ν U
      ∂unitaryHaarMeasure (a := a)

/-- The orbit-moment integral is exactly Lean-QIT's unitary twirl of the fixed
rank-one tensor-power state. -/
theorem pureHaarOrbitMoment_eq_unitaryTwirl
    {a : Type*} [Fintype a] [DecidableEq a] [Nonempty a]
    (n : ℕ) (ν : PureVector a) :
    pureHaarOrbitMoment n ν =
      unitaryTwirl n (rankOneMatrix (ν.tensorPower n).amp) := by
  rw [pureHaarOrbitMoment, unitaryTwirl]
  congr 1
  funext U
  exact rennerMIIDProjectorZero_eq_unitaryTwirlIntegrand (a := a) n ν U

/-- Every pure Haar orbit moment is positive semidefinite. -/
theorem pureHaarOrbitMoment_posSemidef
    {a : Type*} [Fintype a] [DecidableEq a] [Nonempty a]
    (n : ℕ) (ν : PureVector a) :
    (pureHaarOrbitMoment n ν).PosSemidef := by
  rw [pureHaarOrbitMoment_eq_unitaryTwirl]
  exact unitaryTwirl_posSemidef_of_posSemidef n
    (rankOneMatrix_pos (ν.tensorPower n).amp)

/-- Every pure Haar orbit moment has unit trace. -/
theorem pureHaarOrbitMoment_trace_eq_one
    {a : Type*} [Fintype a] [DecidableEq a] [Nonempty a]
    (n : ℕ) (ν : PureVector a) :
    (pureHaarOrbitMoment n ν).trace = 1 := by
  rw [pureHaarOrbitMoment_eq_unitaryTwirl, unitaryTwirl_trace]
  exact (ν.tensorPower n).trace_rankOne_eq_one

/-- Lean-QIT's compressed Haar-moment identity, exposed using the local moment
name.  The coefficient is the inverse dimension of the symmetric subspace. -/
theorem pureHaarOrbitMoment_mul_symmetricProjectionMatrix
    {a : Type*} [Fintype a] [DecidableEq a] [Nonempty a]
    (n : ℕ) (ν : PureVector a) :
    pureHaarOrbitMoment n ν * symmetricProjectionMatrix (a := a) n =
      ((Fintype.card (TensorPowerProfile a n) : ℂ)⁻¹ : ℂ) •
        symmetricProjectionMatrix (a := a) n := by
  simpa [pureHaarOrbitMoment] using
    rennerMIIDProjectorZero_average_mul_symmetricProjectionMatrix
      (a := a) n ν

/-- The full pure-state Haar moment is the normalized projector onto the
symmetric subspace.

This upgrades the compressed identity above to an equality of matrices.  The
upgrade uses positivity and trace preservation to show that the complementary
symmetric sector has zero mass, after which projection-support rigidity removes
both complementary blocks. -/
theorem pureHaarOrbitMoment_eq_inv_profileCard_smul_symmetricProjectionMatrix
    {a : Type*} [Fintype a] [DecidableEq a] [Nonempty a]
    (n : ℕ) (ν : PureVector a) :
    pureHaarOrbitMoment n ν =
      ((Fintype.card (TensorPowerProfile a n) : ℂ)⁻¹ : ℂ) •
        symmetricProjectionMatrix (a := a) n := by
  let M : CMatrix (TensorPower a n) := pureHaarOrbitMoment n ν
  let P : CMatrix (TensorPower a n) := symmetricProjectionMatrix (a := a) n
  let Q : CMatrix (TensorPower a n) := 1 - P
  let profileCard : ℕ := Fintype.card (TensorPowerProfile a n)

  have hMpos : M.PosSemidef := by
    simpa [M] using pureHaarOrbitMoment_posSemidef n ν
  have hMtrace : M.trace = 1 := by
    simpa [M] using pureHaarOrbitMoment_trace_eq_one n ν
  have hMP : M * P = ((profileCard : ℂ)⁻¹ : ℂ) • P := by
    simpa [M, P, profileCard] using
      pureHaarOrbitMoment_mul_symmetricProjectionMatrix n ν

  letI : Nonempty (TensorPowerProfile a n) :=
    ⟨constantTensorPowerProfile (a := a) (Classical.arbitrary a) n⟩
  have hprofileCardNat : profileCard ≠ 0 := by
    simp [profileCard]
  have hprofileCardComplex : (profileCard : ℂ) ≠ 0 := by
    exact_mod_cast hprofileCardNat
  have hMPtrace : (M * P).trace = 1 := by
    rw [hMP, Matrix.trace_smul]
    rw [show P.trace = (profileCard : ℂ) by
      simpa [P, profileCard] using
        symmetricProjectionMatrix_trace_eq_profile_card (a := a) n]
    simp [hprofileCardComplex]

  have hQherm : Q.IsHermitian := by
    simpa [Q, P] using
      symmetricProjectionMatrix_complement_isHermitian (a := a) n
  have hQid : Q * Q = Q := by
    simpa [Q, P] using
      symmetricProjectionMatrix_complement_idempotent (a := a) n
  have hQmassComplex : (Q * M).trace = 0 := by
    calc
      (Q * M).trace = M.trace - (P * M).trace := by
        simp [Q, Matrix.sub_mul]
      _ = M.trace - (M * P).trace := by rw [Matrix.trace_mul_comm P M]
      _ = 0 := by rw [hMtrace, hMPtrace, sub_self]
  have hQmass : ((Q * M).trace).re = 0 := by
    rw [hQmassComplex]
    rfl
  have hQzero :=
    hermitianProjection_mul_psd_eq_zero_of_trace_re_eq_zero
      hMpos hQherm hQid hQmass
  have hMsupported : M = M * P := by
    have hright : M * Q = 0 := hQzero.2
    change M * (1 - P) = 0 at hright
    rw [Matrix.mul_sub, Matrix.mul_one] at hright
    exact sub_eq_zero.mp hright

  calc
    pureHaarOrbitMoment n ν = M := rfl
    _ = M * P := hMsupported
    _ = ((profileCard : ℂ)⁻¹ : ℂ) • P := hMP
    _ = ((Fintype.card (TensorPowerProfile a n) : ℂ)⁻¹ : ℂ) •
        symmetricProjectionMatrix (a := a) n := by rfl

/-- Stars-and-bars form of the general Haar pure-state moment identity. -/
theorem pureHaarOrbitMoment_eq_inv_choose_smul_symmetricProjectionMatrix
    {a : Type*} [Fintype a] [DecidableEq a] [Nonempty a]
    (n : ℕ) (ν : PureVector a) :
    pureHaarOrbitMoment n ν =
      ((Nat.choose (Fintype.card a + n - 1) n : ℂ)⁻¹ : ℂ) •
        symmetricProjectionMatrix (a := a) n := by
  rw [pureHaarOrbitMoment_eq_inv_profileCard_smul_symmetricProjectionMatrix]
  rw [tensorPowerProfile_card_eq_choose (a := a) n]
  rw [Nat.add_comm n (Fintype.card a)]

/-- The Haar moment has no support outside the symmetric tensor-power
subspace, on either side. -/
theorem pureHaarOrbitMoment_symmetric_support
    {a : Type*} [Fintype a] [DecidableEq a] [Nonempty a]
    (n : ℕ) (ν : PureVector a) :
    pureHaarOrbitMoment n ν * symmetricProjectionMatrix (a := a) n =
        pureHaarOrbitMoment n ν ∧
      symmetricProjectionMatrix (a := a) n * pureHaarOrbitMoment n ν =
        pureHaarOrbitMoment n ν := by
  rw [pureHaarOrbitMoment_eq_inv_choose_smul_symmetricProjectionMatrix]
  constructor <;>
    simp [symmetricProjectionMatrix_idempotent (a := a) n]

/-- First Haar moment used in `main.tex`. -/
theorem pureHaarOrbitMoment_one
    {a : Type*} [Fintype a] [DecidableEq a] [Nonempty a]
    (ν : PureVector a) :
    pureHaarOrbitMoment 1 ν =
      ((Fintype.card a : ℂ)⁻¹ : ℂ) •
        symmetricProjectionMatrix (a := a) 1 := by
  simpa using
    pureHaarOrbitMoment_eq_inv_choose_smul_symmetricProjectionMatrix 1 ν

/-- Second Haar moment used in `main.tex`. -/
theorem pureHaarOrbitMoment_two
    {a : Type*} [Fintype a] [DecidableEq a] [Nonempty a]
    (ν : PureVector a) :
    pureHaarOrbitMoment 2 ν =
      ((Nat.choose (Fintype.card a + 1) 2 : ℂ)⁻¹ : ℂ) •
        symmetricProjectionMatrix (a := a) 2 := by
  simpa using
    pureHaarOrbitMoment_eq_inv_choose_smul_symmetricProjectionMatrix 2 ν

/-- Third Haar moment used in `main.tex`. -/
theorem pureHaarOrbitMoment_three
    {a : Type*} [Fintype a] [DecidableEq a] [Nonempty a]
    (ν : PureVector a) :
    pureHaarOrbitMoment 3 ν =
      ((Nat.choose (Fintype.card a + 2) 3 : ℂ)⁻¹ : ℂ) •
        symmetricProjectionMatrix (a := a) 3 := by
  simpa using
    pureHaarOrbitMoment_eq_inv_choose_smul_symmetricProjectionMatrix 3 ν

end

end EntanglementPurification
