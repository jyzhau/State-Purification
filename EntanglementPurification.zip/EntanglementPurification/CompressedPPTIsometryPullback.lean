import EntanglementPurification.PPTCompressedInstrument
import EntanglementPurification.PureSchmidtIsometry
import Mathlib.Tactic

/-!
# Pulling compressed PPT data back along local isometries

This module implements the change of Schmidt coordinates used in the paper.
If `V_A : s_A → r_A` and `V_B : s_B → r_B` are local isometries, every
resource operator is compressed by `V_A ⊗ V_B`.  Positivity, Bob-PPT,
completeness, resource insertion, and the four-sector identities are preserved.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

universe uA uB vA vB

variable {sA : Type uA} {sB : Type uB} {rA : Type vA} {rB : Type vB}
variable [Fintype sA] [DecidableEq sA] [Fintype sB] [DecidableEq sB]
variable [Fintype rA] [DecidableEq rA] [Fintype rB] [DecidableEq rB]

/-- Entrywise complex conjugate of a reference isometry.  This is the Bob-side
isometry appearing after partial transpose. -/
def conjugateReferenceIsometry (V : ReferenceIsometry sB rB) :
    ReferenceIsometry sB rB where
  matrix := V.matrix.map star
  isometry := by
    ext i j
    simpa [Matrix.mul_apply, Matrix.conjTranspose_apply, Matrix.one_apply]
      using V.sum_mul_star i j

@[simp]
theorem conjugateReferenceIsometry_matrix
    (V : ReferenceIsometry sB rB) :
    (conjugateReferenceIsometry V).matrix = V.matrix.map star := rfl

/-- Product local isometry on the bipartite resource register. -/
def localResourceIsometry
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB) :
    ReferenceIsometry (sA × sB) (rA × rB) :=
  VA.prod VB

/-- Bob-conjugated product isometry used after partial transpose. -/
def localResourcePPTIsometry
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB) :
    ReferenceIsometry (sA × sB) (rA × rB) :=
  VA.prod (conjugateReferenceIsometry VB)

/-- Compression of an ambient resource operator to the Schmidt source
register. -/
def localResourcePullback
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (X : CMatrix (rA × rB)) : CMatrix (sA × sB) :=
  Matrix.conjTranspose (localResourceIsometry VA VB).matrix * X *
    (localResourceIsometry VA VB).matrix

/-- Compression of a four-sector resource operator. -/
def localSectorResourceIsometry
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB) :
    ReferenceIsometry (LocalMultiplicitySector × (sA × sB))
      (LocalMultiplicitySector × (rA × rB)) :=
  let sectorId : ReferenceIsometry LocalMultiplicitySector
      LocalMultiplicitySector :=
    ReferenceIsometry.ofEquiv (Equiv.refl LocalMultiplicitySector)
  sectorId.prod (localResourceIsometry VA VB)

/-- Compression of a four-sector resource operator. -/
def localSectorResourcePullback
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (K : CMatrix (LocalMultiplicitySector × (rA × rB))) :
    CMatrix (LocalMultiplicitySector × (sA × sB)) :=
  Matrix.conjTranspose (localSectorResourceIsometry VA VB).matrix * K *
    (localSectorResourceIsometry VA VB).matrix

/-- Four-sector version of the Bob-conjugated product isometry.  The sector
register is left unchanged; only Bob's resource isometry is conjugated. -/
def localSectorResourcePPTIsometry
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB) :
    ReferenceIsometry (LocalMultiplicitySector × (sA × sB))
      (LocalMultiplicitySector × (rA × rB)) :=
  let sectorId : ReferenceIsometry LocalMultiplicitySector
      LocalMultiplicitySector :=
    ReferenceIsometry.ofEquiv (Equiv.refl LocalMultiplicitySector)
  sectorId.prod (localResourcePPTIsometry VA VB)

theorem localResourcePullback_posSemidef
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    {X : CMatrix (rA × rB)} (hX : X.PosSemidef) :
    (localResourcePullback VA VB X).PosSemidef := by
  exact hX.conjTranspose_mul_mul_same (localResourceIsometry VA VB).matrix

theorem localSectorResourcePullback_posSemidef
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    {K : CMatrix (LocalMultiplicitySector × (rA × rB))}
    (hK : K.PosSemidef) :
    (localSectorResourcePullback VA VB K).PosSemidef := by
  exact hK.conjTranspose_mul_mul_same
    (localSectorResourceIsometry VA VB).matrix

@[simp]
theorem localResourcePullback_one
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB) :
    localResourcePullback VA VB (1 : CMatrix (rA × rB)) = 1 := by
  simpa [localResourcePullback] using (localResourceIsometry VA VB).isometry

theorem localResourcePullback_add
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (X Y : CMatrix (rA × rB)) :
    localResourcePullback VA VB (X + Y) =
      localResourcePullback VA VB X + localResourcePullback VA VB Y := by
  simp [localResourcePullback, Matrix.mul_add, Matrix.add_mul]

theorem localResourcePullback_smul
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (c : ℝ) (X : CMatrix (rA × rB)) :
    localResourcePullback VA VB (c • X) =
      c • localResourcePullback VA VB X := by
  simp [localResourcePullback, Matrix.mul_smul, Matrix.smul_mul]

/-- Sequential left/right action on a pure vector is multiplication by the
Kronecker product isometry. -/
theorem localResourceIsometry_mulVec_amp
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (psi : PureVector (sA × sB)) :
    (localResourceIsometry VA VB).matrix.mulVec psi.amp =
      (VA.applyPureVector (VB.applyPureVectorRight psi)).amp := by
  funext x
  rcases x with ⟨a, b⟩
  simp [localResourceIsometry, ReferenceIsometry.prod,
    ReferenceIsometry.applyPureVector_amp, ReferenceIsometry.applyAmp,
    ReferenceIsometry.applyPureVectorRight_amp,
    ReferenceIsometry.applyAmpRight, Matrix.mulVec, dotProduct,
    Matrix.kronecker, Matrix.kroneckerMap_apply, Fintype.sum_prod_type,
    Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i hi
  apply Finset.sum_congr rfl
  intro j hj
  ring

/-- The sector/product isometry sends a source resource embedding to the
embedding of the isometrically embedded resource vector. -/
theorem localSectorResourceIsometry_mul_sectorResourceEmbedding
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (eta : sA × sB → ℂ) :
    (localSectorResourceIsometry VA VB).matrix *
        sectorResourceEmbedding eta =
      sectorResourceEmbedding
        ((localResourceIsometry VA VB).matrix.mulVec eta) := by
  ext p z
  rcases p with ⟨s, ⟨a, b⟩⟩
  by_cases hsz : s = z <;>
    simp [localSectorResourceIsometry, localResourceIsometry,
    ReferenceIsometry.prod, ReferenceIsometry.ofEquiv,
    sectorResourceEmbedding, Matrix.mul_apply, Matrix.mulVec, dotProduct,
    Matrix.kronecker, Matrix.kroneckerMap_apply, Fintype.sum_prod_type,
    apply_ite, hsz]

/-- Pure-resource insertion commutes with local-isometry compression. -/
theorem insertPureResourceBlock_localSectorResourcePullback
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (eta : sA × sB → ℂ)
    (K : CMatrix (LocalMultiplicitySector × (rA × rB))) :
    insertPureResourceBlock eta (localSectorResourcePullback VA VB K) =
      insertPureResourceBlock
        ((localResourceIsometry VA VB).matrix.mulVec eta) K := by
  rw [insertPureResourceBlock, insertPureResourceBlock,
    localSectorResourcePullback]
  rw [show
      Matrix.conjTranspose (sectorResourceEmbedding eta) *
          (Matrix.conjTranspose
              (localSectorResourceIsometry VA VB).matrix * K *
            (localSectorResourceIsometry VA VB).matrix) *
          sectorResourceEmbedding eta =
        Matrix.conjTranspose
            ((localSectorResourceIsometry VA VB).matrix *
              sectorResourceEmbedding eta) * K *
            ((localSectorResourceIsometry VA VB).matrix *
              sectorResourceEmbedding eta) by
      rw [Matrix.conjTranspose_mul]
      simp only [Matrix.mul_assoc]]
  rw [localSectorResourceIsometry_mul_sectorResourceEmbedding]

/-- Compression preserves the resource quadratic form after moving the vector
through the local isometry. -/
theorem localResourcePullback_quadratic
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (eta : sA × sB → ℂ) (X : CMatrix (rA × rB)) :
    dotProduct (star eta)
        ((localResourcePullback VA VB X).mulVec eta) =
      dotProduct
        (star ((localResourceIsometry VA VB).matrix.mulVec eta))
        (X.mulVec ((localResourceIsometry VA VB).matrix.mulVec eta)) := by
  rw [localResourcePullback]
  rw [← Matrix.mulVec_mulVec]
  rw [← Matrix.mulVec_mulVec]
  rw [Matrix.dotProduct_mulVec]
  rw [← Matrix.star_mulVec]

/-- Resource-sector blocks commute with local-isometry pullback. -/
theorem resourceSectorBlock_localSectorResourcePullback
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (K : CMatrix (LocalMultiplicitySector × (rA × rB)))
    (z w : LocalMultiplicitySector) :
    resourceSectorBlock (localSectorResourcePullback VA VB K) z w =
      localResourcePullback VA VB (resourceSectorBlock K z w) := by
  ext i j
  rcases i with ⟨iA, iB⟩
  rcases j with ⟨jA, jB⟩
  simp [localSectorResourcePullback, localSectorResourceIsometry,
    localResourcePullback, localResourceIsometry, ReferenceIsometry.prod,
    ReferenceIsometry.ofEquiv, resourceSectorBlock, Matrix.mul_apply,
    Matrix.conjTranspose_apply, Matrix.kronecker,
    Matrix.kroneckerMap_apply, Fintype.sum_prod_type, apply_ite]

/-- Rectangular Kronecker sandwich covariance of Bob partial transpose. -/
theorem partialTransposeB_kronecker_sandwich_rectangular
    {A A' B B' : Type*}
    [Fintype A] [Fintype A'] [Fintype B] [Fintype B']
    (LA : Matrix A' A ℂ) (RA : Matrix A A' ℂ)
    (LB : Matrix B' B ℂ) (RB : Matrix B B' ℂ)
    (X : CMatrix (A × B)) :
    QIT.partialTransposeB
        (Matrix.kronecker LA LB * X * Matrix.kronecker RA RB) =
      Matrix.kronecker LA (Matrix.transpose RB) *
        QIT.partialTransposeB X *
          Matrix.kronecker RA (Matrix.transpose LB) := by
  unfold Matrix.kronecker
  ext ⟨i, j⟩ ⟨k, l⟩
  simp only [QIT.partialTransposeB_apply, Matrix.mul_apply,
    Fintype.sum_prod_type, Matrix.kroneckerMap_apply, Matrix.transpose_apply]
  simp_rw [Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro x hx
  rw [Finset.sum_comm]
  conv_rhs => rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro y hy
  conv_rhs => rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro q hq
  apply Finset.sum_congr rfl
  intro t ht
  ring

/-- Local pullback turns Bob-PPT positivity into an ordinary PSD sandwich by
the Bob-conjugated local isometry. -/
theorem partialTransposeB_localResourcePullback
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (X : CMatrix (rA × rB)) :
    QIT.partialTransposeB (localResourcePullback VA VB X) =
      Matrix.conjTranspose (localResourcePPTIsometry VA VB).matrix *
        QIT.partialTransposeB X *
          (localResourcePPTIsometry VA VB).matrix := by
  rw [localResourcePullback]
  change QIT.partialTransposeB
      (Matrix.conjTranspose (Matrix.kronecker VA.matrix VB.matrix) * X *
        Matrix.kronecker VA.matrix VB.matrix) = _
  rw [show (Matrix.kronecker VA.matrix VB.matrix).conjTranspose =
      Matrix.kronecker VA.matrix.conjTranspose VB.matrix.conjTranspose from
    Matrix.conjTranspose_kronecker VA.matrix VB.matrix]
  rw [partialTransposeB_kronecker_sandwich_rectangular]
  change
    Matrix.kronecker VA.matrix.conjTranspose VB.matrix.transpose *
          QIT.partialTransposeB X *
        Matrix.kronecker VA.matrix VB.matrix.conjTranspose.transpose =
      Matrix.conjTranspose
          (Matrix.kronecker VA.matrix (VB.matrix.map star)) *
        QIT.partialTransposeB X *
          Matrix.kronecker VA.matrix (VB.matrix.map star)
  rw [show (Matrix.kronecker VA.matrix (VB.matrix.map star)).conjTranspose =
      Matrix.kronecker VA.matrix.conjTranspose
        (VB.matrix.map star).conjTranspose from
    Matrix.conjTranspose_kronecker VA.matrix (VB.matrix.map star)]
  have hleft :
      (VB.matrix.map star).conjTranspose = VB.matrix.transpose := by
    ext i j
    simp [Matrix.conjTranspose_apply]
  have hright :
      VB.matrix.conjTranspose.transpose = VB.matrix.map star :=
    Matrix.transpose_conjTranspose VB.matrix
  rw [hleft, hright]

theorem partialTransposeB_localResourcePullback_posSemidef
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    {X : CMatrix (rA × rB)}
    (hX : (QIT.partialTransposeB X).PosSemidef) :
    (QIT.partialTransposeB (localResourcePullback VA VB X)).PosSemidef := by
  rw [partialTransposeB_localResourcePullback]
  exact hX.conjTranspose_mul_mul_same (localResourcePPTIsometry VA VB).matrix

/-- The sector/resource partial transpose is covariant under compression by
local isometries. -/
theorem sectorResourcePartialTransposeB_localSectorResourcePullback
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (K : CMatrix (LocalMultiplicitySector × (rA × rB))) :
    sectorResourcePartialTransposeB
        (localSectorResourcePullback VA VB K) =
      localSectorResourcePullback VA (conjugateReferenceIsometry VB)
        (sectorResourcePartialTransposeB K) := by
  ext p q
  rcases p with ⟨⟨s₁, s₂⟩, ⟨a, b⟩⟩
  rcases q with ⟨⟨t₁, t₂⟩, ⟨c, e⟩⟩
  have hblock :
      resourceSectorBlock
          (sectorResourcePartialTransposeB
            (localSectorResourcePullback VA VB K))
          (s₁, s₂) (t₁, t₂) =
        resourceSectorBlock
          (localSectorResourcePullback VA (conjugateReferenceIsometry VB)
            (sectorResourcePartialTransposeB K))
          (s₁, s₂) (t₁, t₂) := by
    calc
      _ = QIT.partialTransposeB
          (resourceSectorBlock (localSectorResourcePullback VA VB K)
            (s₁, t₂) (t₁, s₂)) :=
        resourceSectorBlock_sectorResourcePartialTransposeB
          (localSectorResourcePullback VA VB K) s₁ t₂ t₁ s₂
      _ = QIT.partialTransposeB
          (localResourcePullback VA VB
            (resourceSectorBlock K (s₁, t₂) (t₁, s₂))) := by
        rw [resourceSectorBlock_localSectorResourcePullback]
      _ = localResourcePullback VA (conjugateReferenceIsometry VB)
          (QIT.partialTransposeB
            (resourceSectorBlock K (s₁, t₂) (t₁, s₂))) := by
        rw [partialTransposeB_localResourcePullback]
        rfl
      _ = localResourcePullback VA (conjugateReferenceIsometry VB)
          (resourceSectorBlock (sectorResourcePartialTransposeB K)
            (s₁, s₂) (t₁, t₂)) := by
        rw [resourceSectorBlock_sectorResourcePartialTransposeB
          K s₁ t₂ t₁ s₂]
      _ = _ := by
        rw [resourceSectorBlock_localSectorResourcePullback]
  exact congr_fun (congr_fun hblock (a, b)) (c, e)

theorem sectorResourcePartialTransposeB_localSectorResourcePullback_posSemidef
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    {K : CMatrix (LocalMultiplicitySector × (rA × rB))}
    (hK : (sectorResourcePartialTransposeB K).PosSemidef) :
    (sectorResourcePartialTransposeB
      (localSectorResourcePullback VA VB K)).PosSemidef := by
  rw [sectorResourcePartialTransposeB_localSectorResourcePullback]
  exact localSectorResourcePullback_posSemidef VA
    (conjugateReferenceIsometry VB) hK

/-- Pull a complete compressed PPT certificate back to smaller Schmidt
coordinates.  Every structural field of `CompressedPPTInstrumentData` is
transported, including the optimal inserted block and both vanishing cross
sector quadratic forms. -/
def CompressedPPTInstrumentData.pullbackLocalIsometries
    {d : ℕ}
    (data : CompressedPPTInstrumentData d rA rB)
    (target : PureVector (sA × sB))
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (hresource :
      data.resource = VA.applyPureVector (VB.applyPureVectorRight target)) :
    CompressedPPTInstrumentData d sA sB := by
  have hamp :
      (localResourceIsometry VA VB).matrix.mulVec target.amp =
        data.resource.amp := by
    rw [localResourceIsometry_mulVec_amp]
    exact (congrArg (fun psi : PureVector (rA × rB) => psi.amp)
      hresource).symm
  exact
    { resource := target
      success := localSectorResourcePullback VA VB data.success
      outputSuccess := fun z =>
        localResourcePullback VA VB (data.outputSuccess z)
      outputFailure := fun z =>
        localResourcePullback VA VB (data.outputFailure z)
      residualSuccess := fun z =>
        localResourcePullback VA VB (data.residualSuccess z)
      success_branchPPT := by
        exact ⟨
          localSectorResourcePullback_posSemidef VA VB
            data.success_branchPPT.1,
          sectorResourcePartialTransposeB_localSectorResourcePullback_posSemidef
            VA VB data.success_branchPPT.2⟩
      outputSuccess_pos := by
        intro z
        exact localResourcePullback_posSemidef VA VB
          (data.outputSuccess_pos z)
      outputFailure_pos := by
        intro z
        exact localResourcePullback_posSemidef VA VB
          (data.outputFailure_pos z)
      outputFailure_ppt := by
        intro z
        exact partialTransposeB_localResourcePullback_posSemidef VA VB
          (data.outputFailure_ppt z)
      output_complement := by
        intro z
        calc
          localResourcePullback VA VB (data.outputSuccess z) +
                localResourcePullback VA VB (data.outputFailure z) =
              localResourcePullback VA VB
                (data.outputSuccess z + data.outputFailure z) :=
            (localResourcePullback_add VA VB _ _).symm
          _ = localResourcePullback VA VB 1 := by
            rw [data.output_complement z]
          _ = 1 := localResourcePullback_one VA VB
      success_trace_decomposition := by
        intro z
        rw [resourceSectorBlock_localSectorResourcePullback]
        calc
          localResourcePullback VA VB (data.outputSuccess z) =
              localResourcePullback VA VB
                (localSectorTraceScale d z •
                    resourceSectorBlock data.success z z +
                  data.residualSuccess z) := by
            rw [data.success_trace_decomposition z]
          _ = localResourcePullback VA VB
                (localSectorTraceScale d z •
                  resourceSectorBlock data.success z z) +
              localResourcePullback VA VB (data.residualSuccess z) :=
            localResourcePullback_add VA VB _ _
          _ = localSectorTraceScale d z •
                localResourcePullback VA VB
                  (resourceSectorBlock data.success z z) +
              localResourcePullback VA VB (data.residualSuccess z) := by
            rw [localResourcePullback_smul]
      residualSuccess_pos := by
        intro z
        exact localResourcePullback_posSemidef VA VB
          (data.residualSuccess_pos z)
      inserted_optimal := by
        rw [insertPureResourceBlock_localSectorResourcePullback]
        rw [hamp]
        exact data.inserted_optimal
      zero_output_PM := by
        rw [localResourcePullback_quadratic, hamp]
        exact data.zero_output_PM
      zero_output_MP := by
        rw [localResourcePullback_quadratic, hamp]
        exact data.zero_output_MP }

end

end EntanglementPurification
