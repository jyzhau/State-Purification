import EntanglementPurification.GlobalSDP
import QIT.Core.Map.ChoiCharacterization
import Mathlib.Tactic

/-!
# Choi representation of the global performance objective

This file records the trace-pairing identity which turns an operational
matrix-map objective into the input-first Choi-matrix objective used by the
global SDP.  The transpose on the input observable is forced by Lean-QIT's
convention

`choi Phi (i, j) (i', j') = Phi (Matrix.single i i' 1) j j'`.
-/

namespace EntanglementPurification

open QIT

noncomputable section

universe u v

variable {x : Type u} {y : Type v}
variable [Fintype x] [DecidableEq x] [Fintype y] [DecidableEq y]

/-- Reindex the four finite sums in exactly the order needed below. -/
private theorem sum_four_rotate
    {a b c d : Type*} [Fintype a] [Fintype b] [Fintype c] [Fintype d]
    (f : a → b → c → d → ℂ) :
    (∑ i, ∑ j, ∑ k, ∑ l, f i j k l) =
      ∑ l, ∑ i, ∑ k, ∑ j, f i j k l := by
  classical
  calc
    (∑ i, ∑ j, ∑ k, ∑ l, f i j k l) =
        ∑ i, ∑ j, ∑ l, ∑ k, f i j k l := by
      apply Finset.sum_congr rfl
      intro i _
      apply Finset.sum_congr rfl
      intro j _
      rw [Finset.sum_comm]
    _ = ∑ i, ∑ l, ∑ j, ∑ k, f i j k l := by
      apply Finset.sum_congr rfl
      intro i _
      rw [Finset.sum_comm]
    _ = ∑ l, ∑ i, ∑ j, ∑ k, f i j k l := by
      rw [Finset.sum_comm]
    _ = ∑ l, ∑ i, ∑ k, ∑ j, f i j k l := by
      apply Finset.sum_congr rfl
      intro l _
      apply Finset.sum_congr rfl
      intro i _
      rw [Finset.sum_comm]

/-- Trace pairing with a map reconstructed from an arbitrary input-first
Choi matrix. -/
theorem trace_mul_ofChoiMatrix_eq_trace_kronecker_transpose_mul
    (J : CMatrix (Prod x y)) (X : CMatrix x) (B : CMatrix y) :
    (B * MatrixMap.ofChoiMatrix J X).trace =
      (Matrix.kronecker X.transpose B * J).trace := by
  simp only [Matrix.trace, Matrix.diag, Matrix.mul_apply,
    MatrixMap.ofChoiMatrix_apply, Matrix.kronecker,
    Matrix.kroneckerMap_apply, Matrix.transpose_apply,
    Fintype.sum_prod_type, Finset.mul_sum]
  simpa only [mul_assoc, mul_comm, mul_left_comm] using
    (sum_four_rotate
      (fun j k i i' ↦ B j k * (X i i' * J (i, k) (i', j))))

/-- Exact Choi objective identity for Lean-QIT's input-first convention. -/
theorem trace_mul_map_eq_trace_kronecker_transpose_mul_choi
    (Phi : MatrixMap x y) (X : CMatrix x) (B : CMatrix y) :
    (B * Phi X).trace =
      (Matrix.kronecker X.transpose B * MatrixMap.choi Phi).trace := by
  calc
    (B * Phi X).trace =
        (B * MatrixMap.ofChoiMatrix (MatrixMap.choi Phi) X).trace := by
      rw [MatrixMap.ofChoiMatrix_choi]
    _ = (Matrix.kronecker X.transpose B * MatrixMap.choi Phi).trace :=
      trace_mul_ofChoiMatrix_eq_trace_kronecker_transpose_mul
        (MatrixMap.choi Phi) X B

/-- Real-part version of the input-first Choi objective identity. -/
theorem trace_mul_map_re_eq_globalSDPObjective_choi
    (Phi : MatrixMap x y) (X : CMatrix x) (B : CMatrix y) :
    ((B * Phi X).trace).re =
      globalSDPObjective (Matrix.kronecker X.transpose B) (MatrixMap.choi Phi) := by
  rw [globalSDPObjective,
    trace_mul_map_eq_trace_kronecker_transpose_mul_choi]

/-- Specialized real SDP objective for a map reconstructed from a supplied
Choi matrix. -/
theorem trace_mul_ofChoiMatrix_re_eq_globalSDPObjective
    (J : CMatrix (Prod x y)) (X : CMatrix x) (B : CMatrix y) :
    ((B * MatrixMap.ofChoiMatrix J X).trace).re =
      globalSDPObjective (Matrix.kronecker X.transpose B) J := by
  rw [globalSDPObjective,
    trace_mul_ofChoiMatrix_eq_trace_kronecker_transpose_mul]

end

end EntanglementPurification
