import EntanglementPurification.LocalMixedSchurCompleteness
import EntanglementPurification.LocalMixedSchurReducing
import EntanglementPurification.JointContractionSchur
import EntanglementPurification.JointContractionReducing

/-!
# Physical invariance makes the joint contraction range reducing

This module supplies the missing representation-theoretic bridge between the
paper-form local-unitary invariance of a physical joint operator and the
range-reducing hypothesis used by `JointContractionReducing`.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b r : Type*}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

/-- The joint contraction projection is the tensor product of the two local
contraction projections and the identity on the resource spectator. -/
theorem jointContractionRangeProjection_eq_local_kronecker :
    jointContractionRangeProjection (a := a) (b := b) (r := r) =
      Matrix.kronecker
        (Matrix.kronecker
          (localContractionRangeProjection (x := a))
          (localContractionRangeProjection (x := b)))
        (1 : CMatrix r) := by
  let e := jointContractionCoordinateEquiv (a := a) (b := b) (r := r)
  let G := jointContractionCanonicalIsometry (a := a) (b := b) (r := r)
  unfold jointContractionRangeProjection jointContractionIsometry
  rw [Matrix.conjTranspose_reindex]
  have hmul :
      Matrix.reindex
          (Equiv.refl (JointContractionPhysicalIndex a b r)) e G *
        Matrix.reindex e
          (Equiv.refl (JointContractionPhysicalIndex a b r))
          (Matrix.conjTranspose G) =
      Matrix.reindex
          (Equiv.refl (JointContractionPhysicalIndex a b r))
          (Equiv.refl (JointContractionPhysicalIndex a b r))
          (G * Matrix.conjTranspose G) := by
    simp
  rw [hmul]
  change G * Matrix.conjTranspose G = _
  dsimp [G, jointContractionCanonicalIsometry]
  rw [Matrix.conjTranspose_kronecker]
  rw [← Matrix.mul_kronecker_mul]
  rw [Matrix.conjTranspose_kronecker]
  rw [← Matrix.mul_kronecker_mul]
  simp [localContractionRangeProjection]

/-- The local Alice contraction projector, extended over Bob and the resource. -/
private def jointAliceContractionRangeProjection :
    CMatrix (JointContractionPhysicalIndex a b r) :=
  Matrix.kronecker
    (Matrix.kronecker
      (localContractionRangeProjection (x := a))
      (1 : CMatrix (LocalMixedSchurSpace b)))
    (1 : CMatrix r)

/-- The local Bob contraction projector, extended over Alice and the resource. -/
private def jointBobContractionRangeProjection :
    CMatrix (JointContractionPhysicalIndex a b r) :=
  Matrix.kronecker
    (Matrix.kronecker
      (1 : CMatrix (LocalMixedSchurSpace a))
      (localContractionRangeProjection (x := b)))
    (1 : CMatrix r)

/-- Intersecting the independently extended local contraction ranges gives
the joint contraction range. -/
private theorem jointAlice_mul_jointBob_rangeProjection :
    jointAliceContractionRangeProjection (a := a) (b := b) (r := r) *
        jointBobContractionRangeProjection =
      jointContractionRangeProjection := by
  rw [jointContractionRangeProjection_eq_local_kronecker]
  unfold jointAliceContractionRangeProjection
    jointBobContractionRangeProjection
  unfold Matrix.kronecker
  rw [← Matrix.mul_kronecker_mul]
  rw [← Matrix.mul_kronecker_mul]
  simp

/-- Reassociate the physical tensor factors with Alice first. -/
private def jointAliceSpectatorEquiv :
    JointContractionPhysicalIndex a b r ≃
      LocalMixedSchurSpace a × (LocalMixedSchurSpace b × r) where
  toFun q := (q.1.1, (q.1.2, q.2))
  invFun q := ((q.1, q.2.1), q.2.2)
  left_inv q := by rcases q with ⟨⟨uA, uB⟩, z⟩; rfl
  right_inv q := by rcases q with ⟨uA, uB, z⟩; rfl

/-- Reorder the physical tensor factors with Bob first. -/
private def jointBobSpectatorEquiv :
    JointContractionPhysicalIndex a b r ≃
      LocalMixedSchurSpace b × (LocalMixedSchurSpace a × r) where
  toFun q := (q.1.2, (q.1.1, q.2))
  invFun q := ((q.2.1, q.1), q.2.2)
  left_inv q := by rcases q with ⟨⟨uA, uB⟩, z⟩; rfl
  right_inv q := by rcases q with ⟨uB, uA, z⟩; rfl

/-- With Bob's unitary set to the identity, reassociation exposes exactly an
Alice mixed-Schur representation amplified by an inert spectator. -/
private theorem reindex_jointPhysicalRepresentation_alice
    (U : Matrix.unitaryGroup a ℂ) :
    Matrix.reindex jointAliceSpectatorEquiv jointAliceSpectatorEquiv
        (jointContractionPhysicalRepresentation (r := r) U
          (1 : Matrix.unitaryGroup b ℂ)) =
      Matrix.kronecker (localMixedSchurRepresentation U)
        (1 : CMatrix (LocalMixedSchurSpace b × r)) := by
  ext ⟨uA, uB, z⟩ ⟨vA, vB, z'⟩
  simp [jointAliceSpectatorEquiv,
    jointContractionPhysicalRepresentation,
    localMixedSchurRepresentation, localEntrywiseConjugate,
    Matrix.reindex_apply, Matrix.kronecker, Matrix.one_apply,
    Prod.ext_iff]
  split_ifs <;> simp_all

/-- With Alice's unitary set to the identity, reordering exposes exactly a
Bob mixed-Schur representation amplified by an inert spectator. -/
private theorem reindex_jointPhysicalRepresentation_bob
    (V : Matrix.unitaryGroup b ℂ) :
    Matrix.reindex jointBobSpectatorEquiv jointBobSpectatorEquiv
        (jointContractionPhysicalRepresentation (r := r)
          (1 : Matrix.unitaryGroup a ℂ) V) =
      Matrix.kronecker (localMixedSchurRepresentation V)
        (1 : CMatrix (LocalMixedSchurSpace a × r)) := by
  ext ⟨uB, uA, z⟩ ⟨vB, vA, z'⟩
  simp [jointBobSpectatorEquiv,
    jointContractionPhysicalRepresentation,
    localMixedSchurRepresentation, localEntrywiseConjugate,
    Matrix.reindex_apply, Matrix.kronecker, Matrix.one_apply,
    Prod.ext_iff]
  split_ifs <;> simp_all

/-- Alice's extended physical projector becomes the standard amplified local
projector after reassociation. -/
private theorem reindex_jointAliceContractionRangeProjection :
    Matrix.reindex jointAliceSpectatorEquiv jointAliceSpectatorEquiv
        (jointAliceContractionRangeProjection (a := a) (b := b) (r := r)) =
      localAmplifiedContractionRangeProjection
        (x := a) (s := LocalMixedSchurSpace b × r) := by
  rw [localAmplifiedContractionRangeProjection_eq_kronecker]
  ext ⟨uA, uB, z⟩ ⟨vA, vB, z'⟩
  simp [jointAliceSpectatorEquiv,
    jointAliceContractionRangeProjection,
    Matrix.reindex_apply, Matrix.kronecker, Matrix.one_apply,
    Prod.ext_iff]
  split_ifs <;> simp_all

/-- Bob's extended physical projector becomes the standard amplified local
projector after reordering. -/
private theorem reindex_jointBobContractionRangeProjection :
    Matrix.reindex jointBobSpectatorEquiv jointBobSpectatorEquiv
        (jointBobContractionRangeProjection (a := a) (b := b) (r := r)) =
      localAmplifiedContractionRangeProjection
        (x := b) (s := LocalMixedSchurSpace a × r) := by
  rw [localAmplifiedContractionRangeProjection_eq_kronecker]
  ext ⟨uB, uA, z⟩ ⟨vB, vA, z'⟩
  simp [jointBobSpectatorEquiv,
    jointBobContractionRangeProjection,
    Matrix.reindex_apply, Matrix.kronecker, Matrix.one_apply,
    Prod.ext_iff]
  split_ifs <;> simp_all

/-- Simultaneous row/column reindexing preserves multiplication. -/
private theorem reindex_mul
    {i j : Type*} [Fintype i] [Fintype j]
    (e : i ≃ j) (A K : CMatrix i) :
    Matrix.reindex e e (A * K) =
      Matrix.reindex e e A * Matrix.reindex e e K := by
  symm
  simp

/-- Simultaneous row/column reindexing preserves a conjugation product. -/
private theorem reindex_conjugation
    {i j : Type*} [Fintype i] [Fintype j]
    (e : i ≃ j) (A K : CMatrix i) :
    Matrix.reindex e e (A * K * Matrix.conjTranspose A) =
      Matrix.reindex e e A * Matrix.reindex e e K *
        Matrix.conjTranspose (Matrix.reindex e e A) := by
  rw [Matrix.conjTranspose_reindex]
  symm
  have hAK :
      Matrix.reindex e e A * Matrix.reindex e e K =
        Matrix.reindex e e (A * K) := by
    simp
  have hAKA :
      Matrix.reindex e e (A * K) *
          Matrix.reindex e e (Matrix.conjTranspose A) =
        Matrix.reindex e e (A * K * Matrix.conjTranspose A) := by
    simp
  rw [hAK, hAKA]

/-- Joint physical invariance restricted to Alice becomes precisely the
amplified one-side invariance after reassociation. -/
private theorem reindex_alice_isLocalAmplifiedInvariant
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K) :
    IsLocalAmplifiedMixedSchurInvariant
      (Matrix.reindex jointAliceSpectatorEquiv jointAliceSpectatorEquiv K) := by
  intro U
  change Matrix.kronecker (localMixedSchurRepresentation U)
          (1 : CMatrix (LocalMixedSchurSpace b × r)) *
        Matrix.reindex jointAliceSpectatorEquiv jointAliceSpectatorEquiv K *
        Matrix.conjTranspose
          (Matrix.kronecker (localMixedSchurRepresentation U)
            (1 : CMatrix (LocalMixedSchurSpace b × r))) =
      Matrix.reindex jointAliceSpectatorEquiv jointAliceSpectatorEquiv K
  rw [← reindex_jointPhysicalRepresentation_alice]
  rw [← reindex_conjugation]
  exact congrArg
    (Matrix.reindex jointAliceSpectatorEquiv jointAliceSpectatorEquiv)
    (hInvariant U (1 : Matrix.unitaryGroup b ℂ))

/-- Joint physical invariance restricted to Bob becomes precisely the
amplified one-side invariance after reordering. -/
private theorem reindex_bob_isLocalAmplifiedInvariant
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K) :
    IsLocalAmplifiedMixedSchurInvariant
      (Matrix.reindex jointBobSpectatorEquiv jointBobSpectatorEquiv K) := by
  intro V
  change Matrix.kronecker (localMixedSchurRepresentation V)
          (1 : CMatrix (LocalMixedSchurSpace a × r)) *
        Matrix.reindex jointBobSpectatorEquiv jointBobSpectatorEquiv K *
        Matrix.conjTranspose
          (Matrix.kronecker (localMixedSchurRepresentation V)
            (1 : CMatrix (LocalMixedSchurSpace a × r))) =
      Matrix.reindex jointBobSpectatorEquiv jointBobSpectatorEquiv K
  rw [← reindex_jointPhysicalRepresentation_bob]
  rw [← reindex_conjugation]
  exact congrArg
    (Matrix.reindex jointBobSpectatorEquiv jointBobSpectatorEquiv)
    (hInvariant (1 : Matrix.unitaryGroup a ℂ) V)

/-- Physical invariance and Hermiticity make K commute with Alice's
contraction-range projector, extended over Bob and the resource. -/
private theorem jointAliceContractionRangeProjection_commutes
    (hcardA : 2 ≤ Fintype.card a)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K)
    (hHermitian : K.IsHermitian) :
    jointAliceContractionRangeProjection (a := a) (b := b) (r := r) * K =
      K * jointAliceContractionRangeProjection := by
  let e := jointAliceSpectatorEquiv (a := a) (b := b) (r := r)
  let K' : CMatrix
      (LocalAmplifiedMixedSchurSpace a (LocalMixedSchurSpace b × r)) :=
    Matrix.reindex e e K
  have hInvariant' : IsLocalAmplifiedMixedSchurInvariant K' := by
    simpa [e, K'] using
      reindex_alice_isLocalAmplifiedInvariant hInvariant
  have hHermitian' : K'.IsHermitian := by
    exact hHermitian.reindex e
  have hcomm :
      localAmplifiedContractionRangeProjection
            (x := a) (s := LocalMixedSchurSpace b × r) * K' =
        K' * localAmplifiedContractionRangeProjection :=
    localAmplifiedInvariant_commutes_contractionRangeProjection
      hcardA hInvariant' hHermitian'
  have hcomm' :
      Matrix.reindex e e jointAliceContractionRangeProjection *
          Matrix.reindex e e K =
        Matrix.reindex e e K *
          Matrix.reindex e e jointAliceContractionRangeProjection := by
    have hPA :
        Matrix.reindex e e
            (jointAliceContractionRangeProjection
              (a := a) (b := b) (r := r)) =
          localAmplifiedContractionRangeProjection
            (x := a) (s := LocalMixedSchurSpace b × r) := by
      change Matrix.reindex jointAliceSpectatorEquiv
          jointAliceSpectatorEquiv jointAliceContractionRangeProjection =
        localAmplifiedContractionRangeProjection
      exact reindex_jointAliceContractionRangeProjection
    rw [hPA]
    change localAmplifiedContractionRangeProjection * K' =
      K' * localAmplifiedContractionRangeProjection
    exact hcomm
  apply (Matrix.reindexLinearEquiv ℂ ℂ e e).injective
  change Matrix.reindex e e
        (jointAliceContractionRangeProjection * K) =
      Matrix.reindex e e
        (K * jointAliceContractionRangeProjection)
  calc
    Matrix.reindex e e (jointAliceContractionRangeProjection * K) =
        Matrix.reindex e e jointAliceContractionRangeProjection *
          Matrix.reindex e e K :=
      reindex_mul e jointAliceContractionRangeProjection K
    _ = Matrix.reindex e e K *
        Matrix.reindex e e jointAliceContractionRangeProjection := hcomm'
    _ = Matrix.reindex e e
        (K * jointAliceContractionRangeProjection) :=
      (reindex_mul e K jointAliceContractionRangeProjection).symm

/-- Physical invariance and Hermiticity make K commute with Bob's
contraction-range projector, extended over Alice and the resource. -/
private theorem jointBobContractionRangeProjection_commutes
    (hcardB : 2 ≤ Fintype.card b)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K)
    (hHermitian : K.IsHermitian) :
    jointBobContractionRangeProjection (a := a) (b := b) (r := r) * K =
      K * jointBobContractionRangeProjection := by
  let e := jointBobSpectatorEquiv (a := a) (b := b) (r := r)
  let K' : CMatrix
      (LocalAmplifiedMixedSchurSpace b (LocalMixedSchurSpace a × r)) :=
    Matrix.reindex e e K
  have hInvariant' : IsLocalAmplifiedMixedSchurInvariant K' := by
    simpa [e, K'] using
      reindex_bob_isLocalAmplifiedInvariant hInvariant
  have hHermitian' : K'.IsHermitian := by
    exact hHermitian.reindex e
  have hcomm :
      localAmplifiedContractionRangeProjection
            (x := b) (s := LocalMixedSchurSpace a × r) * K' =
        K' * localAmplifiedContractionRangeProjection :=
    localAmplifiedInvariant_commutes_contractionRangeProjection
      hcardB hInvariant' hHermitian'
  have hcomm' :
      Matrix.reindex e e jointBobContractionRangeProjection *
          Matrix.reindex e e K =
        Matrix.reindex e e K *
          Matrix.reindex e e jointBobContractionRangeProjection := by
    have hPB :
        Matrix.reindex e e
            (jointBobContractionRangeProjection
              (a := a) (b := b) (r := r)) =
          localAmplifiedContractionRangeProjection
            (x := b) (s := LocalMixedSchurSpace a × r) := by
      change Matrix.reindex jointBobSpectatorEquiv
          jointBobSpectatorEquiv jointBobContractionRangeProjection =
        localAmplifiedContractionRangeProjection
      exact reindex_jointBobContractionRangeProjection
    rw [hPB]
    change localAmplifiedContractionRangeProjection * K' =
      K' * localAmplifiedContractionRangeProjection
    exact hcomm
  apply (Matrix.reindexLinearEquiv ℂ ℂ e e).injective
  change Matrix.reindex e e
        (jointBobContractionRangeProjection * K) =
      Matrix.reindex e e
        (K * jointBobContractionRangeProjection)
  calc
    Matrix.reindex e e (jointBobContractionRangeProjection * K) =
        Matrix.reindex e e jointBobContractionRangeProjection *
          Matrix.reindex e e K :=
      reindex_mul e jointBobContractionRangeProjection K
    _ = Matrix.reindex e e K *
        Matrix.reindex e e jointBobContractionRangeProjection := hcomm'
    _ = Matrix.reindex e e
        (K * jointBobContractionRangeProjection) :=
      (reindex_mul e K jointBobContractionRangeProjection).symm

/-- The final physical bridge for task D: independent local-unitary
conjugation invariance, together with Hermiticity, forces the full joint
contraction range to reduce K. No reducing or Hom-zero condition is an
input; the one-side Hom classification is supplied by
localMixedIntertwiner_eq_span_contractions through the amplified theorem. -/
theorem jointContractionRangeReducing_of_physicalInvariant
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K)
    (hHermitian : K.IsHermitian) :
    IsJointContractionRangeReducing K := by
  let PA :=
    jointAliceContractionRangeProjection (a := a) (b := b) (r := r)
  let PB :=
    jointBobContractionRangeProjection (a := a) (b := b) (r := r)
  have hA : PA * K = K * PA := by
    simpa [PA] using
      jointAliceContractionRangeProjection_commutes
        hcardA hInvariant hHermitian
  have hB : PB * K = K * PB := by
    simpa [PB] using
      jointBobContractionRangeProjection_commutes
        hcardB hInvariant hHermitian
  have hP : PA * PB =
      jointContractionRangeProjection (a := a) (b := b) (r := r) := by
    simpa [PA, PB] using
      (jointAlice_mul_jointBob_rangeProjection (a := a) (b := b) (r := r))
  rw [IsJointContractionRangeReducing, ← hP]
  calc
    (PA * PB) * K = PA * (PB * K) := by
      rw [Matrix.mul_assoc]
    _ = PA * (K * PB) := by rw [hB]
    _ = (PA * K) * PB := by rw [Matrix.mul_assoc]
    _ = (K * PA) * PB := by rw [hA]
    _ = K * (PA * PB) := by rw [Matrix.mul_assoc]

/-- Positive semidefiniteness supplies the Hermiticity required by the main
physical reducing theorem. -/
theorem jointContractionRangeReducing_of_physicalInvariant_posSemidef
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K)
    (hK : K.PosSemidef) :
    IsJointContractionRangeReducing K :=
  jointContractionRangeReducing_of_physicalInvariant
    hcardA hcardB hInvariant hK.isHermitian

end

end EntanglementPurification
