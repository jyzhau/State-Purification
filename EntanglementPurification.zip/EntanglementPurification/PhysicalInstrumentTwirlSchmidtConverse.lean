import EntanglementPurification.PhysicalInstrumentTwirlGlobalOptimalEffect
import EntanglementPurification.PPTSchmidtCertificate

/-!
# Schmidt converse for an exactly optimal twirled physical instrument

This module composes the canonical compressed-data construction for an exactly
optimal `PhysicalPPTInstrument` with the Appendix-B Schmidt converse.

The resource is explicitly the coordinate model
`ambientSignedSchmidtResource p hp`.  Thus the two endpoints below cover that
fixed signed Schmidt-coordinate realization; they do not claim a basis-free
identification for an arbitrary bipartite pure resource.
-/

namespace EntanglementPurification

open QIT

noncomputable section

/-- An exactly optimal physical PPT instrument assisted by the signed Schmidt
resource satisfies the full two-point/three-point majorization conclusion of
Appendix B after the genuine local Haar twirl. -/
theorem physicalInstrumentTwirlGlobalOptimal_implies_schmidt_majorization
    {d m : ℕ}
    (M : PhysicalPPTInstrument
      (Fin d) (Fin d) (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d)
    (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hattains :
      globalSDPObjective
          (globalPaperEq986PerformanceOperator hd nu gamma)
          (pureResourceInsert (ambientSignedSchmidtResource p hp).amp
            (MatrixMap.choi (M.instrument.branch true))) =
        globalOptimalGain ((d : ℕ) ^ 2) gamma) :
    p 0 ≤ 2 / 3 ∧
      (p 0 ≤ 1 / 2 →
        PrefixMajorizedBy p (twoPointComparison (m + 1))) ∧
      (1 / 2 < p 0 →
        zStar (p 0) ≤ tailFromTwo p ∧
        2 * (p 0 - 1 / 2) ^ 2 < tailFromTwo p ∧
        PrefixMajorizedBy p
          (threePointComparison m (p 0) (zStar (p 0)))) := by
  let data :=
    physicalInstrumentTwirlGlobalOptimalCompressedData M hd nu
      hgamma0 hgamma1 (ambientSignedSchmidtResource p hp) hattains
  exact data.implies_schmidt_majorization hd p hp (by simp [data])

/-- In the same signed Schmidt-coordinate model, exact optimality forces the
resource collision probability `sum_j p_j^2` to be at most one half. -/
theorem physicalInstrumentTwirlGlobalOptimal_implies_collisionProbability_le_half
    {d m : ℕ}
    (M : PhysicalPPTInstrument
      (Fin d) (Fin d) (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d)
    (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hattains :
      globalSDPObjective
          (globalPaperEq986PerformanceOperator hd nu gamma)
          (pureResourceInsert (ambientSignedSchmidtResource p hp).amp
            (MatrixMap.choi (M.instrument.branch true))) =
        globalOptimalGain ((d : ℕ) ^ 2) gamma) :
    collisionProbability p ≤ 1 / 2 := by
  let data :=
    physicalInstrumentTwirlGlobalOptimalCompressedData M hd nu
      hgamma0 hgamma1 (ambientSignedSchmidtResource p hp) hattains
  exact data.implies_collisionProbability_le_half hd p hp (by simp [data])

end

end EntanglementPurification
