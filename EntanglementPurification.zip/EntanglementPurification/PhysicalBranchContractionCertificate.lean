import EntanglementPurification.JointContractionPhysicalReducing
import EntanglementPurification.PhysicalPPTCompression

/-!
# Physical branch certificate in joint contraction coordinates

This module packages the representation-theoretic and PPT interfaces into
paper-facing endpoints.  Starting from physical local-unitary invariance and
physical positivity, it derives the two vanishing cross blocks and the
contraction/residual decomposition.  With the physical Bob-PPT condition it
also derives the compressed `BranchPPT` predicate.

None of reducing, the Schur factorization, the residual decomposition, or the
compressed PPT conclusion is an input hypothesis.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b r : Type*}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

/-- Physical local-unitary invariance and positivity force both cross blocks
between the joint contraction range and its complement to vanish.  This is the
finite-matrix form of the two equalities at `main.tex:2950--2953`. -/
theorem jointContractionPhysicalInvariant_offDiagonal_zero
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K)
    (hK : K.PosSemidef) :
    jointContractionRangeProjection (a := a) (b := b) (r := r) * K *
          (1 - jointContractionRangeProjection) = 0 ∧
      (1 - jointContractionRangeProjection (a := a) (b := b) (r := r)) * K *
          jointContractionRangeProjection = 0 := by
  have hreduce : IsJointContractionRangeReducing K :=
    jointContractionRangeReducing_of_physicalInvariant_posSemidef
      hcardA hcardB hInvariant hK
  exact ⟨
    jointContractionRangeReducing_left_offDiagonal_zero
      hcardA hcardB hreduce,
    jointContractionRangeReducing_right_offDiagonal_zero
      hcardA hcardB hreduce⟩

/-- Paper equation `eq:branch_contraction_residual_decomposition`, including
positivity of the residual, now derived from physical invariance and PSD rather
than from a reducing hypothesis. -/
theorem jointContractionPhysicalInvariant_schur_residual_decomposition
    [Nonempty a] [Nonempty b]
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K)
    (hK : K.PosSemidef) :
    K = jointContractionEmbedding
          (Matrix.kronecker (jointContractionSchurCoefficient K)
            (1 : CMatrix (a × b))) +
        jointContractionResidual K ∧
      (jointContractionResidual K).PosSemidef := by
  have hreduce : IsJointContractionRangeReducing K :=
    jointContractionRangeReducing_of_physicalInvariant_posSemidef
      hcardA hcardB hInvariant hK
  have hSchur :
      jointContractionPullback K =
        Matrix.kronecker (jointContractionSchurCoefficient K)
          (1 : CMatrix (a × b)) :=
    jointContractionPullback_eq_schurCoefficient_kronecker_one_of_physicalInvariant
      K hInvariant
  have hdecomp :=
    jointContractionRangeReducing_decomposition hcardA hcardB hreduce
  rw [hSchur] at hdecomp
  exact ⟨hdecomp, jointContractionResidual_posSemidef hK⟩

/-- The physical joint representation is unitary in the concrete right-unitary
form needed for conjugation calculations. -/
private theorem jointContractionPhysicalRepresentation_mul_conjTranspose
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    jointContractionPhysicalRepresentation (r := r) U V *
        Matrix.conjTranspose
          (jointContractionPhysicalRepresentation (r := r) U V) =
      (1 : CMatrix (JointContractionPhysicalIndex a b r)) := by
  have hBarU :
      localEntrywiseConjugate U ∈ Matrix.unitaryGroup a ℂ := by
    change (↑(Matrix.UnitaryGroup.map_star U) : CMatrix a) ∈
      Matrix.unitaryGroup a ℂ
    exact SetLike.coe_mem (Matrix.UnitaryGroup.map_star U)
  have hBarV :
      localEntrywiseConjugate V ∈ Matrix.unitaryGroup b ℂ := by
    change (↑(Matrix.UnitaryGroup.map_star V) : CMatrix b) ∈
      Matrix.unitaryGroup b ℂ
    exact SetLike.coe_mem (Matrix.UnitaryGroup.map_star V)
  have hPiU :
      localMixedSchurRepresentation U ∈
        Matrix.unitaryGroup (LocalMixedSchurSpace a) ℂ :=
    Matrix.kronecker_mem_unitary
      (Matrix.kronecker_mem_unitary hBarU hBarU) (SetLike.coe_mem U)
  have hPiV :
      localMixedSchurRepresentation V ∈
        Matrix.unitaryGroup (LocalMixedSchurSpace b) ℂ :=
    Matrix.kronecker_mem_unitary
      (Matrix.kronecker_mem_unitary hBarV hBarV) (SetLike.coe_mem V)
  have hR :
      jointContractionPhysicalRepresentation (r := r) U V ∈
        Matrix.unitaryGroup (JointContractionPhysicalIndex a b r) ℂ := by
    exact Matrix.kronecker_mem_unitary
      (Matrix.kronecker_mem_unitary hPiU hPiV)
      (SetLike.coe_mem (1 : Matrix.unitaryGroup r ℂ))
  simpa [Matrix.star_eq_conjTranspose] using
    (Matrix.mem_unitaryGroup_iff.mp hR)

/-- The joint contraction range projection is invariant under the physical
local-unitary representation. -/
private theorem jointContractionRangeProjection_physicalInvariant :
    JointContractionPhysicalInvariant
      (jointContractionRangeProjection (a := a) (b := b) (r := r)) := by
  intro U V
  let R := jointContractionPhysicalRepresentation (r := r) U V
  let G := jointContractionIsometry (a := a) (b := b) (r := r)
  let C := jointContractionCoordinateRepresentation (r := r) U V
  have hIntertwines : R * G = G * C := by
    simpa [R, G, C] using
      (jointContractionIsometry_intertwines (r := r) U V)
  have hC :
      C * Matrix.conjTranspose C =
        (1 : CMatrix (JointContractionCoordinateIndex a b r)) := by
    simpa [C] using
      (jointContractionCoordinateRepresentation_mul_conjTranspose
        (r := r) U V)
  change R * (G * Matrix.conjTranspose G) * Matrix.conjTranspose R =
    G * Matrix.conjTranspose G
  calc
    R * (G * Matrix.conjTranspose G) * Matrix.conjTranspose R =
        (R * G) * Matrix.conjTranspose (R * G) := by
      simp only [Matrix.conjTranspose_mul, Matrix.mul_assoc]
    _ = (G * C) * Matrix.conjTranspose (G * C) := by
      rw [hIntertwines]
    _ = G * (C * Matrix.conjTranspose C) *
        Matrix.conjTranspose G := by
      simp only [Matrix.conjTranspose_mul, Matrix.mul_assoc]
    _ = G * Matrix.conjTranspose G := by
      rw [hC, Matrix.mul_one]

/-- The residual block in the branch decomposition inherits the paper's
local-unitary (equivalently, local-twirl) invariance from the physical branch.

This is the formal counterpart of the invariance statement at main.tex:2985.
It is derived from the residual definition; residual invariance is not an
input hypothesis. -/
theorem jointContractionResidual_physicalInvariant
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K) :
    JointContractionPhysicalInvariant (jointContractionResidual K) := by
  intro U V
  let R := jointContractionPhysicalRepresentation (r := r) U V
  let P := jointContractionRangeProjection (a := a) (b := b) (r := r)
  let A : CMatrix (JointContractionPhysicalIndex a b r) := 1 - P
  have hRright : R * Matrix.conjTranspose R = 1 := by
    simpa [R] using
      (jointContractionPhysicalRepresentation_mul_conjTranspose
        (r := r) U V)
  have hRleft : Matrix.conjTranspose R * R = 1 := by
    have h := jointContractionPhysicalRepresentation_mul_conjTranspose
      (r := r) U⁻¹ V⁻¹
    simpa [R] using h
  have hP : R * P * Matrix.conjTranspose R = P := by
    simpa [R, P] using
      (jointContractionRangeProjection_physicalInvariant
        (a := a) (b := b) (r := r) U V)
  have hA : R * A * Matrix.conjTranspose R = A := by
    dsimp [A]
    calc
      R * (1 - P) * Matrix.conjTranspose R =
          R * Matrix.conjTranspose R -
            R * P * Matrix.conjTranspose R := by
        simp only [Matrix.mul_sub, Matrix.sub_mul, Matrix.mul_one]
      _ = 1 - P := by rw [hRright, hP]
  have hK : R * K * Matrix.conjTranspose R = K := by
    simpa [R] using hInvariant U V
  have hProduct :
      R * (A * K * A) * Matrix.conjTranspose R =
        (R * A * Matrix.conjTranspose R) *
          (R * K * Matrix.conjTranspose R) *
          (R * A * Matrix.conjTranspose R) := by
    symm
    calc
      (R * A * Matrix.conjTranspose R) *
            (R * K * Matrix.conjTranspose R) *
            (R * A * Matrix.conjTranspose R) =
          R * A * (Matrix.conjTranspose R * R) * K *
            (Matrix.conjTranspose R * R) * A *
            Matrix.conjTranspose R := by
        simp only [Matrix.mul_assoc]
      _ = R * A * K * A * Matrix.conjTranspose R := by
        rw [hRleft]
        simp only [Matrix.mul_one]
      _ = R * (A * K * A) * Matrix.conjTranspose R := by
        simp only [Matrix.mul_assoc]
  change R * (A * K * A) * Matrix.conjTranspose R = A * K * A
  rw [hProduct, hA, hK]

variable {ra rb : Type*}
  [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]

/-- A single callable endpoint for the physical part of task D.

For a locally twirled physical PSD branch which is also Bob-PPT, it returns:

1. the derived reducing property;
2. the unique Schur factorization of the contraction pullback;
3. the physical contraction-plus-residual decomposition;
4. positivity of the residual; and
5. positivity and Bob-PPT positivity of the compressed Schur coefficient.
-/
theorem physicalInvariantPPTBranch_contractionCertificate
    [Nonempty a] [Nonempty b]
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {K : CMatrix (JointContractionPhysicalIndex a b (ra × rb))}
    (hInvariant : JointContractionPhysicalInvariant K)
    (hK : K.PosSemidef)
    (hKppt : (physicalBranchPartialTransposeB K).PosSemidef) :
    IsJointContractionRangeReducing K ∧
      jointContractionPullback K =
        Matrix.kronecker (jointContractionSchurCoefficient K)
          (1 : CMatrix (a × b)) ∧
      K = jointContractionEmbedding
            (Matrix.kronecker (jointContractionSchurCoefficient K)
              (1 : CMatrix (a × b))) +
          jointContractionResidual K ∧
      (jointContractionResidual K).PosSemidef ∧
      BranchPPT (jointContractionSchurCoefficient K) := by
  have hreduce : IsJointContractionRangeReducing K :=
    jointContractionRangeReducing_of_physicalInvariant_posSemidef
      hcardA hcardB hInvariant hK
  have hSchur :
      jointContractionPullback K =
        Matrix.kronecker (jointContractionSchurCoefficient K)
          (1 : CMatrix (a × b)) :=
    jointContractionPullback_eq_schurCoefficient_kronecker_one_of_physicalInvariant
      K hInvariant
  have hdecomp :=
    jointContractionRangeReducing_decomposition hcardA hcardB hreduce
  rw [hSchur] at hdecomp
  let u : a := Classical.choice (inferInstance : Nonempty a)
  let v : b := Classical.choice (inferInstance : Nonempty b)
  have hppt : BranchPPT (jointContractionSchurCoefficient K) :=
    branchPPT_of_physical K (jointContractionSchurCoefficient K)
      u v hK hKppt hSchur
  exact ⟨hreduce, hSchur, hdecomp,
    jointContractionResidual_posSemidef hK, hppt⟩

end

end EntanglementPurification
