import EntanglementPurification.PPTCompressedInstrument
import EntanglementPurification.PPTPairwiseCertificate
import EntanglementPurification.PPTTestVectors

/-!
# Scalar PPT tests for the auxiliary resource effect

The first theorem below is the formal single-vector calculation in equations
`eq:resource_block_partial_transpose_expansion`--`eq:N_00_ppt_lower_bound`.
It derives the `1/3` bound from branch PPT and the positive residual budget;
the bound is not an input assumption.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

/-- The single-vector PPT test forces the projected diagonal entry of the
auxiliary resource operator to be at least `1/3`. -/
theorem singleVectorPPT_auxiliaryResourceEffect_lower_bound
    {ra rb : Type*}
    [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]
    (d : ℕ) (hd : 2 ≤ d) (eta : PureVector (ra × rb))
    {K : CMatrix (LocalMultiplicitySector × (ra × rb))}
    (hK : BranchPPT K)
    (hinsert : insertPureResourceBlock eta.amp K =
      rankOneMatrix (localOptimalMultiplicityVector d))
    (hPPupper : resourceSectorBlock K sectorPP sectorPP ≤
      (localContractionAlpha d) ^ 2 • (1 : CMatrix (ra × rb)))
    (hMMupper : resourceSectorBlock K sectorMM sectorMM ≤
      (localContractionBeta d) ^ 2 • (1 : CMatrix (ra × rb)))
    {Q : CMatrix (ra × rb)}
    (hQ0 : Q.PosSemidef)
    (hQeta : Q.mulVec eta.amp = 0)
    (hQD : (Q -
      (1 / (localContractionAlpha d * localContractionBeta d) : ℝ) •
        (resourceSectorBlock K sectorPM sectorPM +
          resourceSectorBlock K sectorMP sectorMP)).PosSemidef)
    (u : ra × rb) :
    (1 / 3 : ℝ) ≤
      ((pureVectorPerpProjection eta *
          sectorPPTAuxiliaryResourceEffect eta d K Q *
          pureVectorPerpProjection eta) u u).re := by
  rcases hK with ⟨hKpsd, hKpt⟩
  change (sectorResourcePartialTransposeB K).PosSemidef at hKpt
  let t : ℝ := localContractionAlpha d * localContractionBeta d
  let P : CMatrix (ra × rb) := pureVectorPerpProjection eta
  let R : CMatrix (ra × rb) := rankOneMatrix eta.amp
  let C : CMatrix (ra × rb) := resourceSectorBlock K sectorPP sectorMM
  let B : CMatrix (ra × rb) := resourceSectorBlock K sectorMM sectorPP
  let D : CMatrix (ra × rb) :=
    resourceSectorBlock K sectorPM sectorPM +
      resourceSectorBlock K sectorMP sectorMP
  let A : CMatrix (ra × rb) := projectedNormalizedHermitianCross eta t C
  let N : CMatrix (ra × rb) := sectorPPTAuxiliaryResourceEffect eta d K Q

  have halpha : 0 < localContractionAlpha d := by
    unfold localContractionAlpha
    positivity
  have hdR : (1 : ℝ) < (d : ℝ) := by exact_mod_cast hd
  have hbeta : 0 < localContractionBeta d := by
    unfold localContractionBeta
    positivity
  have ht : 0 < t := mul_pos halpha hbeta
  have htne : t ≠ 0 := ne_of_gt ht

  have hdecomp :=
    inserted_optimal_forces_off_diagonal_block_decompositions
      d hd eta hKpsd hinsert hPPupper hMMupper
  have hC : C = (t : ℂ) • R + P * C * P := by
    simpa [C, t, R, P] using hdecomp.1
  have hB : B = (t : ℂ) • R + P * B * P := by
    simpa [B, t, R, P] using hdecomp.2
  have hCadj : Matrix.conjTranspose C = B := by
    simpa [C, B] using
      (resourceSectorBlock_conjTranspose hKpsd.isHermitian sectorPP sectorMM)
  have hCross : C + B = (2 * t : ℝ) • R + P * (C + B) * P := by
    calc
      C + B = ((t : ℂ) • R + P * C * P) +
          ((t : ℂ) • R + P * B * P) := by
        exact congrArg₂ (fun X Y : CMatrix (ra × rb) => X + Y) hC hB
      _ = (2 * t : ℝ) • R + P * (C + B) * P := by
        change _ = (((2 * t : ℝ) : ℂ) • R) + P * (C + B) * P
        push_cast
        simp only [Matrix.mul_add, Matrix.add_mul]
        module
  have hAdef : A = (1 / t : ℝ) • (P * (C + B) * P) := by
    simp [A, projectedNormalizedHermitianCross, hCadj, P]
  have hCrossNormalized :
      (1 / t : ℝ) • (C + B) = (2 : ℝ) • R + A := by
    rw [hCross]
    simp only [smul_add, smul_smul]
    rw [show (1 / t : ℝ) * (2 * t) = 2 by field_simp [htne]]
    rw [hAdef]

  have hQstar : (Matrix.conjTranspose Q).mulVec eta.amp = 0 := by
    rw [hQ0.isHermitian.eq]
    exact hQeta
  have hQcompression : Q = P * Q * P := by
    simpa [P] using
      (matrix_eq_eigen_rankOne_add_perp_compression
        eta Q 0 (by simpa using hQeta) (by simpa using hQstar))
  have hPid : P * P = P := by
    simp [P]
  have hAPA : P * A * P = A := by
    rw [hAdef]
    simp only [Matrix.mul_smul, Matrix.smul_mul]
    congr 1
    calc
      P * (P * (C + B) * P) * P =
          (P * P) * (C + B) * (P * P) := by noncomm_ring
      _ = P * (C + B) * P := by rw [hPid]

  have hNdef : N = auxiliaryResourceEffect Q A := by rfl
  have hPNP :
      P * N * P = (1 / 6 : ℝ) • (Q + ((2 : ℝ) • P - A)) := by
    rw [hNdef]
    simp only [auxiliaryResourceEffect, realScalarIdentity,
      Matrix.mul_smul, Matrix.smul_mul, Matrix.mul_add, Matrix.add_mul,
      Matrix.mul_sub, Matrix.sub_mul, Matrix.mul_one]
    rw [← hQcompression, hPid, hAPA]

  have hLHS :
      (6 : ℝ) • (P * N * P) - (2 : ℝ) • (1 : CMatrix (ra × rb)) =
        Q - (2 : ℝ) • R - A := by
    rw [hPNP, smul_smul]
    norm_num
    simp only [P, pureVectorPerpProjection, R]
    module
  have hRHS :
      (Q - (1 / t : ℝ) • D) + (1 / t : ℝ) • (D - C - B) =
        Q - (2 : ℝ) • R - A := by
    calc
      (Q - (1 / t : ℝ) • D) + (1 / t : ℝ) • (D - C - B) =
          Q - (1 / t : ℝ) • (C + B) := by module
      _ = Q - ((2 : ℝ) • R + A) := by rw [hCrossNormalized]
      _ = Q - (2 : ℝ) • R - A := by module
  have hCertificateMatrix :
      (6 : ℝ) • (P * N * P) - (2 : ℝ) • (1 : CMatrix (ra × rb)) =
        (Q - (1 / t : ℝ) • D) + (1 / t : ℝ) • (D - C - B) := by
    calc
      _ = Q - (2 : ℝ) • R - A := hLHS
      _ = _ := hRHS.symm

  have hQD' : (Q - (1 / t : ℝ) • D).PosSemidef := by
    simpa [t, D] using hQD
  have hQDdiag : 0 ≤ ((Q - (1 / t : ℝ) • D) u u).re := by
    have h := matrixQuadratic_re_nonneg hQD' (coordinateBasisVector u)
    simpa [matrixQuadratic] using h
  have hPPTdiag : 0 ≤ (D u u - C u u - B u u).re := by
    have h := matrixQuadratic_re_nonneg hKpt (singlePPTTestVector u)
    rw [singlePPTTestVector_quadratic] at h
    simpa [D, C, B] using h

  have hEntry := congrFun (congrFun hCertificateMatrix u) u
  have hReal := congrArg Complex.re hEntry
  have hScalar :
      6 * ((P * N * P) u u).re - 2 =
        ((Q - (1 / t : ℝ) • D) u u).re +
          (1 / t) * (D u u - C u u - B u u).re := by
    simpa [Complex.real_smul, Matrix.one_apply] using hReal
  have hinv : 0 ≤ (1 / t : ℝ) := le_of_lt (one_div_pos.mpr ht)
  have hscaled : 0 ≤ (1 / t) * (D u u - C u u - B u u).re :=
    mul_nonneg hinv hPPTdiag
  change (1 / 3 : ℝ) ≤ ((P * N * P) u u).re
  nlinarith

namespace CompressedPPTInstrumentData

variable {d : ℕ} {ra rb : Type*}
  [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]

/-- Record-level form of `eq:N_00_ppt_lower_bound`. -/
theorem auxiliaryEffect_projected_diagonal_lower_bound
    (data : CompressedPPTInstrumentData d ra rb) (hd : 2 ≤ d)
    (u : ra × rb) :
    (1 / 3 : ℝ) ≤
      ((pureVectorPerpProjection data.resource * data.auxiliaryEffect *
          pureVectorPerpProjection data.resource) u u).re := by
  exact singleVectorPPT_auxiliaryResourceEffect_lower_bound d hd data.resource
    data.success_branchPPT data.inserted_optimal data.success_PP_upper
    (data.success_MM_upper hd) data.crossSectorBudget_posSemidef
    data.crossSectorBudget_mulVec_resource_eq_zero
    data.crossSectorBudget_sub_scaled_diagonal_posSemidef u

end CompressedPPTInstrumentData

/-- Compressing an effect by the orthogonal projector of a pure vector cannot
increase it past that projector, hence the same holds on every diagonal
entry. -/
theorem effect_perpCompression_diagonal_upper_bound
    {r : Type*} [Fintype r] [DecidableEq r]
    (eta : PureVector r) {N : CMatrix r} (hN : IsEffectMatrix N) (u : r) :
    ((pureVectorPerpProjection eta * N *
        pureVectorPerpProjection eta) u u).re ≤
      (pureVectorPerpProjection eta u u).re := by
  let P : CMatrix r := pureVectorPerpProjection eta
  have hPid : P * P = P := by
    simp [P]
  have hPstar : Matrix.conjTranspose P = P := by
    simp [P]
  have hgap : ((1 : CMatrix r) - N).PosSemidef :=
    Matrix.le_iff.mp hN.2
  have hsandwich := hgap.conjTranspose_mul_mul_same P
  have hdiff : (P - P * N * P).PosSemidef := by
    convert hsandwich using 1
    rw [hPstar]
    noncomm_ring [hPid]
  have hdiag :=
    matrixQuadratic_re_nonneg hdiff (coordinateBasisVector u)
  have hdiag' : 0 ≤ (P u u - (P * N * P) u u).re := by
    simpa [matrixQuadratic] using hdiag
  change ((P * N * P) u u).re ≤ (P u u).re
  exact sub_nonneg.mp (by simpa using hdiag')

namespace CompressedPPTInstrumentData

variable {d : ℕ} {ra rb : Type*}
  [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]

/-- The projected auxiliary effect is bounded above by the resource
orthogonal-complement projector on every coordinate. -/
theorem auxiliaryEffect_projected_diagonal_upper_bound
    (data : CompressedPPTInstrumentData d ra rb) (hd : 2 ≤ d)
    (u : ra × rb) :
    ((pureVectorPerpProjection data.resource * data.auxiliaryEffect *
        pureVectorPerpProjection data.resource) u u).re ≤
      (pureVectorPerpProjection data.resource u u).re := by
  exact effect_perpCompression_diagonal_upper_bound data.resource
    (data.auxiliaryEffect_isEffect hd) u

end CompressedPPTInstrumentData

/-- If one coordinate of the pure resource is the nonnegative real amplitude
sqrt p, the corresponding diagonal of its orthogonal-complement projector is
exactly 1 - p. -/
theorem pureVectorPerpProjection_diagonal_re_eq_one_sub
    {r : Type*} [Fintype r] [DecidableEq r]
    (eta : PureVector r) (u : r) (p : ℝ) (hp : 0 ≤ p)
    (hu : eta.amp u = (Real.sqrt p : ℂ)) :
    (pureVectorPerpProjection eta u u).re = 1 - p := by
  simp [pureVectorPerpProjection, rankOneMatrix_apply, hu]
  nlinarith [Real.sq_sqrt hp]

namespace CompressedPPTInstrumentData

variable {d : ℕ} {ra rb : Type*}
  [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]

/-- Coordinate form of the projected upper bound. -/
theorem auxiliaryEffect_projected_diagonal_upper_bound_one_sub
    (data : CompressedPPTInstrumentData d ra rb) (hd : 2 ≤ d)
    (u : ra × rb) (p : ℝ) (hp : 0 ≤ p)
    (hu : data.resource.amp u = (Real.sqrt p : ℂ)) :
    ((pureVectorPerpProjection data.resource * data.auxiliaryEffect *
        pureVectorPerpProjection data.resource) u u).re ≤ 1 - p := by
  calc
    ((pureVectorPerpProjection data.resource * data.auxiliaryEffect *
          pureVectorPerpProjection data.resource) u u).re ≤
        (pureVectorPerpProjection data.resource u u).re :=
      data.auxiliaryEffect_projected_diagonal_upper_bound hd u
    _ = 1 - p :=
      pureVectorPerpProjection_diagonal_re_eq_one_sub
        data.resource u p hp hu

/-- The single-coordinate interval already forces the corresponding resource
probability to be at most 2/3.  In the paper this rules out Schmidt rank one
before the second Schmidt coordinate is chosen. -/
theorem resource_coordinate_probability_le_two_thirds
    (data : CompressedPPTInstrumentData d ra rb) (hd : 2 ≤ d)
    (u : ra × rb) (p : ℝ) (hp : 0 ≤ p)
    (hu : data.resource.amp u = (Real.sqrt p : ℂ)) :
    p ≤ 2 / 3 := by
  have hlo :=
    data.auxiliaryEffect_projected_diagonal_lower_bound hd u
  have hhi :=
    data.auxiliaryEffect_projected_diagonal_upper_bound_one_sub
      hd u p hp hu
  nlinarith

/-- Record-level form of eq:N_pairwise_budget.  The proof combines success
PPT, the positive residual budget, and failure PPT; the cross-entry bound is
not a field of CompressedPPTInstrumentData. -/
theorem auxiliaryEffect_projected_cross_upper_bound
    (data : CompressedPPTInstrumentData d ra rb) (hd : 2 ≤ d)
    (a0 a1 : ra) (b0 b1 : rb) (ha : a0 ≠ a1) :
    ((pureVectorPerpProjection data.resource * data.auxiliaryEffect *
        pureVectorPerpProjection data.resource)
      (a0, b0) (a1, b1)).re ≤ 1 / 3 := by
  have hfailure :
      (QIT.partialTransposeB
        (realScalarIdentity (r := ra × rb) 2 -
          data.crossSectorBudget)).PosSemidef := by
    simpa [realScalarIdentity,
      data.mixedFailureBudget_eq_two_sub_crossSectorBudget] using
        data.partialTransposeB_mixedFailureBudget_posSemidef
  exact pairwisePPT_auxiliaryResourceEffect_upper_bound
    a0 a1 b0 b1 ha d hd data.resource data.success_branchPPT
    data.inserted_optimal data.success_PP_upper (data.success_MM_upper hd)
    data.crossSectorBudget data.crossSectorBudget_posSemidef
    data.crossSectorBudget_mulVec_resource_eq_zero
    data.crossSectorBudget_sub_scaled_diagonal_posSemidef hfailure

/-- The three displayed effect conclusions of the paper's PPT-induced
resource-effect certificate, packaged for a distinguished coordinate. -/
theorem auxiliaryEffect_coordinate_certificate
    (data : CompressedPPTInstrumentData d ra rb) (hd : 2 ≤ d)
    (a0 a1 : ra) (b0 b1 : rb) (ha : a0 ≠ a1)
    (p0 : ℝ) (hp0 : 0 ≤ p0)
    (heta0 : data.resource.amp (a0, b0) = (Real.sqrt p0 : ℂ)) :
    IsEffectMatrix data.auxiliaryEffect ∧
      (1 / 3 : ℝ) ≤
        ((pureVectorPerpProjection data.resource * data.auxiliaryEffect *
          pureVectorPerpProjection data.resource) (a0, b0) (a0, b0)).re ∧
      ((pureVectorPerpProjection data.resource * data.auxiliaryEffect *
          pureVectorPerpProjection data.resource) (a0, b0) (a0, b0)).re ≤
        1 - p0 ∧
      ((pureVectorPerpProjection data.resource * data.auxiliaryEffect *
          pureVectorPerpProjection data.resource) (a0, b0) (a1, b1)).re ≤
        1 / 3 := by
  exact ⟨data.auxiliaryEffect_isEffect hd,
    data.auxiliaryEffect_projected_diagonal_lower_bound hd (a0, b0),
    data.auxiliaryEffect_projected_diagonal_upper_bound_one_sub
      hd (a0, b0) p0 hp0 heta0,
    data.auxiliaryEffect_projected_cross_upper_bound
      hd a0 a1 b0 b1 ha⟩

end CompressedPPTInstrumentData

end

end EntanglementPurification
