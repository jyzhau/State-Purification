import EntanglementPurification.FiniteEntanglementOfFormation
import EntanglementPurification.PhysicalLocalTwirlObjective
import EntanglementPurification.ArbitraryPureOperationalNecessity

/-!
# Mixed-resource necessity for a fixed physical PPT instrument

The paper inserts a mixed assisting state into one fixed success/failure
instrument.  The equation-986 objective is affine in that state.  Therefore,
if the mixed state attains the global upper bound, every positive-weight pure
member of every finite decomposition attains the same bound.  This file makes
that linearity and saturation step explicit.

The affine lemma is first exposed with the pure-state endpoint as a parameter;
the final theorem discharges that parameter with the basis-free arbitrary-pure
Schmidt converse.
-/

namespace EntanglementPurification

open QIT
open scoped NNReal ComplexOrder MatrixOrder

noncomputable section

universe u v w z

variable {a : Type u} {b : Type v} {ra : Type w} {rb : Type z}
  [Fintype a] [DecidableEq a] [Nonempty a]
  [Fintype b] [DecidableEq b] [Nonempty b]
  [Fintype ra] [DecidableEq ra]
  [Fintype rb] [DecidableEq rb]

/-- Complex trace functional obtained by inserting an arbitrary resource
matrix into the fixed physical success branch. -/
noncomputable def physicalEq986FixedResourceTraceLinearMap
    (M : PhysicalPPTInstrument a b ra rb)
    (nu : PureVector (a × b)) (gamma : ℝ) :
    CMatrix (ra × rb) →ₗ[ℂ] ℂ where
  toFun omega :=
    (physicalEq986FixedResourcePairing nu gamma omega *
      physicalInstrumentChoi (M.instrument.branch true)).trace
  map_add' := by
    intro omega tau
    simp [physicalEq986FixedResourcePairing, Matrix.transpose_add,
      Matrix.kronecker_add, Matrix.add_mul, Matrix.trace_add]
  map_smul' := by
    intro c omega
    simp [physicalEq986FixedResourcePairing, Matrix.transpose_smul,
      Matrix.kronecker_smul, Matrix.trace_smul]

/-- Real equation-986 gain of a fixed branch against an arbitrary resource
matrix.  For density matrices this is the paper's mixed-resource objective. -/
def physicalEq986FixedResourceGain
    (M : PhysicalPPTInstrument a b ra rb)
    (nu : PureVector (a × b)) (gamma : ℝ)
    (omega : CMatrix (ra × rb)) : ℝ :=
  (physicalEq986FixedResourceTraceLinearMap M nu gamma omega).re

/-- State-valued wrapper for the fixed-resource gain. -/
def physicalMixedResourceAverageAcceptedGain
    (M : PhysicalPPTInstrument a b ra rb)
    (nu : PureVector (a × b)) (gamma : ℝ)
    (omega : State (ra × rb)) : ℝ :=
  physicalEq986FixedResourceGain M nu gamma omega.matrix

/-- Paper-indexed wrapper.  The hypothesis `d ≥ 2` supplies the nonempty local
system instances needed by the equation-986 performance operator. -/
def physicalPaperMixedResourceAverageAcceptedGain
    {d : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d)) (gamma : ℝ)
    (omega : State (ra × rb)) : ℝ := by
  letI : Nonempty (Fin d) := ⟨⟨0, by omega⟩⟩
  exact physicalMixedResourceAverageAcceptedGain M nu gamma omega

omit [Nonempty a] [Nonempty b]
  [Fintype ra] [DecidableEq ra] [Fintype rb] [DecidableEq rb] in
/-- Transposing a pure-state density matrix implements the coordinatewise
conjugation forced by the input-first Choi convention. -/
theorem rankOneMatrix_transpose_eq_rankOneMatrix_star
    (eta : ra × rb → ℂ) :
    (rankOneMatrix eta).transpose =
      rankOneMatrix (fun i => star (eta i)) := by
  ext i j
  simp [rankOneMatrix_apply, mul_comm]

/-- On a pure resource, the mixed-state trace pairing is exactly the already
verified operational accepted-gain quantity. -/
theorem physicalPaperMixedResourceAverageAcceptedGain_pure
    {d : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d)) (gamma : ℝ)
    (hgamma0 : 0 ≤ gamma) (hgamma1 : gamma ≤ 1)
    (resource : PureVector (ra × rb)) :
    physicalPaperMixedResourceAverageAcceptedGain M hd nu gamma resource.state =
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
        hgamma0 hgamma1 resource := by
  letI : Nonempty (Fin d) := ⟨⟨0, by omega⟩⟩
  let eta : ra × rb → ℂ := fun i => star (resource.amp i)
  let P := physicalRegroupedEq986PerformanceOperator nu gamma
  let K := physicalInstrumentChoi (M.instrument.branch true)
  have hpair :
      physicalEq986FixedResourceGain M nu gamma resource.state.matrix =
        globalSDPObjective P (physicalPureResourceInsert eta K) := by
    have htrace :=
      trace_mul_physicalPureResourceInsert_eq_trace_kronecker_rankOne_mul
        P eta K
    exact congrArg Complex.re (by
      simpa [physicalEq986FixedResourceGain,
        physicalEq986FixedResourceTraceLinearMap,
        physicalEq986FixedResourcePairing, PureVector.state_matrix,
        rankOneMatrix_transpose_eq_rankOneMatrix_star, eta, P, K]
        using htrace.symm)
  rw [physicalPaperMixedResourceAverageAcceptedGain,
    physicalMixedResourceAverageAcceptedGain, hpair]
  rw [physicalPureResourceInsert_physicalInstrumentChoi]
  dsimp [P]
  rw [physicalRegroupedEq986PerformanceOperator]
  rw [globalSDPObjective_physicalInsertedChoiMatrix]
  rw [physicalPaperOperationalAverageAcceptedGain_eq_globalSDPObjective]
  rfl

/-- The fixed mixed-resource objective is affine over Lean-QIT's finite pure
ensembles. -/
theorem physicalPaperMixedResourceAverageAcceptedGain_averageState
    {ι : Type*} [Fintype ι] [DecidableEq ι]
    {d : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d)) (gamma : ℝ)
    (hgamma0 : 0 ≤ gamma) (hgamma1 : gamma ≤ 1)
    (E : BipartitePureEnsemble ι ra rb) :
    physicalPaperMixedResourceAverageAcceptedGain M hd nu gamma E.averageState =
      ∑ i, (E.probs i : ℝ) *
        physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0 hgamma1 (E.pure i) := by
  letI : Nonempty (Fin d) := ⟨⟨0, by omega⟩⟩
  rw [physicalPaperMixedResourceAverageAcceptedGain,
    physicalMixedResourceAverageAcceptedGain]
  simp only [BipartitePureEnsemble.averageState_matrix,
    physicalEq986FixedResourceGain]
  change
    ((physicalEq986FixedResourceTraceLinearMap M nu gamma)
      (∑ i, (E.probs i) • (E.pure i).state.matrix)).re = _
  rw [map_sum]
  rw [Complex.re_sum]
  apply Finset.sum_congr rfl
  intro i _
  rw [show E.probs i • (E.pure i).state.matrix =
      (E.probs i : ℂ) • (E.pure i).state.matrix by
    ext p q
    change (algebraMap ℝ≥0 ℂ (E.probs i)) * (E.pure i).state.matrix p q =
      (E.probs i : ℂ) * (E.pure i).state.matrix p q
    rfl]
  rw [map_smul]
  change
    (((E.probs i : ℂ) *
      (physicalEq986FixedResourceTraceLinearMap M nu gamma)
        (E.pure i).state.matrix).re) = _
  simp only [Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im,
    zero_mul, sub_zero]
  congr 1
  simpa [physicalPaperMixedResourceAverageAcceptedGain,
    physicalMixedResourceAverageAcceptedGain,
    physicalEq986FixedResourceGain] using
      (physicalPaperMixedResourceAverageAcceptedGain_pure
        M hd nu gamma hgamma0 hgamma1 (E.pure i))

/-- Exact mixed-resource attainment forces every positive-weight pure
component of every displayed decomposition to attain the pure-resource
optimum for the same physical PPT instrument. -/
theorem pure_component_attains_of_mixed_attains
    {d : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (omega : State (ra × rb))
    (hattains :
      physicalPaperMixedResourceAverageAcceptedGain M hd nu gamma omega =
        globalOptimalGain ((d : ℝ) ^ 2) gamma)
    {n : ℕ} (E : BipartitePureEnsemble (Fin (n + 1)) ra rb)
    (hE : E.averageState = omega)
    (i : Fin (n + 1)) (hi : 0 < (E.probs i : ℝ)) :
    physicalPaperOperationalAverageAcceptedGain M hd nu gamma
        hgamma0.le hgamma1.le (E.pure i) =
      globalOptimalGain ((d : ℝ) ^ 2) gamma := by
  letI : Nonempty (Fin d) := ⟨⟨0, by omega⟩⟩
  apply E.component_eq_of_weighted_average_eq_upperBound
    (fun j => physicalPaperOperationalAverageAcceptedGain M hd nu gamma
      hgamma0.le hgamma1.le (E.pure j))
    (globalOptimalGain ((d : ℝ) ^ 2) gamma)
  · intro j
    exact physicalPaperOperationalAverageAcceptedGain_le_globalOptimalGain
      M hd nu hgamma0 hgamma1 (E.pure j)
  · rw [← physicalPaperMixedResourceAverageAcceptedGain_averageState
      M hd nu gamma hgamma0.le hgamma1.le E, hE, hattains]
  · exact hi

/-- Convex-roof endpoint of the mixed-resource argument.  Once the pure
necessity theorem is available for arbitrary pure resources, exact attainment
by `omega` forces its finite entanglement of formation to be at least one
ebit. -/
theorem one_le_finiteEntanglementOfFormation_of_mixed_attains
    {d : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (omega : State (ra × rb))
    (hattains :
      physicalPaperMixedResourceAverageAcceptedGain M hd nu gamma omega =
        globalOptimalGain ((d : ℝ) ^ 2) gamma)
    (hpure : ∀ resource : PureVector (ra × rb),
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le resource =
        globalOptimalGain ((d : ℝ) ^ 2) gamma →
      1 ≤ resource.entanglementEntropy) :
    1 ≤ finiteEntanglementOfFormation omega := by
  apply one_le_finiteEntanglementOfFormation_of_all_decompositions
    omega (finitePureDecompositionCosts_nonempty omega)
  intro n E hE
  rw [BipartitePureEnsemble.averageEntanglement]
  calc
    1 = ∑ i, (E.probs i : ℝ) * 1 := by
      rw [← Finset.sum_mul, E.sum_coe_probs]
      ring
    _ ≤ ∑ i, (E.probs i : ℝ) * (E.pure i).entanglementEntropy := by
      apply Finset.sum_le_sum
      intro i _
      by_cases hi : (E.probs i : ℝ) = 0
      · simp [hi]
      · apply mul_le_mul_of_nonneg_left
        · apply hpure (E.pure i)
          exact pure_component_attains_of_mixed_attains
            (ra := ra) (rb := rb) (d := d) (n := n)
            M hd nu hgamma0 hgamma1 omega hattains E hE i
              (lt_of_le_of_ne (E.prob_nonneg i) (Ne.symm hi))
        · exact E.prob_nonneg i

/-- Paper-facing mixed-resource endpoint with no externally supplied pure-state
or Schmidt-coordinate hypothesis.  Exact attainment by one fixed physical PPT
instrument forces the finite-ensemble entanglement of formation of the mixed
resource to be at least one ebit. -/
theorem physicalOperationalAttainment_arbitraryMixed_implies_one_le_finiteEntanglementOfFormation
    {d : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (omega : State (ra × rb))
    (hattains :
      physicalPaperMixedResourceAverageAcceptedGain M hd nu gamma omega =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) :
    1 ≤ finiteEntanglementOfFormation omega := by
  apply one_le_finiteEntanglementOfFormation_of_mixed_attains
    M hd nu hgamma0 hgamma1 omega hattains
  intro resource hpureAttains
  exact
    physicalOperationalAttainment_arbitraryPure_implies_one_le_entanglementEntropy
      M hd nu hgamma0 hgamma1 resource hpureAttains

end

end EntanglementPurification
