import QIT.Classical.Bridge
import QIT.Information.Entropy.PureEntanglement
import QIT.Information.Entropy.EntropyTensorPower
import QIT.Information.Renyi.AlphaEntropyContinuity
import QIT.Measurements.Projective
import QIT.States.Purification.Equivalence
import Mathlib.Tactic

/-!
# Basis-free Schmidt isometry witnesses

For a finite probability distribution `p`, its canonical diagonal purification
is a basis-independent standard Schmidt vector.  A `PureSchmidtIsometryWitness`
records that a bipartite pure vector is obtained from this standard vector by
one isometry on each local register.

The main interface theorem in this file proves that every such witness computes
the Lean-QIT entanglement entropy as the Shannon entropy of `p`.  The final
existence theorem constructs a witness for every finite-dimensional bipartite
pure vector, allowing the two tensor factors to be exchanged when the first
factor is the smaller purifying register.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder NNReal

noncomputable section

universe u v w

/-- Shannon entropy in bits of a finite `NNReal` probability distribution. -/
def schmidtShannonEntropyBits {s : Type u} [Fintype s] (p : s → ℝ≥0) : ℝ :=
  -∑ i, QIT.xlog2 (p i : ℝ)

/-- The standard positive Schmidt vector associated with `p`.

It is defined without choosing ambient bases: it is the canonical purification
of the diagonal state whose probabilities are `p`.  Sign or phase conventions
for Schmidt coefficients can subsequently be absorbed into either local
isometry. -/
def schmidtStandardVector {s : Type u} [Fintype s] [DecidableEq s]
    (p : s → ℝ≥0) (hp : ∑ i, p i = 1) : PureVector (Prod s s) :=
  (Classical.diagonalState p hp).canonicalPurification

/-- The target marginal of the standard Schmidt vector is the prescribed
diagonal probability state. -/
theorem schmidtStandardVector_marginalB
    {s : Type u} [Fintype s] [DecidableEq s]
    (p : s → ℝ≥0) (hp : ∑ i, p i = 1) :
    (schmidtStandardVector p hp).state.marginalB =
      Classical.diagonalState p hp := by
  apply State.ext
  exact (Classical.diagonalState p hp).canonicalPurification_purifies

/-- The standard Schmidt vector has Shannon entropy `H(p)`. -/
theorem schmidtStandardVector_entanglementEntropy
    {s : Type u} [Fintype s] [DecidableEq s]
    (p : s → ℝ≥0) (hp : ∑ i, p i = 1) :
    (schmidtStandardVector p hp).entanglementEntropy =
      schmidtShannonEntropyBits p := by
  rw [PureVector.entanglementEntropy, schmidtStandardVector_marginalB]
  exact State.vonNeumann_eq_neg_sum_xlog2_of_diagonal
    (Classical.diagonalState p hp) (fun i => (p i : ℝ))
    (Classical.diagonalState_matrix p hp)

/-- Applying an isometry on the first local factor preserves pure-state
entanglement entropy. -/
theorem entanglementEntropy_applyPureVector
    {s : Type u} {a : Type v} {b : Type w}
    [Fintype s] [DecidableEq s] [Fintype a] [DecidableEq a]
    [Fintype b] [DecidableEq b]
    (V : ReferenceIsometry s a) (psi : PureVector (Prod s b)) :
    (V.applyPureVector psi).entanglementEntropy = psi.entanglementEntropy := by
  rw [PureVector.entanglementEntropy_eq_marginalA,
    PureVector.entanglementEntropy_eq_marginalA]
  exact State.vonNeumann_eq_of_matrix_eq_isometry_conj
    psi.state.marginalA (V.applyPureVector psi).state.marginalA
    V.matrix V.isometry (V.marginalA_applyPureVector psi)

/-- Applying an isometry on the second local factor preserves pure-state
entanglement entropy. -/
theorem entanglementEntropy_applyPureVectorRight
    {s : Type u} {a : Type v} {b : Type w}
    [Fintype s] [DecidableEq s] [Fintype a] [DecidableEq a]
    [Fintype b] [DecidableEq b]
    (V : ReferenceIsometry s b) (psi : PureVector (Prod a s)) :
    (V.applyPureVectorRight psi).entanglementEntropy = psi.entanglementEntropy := by
  rw [PureVector.entanglementEntropy_eq_marginalA,
    PureVector.entanglementEntropy_eq_marginalA,
    V.marginalA_applyPureVectorRight]

/-- A basis-free Schmidt standard-form certificate for a bipartite pure vector.

The Schmidt label type `s` need not be either ambient register.  Zero
probabilities are permitted, and `left` and `right` may therefore be rectangular
isometries into larger local spaces. -/
structure PureSchmidtIsometryWitness
    {a : Type v} {b : Type w} [Fintype a] [DecidableEq a]
    [Fintype b] [DecidableEq b]
    (psi : PureVector (Prod a b))
    (s : Type u) [Fintype s] [DecidableEq s] where
  probabilities : s → ℝ≥0
  probabilities_sum : ∑ i, probabilities i = 1
  left : ReferenceIsometry s a
  right : ReferenceIsometry s b
  eq_localIsometries :
    psi = left.applyPureVector
      (right.applyPureVectorRight
        (schmidtStandardVector probabilities probabilities_sum))

namespace PureSchmidtIsometryWitness

variable {a : Type v} {b : Type w} {s : Type u}
variable [Fintype a] [DecidableEq a] [Fintype b] [DecidableEq b]
variable [Fintype s] [DecidableEq s]

/-- A Schmidt-isometry witness computes the actual Lean-QIT pure-state
entanglement entropy. -/
theorem entanglementEntropy_eq
    {psi : PureVector (Prod a b)}
    (W : PureSchmidtIsometryWitness psi s) :
    psi.entanglementEntropy = schmidtShannonEntropyBits W.probabilities := by
  calc
    psi.entanglementEntropy =
        (W.left.applyPureVector
          (W.right.applyPureVectorRight
            (schmidtStandardVector W.probabilities
              W.probabilities_sum))).entanglementEntropy :=
      congrArg PureVector.entanglementEntropy W.eq_localIsometries
    _ = schmidtShannonEntropyBits W.probabilities := by
      rw [entanglementEntropy_applyPureVector,
        entanglementEntropy_applyPureVectorRight,
        schmidtStandardVector_entanglementEntropy]

end PureSchmidtIsometryWitness

/-! ## Existence from the marginal spectral decomposition -/

/-- The eigenvector unitary of a finite state, viewed as a reference
isometry. -/
def stateEigenvectorIsometry
    {s : Type u} [Fintype s] [DecidableEq s]
    (rho : State s) : ReferenceIsometry s s where
  matrix := rho.pos.isHermitian.eigenvectorUnitary
  isometry := by
    simpa [Matrix.star_eq_conjTranspose] using
      Matrix.UnitaryGroup.star_mul_self rho.pos.isHermitian.eigenvectorUnitary

/-- Applying the eigenvector unitary to the target half of the standard
Schmidt vector gives a purification of the original state. -/
theorem stateEigenvectorIsometry_applyStandard_purifies
    {s : Type u} [Fintype s] [DecidableEq s]
    (rho : State s) :
    ((stateEigenvectorIsometry rho).applyPureVectorRight
      (schmidtStandardVector (ProjectiveMeasurement.stateEigenvalueProb rho)
        (ProjectiveMeasurement.stateEigenvalueProb_sum rho))).Purifies rho := by
  rw [PureVector.purifies_iff]
  rw [(stateEigenvectorIsometry rho).rankOne_applyPureVectorRight]
  rw [(stateEigenvectorIsometry rho).partialTraceA_applyMatrixRight]
  rw [← State.marginalB_matrix]
  rw [(schmidtStandardVector_marginalB
    (ProjectiveMeasurement.stateEigenvalueProb rho)
    (ProjectiveMeasurement.stateEigenvalueProb_sum rho))]
  simpa [stateEigenvectorIsometry, Matrix.star_eq_conjTranspose] using
    (ProjectiveMeasurement.state_matrix_eq_unitary_diagonalEigenvalueProb rho).symm

/-- If the right register is no larger than the left register, every pure
vector has a Schmidt-isometry witness indexed by the right register. -/
theorem exists_pureSchmidtIsometryWitness_of_card_right_le_left
    {a : Type v} {b : Type w}
    [Fintype a] [DecidableEq a] [Fintype b] [DecidableEq b]
    (psi : PureVector (Prod a b))
    (hcard : Fintype.card b ≤ Fintype.card a) :
    Nonempty (PureSchmidtIsometryWitness psi b) := by
  let rho : State b := psi.state.marginalB
  let p : b → ℝ≥0 := ProjectiveMeasurement.stateEigenvalueProb rho
  let hp : ∑ i, p i = 1 := ProjectiveMeasurement.stateEigenvalueProb_sum rho
  let U : ReferenceIsometry b b := stateEigenvectorIsometry rho
  let standard : PureVector (Prod b b) := schmidtStandardVector p hp
  let spectralPurification : PureVector (Prod b b) :=
    U.applyPureVectorRight standard
  have hspectral : spectralPurification.Purifies rho := by
    simpa [spectralPurification, standard, U, p, hp, rho] using
      stateEigenvectorIsometry_applyStandard_purifies rho
  have hpsi : psi.Purifies rho := by
    simp [rho]
  rcases
      PureVector.exists_referenceIsometry_applyPureVector_eq_of_purifies_same_state
        hspectral hpsi hcard with
    ⟨V, hV⟩
  exact ⟨{
    probabilities := p
    probabilities_sum := hp
    left := V
    right := U
    eq_localIsometries := by
      simpa [spectralPurification, standard] using hV }⟩

/-- An arbitrary bipartite pure vector has either a direct Schmidt witness or
one after exchanging its two tensor factors.  The selected Schmidt label is
always the smaller ambient register, so the required local embedding exists. -/
inductive PureSchmidtIsometryNormalForm
    {a : Type v} {b : Type w}
    [Fintype a] [DecidableEq a] [Fintype b] [DecidableEq b]
    (psi : PureVector (Prod a b)) : Type (max u v w)
  | direct (witness : PureSchmidtIsometryWitness psi b) :
      PureSchmidtIsometryNormalForm psi
  | swapped
      (witness : PureSchmidtIsometryWitness
        (psi.reindex (Equiv.prodComm a b)) a) :
      PureSchmidtIsometryNormalForm psi

/-- Every finite-dimensional bipartite pure vector has a Schmidt-isometry
normal form, with a possible exchange of the two named local registers. -/
theorem pureSchmidtIsometryNormalForm_nonempty
    {a : Type v} {b : Type w}
    [Fintype a] [DecidableEq a] [Fintype b] [DecidableEq b]
    (psi : PureVector (Prod a b)) :
    Nonempty (PureSchmidtIsometryNormalForm psi) := by
  by_cases hcard : Fintype.card b ≤ Fintype.card a
  · rcases exists_pureSchmidtIsometryWitness_of_card_right_le_left
      psi hcard with ⟨W⟩
    exact ⟨PureSchmidtIsometryNormalForm.direct W⟩
  · have hcard' : Fintype.card a ≤ Fintype.card b :=
      Nat.le_of_lt (Nat.lt_of_not_ge hcard)
    rcases exists_pureSchmidtIsometryWitness_of_card_right_le_left
      (psi.reindex (Equiv.prodComm a b)) hcard' with ⟨W⟩
    exact ⟨PureSchmidtIsometryNormalForm.swapped W⟩

namespace PureSchmidtIsometryNormalForm

variable {a : Type v} {b : Type w}
variable [Fintype a] [DecidableEq a] [Fintype b] [DecidableEq b]
variable {psi : PureVector (Prod a b)}

/-- The entropy statement carried by either orientation of a Schmidt normal
form. -/
def EntropyFormula (W : PureSchmidtIsometryNormalForm psi) : Prop :=
  match W with
  | .direct witness =>
      psi.entanglementEntropy =
        schmidtShannonEntropyBits witness.probabilities
  | .swapped witness =>
      psi.entanglementEntropy =
        schmidtShannonEntropyBits witness.probabilities

/-- Every constructed normal form carries the exact entropy formula for its
Schmidt probabilities. -/
theorem entropyFormula (W : PureSchmidtIsometryNormalForm psi) :
    W.EntropyFormula := by
  cases W with
  | direct witness =>
      exact witness.entanglementEntropy_eq
  | swapped witness =>
      have h := witness.entanglementEntropy_eq
      rw [PureVector.entanglementEntropy_reindex_prodComm] at h
      exact h

end PureSchmidtIsometryNormalForm

end

end EntanglementPurification
