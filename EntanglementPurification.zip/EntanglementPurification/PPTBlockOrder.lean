import EntanglementPurification.PPTSectorBlocks

/-!
# Order bounds for the `++`-to-`--` resource-sector block

This file isolates the finite-dimensional positive-semidefinite matrix argument
used in the proof of `eq:auxiliary_operator_bounds` in `main.tex`.

For a positive-semidefinite resource matrix `K`, we test `K` on two scaled
embeddings between the `++` and `--` sectors:

* `x ↦ β |++⟩ ⊗ x + α |--⟩ ⊗ x`, and
* `x ↦ β |++⟩ ⊗ x - α |--⟩ ⊗ x`.

The resulting congruences control the Hermitian part of the cross-sector block from
upper bounds on the two diagonal blocks.  Mixed Schur--Weyl reduction and the
PPT constraints that supply those diagonal bounds belong to earlier modules;
they are not assumed away here.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {r : Type*} [Fintype r] [DecidableEq r]

private def fixedSectorEmbedding (z : LocalMultiplicitySector) :
    Matrix (LocalMultiplicitySector × r) r ℂ :=
  fun p i => if p = (z, i) then 1 else 0

private theorem fixedSectorEmbedding_congruence
    (K : CMatrix (LocalMultiplicitySector × r))
    (z w : LocalMultiplicitySector) :
    Matrix.conjTranspose (fixedSectorEmbedding (r := r) z) * K *
        fixedSectorEmbedding (r := r) w =
      resourceSectorBlock K z w := by
  ext i j
  simp [fixedSectorEmbedding, resourceSectorBlock, Matrix.mul_apply]

/-- The scaled `++`-to-`--` embedding with the plus sign:
`x ↦ β |++⟩ ⊗ x + α |--⟩ ⊗ x`. -/
def ppmmPlusEmbedding (alpha beta : ℝ) :
    Matrix (LocalMultiplicitySector × r) r ℂ :=
  (beta : ℂ) • fixedSectorEmbedding (r := r) sectorPP +
    (alpha : ℂ) • fixedSectorEmbedding (r := r) sectorMM

/-- The scaled `++`-to-`--` embedding with the minus sign:
`x ↦ β |++⟩ ⊗ x - α |--⟩ ⊗ x`. -/
def ppmmMinusEmbedding (alpha beta : ℝ) :
    Matrix (LocalMultiplicitySector × r) r ℂ :=
  (beta : ℂ) • fixedSectorEmbedding (r := r) sectorPP -
    (alpha : ℂ) • fixedSectorEmbedding (r := r) sectorMM

/-- Congruence by the plus embedding exposes the positive Hermitian cross term. -/
theorem ppmmPlusEmbedding_congruence
    (K : CMatrix (LocalMultiplicitySector × r)) (alpha beta : ℝ) :
    Matrix.conjTranspose (ppmmPlusEmbedding (r := r) alpha beta) * K *
        ppmmPlusEmbedding (r := r) alpha beta =
      (beta ^ 2 : ℝ) • resourceSectorBlock K sectorPP sectorPP +
      (alpha ^ 2 : ℝ) • resourceSectorBlock K sectorMM sectorMM +
      (alpha * beta : ℝ) •
        (resourceSectorBlock K sectorPP sectorMM +
          resourceSectorBlock K sectorMM sectorPP) := by
  simp [ppmmPlusEmbedding, Matrix.conjTranspose_add,
    Matrix.conjTranspose_smul, Matrix.add_mul, Matrix.mul_add,
    Matrix.smul_mul, Matrix.mul_smul, fixedSectorEmbedding_congruence]
  module

/-- Congruence by the minus embedding exposes the negative Hermitian cross term. -/
theorem ppmmMinusEmbedding_congruence
    (K : CMatrix (LocalMultiplicitySector × r)) (alpha beta : ℝ) :
    Matrix.conjTranspose (ppmmMinusEmbedding (r := r) alpha beta) * K *
        ppmmMinusEmbedding (r := r) alpha beta =
      (beta ^ 2 : ℝ) • resourceSectorBlock K sectorPP sectorPP +
      (alpha ^ 2 : ℝ) • resourceSectorBlock K sectorMM sectorMM -
      (alpha * beta : ℝ) •
        (resourceSectorBlock K sectorPP sectorMM +
          resourceSectorBlock K sectorMM sectorPP) := by
  simp [ppmmMinusEmbedding, Matrix.conjTranspose_sub,
    Matrix.conjTranspose_smul, Matrix.sub_mul, Matrix.mul_sub,
    Matrix.smul_mul, Matrix.mul_smul, fixedSectorEmbedding_congruence]
  module

/-- The block-matrix order estimate used in `eq:auxiliary_operator_bounds`.

If `K` is positive semidefinite and its `++`- and `--`-diagonal blocks are
bounded respectively by `α² I` and `β² I`, then the Hermitian part of its
`++`-to-`--` block lies between `-2 α β I` and `2 α β I`.

The proof derives both signs from congruences of `K`; the desired cross-block
bound is therefore a conclusion, not an assumption.
-/
theorem crossBlockHermitian_order
    (K : CMatrix (LocalMultiplicitySector × r))
    (hK : K.PosSemidef) (alpha beta : ℝ)
    (halpha : 0 < alpha) (hbeta : 0 < beta)
    (hA : resourceSectorBlock K sectorPP sectorPP ≤
      (alpha ^ 2 : ℝ) • (1 : CMatrix r))
    (hD : resourceSectorBlock K sectorMM sectorMM ≤
      (beta ^ 2 : ℝ) • (1 : CMatrix r)) :
    ((-2 * alpha * beta : ℝ) • (1 : CMatrix r)) ≤
        resourceSectorBlock K sectorPP sectorMM +
          Matrix.conjTranspose (resourceSectorBlock K sectorPP sectorMM) ∧
      resourceSectorBlock K sectorPP sectorMM +
          Matrix.conjTranspose (resourceSectorBlock K sectorPP sectorMM) ≤
        ((2 * alpha * beta : ℝ) • (1 : CMatrix r)) := by
  let A := resourceSectorBlock K sectorPP sectorPP
  let D := resourceSectorBlock K sectorMM sectorMM
  let C := resourceSectorBlock K sectorPP sectorMM
  have hab : 0 < alpha * beta := mul_pos halpha hbeta
  have hCadj : Matrix.conjTranspose C =
      resourceSectorBlock K sectorMM sectorPP := by
    exact resourceSectorBlock_conjTranspose hK.isHermitian sectorPP sectorMM
  have hAgap : ((alpha ^ 2 : ℝ) • (1 : CMatrix r) - A).PosSemidef := by
    exact Matrix.le_iff.mp hA
  have hDgap : ((beta ^ 2 : ℝ) • (1 : CMatrix r) - D).PosSemidef := by
    exact Matrix.le_iff.mp hD
  have hplus :
      ((beta ^ 2 : ℝ) • A + (alpha ^ 2 : ℝ) • D +
        (alpha * beta : ℝ) • (C + Matrix.conjTranspose C)).PosSemidef := by
    have hc := hK.conjTranspose_mul_mul_same
      (ppmmPlusEmbedding (r := r) alpha beta)
    rw [ppmmPlusEmbedding_congruence] at hc
    simpa [A, D, C, hCadj] using hc
  have hminus :
      ((beta ^ 2 : ℝ) • A + (alpha ^ 2 : ℝ) • D -
        (alpha * beta : ℝ) • (C + Matrix.conjTranspose C)).PosSemidef := by
    have hc := hK.conjTranspose_mul_mul_same
      (ppmmMinusEmbedding (r := r) alpha beta)
    rw [ppmmMinusEmbedding_congruence] at hc
    simpa [A, D, C, hCadj] using hc
  have hbetaSq : 0 ≤ beta ^ 2 := sq_nonneg beta
  have halphaSq : 0 ≤ alpha ^ 2 := sq_nonneg alpha
  constructor
  · rw [Matrix.le_iff]
    have hsum :=
      (Matrix.PosSemidef.smul hAgap hbetaSq).add
        ((Matrix.PosSemidef.smul hDgap halphaSq).add hplus)
    have hscaled := Matrix.PosSemidef.smul hsum
      (show 0 ≤ (1 / (alpha * beta) : ℝ) by positivity)
    convert hscaled using 1
    ext i j
    simp [A, D, C, Matrix.one_apply]
    split_ifs <;> field_simp [ne_of_gt hab] <;> ring
  · rw [Matrix.le_iff]
    have hsum :=
      (Matrix.PosSemidef.smul hAgap hbetaSq).add
        ((Matrix.PosSemidef.smul hDgap halphaSq).add hminus)
    have hscaled := Matrix.PosSemidef.smul hsum
      (show 0 ≤ (1 / (alpha * beta) : ℝ) by positivity)
    convert hscaled using 1
    ext i j
    simp [A, D, C, Matrix.one_apply]
    split_ifs <;> field_simp [ne_of_gt hab] <;> ring

end

end EntanglementPurification
