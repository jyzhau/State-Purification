import QIT.Core.Pure
import QIT.Core.Map
import QIT.Symmetry.UnitaryTwirl
import Mathlib.Tactic

/-!
# Orthogonal complement of a normalized pure resource

This is the finite-matrix realization of the projector Pi_eta_perp used in the
PPT resource-effect certificate.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {r : Type*} [Fintype r] [DecidableEq r]

/-- Orthogonal-complement projector I - |eta><eta|. -/
def pureVectorPerpProjection (eta : PureVector r) : CMatrix r :=
  1 - rankOneMatrix eta.amp

/-- A normalized rank-one pure-state matrix is bounded by the identity. -/
theorem rankOneMatrix_pureVector_le_one (eta : PureVector r) :
    rankOneMatrix eta.amp ≤ (1 : CMatrix r) := by
  rw [Matrix.le_iff]
  exact MatrixMap.posSemidef_one_sub_of_posSemidef_idempotent
    (rankOneMatrix eta.amp) (rankOneMatrix_pos eta.amp)
    (by simpa [PureVector.state_matrix] using eta.state_matrix_mul_self)

theorem pureVectorPerpProjection_posSemidef (eta : PureVector r) :
    (pureVectorPerpProjection eta).PosSemidef := by
  exact MatrixMap.posSemidef_one_sub_of_posSemidef_idempotent
    (rankOneMatrix eta.amp) (rankOneMatrix_pos eta.amp)
    (by simpa [PureVector.state_matrix] using eta.state_matrix_mul_self)

theorem pureVectorPerpProjection_le_one (eta : PureVector r) :
    pureVectorPerpProjection eta ≤ (1 : CMatrix r) := by
  rw [Matrix.le_iff]
  simpa [pureVectorPerpProjection] using rankOneMatrix_pos eta.amp

@[simp]
theorem pureVectorPerpProjection_conjTranspose (eta : PureVector r) :
    Matrix.conjTranspose (pureVectorPerpProjection eta) =
      pureVectorPerpProjection eta := by
  simp [pureVectorPerpProjection]

theorem pureVectorPerpProjection_isHermitian (eta : PureVector r) :
    (pureVectorPerpProjection eta).IsHermitian :=
  pureVectorPerpProjection_conjTranspose eta

@[simp]
theorem pureVectorPerpProjection_idempotent (eta : PureVector r) :
    pureVectorPerpProjection eta * pureVectorPerpProjection eta =
      pureVectorPerpProjection eta := by
  have hR : rankOneMatrix eta.amp * rankOneMatrix eta.amp =
      rankOneMatrix eta.amp := by
    simpa [PureVector.state_matrix] using eta.state_matrix_mul_self
  simp only [pureVectorPerpProjection]
  noncomm_ring [hR]

@[simp]
theorem pureVectorPerpProjection_mulVec (eta : PureVector r) :
    Matrix.mulVec (pureVectorPerpProjection eta) eta.amp = 0 := by
  have hnorm : (fun i => star (eta.amp i)) ⬝ᵥ eta.amp = 1 := by
    have htrace := eta.trace_rankOne_eq_one
    rw [rankOneMatrix_trace] at htrace
    rw [dotProduct_comm]
    exact htrace
  have hrank :
      Matrix.mulVec (rankOneMatrix eta.amp) eta.amp = eta.amp := by
    have hnorm_sum :
        (∑ x : r, star (eta.amp x) * eta.amp x) = 1 := by
      simpa [dotProduct] using hnorm
    funext i
    simp only [Matrix.mulVec, rankOneMatrix_apply]
    calc
      (∑ x : r, eta.amp i * star (eta.amp x) * eta.amp x) =
          eta.amp i * (∑ x : r, star (eta.amp x) * eta.amp x) := by
            rw [Finset.mul_sum]
            apply Finset.sum_congr rfl
            intro x _
            ring
      _ = eta.amp i := by rw [hnorm_sum, mul_one]
  rw [pureVectorPerpProjection, Matrix.sub_mulVec,
    Matrix.one_mulVec, hrank]
  exact sub_self eta.amp

/-- If a matrix and its adjoint have the normalized vector `eta` as the same
real-eigenvalue eigenvector, then all mixed matrix elements between `eta` and
its orthogonal complement vanish.  This is exactly the two decompositions in
`eq:forced_offdiagonal_block_decompositions`. -/
theorem matrix_eq_eigen_rankOne_add_perp_compression
    (eta : PureVector r) (C : CMatrix r) (t : ℝ)
    (hC : C.mulVec eta.amp = (t : ℂ) • eta.amp)
    (hCstar : (Matrix.conjTranspose C).mulVec eta.amp =
      (t : ℂ) • eta.amp) :
    C = (t : ℂ) • rankOneMatrix eta.amp +
      pureVectorPerpProjection eta * C * pureVectorPerpProjection eta := by
  let R : CMatrix r := rankOneMatrix eta.amp
  have hCR : C * R = (t : ℂ) • R := by
    exact matrix_mul_rankOneMatrix_eq_smul_of_mulVec_eq_smul
      C eta.amp (t : ℂ) hC
  have hCstarR : Matrix.conjTranspose C * R = (t : ℂ) • R := by
    exact matrix_mul_rankOneMatrix_eq_smul_of_mulVec_eq_smul
      (Matrix.conjTranspose C) eta.amp (t : ℂ) hCstar
  have hRC : R * C = (t : ℂ) • R := by
    have h := congrArg Matrix.conjTranspose hCstarR
    simpa [R, Matrix.conjTranspose_mul] using h
  have hRR : R * R = R := by
    simpa [R, PureVector.state_matrix] using eta.state_matrix_mul_self
  have htRR : ((t : ℂ) • R) * R = (t : ℂ) • R := by
    rw [Matrix.smul_mul, hRR]
  change C = (t : ℂ) • R + (1 - R) * C * (1 - R)
  noncomm_ring [hCR, hRC, htRR]

end

end EntanglementPurification
