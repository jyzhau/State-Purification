import QIT.Entanglement.Majorization
import QIT.Util.Matrix.PosSqrt
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.InnerProductSpace.Positive
import Mathlib.Tactic

/-!
# Effect bounds for the Schmidt-spectrum converse

This file formalizes the operator inequalities used in Appendix
"Effect Constraints and Schmidt-Spectrum Bounds" of `main.tex`.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

/-- A finite-dimensional quantum effect is a positive semidefinite complex
matrix bounded above by the identity. -/
def IsEffectMatrix {r : Type*} [Fintype r] [DecidableEq r]
    (N : CMatrix r) : Prop :=
  N.PosSemidef ∧ N ≤ 1

/-- Real part of the standard quadratic form associated with a complex
matrix. -/
def quadraticRe {r : Type*} [Fintype r]
    (N : CMatrix r) (u : r → ℂ) : ℝ :=
  RCLike.re (star u ⬝ᵥ N.mulVec u)

/-- Squared Euclidean norm of a finite complex vector, written in matrix
coordinates. -/
def cVecNormSq {r : Type*} [Fintype r] (u : r → ℂ) : ℝ :=
  RCLike.re (star u ⬝ᵥ u)

theorem cVecNormSq_nonneg
    {r : Type*} [Fintype r] (u : r → ℂ) :
    0 ≤ cVecNormSq u := by
  exact (Complex.nonneg_iff.mp (dotProduct_star_self_nonneg u)).1

/-- Coordinate norm squared agrees with the Hilbert-space norm after wrapping
the vector as a finite Euclidean-space element. -/
theorem cVecNormSq_eq_norm_toLp_sq
    {r : Type*} [Fintype r] (u : r → ℂ) :
    cVecNormSq u =
      ‖(WithLp.toLp 2 u : EuclideanSpace ℂ r)‖ ^ 2 := by
  calc
    cVecNormSq u =
        RCLike.re (inner ℂ (WithLp.toLp 2 u : EuclideanSpace ℂ r)
          (WithLp.toLp 2 u : EuclideanSpace ℂ r)) := by
      change (star u ⬝ᵥ u).re = (u ⬝ᵥ star u).re
      rw [dotProduct_comm]
    _ = ‖(WithLp.toLp 2 u : EuclideanSpace ℂ r)‖ ^ 2 := by
      simpa using
        (inner_self_eq_norm_sq (𝕜 := ℂ)
          (WithLp.toLp 2 u : EuclideanSpace ℂ r))

/-- Real part of the standard complex inner product of two coordinate
vectors. -/
def cVecInnerRe {r : Type*} [Fintype r]
    (u v : r → ℂ) : ℝ :=
  RCLike.re (star u ⬝ᵥ v)

/-- Real part of the mixed matrix element `⟨u, N v⟩`. -/
def effectCrossRe {r : Type*} [Fintype r]
    (N : CMatrix r) (u v : r → ℂ) : ℝ :=
  cVecInnerRe u (N.mulVec v)

/-- Coordinate/Hilbert-space bridge for mixed inner products. -/
theorem cVecInnerRe_eq_re_inner_toLp
    {r : Type*} [Fintype r] (u v : r → ℂ) :
    cVecInnerRe u v =
      RCLike.re
        (inner ℂ
          (WithLp.toLp 2 u : EuclideanSpace ℂ r)
          (WithLp.toLp 2 v : EuclideanSpace ℂ r)) := by
  change (star u ⬝ᵥ v).re = (v ⬝ᵥ star u).re
  rw [dotProduct_comm]

/-- Hermiticity lets a mixed matrix element be evaluated with `N` acting
on its left vector. -/
theorem effectCrossRe_eq_mulVec_left
    {r : Type*} [Fintype r] [DecidableEq r]
    {N : CMatrix r} (hN : N.IsHermitian) (u v : r → ℂ) :
    effectCrossRe N u v = cVecInnerRe (N.mulVec u) v := by
  simp only [effectCrossRe, cVecInnerRe, Matrix.star_mulVec,
    Matrix.dotProduct_mulVec, hN.eq]

@[simp]
theorem cVecInnerRe_add_right
    {r : Type*} [Fintype r] (u v w : r → ℂ) :
    cVecInnerRe u (v + w) =
      cVecInnerRe u v + cVecInnerRe u w := by
  simp [cVecInnerRe, dotProduct_add]

@[simp]
theorem cVecInnerRe_sub_left
    {r : Type*} [Fintype r] (u v w : r → ℂ) :
    cVecInnerRe (u - v) w =
      cVecInnerRe u w - cVecInnerRe v w := by
  simp [cVecInnerRe, sub_dotProduct]

@[simp]
theorem cVecInnerRe_real_smul_right
    {r : Type*} [Fintype r] (a : ℝ) (u v : r → ℂ) :
    cVecInnerRe u ((a : ℂ) • v) = a * cVecInnerRe u v := by
  simp [cVecInnerRe, dotProduct_smul]

@[simp]
theorem cVecInnerRe_real_smul_left
    {r : Type*} [Fintype r] (a : ℝ) (u v : r → ℂ) :
    cVecInnerRe ((a : ℂ) • u) v = a * cVecInnerRe u v := by
  simp [cVecInnerRe, smul_dotProduct]

theorem cVecInnerRe_symm
    {r : Type*} [Fintype r] (u v : r → ℂ) :
    cVecInnerRe u v = cVecInnerRe v u := by
  let x : EuclideanSpace ℂ r := WithLp.toLp 2 u
  let y : EuclideanSpace ℂ r := WithLp.toLp 2 v
  have hxy : RCLike.re (inner ℂ x y) = cVecInnerRe u v := by
    change (v ⬝ᵥ star u).re = (star u ⬝ᵥ v).re
    rw [dotProduct_comm]
  have hyx : RCLike.re (inner ℂ y x) = cVecInnerRe v u := by
    change (u ⬝ᵥ star v).re = (star v ⬝ᵥ u).re
    rw [dotProduct_comm]
  rw [← hxy, ← hyx, inner_re_symm]

/-- Decompose a mixed effect matrix element into its mean contribution and
the inner product of the centered effect output with an orthogonal
residual. -/
theorem effectCrossRe_centered_residual_identity
    {r : Type*} [Fintype r] [DecidableEq r]
    {N : CMatrix r} (hN : N.IsHermitian)
    (u v w : r → ℂ) (alpha mu : ℝ)
    (hv : v = (alpha : ℂ) • u + w)
    (horth : cVecInnerRe u w = 0) :
    effectCrossRe N u v =
      alpha * quadraticRe N u +
        cVecInnerRe (N.mulVec u - (mu : ℂ) • u) w := by
  rw [effectCrossRe_eq_mulVec_left hN, hv]
  rw [cVecInnerRe_add_right, cVecInnerRe_real_smul_right]
  rw [cVecInnerRe_sub_left, cVecInnerRe_real_smul_left]
  rw [cVecInnerRe_symm (N.mulVec u) u, horth]
  simp only [mul_zero, sub_zero]
  rfl

/-- The real part of a complex inner product is bounded below by the
negative product of the two Euclidean norms.  The norms are kept in the
coordinate-squared form used by the effect calculation. -/
theorem cVecInnerRe_lower_bound
    {r : Type*} [Fintype r] (u v : r → ℂ) :
    -Real.sqrt (cVecNormSq u) * Real.sqrt (cVecNormSq v) ≤
      cVecInnerRe u v := by
  let x : EuclideanSpace ℂ r := WithLp.toLp 2 u
  let y : EuclideanSpace ℂ r := WithLp.toLp 2 v
  have hinner :
      RCLike.re (inner ℂ x y) = cVecInnerRe u v := by
    change (v ⬝ᵥ star u).re = (star u ⬝ᵥ v).re
    rw [dotProduct_comm]
  have habs :
      |RCLike.re (inner ℂ x y)| ≤ ‖x‖ * ‖y‖ :=
    (Complex.abs_re_le_norm _).trans (norm_inner_le_norm x y)
  have hlower :
      -(‖x‖ * ‖y‖) ≤ RCLike.re (inner ℂ x y) :=
    (abs_le.mp habs).1
  have hsqrtX : Real.sqrt (cVecNormSq u) = ‖x‖ := by
    rw [cVecNormSq_eq_norm_toLp_sq]
    exact Real.sqrt_sq (norm_nonneg x)
  have hsqrtY : Real.sqrt (cVecNormSq v) = ‖y‖ := by
    rw [cVecNormSq_eq_norm_toLp_sq]
    exact Real.sqrt_sq (norm_nonneg y)
  simpa [hsqrtX, hsqrtY, hinner] using hlower

/-- Loewner order implies the corresponding inequality for every quadratic
form. -/
theorem quadraticRe_le_of_le
    {r : Type*} [Fintype r] [DecidableEq r]
    {A B : CMatrix r} (hAB : A ≤ B) (u : r → ℂ) :
    quadraticRe A u ≤ quadraticRe B u := by
  have hq :=
    (Matrix.le_iff.mp hAB).dotProduct_mulVec_nonneg u
  have hre := (Complex.nonneg_iff.mp hq).1
  simpa [quadraticRe, Matrix.sub_mulVec] using hre

/-- Every effect satisfies `N² ≤ N`.  This is the operator inequality used in
the centered-variance estimate in `main.tex`. -/
theorem effect_sq_le_self
    {r : Type*} [Fintype r] [DecidableEq r]
    {N : CMatrix r} (hN : IsEffectMatrix N) :
    N * N ≤ N := by
  let S : CMatrix r := psdSqrt N
  have hcomp : (1 - N).PosSemidef := Matrix.le_iff.mp hN.2
  have hconj : (Matrix.conjTranspose S * (1 - N) * S).PosSemidef :=
    hcomp.conjTranspose_mul_mul_same S
  have hSstar : Matrix.conjTranspose S = S := (psdSqrt_isHermitian N).eq
  have hSS : S * S = N := by
    simpa [S] using psdSqrt_mul_self_of_posSemidef hN.1
  apply Matrix.le_iff.mpr
  convert hconj using 1
  rw [hSstar, ← hSS]
  noncomm_ring

/-- For a Hermitian matrix, the squared norm of `N u` is the quadratic form
of `N²` at `u`. -/
theorem cVecNormSq_mulVec_eq_quadraticRe_sq
    {r : Type*} [Fintype r] [DecidableEq r]
    {N : CMatrix r} (hN : N.IsHermitian) (u : r → ℂ) :
    cVecNormSq (N.mulVec u) = quadraticRe (N * N) u := by
  simp only [cVecNormSq, quadraticRe, Matrix.star_mulVec, Matrix.dotProduct_mulVec,
    Matrix.vecMul_vecMul, hN.eq]

/-- Vector form of `N² ≤ N`: applying an effect cannot have squared output
norm larger than its input-output quadratic form. -/
theorem effect_mulVec_normSq_le_quadraticRe
    {r : Type*} [Fintype r] [DecidableEq r]
    {N : CMatrix r} (hN : IsEffectMatrix N) (u : r → ℂ) :
    cVecNormSq (N.mulVec u) ≤ quadraticRe N u := by
  rw [cVecNormSq_mulVec_eq_quadraticRe_sq hN.1.isHermitian]
  exact quadraticRe_le_of_le (effect_sq_le_self hN) u

/-- An effect's expectation on any vector is at most the vector's squared
norm. -/
theorem effect_quadraticRe_le_normSq
    {r : Type*} [Fintype r] [DecidableEq r]
    {N : CMatrix r} (hN : IsEffectMatrix N) (u : r → ℂ) :
    quadraticRe N u ≤ cVecNormSq u := by
  have hquad := quadraticRe_le_of_le hN.2 u
  simpa [quadraticRe, cVecNormSq] using hquad

/-- The diagonal effect lower bound in the paper forces the largest Schmidt
weight to be at most `2/3`. -/
theorem schmidtHead_le_two_thirds_of_effect
    {r : Type*} [Fintype r] [DecidableEq r]
    {N : CMatrix r} (hN : IsEffectMatrix N)
    (u : r → ℂ) (x : ℝ)
    (hu : cVecNormSq u = 1 - x)
    (hlower : (1 / 3 : ℝ) ≤ quadraticRe N u) :
    x ≤ 2 / 3 := by
  have hupper := effect_quadraticRe_le_normSq hN u
  rw [hu] at hupper
  linarith

/-- Bounds on the normalized effect mean used in the monotonicity step of
Appendix B. -/
theorem normalized_effect_mean_bounds
    {r : Type*} [Fintype r] [DecidableEq r]
    {N : CMatrix r} (hN : IsEffectMatrix N)
    (u : r → ℂ) (x mu : ℝ)
    (hx : x < 1)
    (hu : cVecNormSq u = 1 - x)
    (hlower : (1 / 3 : ℝ) ≤ quadraticRe N u)
    (hmean : quadraticRe N u = mu * (1 - x)) :
    1 / (3 * (1 - x)) ≤ mu ∧ mu ≤ 1 := by
  have hxpos : 0 < 1 - x := by linarith
  have hupper := effect_quadraticRe_le_normSq hN u
  rw [hu, hmean] at hupper
  constructor
  · rw [div_le_iff₀ (mul_pos (by norm_num) hxpos)]
    nlinarith [hlower]
  · nlinarith

/-- Expanding the squared norm of the centered vector
`N u - μ u`. -/
theorem centered_cVecNormSq_identity
    {r : Type*} [Fintype r] [DecidableEq r]
    (N : CMatrix r) (u : r → ℂ) (μ : ℝ) :
    cVecNormSq (N.mulVec u - (μ : ℂ) • u) =
      cVecNormSq (N.mulVec u) - 2 * μ * quadraticRe N u +
        μ ^ 2 * cVecNormSq u := by
  let x : EuclideanSpace ℂ r := WithLp.toLp 2 (N.mulVec u)
  let y : EuclideanSpace ℂ r := WithLp.toLp 2 u
  have hcenter :
      (WithLp.toLp 2 (N.mulVec u - (μ : ℂ) • u) :
        EuclideanSpace ℂ r) = x - (μ : ℂ) • y := rfl
  have hxnorm : ‖x‖ ^ 2 = cVecNormSq (N.mulVec u) := by
    simpa [x] using (cVecNormSq_eq_norm_toLp_sq (N.mulVec u)).symm
  have hynorm : ‖y‖ ^ 2 = cVecNormSq u := by
    simpa [y] using (cVecNormSq_eq_norm_toLp_sq u).symm
  have hcross : RCLike.re (inner ℂ x y) = quadraticRe N u := by
    rw [inner_re_symm]
    change (N.mulVec u ⬝ᵥ star u).re =
      (star u ⬝ᵥ N.mulVec u).re
    rw [dotProduct_comm]
  have hscaledCross :
      RCLike.re (inner ℂ x ((μ : ℂ) • y)) =
        μ * quadraticRe N u := by
    have hcrossComplex :
        (inner ℂ x y).re = quadraticRe N u := by
      simpa only [RCLike.re_eq_complex_re] using hcross
    rw [inner_smul_right]
    change (((μ : ℂ) * inner ℂ x y).re) =
      μ * quadraticRe N u
    rw [Complex.mul_re]
    simp only [Complex.ofReal_re, Complex.ofReal_im, zero_mul, sub_zero]
    rw [hcrossComplex]
  rw [cVecNormSq_eq_norm_toLp_sq, hcenter, norm_sub_sq (𝕜 := ℂ)]
  rw [hxnorm]
  have hscaledNorm :
      ‖(μ : ℂ) • y‖ ^ 2 = μ ^ 2 * ‖y‖ ^ 2 := by
    rw [norm_smul]
    simp only [Complex.norm_real, Real.norm_eq_abs]
    rw [mul_pow, sq_abs]
  rw [hscaledNorm, hynorm]
  rw [hscaledCross]
  ring

/-- Centered variance bound for an effect.  If the quadratic-form mean of
`N` on `u` is `mu`, then the centered output has variance at most
`mu * (1 - mu)` times the squared norm of `u`. -/
theorem effect_centered_variance_bound
    {r : Type*} [Fintype r] [DecidableEq r]
    {N : CMatrix r} (hN : IsEffectMatrix N)
    (u : r → ℂ) (mu : ℝ)
    (hmean : quadraticRe N u = mu * cVecNormSq u) :
    cVecNormSq (N.mulVec u - (mu : ℂ) • u) ≤
      mu * (1 - mu) * cVecNormSq u := by
  rw [centered_cVecNormSq_identity]
  have hcontract := effect_mulVec_normSq_le_quadraticRe hN u
  rw [hmean] at hcontract ⊢
  nlinarith

/-- Cauchy--Schwarz bound for the two-vector effect calculation, before
using the variance estimate. -/
theorem effectCrossRe_lower_bound_centered
    {r : Type*} [Fintype r] [DecidableEq r]
    {N : CMatrix r} (hN : N.IsHermitian)
    (u v w : r → ℂ) (alpha mu : ℝ)
    (hv : v = (alpha : ℂ) • u + w)
    (horth : cVecInnerRe u w = 0) :
    alpha * quadraticRe N u -
        Real.sqrt (cVecNormSq (N.mulVec u - (mu : ℂ) • u)) *
          Real.sqrt (cVecNormSq w) ≤
      effectCrossRe N u v := by
  have hid :=
    effectCrossRe_centered_residual_identity hN u v w alpha mu hv horth
  have hcs :=
    cVecInnerRe_lower_bound
      (N.mulVec u - (mu : ℂ) • u) w
  rw [hid]
  linarith

/-- Paper equation `eq:explicit_two_vector_effect_bound` in its abstract
Gram--Schmidt form. -/
theorem effectCrossRe_lower_bound
    {r : Type*} [Fintype r] [DecidableEq r]
    {N : CMatrix r} (hN : IsEffectMatrix N)
    (u v w : r → ℂ) (alpha mu : ℝ)
    (hv : v = (alpha : ℂ) • u + w)
    (horth : cVecInnerRe u w = 0)
    (hmean : quadraticRe N u = mu * cVecNormSq u) :
    alpha * mu * cVecNormSq u -
        Real.sqrt (mu * (1 - mu) * cVecNormSq u) *
          Real.sqrt (cVecNormSq w) ≤
      effectCrossRe N u v := by
  have hraw :=
    effectCrossRe_lower_bound_centered hN.1.isHermitian
      u v w alpha mu hv horth
  have hvariance :=
    effect_centered_variance_bound hN u mu hmean
  have hsqrt :
      Real.sqrt (cVecNormSq (N.mulVec u - (mu : ℂ) • u)) ≤
        Real.sqrt (mu * (1 - mu) * cVecNormSq u) :=
    Real.sqrt_le_sqrt hvariance
  have hmul :
      Real.sqrt (cVecNormSq (N.mulVec u - (mu : ℂ) • u)) *
          Real.sqrt (cVecNormSq w) ≤
        Real.sqrt (mu * (1 - mu) * cVecNormSq u) *
          Real.sqrt (cVecNormSq w) :=
    mul_le_mul_of_nonneg_right hsqrt (Real.sqrt_nonneg _)
  rw [hmean] at hraw
  nlinarith

/-- Specialization of `effectCrossRe_lower_bound` to the Gram data in
Appendix B.  Here `x` is the largest Schmidt weight, `y` the second
weight, and `tail` the mass in all remaining coordinates. -/
theorem effectCrossRe_lower_bound_of_gram_data
    {r : Type*} [Fintype r] [DecidableEq r]
    {N : CMatrix r} (hN : IsEffectMatrix N)
    (u v w : r → ℂ) (x y tail mu : ℝ)
    (hx : x < 1) (hmu0 : 0 ≤ mu) (hmu1 : mu ≤ 1)
    (hu : cVecNormSq u = 1 - x)
    (hv : v =
      ((Real.sqrt (x * y) / (1 - x) : ℝ) : ℂ) • u + w)
    (horth : cVecInnerRe u w = 0)
    (hw : cVecNormSq w = tail / (1 - x))
    (hmean : quadraticRe N u = mu * (1 - x)) :
    mu * Real.sqrt (x * y) -
        Real.sqrt (mu * (1 - mu) * tail) ≤
      effectCrossRe N u v := by
  have hmean' : quadraticRe N u = mu * cVecNormSq u := by
    rw [hu]
    exact hmean
  have hraw :=
    effectCrossRe_lower_bound hN u v w
      (Real.sqrt (x * y) / (1 - x)) mu hv horth hmean'
  rw [hu, hw] at hraw
  have hxpos : 0 < 1 - x := by linarith
  have hxne : 1 - x ≠ 0 := ne_of_gt hxpos
  have hlinear :
      Real.sqrt (x * y) / (1 - x) * mu * (1 - x) =
        mu * Real.sqrt (x * y) := by
    field_simp [hxne]
  have hvarianceNonneg :
      0 ≤ mu * (1 - mu) * (1 - x) :=
    mul_nonneg (mul_nonneg hmu0 (by linarith)) hxpos.le
  have hproduct :
      (mu * (1 - mu) * (1 - x)) * (tail / (1 - x)) =
        mu * (1 - mu) * tail := by
    field_simp [hxne]
  have hsqrtProduct :
      Real.sqrt (mu * (1 - mu) * (1 - x)) *
          Real.sqrt (tail / (1 - x)) =
        Real.sqrt (mu * (1 - mu) * tail) := by
    rw [← Real.sqrt_mul hvarianceNonneg, hproduct]
  rw [hlinear, hsqrtProduct] at hraw
  exact hraw

end

end EntanglementPurification
