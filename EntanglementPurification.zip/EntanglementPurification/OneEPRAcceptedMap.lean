import EntanglementPurification.GlobalConcreteSDP
import EntanglementPurification.GlobalHaarOptimality
import Mathlib.Tactic

/-!
# Map-level model of the accepted one-EPR branch

This file formalizes the finite-dimensional map whose Kraus operators are
displayed in `eq:one_epr_accepted_choi` of `main.tex`.  For an input basis
vector `|a,b>` and an output basis vector `|c>`, the Kraus operator indexed by
`i` has matrix element

`K_i(c,(a,b)) = (1/2) (Gamma_+)((a,b),c),i`.

We prove that its input-first Choi matrix is exactly the unique global
optimizer `J_star = (D+1) P_{W_+}/2`, and hence that this map attains the
global Haar objective.

This is deliberately a map-level statement.  It does not yet formalize the
local gates, measurements, classical communication, or the derivation of
these Kraus operators from the full Algorithm 1 circuit.
-/

namespace EntanglementPurification

open QIT

noncomputable section

/-- Kraus family of the accepted one-EPR map, in the paper's input-first
three-leg convention. -/
def oneEPRAcceptedKraus
    {x : Type*} [DecidableEq x] (i : x) :
    Matrix x (x × x) ℂ :=
  fun out input =>
    (1 / 2 : ℂ) * globalGammaPlus (input, out) i

/-- The map-level accepted branch associated with the displayed one-EPR
Kraus family. -/
def oneEPRAcceptedMap
    {x : Type*} [Fintype x] [DecidableEq x] :
    MatrixMap (x × x) x :=
  MatrixMap.ofKraus (oneEPRAcceptedKraus (x := x))

/-- Before rewriting with the normalized `W_+` projector, the Choi matrix of
the accepted map is the unnormalized contraction projector scaled by `1/4`.
-/
theorem choi_oneEPRAcceptedMap_eq_quarter_gammaPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    MatrixMap.choi (oneEPRAcceptedMap (x := x)) =
      (1 / 4 : ℂ) •
        (globalGammaPlus * Matrix.conjTranspose globalGammaPlus) := by
  rw [oneEPRAcceptedMap, MatrixMap.choi_ofKraus]
  ext p q
  simp only [Matrix.sum_apply, Matrix.vecMulVec_apply,
    oneEPRAcceptedKraus, Matrix.smul_apply, Matrix.mul_apply,
    Matrix.conjTranspose_apply]
  change
    (∑ i : x,
      (1 / 2 : ℂ) * globalGammaPlus p i *
        star ((1 / 2 : ℂ) * globalGammaPlus q i)) =
      (1 / 4 : ℂ) *
        ∑ i : x, globalGammaPlus p i * star (globalGammaPlus q i)
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  simp only [star_mul]
  norm_num
  ring

/-- Equation `eq:one_epr_accepted_choi`: the accepted one-EPR map has Choi
matrix exactly equal to the unique global optimizer. -/
theorem choi_oneEPRAcceptedMap_eq_globalOptimalChoi
    {x : Type*} [Fintype x] [DecidableEq x] :
    MatrixMap.choi (oneEPRAcceptedMap (x := x)) =
      globalOptimalChoi (x := x) := by
  rw [choi_oneEPRAcceptedMap_eq_quarter_gammaPlus,
    globalOptimalChoi, globalPWPlus_eq_scaledGammaPlus]
  rw [smul_smul]
  congr 1
  have hdenom : (Fintype.card x : ℝ) + 1 ≠ 0 := by positivity
  push_cast
  field_simp
  norm_num

/-- The accepted one-EPR map is the map reconstructed from the optimal Choi
matrix. -/
theorem oneEPRAcceptedMap_eq_ofChoi_globalOptimalChoi
    {x : Type*} [Fintype x] [DecidableEq x] :
    oneEPRAcceptedMap (x := x) =
      MatrixMap.ofChoiMatrix (globalOptimalChoi (x := x)) := by
  apply MatrixMap.choi_inj
  rw [choi_oneEPRAcceptedMap_eq_globalOptimalChoi,
    MatrixMap.choi_ofChoiMatrix]

/-- The accepted one-EPR map is completely positive and trace
nonincreasing. -/
theorem oneEPRAcceptedMap_traceNonincreasingCP
    {x : Type*} [Fintype x] [DecidableEq x] :
    MatrixMap.TraceNonincreasingCP (oneEPRAcceptedMap (x := x)) := by
  rw [oneEPRAcceptedMap_eq_ofChoi_globalOptimalChoi]
  exact (isGlobalCPTNChoi_iff_traceNonincreasingCP
    (globalOptimalChoi (x := x))).1 globalOptimalChoi_isGlobalCPTNChoi

/-- Map-level sufficiency endpoint: in paper dimension `D=d^2`, the accepted
one-EPR map reaches the exact Haar-averaged global gain. -/
theorem oneEPRAcceptedMap_attains_globalPaperHaar_gain
    {d : ℕ} (hd : 2 ≤ d)
    (nu : PureVector (GlobalPaperIndex d))
    (gamma : ℝ) :
    globalSDPObjective
        (globalPaperHaarPerformanceOperator hd nu gamma)
        (MatrixMap.choi
          (oneEPRAcceptedMap (x := GlobalPaperIndex d))) =
      globalOptimalGain ((d : ℝ) ^ 2) gamma := by
  rw [choi_oneEPRAcceptedMap_eq_globalOptimalChoi]
  rw [globalPaperHaarPerformanceOperator_eq_raw]
  simpa [GlobalPaperIndex, pow_two] using
    (globalOptimalChoi_raw_objective_eq_globalOptimalGain
      (x := GlobalPaperIndex d) (gamma := gamma)
      (four_le_card_globalPaperIndex hd))

end

end EntanglementPurification
