import EntanglementPurification.GlobalMomentExpansion
import EntanglementPurification.LocalMixedSchur
import QIT.Symmetry.UnitaryTwirl
import Mathlib.Tactic

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {x : Type*} [Fintype x] [DecidableEq x]

@[simp]
private theorem localEntrywiseConjugate_map_star_for_completeness
    (W : Matrix.unitaryGroup x ℂ) :
    localEntrywiseConjugate (Matrix.UnitaryGroup.map_star W) =
      (W : CMatrix x) := by
  ext i j
  simp [localEntrywiseConjugate, Matrix.UnitaryGroup.map_star]

def localMixedIntertwinerPairFlatten
    (T : Matrix (LocalMixedSchurSpace x) x ℂ) :
    CMatrix (x × x) :=
  fun p q => T (p, q.1) q.2

def localMixedIntertwinerTensorFlatten
    (T : Matrix (LocalMixedSchurSpace x) x ℂ) :
    CMatrix (TensorPower x 2) :=
  Matrix.reindex tensorPowerTwoEquiv.symm tensorPowerTwoEquiv.symm
    (localMixedIntertwinerPairFlatten T)

theorem reindex_pairKronecker_eq_unitaryTensorPowerMatrix_two
    (W : Matrix.unitaryGroup x ℂ) :
    Matrix.reindex tensorPowerTwoEquiv.symm tensorPowerTwoEquiv.symm
        (Matrix.kronecker (W : CMatrix x) (W : CMatrix x)) =
      (unitaryTensorPowerMatrix W 2 : CMatrix (TensorPower x 2)) := by
  ext p q
  simp [Matrix.reindex_apply, tensorPowerTwoEquiv,
    Matrix.kronecker, unitaryTensorPowerMatrix_apply_eq_fin_prod,
    ]

theorem localMixedIntertwinerPairFlatten_invariant
    (T : Matrix (LocalMixedSchurSpace x) x ℂ)
    (hT : ∀ U : Matrix.unitaryGroup x ℂ,
      localMixedSchurRepresentation U * T =
        T * localEntrywiseConjugate U) :
    ∀ W : Matrix.unitaryGroup x ℂ,
      Matrix.kronecker (W : CMatrix x) (W : CMatrix x) *
          localMixedIntertwinerPairFlatten T *
          star (Matrix.kronecker (W : CMatrix x) (W : CMatrix x)) =
        localMixedIntertwinerPairFlatten T := by
  intro W
  let U := Matrix.UnitaryGroup.map_star W
  have hRightUnitary :
      localEntrywiseConjugate U *
          Matrix.conjTranspose (localEntrywiseConjugate U) =
        (1 : CMatrix x) := by
    change (↑(Matrix.UnitaryGroup.map_star U) : CMatrix x) *
        Matrix.conjTranspose
          (↑(Matrix.UnitaryGroup.map_star U) : CMatrix x) = 1
    simpa [Matrix.star_eq_conjTranspose] using
      (Matrix.mem_unitaryGroup_iff.mp
        (SetLike.coe_mem (Matrix.UnitaryGroup.map_star U)))
  have hRect :
      localMixedSchurRepresentation U * T *
          Matrix.conjTranspose (localEntrywiseConjugate U) =
        T := by
    calc
      localMixedSchurRepresentation U * T *
          Matrix.conjTranspose (localEntrywiseConjugate U) =
        (T * localEntrywiseConjugate U) *
          Matrix.conjTranspose (localEntrywiseConjugate U) := by
            rw [hT U]
      _ = T *
          (localEntrywiseConjugate U *
            Matrix.conjTranspose (localEntrywiseConjugate U)) := by
              simp only [Matrix.mul_assoc]
      _ = T := by rw [hRightUnitary, Matrix.mul_one]
  rw [Matrix.star_eq_conjTranspose]
  ext ⟨p, q⟩ ⟨r, a⟩
  have hEntry := congrFun (congrFun hRect ((p, q), r)) a
  simp [localMixedIntertwinerPairFlatten,
    localMixedSchurRepresentation,
    Matrix.mul_apply, Matrix.kronecker,
    Matrix.kroneckerMap_apply, Matrix.conjTranspose_apply,
    Fintype.sum_prod_type, U, Finset.sum_mul] at hEntry ⊢
  conv_lhs =>
    rw [Finset.sum_comm]
    enter [2, b]
    rw [Finset.sum_comm]
    enter [2, i]
    rw [Finset.sum_comm]
  simpa [mul_assoc, mul_comm, mul_left_comm] using hEntry

theorem localMixedIntertwinerTensorFlatten_invariant
    (T : Matrix (LocalMixedSchurSpace x) x ℂ)
    (hT : ∀ U : Matrix.unitaryGroup x ℂ,
      localMixedSchurRepresentation U * T =
        T * localEntrywiseConjugate U) :
    ∀ W : Matrix.unitaryGroup x ℂ,
      (unitaryTensorPowerMatrix W 2 : CMatrix (TensorPower x 2)) *
          localMixedIntertwinerTensorFlatten T *
          star (unitaryTensorPowerMatrix W 2 :
            CMatrix (TensorPower x 2)) =
        localMixedIntertwinerTensorFlatten T := by
  intro W
  let e := tensorPowerTwoEquiv (x := x).symm
  let R : CMatrix (x × x) :=
    Matrix.kronecker (W : CMatrix x) (W : CMatrix x)
  let A := localMixedIntertwinerPairFlatten T
  have hPair : R * A * star R = A := by
    exact localMixedIntertwinerPairFlatten_invariant T hT W
  have hRA :
      Matrix.reindex e e R * Matrix.reindex e e A =
        Matrix.reindex e e (R * A) := by
    exact Matrix.reindexLinearEquiv_mul (R := ℂ) (A := ℂ)
      e e e R A
  have hRAstar :
      Matrix.reindex e e (R * A) *
          Matrix.reindex e e (star R) =
        Matrix.reindex e e (R * A * star R) := by
    exact Matrix.reindexLinearEquiv_mul (R := ℂ) (A := ℂ)
      e e e (R * A) (star R)
  dsimp [localMixedIntertwinerTensorFlatten]
  have hR :
      Matrix.reindex e e R =
        (unitaryTensorPowerMatrix W 2 :
          CMatrix (TensorPower x 2)) := by
    simpa [e, R] using
      reindex_pairKronecker_eq_unitaryTensorPowerMatrix_two W
  rw [← hR]
  change Matrix.reindex e e R * Matrix.reindex e e A *
      star (Matrix.reindex e e R) = Matrix.reindex e e A
  rw [Matrix.star_eq_conjTranspose, Matrix.conjTranspose_reindex,
    ← Matrix.star_eq_conjTranspose]
  rw [hRA, hRAstar, hPair]

@[simp]
theorem localMixedIntertwinerTensorFlatten_twoCopyTensorWord
    (T : Matrix (LocalMixedSchurSpace x) x ℂ)
    (i j k a : x) :
    localMixedIntertwinerTensorFlatten T
        (twoCopyTensorWord (a := x) i j)
        (twoCopyTensorWord (a := x) k a) =
      T ((i, j), k) a := by
  simp [localMixedIntertwinerTensorFlatten,
    localMixedIntertwinerPairFlatten, Matrix.reindex_apply,
    tensorPowerTwoEquiv]

/-- The full two-copy unitary commutant is the sum of its symmetric and
antisymmetric scalar blocks. -/
theorem unitaryInvariant_two_exists_symmetric_antisymmetric_decomposition
    [Nontrivial x] (B : CMatrix (TensorPower x 2))
    (hB : ∀ W : Matrix.unitaryGroup x ℂ,
      (unitaryTensorPowerMatrix W 2 : CMatrix (TensorPower x 2)) * B *
          star (unitaryTensorPowerMatrix W 2 :
            CMatrix (TensorPower x 2)) = B) :
    ∃ lamPlus lamMinus : ℂ,
      B =
        lamPlus • symmetricProjectionMatrix (a := x) 2 +
        lamMinus • antisymmetricProjectionMatrix_two (a := x) := by
  obtain ⟨lamPlus, hPlus⟩ :=
    unitaryInvariant_mul_symmetricProjectionMatrix_eq_smul
      (a := x) B hB
  obtain ⟨lamMinus, hMinus⟩ :=
    unitaryInvariant_mul_antisymmetricProjectionMatrix_two_eq_smul
      (a := x) B hB
  refine ⟨lamPlus, lamMinus, ?_⟩
  calc
    B = B * 1 := by rw [Matrix.mul_one]
    _ = B * (symmetricProjectionMatrix (a := x) 2 +
        antisymmetricProjectionMatrix_two (a := x)) := by
          rw [symmetricProjectionMatrix_two_add_antisymmetricProjectionMatrix_two]
    _ = B * symmetricProjectionMatrix (a := x) 2 +
        B * antisymmetricProjectionMatrix_two (a := x) := by
          rw [Matrix.mul_add]
    _ = lamPlus • symmetricProjectionMatrix (a := x) 2 +
        lamMinus • antisymmetricProjectionMatrix_two (a := x) := by
          rw [hPlus, hMinus]

/-- Minimal mixed-Schur completeness theorem needed in the paper: every
intertwiner from the dual defining representation into
bar(V) tensor bar(V) tensor V is a linear combination of the two concrete
contractions. -/
theorem localMixedIntertwiner_eq_span_contractions
    (hcard : 2 ≤ Fintype.card x)
    (T : Matrix (LocalMixedSchurSpace x) x ℂ)
    (hT : ∀ U : Matrix.unitaryGroup x ℂ,
      localMixedSchurRepresentation U * T =
        T * localEntrywiseConjugate U) :
    ∃ c₁ c₂ : ℂ, T = c₁ • localGamma1 + c₂ • localGamma2 := by
  letI : Nontrivial x :=
    Fintype.one_lt_card_iff_nontrivial.mp (by omega)
  let B := localMixedIntertwinerTensorFlatten T
  have hB :
      ∀ W : Matrix.unitaryGroup x ℂ,
        (unitaryTensorPowerMatrix W 2 : CMatrix (TensorPower x 2)) * B *
            star (unitaryTensorPowerMatrix W 2 :
              CMatrix (TensorPower x 2)) = B :=
    localMixedIntertwinerTensorFlatten_invariant T hT
  obtain ⟨lamPlus, lamMinus, hDecomp⟩ :=
    unitaryInvariant_two_exists_symmetric_antisymmetric_decomposition B hB
  refine ⟨(lamPlus + lamMinus) / 2,
    (lamPlus - lamMinus) / 2, ?_⟩
  ext ⟨⟨i, j⟩, k⟩ a
  have hEntry := congrFun (congrFun hDecomp
    (twoCopyTensorWord (a := x) i j))
    (twoCopyTensorWord (a := x) k a)
  simp [B, symmetricProjectionMatrix_two_eq_half_one_add_swap,
    antisymmetricProjectionMatrix_two_eq_half_one_sub_swap,
    Matrix.add_apply, Matrix.sub_apply, Matrix.smul_apply,
    Matrix.one_apply, tensorPowerSwapMatrix_two,
    permutationMatrix, PEquiv.toMatrix,
    permEquiv_twoCopySwapPerm_twoCopyTensorWord,
    twoCopyTensorWord_eq_iff, globalGamma1, globalGamma2] at hEntry ⊢
  by_cases hik : i = k <;>
    by_cases hja : j = a <;>
      by_cases hia : i = a <;>
        by_cases hjk : j = k <;>
          simp_all <;>
          ring_nf at *

/-- Orthogonality to both concrete contraction copies kills a mixed
intertwiner.  This is the local Hom-space-zero statement in a matrix form
that can be applied to off-diagonal blocks. -/
theorem localMixedIntertwiner_eq_zero_of_gamma_orthogonal
    (hcard : 2 ≤ Fintype.card x)
    (T : Matrix (LocalMixedSchurSpace x) x ℂ)
    (hT : ∀ U : Matrix.unitaryGroup x ℂ,
      localMixedSchurRepresentation U * T =
        T * localEntrywiseConjugate U)
    (hGamma1 :
      Matrix.conjTranspose (localGamma1 (x := x)) * T = 0)
    (hGamma2 :
      Matrix.conjTranspose (localGamma2 (x := x)) * T = 0) :
    T = 0 := by
  obtain ⟨c₁, c₂, rfl⟩ :=
    localMixedIntertwiner_eq_span_contractions hcard T hT
  let x₀ : x := Classical.choice
    (Fintype.card_pos_iff.mp (by omega : 0 < Fintype.card x))
  have e₁ := congrFun (congrFun hGamma1 x₀) x₀
  have e₂ := congrFun (congrFun hGamma2 x₀) x₀
  simp [Matrix.mul_add, Matrix.mul_smul,
    globalGamma1_conjTranspose_mul_self,
    globalGamma1_conjTranspose_mul_globalGamma2,
    globalGamma2_conjTranspose_mul_globalGamma1,
    globalGamma2_conjTranspose_mul_self,
    Matrix.add_apply, Matrix.smul_apply, Matrix.zero_apply,
    smul_eq_mul] at e₁ e₂
  have hcoef :
      (Fintype.card x : ℂ) ^ 2 - 1 ≠ 0 := by
    intro hzero
    have hsqComplex :
        (Fintype.card x : ℂ) ^ 2 = 1 :=
      sub_eq_zero.mp hzero
    have hsqNat : (Fintype.card x) ^ 2 = 1 := by
      exact_mod_cast hsqComplex
    nlinarith
  have hc₁prod :
      ((Fintype.card x : ℂ) ^ 2 - 1) * c₁ = 0 := by
    linear_combination (Fintype.card x : ℂ) * e₁ - e₂
  have hc₁ : c₁ = 0 :=
    (mul_eq_zero.mp hc₁prod).resolve_left hcoef
  have hc₂ : c₂ = 0 := by
    rw [hc₁] at e₁
    simpa using e₁
  rw [hc₁, hc₂]
  simp

/-- Orthogonal projection onto the two copies of the dual defining
representation carried by the concrete contractions. -/
def localContractionIsotypicProjection :
    CMatrix (LocalMixedSchurSpace x) :=
  localPWPlus + localPWMinus

/-- The local contraction-isotypic projection absorbs the first concrete
contraction.  This turns the abstract span conclusion above into an explicit
range statement. -/
theorem localContractionIsotypicProjection_mul_gamma1
    (hcard : 2 ≤ Fintype.card x) :
    localContractionIsotypicProjection (x := x) * localGamma1 =
      localGamma1 := by
  rw [localContractionIsotypicProjection,
    show localPWPlus (x := x) = globalPWPlus from rfl,
    show localPWMinus (x := x) = globalPWMinus from rfl,
    globalPWPlus_eq_scaledGammaPlus,
    globalPWMinus_eq_scaledGammaMinus hcard]
  simp only [Matrix.add_mul, Matrix.smul_mul, Matrix.mul_assoc,
    globalGammaPlus, globalGammaMinus,
    Matrix.conjTranspose_add, Matrix.conjTranspose_sub,
    Matrix.sub_mul, Matrix.mul_add, Matrix.mul_sub,
    Matrix.mul_smul, Matrix.mul_one, smul_add, smul_sub,
    globalGamma1_conjTranspose_mul_self,
    globalGamma2_conjTranspose_mul_globalGamma1]
  ext p a
  simp [Matrix.add_apply, Matrix.sub_apply, Matrix.smul_apply]
  have hreal : (1 : ℝ) < Fintype.card x := by exact_mod_cast hcard
  have hminus : (-1 + (Fintype.card x : ℂ)) ≠ 0 := by
    exact_mod_cast (ne_of_gt (sub_pos.mpr hreal))
  have hplus : (1 + (Fintype.card x : ℂ)) ≠ 0 := by
    exact_mod_cast (show (1 + (Fintype.card x : ℝ)) ≠ 0 by positivity)
  have hprodPlus :
      (1 + (Fintype.card x : ℂ)) *
          (1 + (Fintype.card x : ℂ))⁻¹ = 1 :=
    mul_inv_cancel₀ hplus
  have hprodMinus :
      (-1 + (Fintype.card x : ℂ)) *
          (-1 + (Fintype.card x : ℂ))⁻¹ = 1 :=
    mul_inv_cancel₀ hminus
  linear_combination
    ((globalGamma1 p a + globalGamma2 p a) / 2) * hprodPlus +
    ((globalGamma1 p a - globalGamma2 p a) / 2) * hprodMinus

/-- The local contraction-isotypic projection also absorbs the second
concrete contraction. -/
theorem localContractionIsotypicProjection_mul_gamma2
    (hcard : 2 ≤ Fintype.card x) :
    localContractionIsotypicProjection (x := x) * localGamma2 =
      localGamma2 := by
  rw [localContractionIsotypicProjection,
    show localPWPlus (x := x) = globalPWPlus from rfl,
    show localPWMinus (x := x) = globalPWMinus from rfl,
    globalPWPlus_eq_scaledGammaPlus,
    globalPWMinus_eq_scaledGammaMinus hcard]
  simp only [Matrix.add_mul, Matrix.smul_mul, Matrix.mul_assoc,
    globalGammaPlus, globalGammaMinus,
    Matrix.conjTranspose_add, Matrix.conjTranspose_sub,
    Matrix.sub_mul, Matrix.mul_add, Matrix.mul_sub,
    Matrix.mul_smul, Matrix.mul_one, smul_add, smul_sub,
    globalGamma2_conjTranspose_mul_self,
    globalGamma1_conjTranspose_mul_globalGamma2]
  ext p a
  simp [Matrix.add_apply, Matrix.sub_apply, Matrix.smul_apply]
  have hreal : (1 : ℝ) < Fintype.card x := by exact_mod_cast hcard
  have hminus : (-1 + (Fintype.card x : ℂ)) ≠ 0 := by
    exact_mod_cast (ne_of_gt (sub_pos.mpr hreal))
  have hplus : (1 + (Fintype.card x : ℂ)) ≠ 0 := by
    exact_mod_cast (show (1 + (Fintype.card x : ℝ)) ≠ 0 by positivity)
  have hprodPlus :
      (1 + (Fintype.card x : ℂ)) *
          (1 + (Fintype.card x : ℂ))⁻¹ = 1 :=
    mul_inv_cancel₀ hplus
  have hprodMinus :
      (-1 + (Fintype.card x : ℂ)) *
          (-1 + (Fintype.card x : ℂ))⁻¹ = 1 :=
    mul_inv_cancel₀ hminus
  linear_combination
    ((globalGamma1 p a + globalGamma2 p a) / 2) * hprodPlus +
    ((globalGamma2 p a - globalGamma1 p a) / 2) * hprodMinus

end

end EntanglementPurification
