import EntanglementPurification.GlobalOptimalLocalBlock
import EntanglementPurification.PhysicalLocalTwirlResource

/-!
# Local-twirl invariance of the inserted global optimizer
-/

namespace EntanglementPurification

open QIT MeasureTheory
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b : Type*}
  [Fintype a] [Fintype b] [DecidableEq a] [DecidableEq b]

/-- The first product-space contraction, with the global physical rows
regrouped into Alice/Bob order. -/
def physicalRegroupedGlobalGamma1 :
    Matrix (JointContractionUnassistedPhysicalIndex a b) (a × b) ℂ :=
  fun p q =>
    globalGamma1 (x := a × b)
      ((physicalInsertedChoiEquiv (a := a) (b := b)).symm p) q

/-- The second product-space contraction, with the global physical rows
regrouped into Alice/Bob order. -/
def physicalRegroupedGlobalGamma2 :
    Matrix (JointContractionUnassistedPhysicalIndex a b) (a × b) ℂ :=
  fun p q =>
    globalGamma2 (x := a × b)
      ((physicalInsertedChoiEquiv (a := a) (b := b)).symm p) q

/-- The regrouped product-space `Γ₊`. -/
def physicalRegroupedGlobalGammaPlus :
    Matrix (JointContractionUnassistedPhysicalIndex a b) (a × b) ℂ :=
  physicalRegroupedGlobalGamma1 + physicalRegroupedGlobalGamma2

/-- The normalized global `W₊`, with its physical rows regrouped by party. -/
def physicalRegroupedGlobalWPlus :
    Matrix (JointContractionUnassistedPhysicalIndex a b) (a × b) ℂ :=
  fun p q =>
    globalWPlus (x := a × b)
      ((physicalInsertedChoiEquiv (a := a) (b := b)).symm p) q

omit [Fintype a] [Fintype b] in
@[simp]
theorem physicalRegroupedGlobalGamma1_apply
    (uA : LocalMixedSchurSpace a) (uB : LocalMixedSchurSpace b)
    (i : a) (j : b) :
    physicalRegroupedGlobalGamma1 (a := a) (b := b) (uA, uB) (i, j) =
      globalGamma1 uA i * globalGamma1 uB j := by
  rcases uA with ⟨⟨iA₁, iA₂⟩, oA⟩
  rcases uB with ⟨⟨iB₁, iB₂⟩, oB⟩
  simp only [physicalRegroupedGlobalGamma1, physicalInsertedChoiEquiv,
    globalGamma1]
  by_cases hA₁ : iA₁ = oA <;> by_cases hB₁ : iB₁ = oB <;>
    by_cases hA₂ : iA₂ = i <;> by_cases hB₂ : iB₂ = j <;>
    simp [hA₁, hB₁, hA₂, hB₂]

omit [Fintype a] [Fintype b] in
@[simp]
theorem physicalRegroupedGlobalGamma2_apply
    (uA : LocalMixedSchurSpace a) (uB : LocalMixedSchurSpace b)
    (i : a) (j : b) :
    physicalRegroupedGlobalGamma2 (a := a) (b := b) (uA, uB) (i, j) =
      globalGamma2 uA i * globalGamma2 uB j := by
  rcases uA with ⟨⟨iA₁, iA₂⟩, oA⟩
  rcases uB with ⟨⟨iB₁, iB₂⟩, oB⟩
  simp only [physicalRegroupedGlobalGamma2, physicalInsertedChoiEquiv,
    globalGamma2]
  by_cases hA₂ : iA₂ = oA <;> by_cases hB₂ : iB₂ = oB <;>
    by_cases hA₁ : iA₁ = i <;> by_cases hB₁ : iB₁ = j <;>
    simp [hA₁, hB₁, hA₂, hB₂]

omit [Fintype a] [Fintype b] in
theorem physicalRegroupedGlobalGamma1_eq_kronecker :
    physicalRegroupedGlobalGamma1 (a := a) (b := b) =
      Matrix.kronecker (globalGamma1 (x := a)) (globalGamma1 (x := b)) := by
  ext u q
  exact physicalRegroupedGlobalGamma1_apply u.1 u.2 q.1 q.2

omit [Fintype a] [Fintype b] in
theorem physicalRegroupedGlobalGamma2_eq_kronecker :
    physicalRegroupedGlobalGamma2 (a := a) (b := b) =
      Matrix.kronecker (globalGamma2 (x := a)) (globalGamma2 (x := b)) := by
  ext u q
  exact physicalRegroupedGlobalGamma2_apply u.1 u.2 q.1 q.2

theorem physicalRegroupedGlobalWPlus_eq_smul_gammaPlus :
    physicalRegroupedGlobalWPlus (a := a) (b := b) =
      (1 / Real.sqrt (2 * ((Fintype.card (a × b) : ℝ) + 1))) •
        physicalRegroupedGlobalGammaPlus := by
  rfl

/-- The output representation paired with Alice's local mixed action. -/
def physicalAliceUnassistedOutputRepresentation
    (U : Matrix.unitaryGroup a ℂ) : CMatrix (a × b) :=
  Matrix.kronecker (localEntrywiseConjugate U) (1 : CMatrix b)

/-- The output representation paired with Bob's local mixed action. -/
def physicalBobUnassistedOutputRepresentation
    (V : Matrix.unitaryGroup b ℂ) : CMatrix (a × b) :=
  Matrix.kronecker (1 : CMatrix a) (localEntrywiseConjugate V)

private theorem physicalAliceUnassistedMixedRepresentation_mul_gamma1
    (U : Matrix.unitaryGroup a ℂ) :
    physicalAliceUnassistedMixedRepresentation (b := b) U *
        physicalRegroupedGlobalGamma1 =
      physicalRegroupedGlobalGamma1 *
        physicalAliceUnassistedOutputRepresentation U := by
  rw [physicalRegroupedGlobalGamma1_eq_kronecker]
  simp only [physicalAliceUnassistedMixedRepresentation,
    jointContractionUnassistedPhysicalRepresentation,
    localMixedSchurRepresentation_one,
    physicalAliceUnassistedOutputRepresentation]
  unfold Matrix.kronecker
  rw [← Matrix.mul_kronecker_mul, ← Matrix.mul_kronecker_mul,
    localGamma1_intertwines]
  simp

private theorem physicalAliceUnassistedMixedRepresentation_mul_gamma2
    (U : Matrix.unitaryGroup a ℂ) :
    physicalAliceUnassistedMixedRepresentation (b := b) U *
        physicalRegroupedGlobalGamma2 =
      physicalRegroupedGlobalGamma2 *
        physicalAliceUnassistedOutputRepresentation U := by
  rw [physicalRegroupedGlobalGamma2_eq_kronecker]
  simp only [physicalAliceUnassistedMixedRepresentation,
    jointContractionUnassistedPhysicalRepresentation,
    localMixedSchurRepresentation_one,
    physicalAliceUnassistedOutputRepresentation]
  unfold Matrix.kronecker
  rw [← Matrix.mul_kronecker_mul, ← Matrix.mul_kronecker_mul,
    localGamma2_intertwines]
  simp

private theorem physicalBobUnassistedMixedRepresentation_mul_gamma1
    (V : Matrix.unitaryGroup b ℂ) :
    physicalBobUnassistedMixedRepresentation (a := a) V *
        physicalRegroupedGlobalGamma1 =
      physicalRegroupedGlobalGamma1 *
        physicalBobUnassistedOutputRepresentation V := by
  rw [physicalRegroupedGlobalGamma1_eq_kronecker]
  simp only [physicalBobUnassistedMixedRepresentation,
    jointContractionUnassistedPhysicalRepresentation,
    localMixedSchurRepresentation_one,
    physicalBobUnassistedOutputRepresentation]
  unfold Matrix.kronecker
  rw [← Matrix.mul_kronecker_mul, ← Matrix.mul_kronecker_mul,
    localGamma1_intertwines]
  simp

private theorem physicalBobUnassistedMixedRepresentation_mul_gamma2
    (V : Matrix.unitaryGroup b ℂ) :
    physicalBobUnassistedMixedRepresentation (a := a) V *
        physicalRegroupedGlobalGamma2 =
      physicalRegroupedGlobalGamma2 *
        physicalBobUnassistedOutputRepresentation V := by
  rw [physicalRegroupedGlobalGamma2_eq_kronecker]
  simp only [physicalBobUnassistedMixedRepresentation,
    jointContractionUnassistedPhysicalRepresentation,
    localMixedSchurRepresentation_one,
    physicalBobUnassistedOutputRepresentation]
  unfold Matrix.kronecker
  rw [← Matrix.mul_kronecker_mul, ← Matrix.mul_kronecker_mul,
    localGamma2_intertwines]
  simp

/-- Alice's local mixed representation intertwines the regrouped global
`W₊` with the conjugate output action. -/
theorem physicalAliceUnassistedMixedRepresentation_mul_globalWPlus
    (U : Matrix.unitaryGroup a ℂ) :
    physicalAliceUnassistedMixedRepresentation (b := b) U *
        physicalRegroupedGlobalWPlus =
      physicalRegroupedGlobalWPlus *
        physicalAliceUnassistedOutputRepresentation U := by
  rw [physicalRegroupedGlobalWPlus_eq_smul_gammaPlus]
  simp only [physicalRegroupedGlobalGammaPlus, Matrix.mul_smul,
    Matrix.smul_mul, Matrix.mul_add, Matrix.add_mul,
    physicalAliceUnassistedMixedRepresentation_mul_gamma1,
    physicalAliceUnassistedMixedRepresentation_mul_gamma2]

/-- Bob's local mixed representation intertwines the regrouped global
`W₊` with the conjugate output action. -/
theorem physicalBobUnassistedMixedRepresentation_mul_globalWPlus
    (V : Matrix.unitaryGroup b ℂ) :
    physicalBobUnassistedMixedRepresentation (a := a) V *
        physicalRegroupedGlobalWPlus =
      physicalRegroupedGlobalWPlus *
        physicalBobUnassistedOutputRepresentation V := by
  rw [physicalRegroupedGlobalWPlus_eq_smul_gammaPlus]
  simp only [physicalRegroupedGlobalGammaPlus, Matrix.mul_smul,
    Matrix.smul_mul, Matrix.mul_add, Matrix.add_mul,
    physicalBobUnassistedMixedRepresentation_mul_gamma1,
    physicalBobUnassistedMixedRepresentation_mul_gamma2]

/-- The regrouped displayed optimizer is the scalar multiple of the range
projector generated by the regrouped global `W₊`. -/
theorem physicalInsertedChoiMatrix_globalOptimalChoi_eq_regroupedWPlus :
    physicalInsertedChoiMatrix (a := a) (b := b)
        (globalOptimalChoi (x := a × b)) =
      (((Fintype.card (a × b) : ℝ) + 1) / 2) •
        (physicalRegroupedGlobalWPlus *
          Matrix.conjTranspose physicalRegroupedGlobalWPlus) := by
  ext p q
  simp [globalOptimalChoi, physicalInsertedChoiMatrix,
    Matrix.reindexAlgEquiv_apply, Matrix.reindex_apply, globalPWPlus,
    physicalRegroupedGlobalWPlus, Matrix.mul_apply,
    Matrix.conjTranspose_apply]

private theorem physicalAliceUnassistedOutputRepresentation_mul_conjTranspose
    (U : Matrix.unitaryGroup a ℂ) :
    physicalAliceUnassistedOutputRepresentation (b := b) U *
        Matrix.conjTranspose
          (physicalAliceUnassistedOutputRepresentation (b := b) U) =
      (1 : CMatrix (a × b)) := by
  have hBarU :
      localEntrywiseConjugate U ∈ Matrix.unitaryGroup a ℂ := by
    change (↑(Matrix.UnitaryGroup.map_star U) : CMatrix a) ∈
      Matrix.unitaryGroup a ℂ
    exact SetLike.coe_mem (Matrix.UnitaryGroup.map_star U)
  have hR :
      physicalAliceUnassistedOutputRepresentation (b := b) U ∈
        Matrix.unitaryGroup (a × b) ℂ := by
    exact Matrix.kronecker_mem_unitary hBarU
      (SetLike.coe_mem (1 : Matrix.unitaryGroup b ℂ))
  simpa [Matrix.star_eq_conjTranspose] using
    (Matrix.mem_unitaryGroup_iff.mp hR)

private theorem physicalBobUnassistedOutputRepresentation_mul_conjTranspose
    (V : Matrix.unitaryGroup b ℂ) :
    physicalBobUnassistedOutputRepresentation (a := a) V *
        Matrix.conjTranspose
          (physicalBobUnassistedOutputRepresentation (a := a) V) =
      (1 : CMatrix (a × b)) := by
  have hBarV :
      localEntrywiseConjugate V ∈ Matrix.unitaryGroup b ℂ := by
    change (↑(Matrix.UnitaryGroup.map_star V) : CMatrix b) ∈
      Matrix.unitaryGroup b ℂ
    exact SetLike.coe_mem (Matrix.UnitaryGroup.map_star V)
  have hR :
      physicalBobUnassistedOutputRepresentation (a := a) V ∈
        Matrix.unitaryGroup (a × b) ℂ := by
    exact Matrix.kronecker_mem_unitary
      (SetLike.coe_mem (1 : Matrix.unitaryGroup a ℂ)) hBarV
  simpa [Matrix.star_eq_conjTranspose] using
    (Matrix.mem_unitaryGroup_iff.mp hR)

private theorem smul_rangeProjector_fixed_of_intertwines
    {h x : Type*} [Fintype h] [Fintype x]
    [DecidableEq h] [DecidableEq x]
    (c : ℂ) (A : CMatrix h) (W : Matrix h x ℂ) (R : CMatrix x)
    (hIntertwines : A * W = W * R)
    (hUnitary : R * Matrix.conjTranspose R = 1) :
    A * (c • (W * Matrix.conjTranspose W)) * Matrix.conjTranspose A =
      c • (W * Matrix.conjTranspose W) := by
  have hAdjoint :
      Matrix.conjTranspose W * Matrix.conjTranspose A =
        Matrix.conjTranspose R * Matrix.conjTranspose W := by
    simpa only [Matrix.conjTranspose_mul] using
      congrArg Matrix.conjTranspose hIntertwines
  calc
    A * (c • (W * Matrix.conjTranspose W)) * Matrix.conjTranspose A =
        c • ((A * W) *
          (Matrix.conjTranspose W * Matrix.conjTranspose A)) := by
      simp only [Matrix.mul_smul, Matrix.smul_mul, Matrix.mul_assoc]
    _ = c • ((W * R) *
          (Matrix.conjTranspose R * Matrix.conjTranspose W)) := by
      rw [hIntertwines, hAdjoint]
    _ = c • (W * ((R * Matrix.conjTranspose R) *
          Matrix.conjTranspose W)) := by
      simp only [Matrix.mul_assoc]
    _ = c • (W * Matrix.conjTranspose W) := by
      rw [hUnitary, Matrix.one_mul]

/-- Every pointwise Alice local conjugation fixes the regrouped global
optimizer exactly. -/
theorem physicalAliceUnassistedTwirlIntegrand_globalOptimalChoi_fixed
    (U : Matrix.unitaryGroup a ℂ) :
    physicalAliceUnassistedTwirlIntegrand
        (physicalInsertedChoiMatrix (a := a) (b := b)
          (globalOptimalChoi (x := a × b))) U =
      physicalInsertedChoiMatrix (a := a) (b := b)
        (globalOptimalChoi (x := a × b)) := by
  rw [physicalAliceUnassistedTwirlIntegrand,
    physicalInsertedChoiMatrix_globalOptimalChoi_eq_regroupedWPlus]
  simp only [Matrix.star_eq_conjTranspose]
  exact smul_rangeProjector_fixed_of_intertwines
    ((((Fintype.card (a × b) : ℝ) + 1) / 2 : ℝ) : ℂ)
    (physicalAliceUnassistedMixedRepresentation (b := b) U)
    physicalRegroupedGlobalWPlus
    (physicalAliceUnassistedOutputRepresentation (b := b) U)
    (physicalAliceUnassistedMixedRepresentation_mul_globalWPlus U)
    (physicalAliceUnassistedOutputRepresentation_mul_conjTranspose U)

/-- Every pointwise Bob local conjugation fixes the regrouped global optimizer
exactly. -/
theorem physicalBobUnassistedTwirlIntegrand_globalOptimalChoi_fixed
    (V : Matrix.unitaryGroup b ℂ) :
    physicalBobUnassistedTwirlIntegrand
        (physicalInsertedChoiMatrix (a := a) (b := b)
          (globalOptimalChoi (x := a × b))) V =
      physicalInsertedChoiMatrix (a := a) (b := b)
        (globalOptimalChoi (x := a × b)) := by
  rw [physicalBobUnassistedTwirlIntegrand,
    physicalInsertedChoiMatrix_globalOptimalChoi_eq_regroupedWPlus]
  simp only [Matrix.star_eq_conjTranspose]
  exact smul_rangeProjector_fixed_of_intertwines
    ((((Fintype.card (a × b) : ℝ) + 1) / 2 : ℝ) : ℂ)
    (physicalBobUnassistedMixedRepresentation (a := a) V)
    physicalRegroupedGlobalWPlus
    (physicalBobUnassistedOutputRepresentation (a := a) V)
    (physicalBobUnassistedMixedRepresentation_mul_globalWPlus V)
    (physicalBobUnassistedOutputRepresentation_mul_conjTranspose V)

/-- The normalized Alice Haar twirl fixes the regrouped global optimizer. -/
theorem physicalAliceUnassistedTwirl_globalOptimalChoi_fixed
    [Nonempty a] [Nonempty b] :
    physicalAliceUnassistedTwirl
        (physicalInsertedChoiMatrix (a := a) (b := b)
          (globalOptimalChoi (x := a × b))) =
      physicalInsertedChoiMatrix (a := a) (b := b)
        (globalOptimalChoi (x := a × b)) := by
  rw [physicalAliceUnassistedTwirl]
  simp_rw [physicalAliceUnassistedTwirlIntegrand_globalOptimalChoi_fixed]
  simp

/-- The normalized Bob Haar twirl fixes the regrouped global optimizer. -/
theorem physicalBobUnassistedTwirl_globalOptimalChoi_fixed
    [Nonempty a] [Nonempty b] :
    physicalBobUnassistedTwirl
        (physicalInsertedChoiMatrix (a := a) (b := b)
          (globalOptimalChoi (x := a × b))) =
      physicalInsertedChoiMatrix (a := a) (b := b)
        (globalOptimalChoi (x := a × b)) := by
  rw [physicalBobUnassistedTwirl]
  simp_rw [physicalBobUnassistedTwirlIntegrand_globalOptimalChoi_fixed]
  simp

/-- Headline fixed-point statement: the genuine two-sided normalized local
Haar twirl preserves the regrouped global optimizer exactly. -/
theorem physicalLocalUnassistedTwirl_globalOptimalChoi_fixed
    [Nonempty a] [Nonempty b] :
    physicalLocalUnassistedTwirl
        (physicalInsertedChoiMatrix (a := a) (b := b)
          (globalOptimalChoi (x := a × b))) =
      physicalInsertedChoiMatrix (a := a) (b := b)
        (globalOptimalChoi (x := a × b)) := by
  unfold physicalLocalUnassistedTwirl
  rw [physicalBobUnassistedTwirl_globalOptimalChoi_fixed,
    physicalAliceUnassistedTwirl_globalOptimalChoi_fixed]

end

end EntanglementPurification
