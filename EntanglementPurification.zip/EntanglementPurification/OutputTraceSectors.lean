import EntanglementPurification.LocalContractionOutputTrace
import EntanglementPurification.PhysicalBranchOutputTrace
import Mathlib.Tactic

/-!
# Canonical coefficients of the four output-trace sectors

After tracing out `A' B'`, the remaining matrix is indexed by

`((A₁ × A₂) × (B₁ × B₂)) × R`.

This file defines the four product projectors selected by
`LocalMultiplicitySector` and a canonical coefficient extractor.  For an
arbitrary matrix `T`, its `z` coefficient is the normalized partial trace of
the compression of `T` to the `z` sector.  Thus the definition makes sense
without any invariance assumption.

The paper's notation `[Tr_{A'B'} K]_z` denotes instead the unique coefficient
in an exact sector expansion.  Identifying that paper coefficient with the
canonical extractor below therefore requires an exact expansion theorem; it
is not built into this definition as an assumption.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b r : Type*}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

/-- The two-copy input projector selected by one local parity label. -/
theorem localInputPairProjector_isHermitian
    (s : LocalParity) :
    (localInputPairProjector (x := a) s).IsHermitian := by
  cases s
  · exact globalInputPairPSym_isHermitian
  · exact localInputPairPAsym_isHermitian

/-- Each local parity projector is idempotent. -/
theorem localInputPairProjector_idempotent
    (s : LocalParity) :
    localInputPairProjector (x := a) s * localInputPairProjector s =
      localInputPairProjector s := by
  cases s
  · exact globalInputPairPSym_idempotent
  · exact localInputPairPAsym_idempotent

/-- Each local parity projector is positive semidefinite. -/
theorem localInputPairProjector_posSemidef
    (s : LocalParity) :
    (localInputPairProjector (x := a) s).PosSemidef := by
  cases s
  · exact globalInputPairPSym_posSemidef
  · exact localInputPairPAsym_posSemidef

/-- Both local parity projectors are symmetric in the fixed product basis.
This is stronger than Hermiticity here because all their entries are real. -/
@[simp]
theorem localInputPairProjector_transpose_apply
    (s : LocalParity) (p q : a × a) :
    localInputPairProjector (x := a) s q p =
      localInputPairProjector s p q := by
  rcases p with ⟨p₁, p₂⟩
  rcases q with ⟨q₁, q₂⟩
  cases s <;>
    simp [localInputPairProjector, globalInputPairPSym,
      localInputPairPAsym, globalInputPairSwap, Matrix.one_apply,
      Prod.ext_iff, eq_comm, and_comm]

/-- Multiplication table of the two orthogonal local parity projectors. -/
theorem localInputPairProjector_mul
    (s t : LocalParity) :
    localInputPairProjector (x := a) s * localInputPairProjector t =
      if s = t then localInputPairProjector s else 0 := by
  cases s <;> cases t
  · simpa [localInputPairProjector] using
      (globalInputPairPSym_idempotent (x := a))
  · simpa [localInputPairProjector] using
      (globalInputPairPSym_mul_localInputPairPAsym (x := a))
  · simp [localInputPairProjector,
      localInputPairPAsym_eq_one_sub_globalInputPairPSym,
      Matrix.sub_mul, globalInputPairPSym_idempotent]
  · simpa [localInputPairProjector] using
      (localInputPairPAsym_idempotent (x := a))

/-- Real trace/rank scale of a local two-copy parity projector. -/
def localInputPairProjectorTraceScale
    (x : Type*) [Fintype x] (s : LocalParity) : ℝ :=
  match s with
  | .plus => (Fintype.card x : ℝ) * ((Fintype.card x : ℝ) + 1) / 2
  | .minus => (Fintype.card x : ℝ) * ((Fintype.card x : ℝ) - 1) / 2

/-- The local projector trace equals its real rank scale. -/
theorem localInputPairProjector_trace_eq_scale
    (s : LocalParity) :
    (localInputPairProjector (x := a) s).trace =
      (localInputPairProjectorTraceScale a s : ℂ) := by
  cases s
  · simp only [localInputPairProjector,
      localInputPairProjectorTraceScale, globalInputPairPSym_trace]
    push_cast
    ring
  · simp only [localInputPairProjector,
      localInputPairProjectorTraceScale, localInputPairPAsym_trace]
    push_cast
    ring

/-- For dimension at least two, both local parity sectors have positive rank. -/
theorem localInputPairProjectorTraceScale_pos
    (hcard : 2 ≤ Fintype.card a) (s : LocalParity) :
    0 < localInputPairProjectorTraceScale a s := by
  have hcard0 : (0 : ℝ) < Fintype.card a := by
    exact_mod_cast (lt_of_lt_of_le (by norm_num : 0 < 2) hcard)
  have hcard1 : (1 : ℝ) < Fintype.card a := by
    exact_mod_cast (lt_of_lt_of_le (by norm_num : 1 < 2) hcard)
  cases s <;> simp only [localInputPairProjectorTraceScale]
  · positivity
  · have : (0 : ℝ) < (Fintype.card a : ℝ) - 1 := sub_pos.mpr hcard1
    positivity

/-- Product projector for one of the four `++,+-,-+,--` input sectors. -/
def jointInputSectorProjector
    (z : LocalMultiplicitySector) :
    CMatrix ((a × a) × (b × b)) :=
  Matrix.kronecker
    (localInputPairProjector (x := a) z.1)
    (localInputPairProjector (x := b) z.2)

/-- The trace/rank scale of a joint input sector.  The two factors are kept
separate because the Lean development permits Alice and Bob to have different
finite dimensions. -/
def jointInputSectorTraceScale
    (a b : Type*) [Fintype a] [Fintype b]
    (z : LocalMultiplicitySector) : ℝ :=
  localInputPairProjectorTraceScale a z.1 *
    localInputPairProjectorTraceScale b z.2

/-- The joint sector projector is Hermitian. -/
theorem jointInputSectorProjector_isHermitian
    (z : LocalMultiplicitySector) :
    (jointInputSectorProjector (a := a) (b := b) z).IsHermitian := by
  rw [Matrix.IsHermitian, jointInputSectorProjector]
  unfold Matrix.kronecker
  rw [
    Matrix.conjTranspose_kronecker,
    localInputPairProjector_isHermitian,
    localInputPairProjector_isHermitian]

/-- The joint sector projector is idempotent. -/
theorem jointInputSectorProjector_idempotent
    (z : LocalMultiplicitySector) :
    jointInputSectorProjector (a := a) (b := b) z *
        jointInputSectorProjector z =
      jointInputSectorProjector z := by
  rw [jointInputSectorProjector]
  unfold Matrix.kronecker
  rw [← Matrix.mul_kronecker_mul,
    localInputPairProjector_idempotent,
    localInputPairProjector_idempotent]

/-- The four joint input-sector projectors are pairwise orthogonal. -/
theorem jointInputSectorProjector_mul
    (z w : LocalMultiplicitySector) :
    jointInputSectorProjector (a := a) (b := b) z *
        jointInputSectorProjector w =
      if z = w then jointInputSectorProjector z else 0 := by
  rcases z with ⟨sA, sB⟩
  rcases w with ⟨tA, tB⟩
  rw [jointInputSectorProjector, jointInputSectorProjector]
  unfold Matrix.kronecker
  rw [← Matrix.mul_kronecker_mul,
    localInputPairProjector_mul, localInputPairProjector_mul]
  by_cases hA : sA = tA <;> by_cases hB : sB = tB
  · subst tA
    subst tB
    simp
  · simp [hA, hB]
  · simp [hA, hB]
  · simp [hA, hB]

/-- The joint projector trace is exactly its product rank scale. -/
theorem jointInputSectorProjector_trace_eq_scale
    (z : LocalMultiplicitySector) :
    (jointInputSectorProjector (a := a) (b := b) z).trace =
      (jointInputSectorTraceScale a b z : ℂ) := by
  rw [jointInputSectorProjector]
  unfold Matrix.kronecker
  rw [Matrix.trace_kronecker,
    localInputPairProjector_trace_eq_scale,
    localInputPairProjector_trace_eq_scale]
  simp only [jointInputSectorTraceScale]
  push_cast
  ring

/-- Every joint sector has positive rank when both local dimensions are at
least two. -/
theorem jointInputSectorTraceScale_pos
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (z : LocalMultiplicitySector) :
    0 < jointInputSectorTraceScale a b z := by
  exact mul_pos
    (localInputPairProjectorTraceScale_pos hcardA z.1)
    (localInputPairProjectorTraceScale_pos hcardB z.2)

/-- Extend a joint input-sector projector by the identity on the resource. -/
def jointInputSectorResourceProjector
    (z : LocalMultiplicitySector) :
    CMatrix (JointContractionInputResourceIndex a b r) :=
  Matrix.kronecker
    (jointInputSectorProjector (a := a) (b := b) z)
    (1 : CMatrix r)

/-- The resource-extended sector projector is Hermitian. -/
theorem jointInputSectorResourceProjector_isHermitian
    (z : LocalMultiplicitySector) :
    (jointInputSectorResourceProjector (a := a) (b := b) (r := r) z).IsHermitian := by
  rw [Matrix.IsHermitian, jointInputSectorResourceProjector]
  unfold Matrix.kronecker
  rw [
    Matrix.conjTranspose_kronecker,
    jointInputSectorProjector_isHermitian]
  simp

/-- The resource-extended sector projector is idempotent. -/
theorem jointInputSectorResourceProjector_idempotent
    (z : LocalMultiplicitySector) :
    jointInputSectorResourceProjector (a := a) (b := b) (r := r) z *
        jointInputSectorResourceProjector z =
      jointInputSectorResourceProjector z := by
  rw [jointInputSectorResourceProjector]
  unfold Matrix.kronecker
  rw [← Matrix.mul_kronecker_mul,
    jointInputSectorProjector_idempotent]
  simp

/-- Canonical resource-valued coefficient of an arbitrary output-trace
matrix.  It is the normalized partial trace of the compression to sector `z`.

No local-unitary invariance or exact sector expansion is assumed here. -/
def outputTraceSectorCoefficient
    (T : CMatrix (JointContractionInputResourceIndex a b r))
    (z : LocalMultiplicitySector) : CMatrix r :=
  (jointInputSectorTraceScale a b z)⁻¹ •
    QIT.partialTraceA
      (jointInputSectorResourceProjector (a := a) (b := b) (r := r) z * T *
        jointInputSectorResourceProjector z)

/-- The canonical sector extractor is additive. -/
theorem outputTraceSectorCoefficient_add
    (T U : CMatrix (JointContractionInputResourceIndex a b r))
    (z : LocalMultiplicitySector) :
    outputTraceSectorCoefficient (T + U) z =
      outputTraceSectorCoefficient T z + outputTraceSectorCoefficient U z := by
  simp [outputTraceSectorCoefficient, Matrix.mul_add, Matrix.add_mul,
    QIT.partialTraceA_add, smul_add]

/-- The canonical sector extractor commutes with complex scalar
multiplication. -/
theorem outputTraceSectorCoefficient_smul
    (c : ℂ) (T : CMatrix (JointContractionInputResourceIndex a b r))
    (z : LocalMultiplicitySector) :
    outputTraceSectorCoefficient (c • T) z =
      c • outputTraceSectorCoefficient T z := by
  unfold outputTraceSectorCoefficient
  rw [Matrix.mul_smul, Matrix.smul_mul, QIT.partialTraceA_smul]
  ext i j
  simp [Complex.real_smul]
  ring

/-- The canonical sector extractor sends the zero matrix to zero. -/
@[simp]
theorem outputTraceSectorCoefficient_zero
    (z : LocalMultiplicitySector) :
    outputTraceSectorCoefficient
        (0 : CMatrix (JointContractionInputResourceIndex a b r)) z = 0 := by
  simpa using
    (outputTraceSectorCoefficient_smul (a := a) (b := b) (r := r)
      (0 : ℂ) (1 : CMatrix (JointContractionInputResourceIndex a b r)) z)

/-- The canonical sector extractor commutes with a finite indexed sum. -/
theorem outputTraceSectorCoefficient_finset_sum
    {ι : Type*} (s : Finset ι)
    (T : ι → CMatrix (JointContractionInputResourceIndex a b r))
    (z : LocalMultiplicitySector) :
    outputTraceSectorCoefficient (∑ i ∈ s, T i) z =
      ∑ i ∈ s, outputTraceSectorCoefficient (T i) z := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert i s hi ih =>
      simp [hi, outputTraceSectorCoefficient_add, ih]

/-- `Fintype`-indexed version of `outputTraceSectorCoefficient_finset_sum`. -/
theorem outputTraceSectorCoefficient_sum
    {ι : Type*} [Fintype ι]
    (T : ι → CMatrix (JointContractionInputResourceIndex a b r))
    (z : LocalMultiplicitySector) :
    outputTraceSectorCoefficient (∑ i, T i) z =
      ∑ i, outputTraceSectorCoefficient (T i) z := by
  simpa using
    (outputTraceSectorCoefficient_finset_sum (a := a) (b := b) (r := r)
      (Finset.univ : Finset ι) T z)

/-- The canonical sector extractor preserves subtraction. -/
theorem outputTraceSectorCoefficient_sub
    (T U : CMatrix (JointContractionInputResourceIndex a b r))
    (z : LocalMultiplicitySector) :
    outputTraceSectorCoefficient (T - U) z =
      outputTraceSectorCoefficient T z - outputTraceSectorCoefficient U z := by
  simp [outputTraceSectorCoefficient, Matrix.mul_sub, Matrix.sub_mul,
    QIT.partialTraceA_sub, smul_sub]

/-- Compressing a PSD output-trace matrix to a nonzero sector and discarding
the input factor gives a PSD resource coefficient. -/
theorem outputTraceSectorCoefficient_posSemidef
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {T : CMatrix (JointContractionInputResourceIndex a b r)}
    (hT : T.PosSemidef) (z : LocalMultiplicitySector) :
    (outputTraceSectorCoefficient T z).PosSemidef := by
  let P := jointInputSectorResourceProjector
    (a := a) (b := b) (r := r) z
  have hP : P.IsHermitian := by
    simpa [P] using
      (jointInputSectorResourceProjector_isHermitian
        (a := a) (b := b) (r := r) z)
  have hcompressed : (P * T * P).PosSemidef := by
    have h := hT.conjTranspose_mul_mul_same P
    rw [hP] at h
    exact h
  have htrace :
      (QIT.partialTraceA (a := ((a × a) × (b × b))) (b := r)
        (P * T * P)).PosSemidef :=
    QIT.partialTraceA_posSemidef hcompressed
  have hscale : 0 ≤ (jointInputSectorTraceScale a b z)⁻¹ :=
    inv_nonneg.mpr (jointInputSectorTraceScale_pos hcardA hcardB z).le
  simpa [outputTraceSectorCoefficient, P] using
    Matrix.PosSemidef.smul htrace hscale

/-- Paper-facing alias: every PSD residual has PSD canonical sector
coefficients.  Residual local-twirl invariance is not an input to this fact. -/
theorem outputTraceResidualSectorCoefficient_posSemidef
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {Tperp : CMatrix (JointContractionInputResourceIndex a b r)}
    (hTperp : Tperp.PosSemidef) (z : LocalMultiplicitySector) :
    (outputTraceSectorCoefficient Tperp z).PosSemidef :=
  outputTraceSectorCoefficient_posSemidef hcardA hcardB hTperp z

/-- The canonical sector extractor is monotone for the Loewner order. -/
theorem outputTraceSectorCoefficient_mono
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {T U : CMatrix (JointContractionInputResourceIndex a b r)}
    (hTU : T ≤ U) (z : LocalMultiplicitySector) :
    outputTraceSectorCoefficient T z ≤ outputTraceSectorCoefficient U z := by
  rw [Matrix.le_iff] at hTU ⊢
  rw [← outputTraceSectorCoefficient_sub]
  exact outputTraceSectorCoefficient_posSemidef hcardA hcardB hTU z

/-- On a matrix which is exactly one sector projector tensored with a resource
matrix, the normalized canonical extractor returns that resource matrix.  This
is the basic normalization lemma used when an exact four-sector expansion has
been proved separately. -/
theorem outputTraceSectorCoefficient_kronecker_self
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (z : LocalMultiplicitySector) (Y : CMatrix r) :
    outputTraceSectorCoefficient
        (Matrix.kronecker
          (jointInputSectorProjector (a := a) (b := b) z) Y) z =
      Y := by
  let P := jointInputSectorProjector (a := a) (b := b) z
  let PR := jointInputSectorResourceProjector
    (a := a) (b := b) (r := r) z
  have hP : P * P = P := by
    simpa [P] using
      (jointInputSectorProjector_idempotent (a := a) (b := b) z)
  have hcompress :
      PR * Matrix.kronecker P Y * PR = Matrix.kronecker P Y := by
    change
      Matrix.kronecker P (1 : CMatrix r) * Matrix.kronecker P Y *
          Matrix.kronecker P (1 : CMatrix r) =
        Matrix.kronecker P Y
    unfold Matrix.kronecker
    rw [← Matrix.mul_kronecker_mul, ← Matrix.mul_kronecker_mul,
      hP, hP]
    simp
  have hscalePos := jointInputSectorTraceScale_pos hcardA hcardB z
  have hscaleNe : jointInputSectorTraceScale a b z ≠ 0 := hscalePos.ne'
  unfold outputTraceSectorCoefficient
  change
    (jointInputSectorTraceScale a b z)⁻¹ •
        QIT.partialTraceA (PR * Matrix.kronecker P Y * PR) = Y
  rw [hcompress, QIT.partialTraceA_kronecker]
  rw [show P.trace = (jointInputSectorTraceScale a b z : ℂ) by
    simpa [P] using
      (jointInputSectorProjector_trace_eq_scale (a := a) (b := b) z)]
  ext i j
  simp [QIT.matrixScale, hscaleNe]

/-- A matrix supported on a different exact sector has zero canonical
coefficient in sector `z`. -/
theorem outputTraceSectorCoefficient_kronecker_of_ne
    (z w : LocalMultiplicitySector) (hzw : z ≠ w) (Y : CMatrix r) :
    outputTraceSectorCoefficient
        (Matrix.kronecker
          (jointInputSectorProjector (a := a) (b := b) w) Y) z =
      0 := by
  let Pz := jointInputSectorProjector (a := a) (b := b) z
  let Pw := jointInputSectorProjector (a := a) (b := b) w
  let PzR := jointInputSectorResourceProjector
    (a := a) (b := b) (r := r) z
  have hproj : Pz * Pw = 0 := by
    simpa [Pz, Pw, hzw] using
      (jointInputSectorProjector_mul (a := a) (b := b) z w)
  have hcompress :
      PzR * Matrix.kronecker Pw Y * PzR = 0 := by
    change
      Matrix.kronecker Pz (1 : CMatrix r) * Matrix.kronecker Pw Y *
          Matrix.kronecker Pz (1 : CMatrix r) = 0
    unfold Matrix.kronecker
    rw [← Matrix.mul_kronecker_mul, hproj]
    simp
  unfold outputTraceSectorCoefficient
  change
    (jointInputSectorTraceScale a b z)⁻¹ •
        QIT.partialTraceA
          (PzR * Matrix.kronecker Pw Y * PzR) = 0
  rw [hcompress]
  ext i j
  simp [QIT.partialTraceA]

section PartialTranspose

variable {ra rb : Type*}
  [Fintype ra] [Fintype rb]
  [DecidableEq ra] [DecidableEq rb]

private theorem partialTransposeB_kronecker_sandwich
    {A B : Type*} [Fintype A] [Fintype B]
    (LA RA : CMatrix A) (LB RB : CMatrix B)
    (X : CMatrix (A × B)) :
    QIT.partialTransposeB
        (Matrix.kronecker LA LB * X * Matrix.kronecker RA RB) =
      Matrix.kronecker LA (Matrix.transpose RB) *
        QIT.partialTransposeB X *
          Matrix.kronecker RA (Matrix.transpose LB) := by
  unfold Matrix.kronecker
  ext ⟨i, j⟩ ⟨k, l⟩
  simp only [QIT.partialTransposeB_apply, Matrix.mul_apply,
    Fintype.sum_prod_type, Matrix.kroneckerMap_apply, Matrix.transpose_apply]
  simp_rw [Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro x hx
  rw [Finset.sum_comm]
  conv_rhs => rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro y hy
  conv_rhs => rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro q hq
  apply Finset.sum_congr rfl
  intro s hs
  ring

/-- Tracing out both input-pair registers after the physical Bob transpose
leaves exactly the resource Bob transpose. -/
theorem partialTraceA_physicalBranchOutputPartialTransposeB
    (T : CMatrix (JointContractionInputResourceIndex a b (ra × rb))) :
    QIT.partialTraceA (physicalBranchOutputPartialTransposeB T) =
      QIT.partialTransposeB (QIT.partialTraceA T) := by
  ext p q
  rcases p with ⟨u, v⟩
  rcases q with ⟨w, x⟩
  simp only [QIT.partialTraceA, QIT.partialTransposeB_apply]
  apply Finset.sum_congr rfl
  intro i hi
  rcases i with ⟨iA, iB⟩
  exact physicalBranchOutputPartialTransposeB_apply
    T iA iA iB iB u w v x

/-- The resource-extended sector projector is fixed by transposition of the
Bob input pair together with Bob's resource register. -/
theorem physicalBranchOutputPartialTransposeB_jointInputSectorResourceProjector
    (z : LocalMultiplicitySector) :
    physicalBranchOutputPartialTransposeB
        (jointInputSectorResourceProjector
          (a := a) (b := b) (r := ra × rb) z) =
      jointInputSectorResourceProjector z := by
  ext p q
  rcases p with ⟨⟨iA, iB⟩, ⟨u, v⟩⟩
  rcases q with ⟨⟨kA, kB⟩, ⟨w, x⟩⟩
  rw [physicalBranchOutputPartialTransposeB_apply]
  simp [jointInputSectorResourceProjector, jointInputSectorProjector,
    Matrix.kronecker, Matrix.one_apply, eq_comm]

private theorem reindex_jointInputSectorResourceProjector_bobGrouping
    (z : LocalMultiplicitySector) :
    (Matrix.reindexAlgEquiv ℂ ℂ
      (jointInputResourceBobGroupingEquiv
        (a := a) (b := b) (ra := ra) (rb := rb)))
        (jointInputSectorResourceProjector
          (a := a) (b := b) (r := ra × rb) z) =
      Matrix.kronecker
        (Matrix.kronecker
          (localInputPairProjector (x := a) z.1) (1 : CMatrix ra))
        (Matrix.kronecker
          (localInputPairProjector (x := b) z.2) (1 : CMatrix rb)) := by
  ext ⟨⟨iA, u⟩, ⟨iB, v⟩⟩ ⟨⟨kA, w⟩, ⟨kB, x⟩⟩
  simp [Matrix.reindexAlgEquiv_apply, Matrix.reindex_apply,
    jointInputResourceBobGroupingEquiv,
    jointInputSectorResourceProjector, jointInputSectorProjector,
    Matrix.kronecker, Matrix.one_apply]
  by_cases huw : u = w <;> by_cases hvx : v = x <;>
    simp [huw, hvx]

/-- Bob partial transpose commutes with compression by a joint input-sector
projector.  The key point is that the projector is a real symmetric local
operator on Bob's input pair and the identity on Bob's resource. -/
theorem physicalBranchOutputPartialTransposeB_sector_compression
    (T : CMatrix (JointContractionInputResourceIndex a b (ra × rb)))
    (z : LocalMultiplicitySector) :
    physicalBranchOutputPartialTransposeB
        (jointInputSectorResourceProjector z * T *
          jointInputSectorResourceProjector z) =
      jointInputSectorResourceProjector z *
        physicalBranchOutputPartialTransposeB T *
          jointInputSectorResourceProjector z := by
  let e := jointInputResourceBobGroupingEquiv
    (a := a) (b := b) (ra := ra) (rb := rb)
  let E := Matrix.reindexAlgEquiv ℂ ℂ e
  let LA : CMatrix ((a × a) × ra) :=
    Matrix.kronecker
      (localInputPairProjector (x := a) z.1) (1 : CMatrix ra)
  let LB : CMatrix ((b × b) × rb) :=
    Matrix.kronecker
      (localInputPairProjector (x := b) z.2) (1 : CMatrix rb)
  let P := jointInputSectorResourceProjector
    (a := a) (b := b) (r := ra × rb) z
  have hEP : E P = Matrix.kronecker LA LB := by
    simpa [E, e, LA, LB, P] using
      (reindex_jointInputSectorResourceProjector_bobGrouping
        (a := a) (b := b) (ra := ra) (rb := rb) z)
  have hLB : Matrix.transpose LB = LB := by
    ext ⟨iB, v⟩ ⟨kB, x⟩
    simp [LB, Matrix.kronecker, Matrix.one_apply, eq_comm]
  have hEPT (X : CMatrix (JointContractionInputResourceIndex a b (ra × rb))) :
      E (physicalBranchOutputPartialTransposeB X) =
        QIT.partialTransposeB (E X) := by
    change E (E.symm (QIT.partialTransposeB (E X))) = _
    exact E.apply_symm_apply _
  apply E.injective
  change E (physicalBranchOutputPartialTransposeB (P * T * P)) =
    E (P * physicalBranchOutputPartialTransposeB T * P)
  rw [hEPT]
  simp only [map_mul]
  rw [hEP]
  rw [hEPT]
  simpa [hLB] using
    (partialTransposeB_kronecker_sandwich LA LA LB LB (E T))

/-- The canonical sector extractor intertwines the physical Bob transpose on
the remaining input/resource matrix with Bob transpose on the resource
coefficient. -/
theorem outputTraceSectorCoefficient_physicalBranchOutputPartialTransposeB
    (T : CMatrix (JointContractionInputResourceIndex a b (ra × rb)))
    (z : LocalMultiplicitySector) :
    outputTraceSectorCoefficient
        (physicalBranchOutputPartialTransposeB T) z =
      QIT.partialTransposeB (outputTraceSectorCoefficient T z) := by
  unfold outputTraceSectorCoefficient
  rw [← physicalBranchOutputPartialTransposeB_sector_compression,
    partialTraceA_physicalBranchOutputPartialTransposeB]
  ext p q
  rcases p with ⟨u, v⟩
  rcases q with ⟨w, x⟩
  simp [QIT.partialTransposeB, Complex.real_smul]

end PartialTranspose

end

end EntanglementPurification
