import Mathlib.Tactic

/-!
# Scalar identities for the global CPTN semidefinite program

This file formalizes the purely real-algebraic part of the proof of
`lem:general_d_global_optimum` in `main.tex`.  It does not assert the operator
decomposition itself.  Instead, it checks the four sector substitutions in
the displayed eigenvalue formula, their signs on the physical parameter
range, the dimension identities, and the resulting primal/dual objective
value.
-/

namespace EntanglementPurification

noncomputable section

/-- The four joint global-unitary/input-swap sectors in the proof of
`lem:general_d_global_optimum`. -/
inductive GlobalSDPSector where
  | WPlus
  | WMinus
  | LPlus
  | LMinus
  deriving DecidableEq, Repr

/-- `F(psi, N^gamma(psi)) = 1 - gamma + gamma / D`, equation
`eq:gd_noise_channel` and the sentence immediately following it. -/
def globalNoiseFidelity (D gamma : ℝ) : ℝ :=
  1 - gamma + gamma / D

/-- The input-copy-swap entry `s_chi` in the four-sector table. -/
def sectorSwap : GlobalSDPSector → ℝ
  | .WPlus => 1
  | .WMinus => -1
  | .LPlus => 1
  | .LMinus => -1

/-- The `C_diag` entry `c_chi` in the four-sector table. -/
def sectorDiag (D : ℝ) : GlobalSDPSector → ℝ
  | .WPlus => D + 1
  | .WMinus => D - 1
  | .LPlus => 0
  | .LMinus => 0

/-- The `C_cross` entry `r_chi` in the four-sector table. -/
def sectorCross (D : ℝ) : GlobalSDPSector → ℝ
  | .WPlus => D + 1
  | .WMinus => -(D - 1)
  | .LPlus => 0
  | .LMinus => 0

/-- The single unsimplified sector-eigenvalue formula displayed immediately
before the four eigenvalues in the proof of
`lem:general_d_global_optimum`. -/
def rawGlobalSectorEigenvalue
    (D gamma s c r : ℝ) : ℝ :=
  (1 - gamma) ^ 2 *
      ((1 + s + c + r) / (D * (D + 1) * (D + 2)) -
        globalNoiseFidelity D gamma * (1 + s) / (D * (D + 1))) +
    gamma * (1 - gamma) / D *
      ((2 + c) / (D * (D + 1)) -
        2 / D * globalNoiseFidelity D gamma) -
    gamma ^ 2 * (1 - gamma) / D ^ 2 * (1 - 1 / D)

/-- The raw eigenvalue specialized using the three entries of a sector. -/
def globalSectorEigenvalue
    (D gamma : ℝ) (sector : GlobalSDPSector) : ℝ :=
  rawGlobalSectorEigenvalue D gamma
    (sectorSwap sector) (sectorDiag D sector) (sectorCross D sector)

/-- The simplified eigenvalue on `W_+`, equation following the common scalar
sector formula in `main.tex`. -/
def lambdaWPlus (D gamma : ℝ) : ℝ :=
  (1 - gamma) * gamma * (D - 1) / (D ^ 2 * (D + 1)) *
    globalNoiseFidelity D gamma

/-- The simplified eigenvalue on `W_-`. -/
def lambdaWMinus (D gamma : ℝ) : ℝ :=
  -((1 - gamma) * gamma / D ^ 2 * globalNoiseFidelity D gamma)

/-- The simplified eigenvalue on the residual antisymmetric sector
`L_-`. -/
def lambdaLMinus (D gamma : ℝ) : ℝ :=
  -((1 - gamma) * gamma / (D * (D + 1)) *
    (2 - (D ^ 2 - 1) / D ^ 2 * gamma))

/-- The simplified eigenvalue on the residual symmetric sector `L_+`. -/
def lambdaLPlus (D gamma : ℝ) : ℝ :=
  -(1 - gamma) / (D ^ 3 * (D + 1) * (D + 2)) *
    (D * (D + 1) ^ 2 + 2 + 2 * (D - 2) * (1 - gamma) +
      (D - 1) ^ 2 * (D + 2) * (1 - gamma) ^ 2)

/-- The value `G_star(D,gamma)` stated in
`lem:general_d_global_optimum`. -/
def globalOptimalGain (D gamma : ℝ) : ℝ :=
  (1 / 2 : ℝ) * globalNoiseFidelity D gamma * gamma * (1 - gamma) *
    (1 - 1 / D)

/-- Dimension of the input-symmetric subspace, viewed as a real scalar. -/
def inputSymmetricDimension (D : ℝ) : ℝ :=
  D * (D + 1) / 2

/-- The coefficient of `P_sym` in the explicit dual certificate. -/
def globalDualCoefficient (D gamma : ℝ) : ℝ :=
  lambdaWPlus D gamma

/-- The two multiplicity-one dimensions plus the two copies of the defining
dual representation exhaust the `D^3`-dimensional three-leg space. -/
theorem global_sector_dimension_sum (D : ℝ) :
    2 * D + D * (D - 1) * (D + 2) / 2 +
        D * (D + 1) * (D - 2) / 2 = D ^ 3 := by
  ring

/-- First residual parity-space dimension identity in `main.tex`. -/
theorem residual_symmetric_dimension (D : ℝ) :
    D ^ 2 * (D + 1) / 2 - D = D * (D - 1) * (D + 2) / 2 := by
  ring

/-- Second residual parity-space dimension identity in `main.tex`. -/
theorem residual_antisymmetric_dimension (D : ℝ) :
    D ^ 2 * (D - 1) / 2 - D = D * (D + 1) * (D - 2) / 2 := by
  ring

/-- Substituting the `W_+` table column into the common scalar formula yields
the displayed simplified eigenvalue. -/
theorem globalSectorEigenvalue_WPlus
    {D gamma : ℝ} (hD : 4 ≤ D) :
    globalSectorEigenvalue D gamma .WPlus = lambdaWPlus D gamma := by
  have hD0 : D ≠ 0 := by linarith
  have hD1 : D + 1 ≠ 0 := by linarith
  have hD2 : D + 2 ≠ 0 := by linarith
  simp only [globalSectorEigenvalue, sectorSwap, sectorDiag, sectorCross,
    rawGlobalSectorEigenvalue, lambdaWPlus, globalNoiseFidelity]
  field_simp
  ring

/-- Substituting the `W_-` table column into the common scalar formula yields
the displayed simplified eigenvalue. -/
theorem globalSectorEigenvalue_WMinus
    {D gamma : ℝ} (hD : 4 ≤ D) :
    globalSectorEigenvalue D gamma .WMinus = lambdaWMinus D gamma := by
  have hD0 : D ≠ 0 := by linarith
  have hD1 : D + 1 ≠ 0 := by linarith
  have hD2 : D + 2 ≠ 0 := by linarith
  simp only [globalSectorEigenvalue, sectorSwap, sectorDiag, sectorCross,
    rawGlobalSectorEigenvalue, lambdaWMinus, globalNoiseFidelity]
  field_simp
  ring

/-- Substituting the `L_-` table column into the common scalar formula yields
the displayed simplified eigenvalue. -/
theorem globalSectorEigenvalue_LMinus
    {D gamma : ℝ} (hD : 4 ≤ D) :
    globalSectorEigenvalue D gamma .LMinus = lambdaLMinus D gamma := by
  have hD0 : D ≠ 0 := by linarith
  have hD1 : D + 1 ≠ 0 := by linarith
  have hD2 : D + 2 ≠ 0 := by linarith
  simp only [globalSectorEigenvalue, sectorSwap, sectorDiag, sectorCross,
    rawGlobalSectorEigenvalue, lambdaLMinus, globalNoiseFidelity]
  field_simp
  ring

/-- Substituting the `L_+` table column into the common scalar formula yields
the displayed simplified eigenvalue. -/
theorem globalSectorEigenvalue_LPlus
    {D gamma : ℝ} (hD : 4 ≤ D) :
    globalSectorEigenvalue D gamma .LPlus = lambdaLPlus D gamma := by
  have hD0 : D ≠ 0 := by linarith
  have hD1 : D + 1 ≠ 0 := by linarith
  have hD2 : D + 2 ≠ 0 := by linarith
  simp only [globalSectorEigenvalue, sectorSwap, sectorDiag, sectorCross,
    rawGlobalSectorEigenvalue, lambdaLPlus, globalNoiseFidelity]
  field_simp
  ring

/-- On the physical range, the noisy-state input fidelity lies strictly
between zero and one. -/
theorem globalNoiseFidelity_mem_Ioo
    {D gamma : ℝ} (hD : 4 ≤ D) (hgamma0 : 0 < gamma)
    (hgamma1 : gamma < 1) :
    0 < globalNoiseFidelity D gamma ∧ globalNoiseFidelity D gamma < 1 := by
  have hDpos : 0 < D := by linarith
  have hDone : 1 < D := by linarith
  have hInvPos : 0 < 1 / D := one_div_pos.mpr hDpos
  have hInvLt : 1 / D < 1 := (div_lt_one hDpos).2 hDone
  constructor
  · simp only [globalNoiseFidelity]
    have hOneMinusGamma : 0 < 1 - gamma := sub_pos.mpr hgamma1
    have hGammaTerm : 0 < gamma / D := div_pos hgamma0 hDpos
    linarith
  · simp only [globalNoiseFidelity]
    have hGammaLoss : 0 < gamma * (1 - 1 / D) :=
      mul_pos hgamma0 (sub_pos.mpr hInvLt)
    have hid : 1 - gamma + gamma / D = 1 - gamma * (1 - 1 / D) := by
      ring
    rw [hid]
    linarith

/-- The `W_+` eigenvalue is strictly positive on the parameter range of the
global benchmark lemma. -/
theorem lambdaWPlus_pos
    {D gamma : ℝ} (hD : 4 ≤ D) (hgamma0 : 0 < gamma)
    (hgamma1 : gamma < 1) :
    0 < lambdaWPlus D gamma := by
  have hDpos : 0 < D := by linarith
  have hDminus : 0 < D - 1 := by linarith
  have hDplus : 0 < D + 1 := by linarith
  have hOneMinus : 0 < 1 - gamma := sub_pos.mpr hgamma1
  have hF := (globalNoiseFidelity_mem_Ioo hD hgamma0 hgamma1).1
  simp only [lambdaWPlus]
  positivity

/-- The `W_-` eigenvalue is strictly negative. -/
theorem lambdaWMinus_neg
    {D gamma : ℝ} (hD : 4 ≤ D) (hgamma0 : 0 < gamma)
    (hgamma1 : gamma < 1) :
    lambdaWMinus D gamma < 0 := by
  have hDpos : 0 < D := by linarith
  have hOneMinus : 0 < 1 - gamma := sub_pos.mpr hgamma1
  have hF := (globalNoiseFidelity_mem_Ioo hD hgamma0 hgamma1).1
  simp only [lambdaWMinus]
  apply neg_lt_zero.mpr
  have hDsq : 0 < D ^ 2 := sq_pos_of_pos hDpos
  exact mul_pos (div_pos (mul_pos hOneMinus hgamma0) hDsq) hF

/-- The bracket appearing in `lambda_{L_-}` is positive on the physical
parameter range. -/
theorem lambdaLMinus_bracket_pos
    {D gamma : ℝ} (hD : 4 ≤ D) (hgamma0 : 0 < gamma)
    (hgamma1 : gamma < 1) :
    0 < 2 - (D ^ 2 - 1) / D ^ 2 * gamma := by
  have hD0 : D ≠ 0 := by linarith
  have hDsqPos : 0 < D ^ 2 := sq_pos_of_ne_zero hD0
  have hid :
      2 - (D ^ 2 - 1) / D ^ 2 * gamma = 2 - gamma + gamma / D ^ 2 := by
    field_simp
    ring
  rw [hid]
  have hFirst : 0 < 2 - gamma := by linarith
  have hSecond : 0 < gamma / D ^ 2 := div_pos hgamma0 hDsqPos
  linarith

/-- The residual antisymmetric eigenvalue is strictly negative. -/
theorem lambdaLMinus_neg
    {D gamma : ℝ} (hD : 4 ≤ D) (hgamma0 : 0 < gamma)
    (hgamma1 : gamma < 1) :
    lambdaLMinus D gamma < 0 := by
  have hDpos : 0 < D := by linarith
  have hDplus : 0 < D + 1 := by linarith
  have hOneMinus : 0 < 1 - gamma := sub_pos.mpr hgamma1
  have hBracket := lambdaLMinus_bracket_pos hD hgamma0 hgamma1
  simp only [lambdaLMinus]
  apply neg_lt_zero.mpr
  exact mul_pos
    (div_pos (mul_pos hOneMinus hgamma0) (mul_pos hDpos hDplus)) hBracket

/-- The bracket appearing in `lambda_{L_+}` is strictly positive. -/
theorem lambdaLPlus_bracket_pos
    {D gamma : ℝ} (hD : 4 ≤ D) (hgamma1 : gamma < 1) :
    0 < D * (D + 1) ^ 2 + 2 + 2 * (D - 2) * (1 - gamma) +
      (D - 1) ^ 2 * (D + 2) * (1 - gamma) ^ 2 := by
  have hDpos : 0 < D := by linarith
  have hDplusOne : 0 < D + 1 := by linarith
  have hDminusTwo : 0 < D - 2 := by linarith
  have hDminusOne : 0 < D - 1 := by linarith
  have hDplusTwo : 0 < D + 2 := by linarith
  have hOneMinus : 0 < 1 - gamma := sub_pos.mpr hgamma1
  positivity

/-- The residual symmetric eigenvalue is strictly negative. -/
theorem lambdaLPlus_neg
    {D gamma : ℝ} (hD : 4 ≤ D) (_hgamma0 : 0 < gamma)
    (hgamma1 : gamma < 1) :
    lambdaLPlus D gamma < 0 := by
  have hDpos : 0 < D := by linarith
  have hDplusOne : 0 < D + 1 := by linarith
  have hDplusTwo : 0 < D + 2 := by linarith
  have hOneMinus : 0 < 1 - gamma := sub_pos.mpr hgamma1
  have hBracket := lambdaLPlus_bracket_pos hD hgamma1
  simp only [lambdaLPlus]
  have hDenom : 0 < D ^ 3 * (D + 1) * (D + 2) := by positivity
  have hFrac : -(1 - gamma) / (D ^ 3 * (D + 1) * (D + 2)) < 0 :=
    div_neg_of_neg_of_pos (neg_neg_of_pos hOneMinus) hDenom
  exact mul_neg_of_neg_of_pos hFrac hBracket

/-- Exactly one of the four scalar sector eigenvalues is positive: `W_+`.
This is the scalar sign conclusion used to isolate the optimal sector. -/
theorem globalSectorEigenvalue_signs
    {D gamma : ℝ} (hD : 4 ≤ D) (hgamma0 : 0 < gamma)
    (hgamma1 : gamma < 1) :
    0 < globalSectorEigenvalue D gamma .WPlus ∧
      globalSectorEigenvalue D gamma .WMinus < 0 ∧
      globalSectorEigenvalue D gamma .LPlus < 0 ∧
      globalSectorEigenvalue D gamma .LMinus < 0 := by
  rw [globalSectorEigenvalue_WPlus hD, globalSectorEigenvalue_WMinus hD,
    globalSectorEigenvalue_LPlus hD, globalSectorEigenvalue_LMinus hD]
  exact ⟨lambdaWPlus_pos hD hgamma0 hgamma1,
    lambdaWMinus_neg hD hgamma0 hgamma1,
    lambdaLPlus_neg hD hgamma0 hgamma1,
    lambdaLMinus_neg hD hgamma0 hgamma1⟩

/-- Consequently `W_+` has strictly larger eigenvalue than every other
sector. -/
theorem globalSectorEigenvalue_WPlus_strictly_maximal
    {D gamma : ℝ} (hD : 4 ≤ D) (hgamma0 : 0 < gamma)
    (hgamma1 : gamma < 1)
    {sector : GlobalSDPSector} (hsector : sector ≠ .WPlus) :
    globalSectorEigenvalue D gamma sector <
      globalSectorEigenvalue D gamma .WPlus := by
  have hsigns := globalSectorEigenvalue_signs hD hgamma0 hgamma1
  have hplus : 0 < globalSectorEigenvalue D gamma .WPlus := hsigns.1
  cases sector with
  | WPlus => exact False.elim (hsector rfl)
  | WMinus => exact lt_trans hsigns.2.1 hplus
  | LPlus => exact lt_trans hsigns.2.2.1 hplus
  | LMinus => exact lt_trans hsigns.2.2.2 hplus

/-- Multiplying the positive `W_+` eigenvalue by
`dim Ran(W_+) * (D+1)/2 = D(D+1)/2` gives exactly the claimed optimum
`G_star(D,gamma)`. -/
theorem lambdaWPlus_mul_symmetricDimension
    {D gamma : ℝ} (hD : 4 ≤ D) :
    lambdaWPlus D gamma * inputSymmetricDimension D =
      globalOptimalGain D gamma := by
  have hD0 : D ≠ 0 := by linarith
  have hD1 : D + 1 ≠ 0 := by linarith
  simp only [lambdaWPlus, inputSymmetricDimension, globalOptimalGain,
    globalNoiseFidelity]
  field_simp

/-- The explicit scalar dual certificate has the same value as the primal
candidate.  The separate operator proof must establish its feasibility. -/
theorem globalDualValue_eq_optimalGain
    {D gamma : ℝ} (hD : 4 ≤ D) :
    globalDualCoefficient D gamma * inputSymmetricDimension D =
      globalOptimalGain D gamma := by
  exact lambdaWPlus_mul_symmetricDimension hD

/-- The claimed global optimum is strictly positive on the physical
parameter range. -/
theorem globalOptimalGain_pos
    {D gamma : ℝ} (hD : 4 ≤ D) (hgamma0 : 0 < gamma)
    (hgamma1 : gamma < 1) :
    0 < globalOptimalGain D gamma := by
  rw [← lambdaWPlus_mul_symmetricDimension hD]
  have hlambda := lambdaWPlus_pos hD hgamma0 hgamma1
  have hdim : 0 < inputSymmetricDimension D := by
    simp only [inputSymmetricDimension]
    have hDpos : 0 < D := by linarith
    have hDplus : 0 < D + 1 := by linarith
    positivity
  positivity

/-- A small real-algebra lemma used to read equality conditions from three
strictly negative sector coefficients. -/
theorem three_negative_coefficients_force_zero_weights
    {a b c x y z : ℝ}
    (ha : a < 0) (hb : b < 0) (hc : c < 0)
    (hx : 0 ≤ x) (hy : 0 ≤ y) (hz : 0 ≤ z)
    (hsum : a * x + b * y + c * z = 0) :
    x = 0 ∧ y = 0 ∧ z = 0 := by
  have hax : a * x ≤ 0 := mul_nonpos_of_nonpos_of_nonneg (le_of_lt ha) hx
  have hby : b * y ≤ 0 := mul_nonpos_of_nonpos_of_nonneg (le_of_lt hb) hy
  have hcz : c * z ≤ 0 := mul_nonpos_of_nonpos_of_nonneg (le_of_lt hc) hz
  have haxNonneg : 0 ≤ a * x := by linarith
  have hbyNonneg : 0 ≤ b * y := by linarith
  have hczNonneg : 0 ≤ c * z := by linarith
  have haxZero : a * x = 0 := le_antisymm hax haxNonneg
  have hbyZero : b * y = 0 := le_antisymm hby hbyNonneg
  have hczZero : c * z = 0 := le_antisymm hcz hczNonneg
  exact ⟨(mul_eq_zero.mp haxZero).resolve_left (ne_of_lt ha),
    (mul_eq_zero.mp hbyZero).resolve_left (ne_of_lt hb),
    (mul_eq_zero.mp hczZero).resolve_left (ne_of_lt hc)⟩

/-- Scalar upper bound for arbitrary nonnegative masses in the four sectors.
The operator layer supplies these masses as traces of positive diagonal
blocks and supplies the capacity bound on the WPlus mass. -/
theorem global_four_sector_objective_le
    {D gamma xWPlus xWMinus xLPlus xLMinus : ℝ}
    (hD : 4 ≤ D) (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (_hxWPlus : 0 ≤ xWPlus) (hxWMinus : 0 ≤ xWMinus)
    (hxLPlus : 0 ≤ xLPlus) (hxLMinus : 0 ≤ xLMinus)
    (hcapacity : xWPlus ≤ inputSymmetricDimension D) :
    lambdaWPlus D gamma * xWPlus +
        lambdaWMinus D gamma * xWMinus +
        lambdaLPlus D gamma * xLPlus +
        lambdaLMinus D gamma * xLMinus ≤
      globalOptimalGain D gamma := by
  have hplus := lambdaWPlus_pos hD hgamma0 hgamma1
  have hminus := lambdaWMinus_neg hD hgamma0 hgamma1
  have hlplus := lambdaLPlus_neg hD hgamma0 hgamma1
  have hlminus := lambdaLMinus_neg hD hgamma0 hgamma1
  have hWMinusTerm :
      lambdaWMinus D gamma * xWMinus ≤ 0 :=
    mul_nonpos_of_nonpos_of_nonneg (le_of_lt hminus) hxWMinus
  have hLPlusTerm :
      lambdaLPlus D gamma * xLPlus ≤ 0 :=
    mul_nonpos_of_nonpos_of_nonneg (le_of_lt hlplus) hxLPlus
  have hLMinusTerm :
      lambdaLMinus D gamma * xLMinus ≤ 0 :=
    mul_nonpos_of_nonpos_of_nonneg (le_of_lt hlminus) hxLMinus
  calc
    lambdaWPlus D gamma * xWPlus +
          lambdaWMinus D gamma * xWMinus +
          lambdaLPlus D gamma * xLPlus +
          lambdaLMinus D gamma * xLMinus
        ≤ lambdaWPlus D gamma * xWPlus := by linarith
    _ ≤ lambdaWPlus D gamma * inputSymmetricDimension D :=
      mul_le_mul_of_nonneg_left hcapacity (le_of_lt hplus)
    _ = globalOptimalGain D gamma :=
      lambdaWPlus_mul_symmetricDimension hD

/-- Equality in the scalar four-sector upper bound occurs exactly when all
available mass is in WPlus.  This is the real-algebraic equality condition
used by the operator-level uniqueness argument. -/
theorem global_four_sector_objective_eq_iff
    {D gamma xWPlus xWMinus xLPlus xLMinus : ℝ}
    (hD : 4 ≤ D) (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (_hxWPlus : 0 ≤ xWPlus) (hxWMinus : 0 ≤ xWMinus)
    (hxLPlus : 0 ≤ xLPlus) (hxLMinus : 0 ≤ xLMinus)
    (hcapacity : xWPlus ≤ inputSymmetricDimension D) :
    (lambdaWPlus D gamma * xWPlus +
          lambdaWMinus D gamma * xWMinus +
          lambdaLPlus D gamma * xLPlus +
          lambdaLMinus D gamma * xLMinus =
        globalOptimalGain D gamma) ↔
      xWPlus = inputSymmetricDimension D ∧
        xWMinus = 0 ∧ xLPlus = 0 ∧ xLMinus = 0 := by
  constructor
  · intro hobjective
    have hplus := lambdaWPlus_pos hD hgamma0 hgamma1
    have hminus := lambdaWMinus_neg hD hgamma0 hgamma1
    have hlplus := lambdaLPlus_neg hD hgamma0 hgamma1
    have hlminus := lambdaLMinus_neg hD hgamma0 hgamma1
    have hWMinusTerm :
        lambdaWMinus D gamma * xWMinus ≤ 0 :=
      mul_nonpos_of_nonpos_of_nonneg (le_of_lt hminus) hxWMinus
    have hLPlusTerm :
        lambdaLPlus D gamma * xLPlus ≤ 0 :=
      mul_nonpos_of_nonpos_of_nonneg (le_of_lt hlplus) hxLPlus
    have hLMinusTerm :
        lambdaLMinus D gamma * xLMinus ≤ 0 :=
      mul_nonpos_of_nonpos_of_nonneg (le_of_lt hlminus) hxLMinus
    have hObjectiveLeTop :
        lambdaWPlus D gamma * xWPlus +
              lambdaWMinus D gamma * xWMinus +
              lambdaLPlus D gamma * xLPlus +
              lambdaLMinus D gamma * xLMinus ≤
            lambdaWPlus D gamma * xWPlus := by
      linarith
    have hTopLeGain :
        lambdaWPlus D gamma * xWPlus ≤ globalOptimalGain D gamma := by
      calc
        lambdaWPlus D gamma * xWPlus
            ≤ lambdaWPlus D gamma * inputSymmetricDimension D :=
          mul_le_mul_of_nonneg_left hcapacity (le_of_lt hplus)
        _ = globalOptimalGain D gamma :=
          lambdaWPlus_mul_symmetricDimension hD
    have hGainLeTop :
        globalOptimalGain D gamma ≤ lambdaWPlus D gamma * xWPlus := by
      rw [← hobjective]
      exact hObjectiveLeTop
    have hTopEqGain :
        lambdaWPlus D gamma * xWPlus = globalOptimalGain D gamma :=
      le_antisymm hTopLeGain hGainLeTop
    have hMulEq :
        lambdaWPlus D gamma * xWPlus =
          lambdaWPlus D gamma * inputSymmetricDimension D := by
      calc
        lambdaWPlus D gamma * xWPlus = globalOptimalGain D gamma :=
          hTopEqGain
        _ = lambdaWPlus D gamma * inputSymmetricDimension D :=
          (lambdaWPlus_mul_symmetricDimension hD).symm
    have hFactor :
        lambdaWPlus D gamma *
            (xWPlus - inputSymmetricDimension D) = 0 := by
      rw [mul_sub, hMulEq, sub_self]
    have hxWPlusEq : xWPlus = inputSymmetricDimension D := by
      have hDifference :
          xWPlus - inputSymmetricDimension D = 0 :=
        (mul_eq_zero.mp hFactor).resolve_left (ne_of_gt hplus)
      exact sub_eq_zero.mp hDifference
    have hResidual :
        lambdaWMinus D gamma * xWMinus +
            lambdaLPlus D gamma * xLPlus +
            lambdaLMinus D gamma * xLMinus = 0 := by
      calc
        lambdaWMinus D gamma * xWMinus +
              lambdaLPlus D gamma * xLPlus +
              lambdaLMinus D gamma * xLMinus =
            (lambdaWPlus D gamma * xWPlus +
                lambdaWMinus D gamma * xWMinus +
                lambdaLPlus D gamma * xLPlus +
                lambdaLMinus D gamma * xLMinus) -
              lambdaWPlus D gamma * xWPlus := by ring
        _ = globalOptimalGain D gamma -
              lambdaWPlus D gamma * xWPlus := by rw [hobjective]
        _ = 0 := by rw [← hTopEqGain, sub_self]
    have hZeros :=
      three_negative_coefficients_force_zero_weights
        hminus hlplus hlminus hxWMinus hxLPlus hxLMinus hResidual
    exact ⟨hxWPlusEq, hZeros⟩
  · rintro ⟨hxWPlusEq, hxWMinusEq, hxLPlusEq, hxLMinusEq⟩
    rw [hxWPlusEq, hxWMinusEq, hxLPlusEq, hxLMinusEq]
    simpa using lambdaWPlus_mul_symmetricDimension (D := D) (gamma := gamma) hD

end

end EntanglementPurification
