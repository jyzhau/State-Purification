import EntanglementPurification.CompressedPPTIsometryPullback
import EntanglementPurification.PhysicalOperationalEq986
import EntanglementPurification.PhysicalOperationalEntropyConverse
import EntanglementPurification.PureVectorConjugation

/-!
# Operational necessity for a locally embedded signed Schmidt form

This file connects the arbitrary-resource operational objective to the
compressed PPT converse.  The input-first Choi convention first replaces the
resource by its coordinatewise conjugate.  A pair of local isometries then
pulls the complete compressed certificate back to the paper's ordered signed
Schmidt coordinates.

The only remaining basis-free existence step for a wholly arbitrary resource
is to construct the ordered, padded signed-Schmidt isometry witness supplied
as an argument below.
-/

namespace EntanglementPurification

open QIT

noncomputable section

universe u v

variable {ra : Type u} {rb : Type v}
  [Fintype ra] [DecidableEq ra]
  [Fintype rb] [DecidableEq rb]

/-- The quantitative core of the arbitrary-coordinate bridge: exact
operational attainment plus a signed-Schmidt local-isometry presentation gives
the collision-probability bound consumed by both entropy and rigidity. -/
theorem physicalOperationalAttainment_implies_collisionProbability_le_half_of_signedSchmidtIsometries
    {d m : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (resource : PureVector (ra × rb))
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (VA : ReferenceIsometry (Fin (m + 3)) ra)
    (VB : ReferenceIsometry (Fin (m + 3)) rb)
    (hschmidt :
      conjugatePureVector resource =
        VA.applyPureVector
          (VB.applyPureVectorRight (ambientSignedSchmidtResource p hp)))
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le resource =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) :
    collisionProbability p ≤ 1 / 2 := by
  have hsdpeq :
      globalSDPObjective
          (globalPaperEq986PerformanceOperator hd nu gamma)
          (pureResourceInsert (conjugatePureVector resource).amp
            (MatrixMap.choi (M.instrument.branch true))) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma := by
    rw [physicalPaperOperationalAverageAcceptedGain_eq_globalSDPObjective]
      at hattains
    simpa [conjugatePureVector] using hattains
  let data : CompressedPPTInstrumentData d ra rb :=
    physicalInstrumentTwirlGlobalOptimalCompressedData
      M hd nu hgamma0 hgamma1 (conjugatePureVector resource) hsdpeq
  have hdataResource : data.resource = conjugatePureVector resource := by
    simp [data]
  let pulled : CompressedPPTInstrumentData d
      (Fin (m + 3)) (Fin (m + 3)) :=
    data.pullbackLocalIsometries
      (ambientSignedSchmidtResource p hp) VA VB
        (hdataResource.trans hschmidt)
  exact pulled.implies_collisionProbability_le_half hd p hp (by rfl)

/-- Exact operational attainment by an arbitrary physical resource implies
one ebit for its coordinatewise conjugate, as soon as the latter is exhibited
as local isometries applied to the paper's ordered signed Schmidt form.

No LOCC-to-PPT implication is used: `M` is already a
`PhysicalPPTInstrument`. -/
theorem physicalOperationalAttainment_implies_one_le_conjugateEntanglement_of_signedSchmidtIsometries
    {d m : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (resource : PureVector (ra × rb))
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (VA : ReferenceIsometry (Fin (m + 3)) ra)
    (VB : ReferenceIsometry (Fin (m + 3)) rb)
    (hschmidt :
      conjugatePureVector resource =
        VA.applyPureVector
          (VB.applyPureVectorRight (ambientSignedSchmidtResource p hp)))
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le resource =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) :
    1 ≤ (conjugatePureVector resource).entanglementEntropy := by
  have hcollision : collisionProbability p ≤ 1 / 2 := by
    exact
      physicalOperationalAttainment_implies_collisionProbability_le_half_of_signedSchmidtIsometries
        M hd nu hgamma0 hgamma1 resource p hp VA VB hschmidt hattains
  have hShannon : 1 ≤ shannonEntropyBits p :=
    one_le_shannonEntropyBits_of_orderedProbability_of_collisionProbability_le_half
      hp hcollision
  have htargetEntropy :
      (ambientSignedSchmidtResource p hp).entanglementEntropy =
        shannonEntropyBits p := by
    simpa [shannonEntropyBits] using
      ambientSignedSchmidtResource_entanglementEntropy p hp
  have hconjugateEntropy :
      (conjugatePureVector resource).entanglementEntropy =
        (ambientSignedSchmidtResource p hp).entanglementEntropy := by
    calc
      (conjugatePureVector resource).entanglementEntropy =
          (VA.applyPureVector
            (VB.applyPureVectorRight
              (ambientSignedSchmidtResource p hp))).entanglementEntropy :=
        congrArg PureVector.entanglementEntropy hschmidt
      _ = (ambientSignedSchmidtResource p hp).entanglementEntropy := by
        rw [entanglementEntropy_applyPureVector,
          entanglementEntropy_applyPureVectorRight]
  rw [hconjugateEntropy, htargetEntropy]
  exact hShannon

/-- Final arbitrary-resource wrapper once coordinatewise conjugation is known
to preserve Lean-QIT pure-state entanglement entropy. -/
theorem physicalOperationalAttainment_implies_one_le_entanglement_of_signedSchmidtIsometries
    {d m : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (resource : PureVector (ra × rb))
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (VA : ReferenceIsometry (Fin (m + 3)) ra)
    (VB : ReferenceIsometry (Fin (m + 3)) rb)
    (hschmidt :
      conjugatePureVector resource =
        VA.applyPureVector
          (VB.applyPureVectorRight (ambientSignedSchmidtResource p hp)))
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le resource =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) :
    1 ≤ resource.entanglementEntropy := by
  rw [← conjugatePureVector_entanglementEntropy resource]
  exact
    physicalOperationalAttainment_implies_one_le_conjugateEntanglement_of_signedSchmidtIsometries
      M hd nu hgamma0 hgamma1 resource p hp VA VB hschmidt hattains

/-- Equality rigidity in arbitrary ambient coordinates: at the one-ebit
threshold the ordered Schmidt spectrum in the local-isometry witness is
exactly `(1/2,1/2,0,...)`.  Together with `hschmidt`, this is precisely the
local-isometry (embedded-EPR) conclusion. -/
theorem physicalOperationalAttainment_entanglement_eq_one_implies_twoPointSpectrum_of_signedSchmidtIsometries
    {d m : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (resource : PureVector (ra × rb))
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (VA : ReferenceIsometry (Fin (m + 3)) ra)
    (VB : ReferenceIsometry (Fin (m + 3)) rb)
    (hschmidt :
      conjugatePureVector resource =
        VA.applyPureVector
          (VB.applyPureVectorRight (ambientSignedSchmidtResource p hp)))
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le resource =
        globalOptimalGain ((d : ℝ) ^ 2) gamma)
    (hentropy : resource.entanglementEntropy = 1) :
    p = twoPointComparison (m + 1) := by
  apply orderedProbability_eq_twoPoint_of_collision_le_half_of_shannon_eq_one hp
  · exact
      physicalOperationalAttainment_implies_collisionProbability_le_half_of_signedSchmidtIsometries
        M hd nu hgamma0 hgamma1 resource p hp VA VB hschmidt hattains
  · have hconjugateEntropy :
        (conjugatePureVector resource).entanglementEntropy = 1 := by
      rw [conjugatePureVector_entanglementEntropy, hentropy]
    have hsignedEntropy :
        (ambientSignedSchmidtResource p hp).entanglementEntropy = 1 := by
      calc
        (ambientSignedSchmidtResource p hp).entanglementEntropy =
            (conjugatePureVector resource).entanglementEntropy := by
          rw [hschmidt, entanglementEntropy_applyPureVector,
            entanglementEntropy_applyPureVectorRight]
        _ = 1 := hconjugateEntropy
    rw [ambientSignedSchmidtResource_entanglementEntropy] at hsignedEntropy
    simpa [shannonEntropyBits] using hsignedEntropy

end

end EntanglementPurification
