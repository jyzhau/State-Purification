import QIT.Util.Matrix.PosSqrt
import Mathlib.Analysis.Matrix.PosDef
import Mathlib.Tactic

/-!
# Rigidity lemmas for the global CPTN SDP

This file contains the finite-matrix support argument used in the uniqueness
part of the global CPTN optimization.  Its statements are independent of the
particular four sectors occurring in `main.tex`.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

/-- A Hermitian idempotent with zero `J`-mass annihilates a positive
semidefinite matrix `J` on both sides.

The hypothesis is stated using the real part of the trace because this is the
real trace pairing used by the SDP objective. -/
theorem hermitianProjection_mul_psd_eq_zero_of_trace_re_eq_zero
    {n : Type*} [Fintype n] [DecidableEq n]
    {P J : CMatrix n}
    (hJ : J.PosSemidef)
    (hPherm : P.IsHermitian)
    (hPid : P * P = P)
    (hmass : ((P * J).trace).re = 0) :
    P * J = 0 ∧ J * P = 0 := by
  have hPJPpos : (P * J * P).PosSemidef := by
    have h := hJ.conjTranspose_mul_mul_same P
    simpa [hPherm.eq] using h
  have htracePJP : (P * J * P).trace = (P * J).trace := by
    calc
      (P * J * P).trace = (P * (P * J)).trace :=
        Matrix.trace_mul_comm (P * J) P
      _ = ((P * P) * J).trace := by rw [Matrix.mul_assoc]
      _ = (P * J).trace := by rw [hPid]
  have hPJPTraceZero : (P * J * P).trace = 0 := by
    apply Complex.ext
    · rw [htracePJP]
      exact hmass
    · exact (Matrix.PosSemidef.trace_nonneg hPJPpos).2.symm
  have hPJPzero : P * J * P = 0 :=
    (Matrix.PosSemidef.trace_eq_zero_iff hPJPpos).mp hPJPTraceZero

  let S : CMatrix n := psdSqrt J
  have hSsq : S * S = J := by
    simpa [S] using psdSqrt_mul_self_of_posSemidef hJ
  have hSherm : S.IsHermitian := by
    simpa [S] using psdSqrt_isHermitian J
  have hSPConjSelf : (S * P).conjTranspose * (S * P) = 0 := by
    calc
      (S * P).conjTranspose * (S * P) = P * S * (S * P) := by
        rw [Matrix.conjTranspose_mul, hPherm.eq, hSherm.eq]
      _ = P * J * P := by
        rw [← Matrix.mul_assoc, Matrix.mul_assoc P S S, hSsq]
      _ = 0 := hPJPzero
  have hSP : S * P = 0 := by
    have htrace : ((S * P).conjTranspose * (S * P)).trace = 0 := by
      rw [hSPConjSelf, Matrix.trace_zero]
    exact (Matrix.trace_conjTranspose_mul_self_eq_zero_iff).mp htrace
  have hJP : J * P = 0 := by
    rw [← hSsq, Matrix.mul_assoc, hSP, Matrix.mul_zero]
  have hPJ : P * J = 0 := by
    rw [← Matrix.conjTranspose_eq_zero]
    calc
      (P * J).conjTranspose = J.conjTranspose * P.conjTranspose := by
        rw [Matrix.conjTranspose_mul]
      _ = J * P := by rw [hJ.isHermitian.eq, hPherm.eq]
      _ = 0 := hJP
  exact ⟨hPJ, hJP⟩

/-- The six one-direction products expressing pairwise orthogonality of four
Hermitian projections.  Hermiticity supplies the reverse-direction products. -/
def PairwiseOrthogonalFour
    {n : Type*} [Fintype n]
    (Pplus P₁ P₂ P₃ : CMatrix n) : Prop :=
  Pplus * P₁ = 0 ∧ Pplus * P₂ = 0 ∧ Pplus * P₃ = 0 ∧
    P₁ * P₂ = 0 ∧ P₁ * P₃ = 0 ∧ P₂ * P₃ = 0

/-- Four-sector rigidity used by the global SDP uniqueness proof.

If four pairwise orthogonal Hermitian projections resolve the identity and a
PSD matrix has zero mass in the three complementary sectors, the matrix is
entirely supported on the distinguished `Pplus` sector.

Pairwise orthogonality is included because it is the paper-facing sector
interface.  The support conclusion itself only needs the identity resolution
and the three zero-mass hypotheses. -/
theorem psd_eq_distinguished_compression_of_four_projection_zero_masses
    {n : Type*} [Fintype n] [DecidableEq n]
    {J Pplus P₁ P₂ P₃ : CMatrix n}
    (hJ : J.PosSemidef)
    (_hPplusHerm : Pplus.IsHermitian)
    (hP₁Herm : P₁.IsHermitian)
    (hP₂Herm : P₂.IsHermitian)
    (hP₃Herm : P₃.IsHermitian)
    (_hPplusId : Pplus * Pplus = Pplus)
    (hP₁Id : P₁ * P₁ = P₁)
    (hP₂Id : P₂ * P₂ = P₂)
    (hP₃Id : P₃ * P₃ = P₃)
    (_horth : PairwiseOrthogonalFour Pplus P₁ P₂ P₃)
    (hresolve : Pplus + P₁ + P₂ + P₃ = 1)
    (hmass₁ : ((P₁ * J).trace).re = 0)
    (hmass₂ : ((P₂ * J).trace).re = 0)
    (hmass₃ : ((P₃ * J).trace).re = 0) :
    J = Pplus * J * Pplus := by
  have hzero₁ :=
    hermitianProjection_mul_psd_eq_zero_of_trace_re_eq_zero
      hJ hP₁Herm hP₁Id hmass₁
  have hzero₂ :=
    hermitianProjection_mul_psd_eq_zero_of_trace_re_eq_zero
      hJ hP₂Herm hP₂Id hmass₂
  have hzero₃ :=
    hermitianProjection_mul_psd_eq_zero_of_trace_re_eq_zero
      hJ hP₃Herm hP₃Id hmass₃
  rcases hzero₁ with ⟨hP₁J, hJP₁⟩
  rcases hzero₂ with ⟨hP₂J, hJP₂⟩
  rcases hzero₃ with ⟨hP₃J, hJP₃⟩
  calc
    J = 1 * J * 1 := by simp
    _ = (Pplus + P₁ + P₂ + P₃) * J *
        (Pplus + P₁ + P₂ + P₃) := by rw [hresolve]
    _ = Pplus * J * Pplus := by
      simp [Matrix.add_mul, Matrix.mul_add, Matrix.mul_assoc,
        hP₁J, hP₂J, hP₃J, hJP₁, hJP₂, hJP₃]

end

end EntanglementPurification
