import EntanglementPurification.GlobalEq986Optimality
import EntanglementPurification.PhysicalLocalTwirlResource

/-!
# Local-twirl preservation of the equation-986 objective

The equation-986 performance operator is itself a full-unitary Haar average.
This module proves pointwise covariance of its integrand and exact fixedness
under conjugation by the mixed representation `bar W ⊗ bar W ⊗ W`, in both
conjugation orientations.  It then transports that fixedness through the
global-to-physical register permutation and the inert resource factor.
Consequently the genuine two-sided physical Haar twirl preserves the literal
complex trace pairing, and hence the real SDP objective, for arbitrary branch
and resource matrices; no positivity, PPT, normalization, or optimality
hypothesis is needed.
-/

namespace EntanglementPurification

open QIT
open MeasureTheory
open scoped ComplexOrder MatrixOrder Matrix.Norms.L2Operator

noncomputable section

universe uA uB uR uX uI

local instance physicalLocalTwirlObjectiveCMatrixContinuousENorm
    {i : Type uI} [Fintype i] [DecidableEq i] :
    ContinuousENorm (CMatrix i) :=
  SeminormedAddGroup.toContinuousENorm

variable {x : Type uX} [Fintype x] [DecidableEq x] [Nonempty x]

omit [Nonempty x] in
private theorem transpose_star_eq_localEntrywiseConjugate
    (W : Matrix.unitaryGroup x ℂ) :
    Matrix.transpose (star (W : CMatrix x)) =
      localEntrywiseConjugate W := by
  ext i j
  simp [localEntrywiseConjugate, Matrix.star_eq_conjTranspose,
    Matrix.conjTranspose_apply]

omit [Nonempty x] in
private theorem transpose_eq_star_localEntrywiseConjugate
    (W : Matrix.unitaryGroup x ℂ) :
    Matrix.transpose (W : CMatrix x) =
      star (localEntrywiseConjugate W) := by
  ext i j
  simp [localEntrywiseConjugate]

omit [Nonempty x] in
private theorem globalHaarOrbitPureMatrix_mul_left
    (nu : PureVector x) (W U : Matrix.unitaryGroup x ℂ) :
    (W : CMatrix x) * globalHaarOrbitPureMatrix nu U *
        star (W : CMatrix x) =
      globalHaarOrbitPureMatrix nu (W * U) := by
  change (W : CMatrix x) *
      ((U : CMatrix x) * rankOneMatrix nu.amp * star (U : CMatrix x)) *
        star (W : CMatrix x) =
    ((W : CMatrix x) * (U : CMatrix x)) * rankOneMatrix nu.amp *
      star ((W : CMatrix x) * (U : CMatrix x))
  simp only [star_mul, Matrix.mul_assoc]

omit [Nonempty x] in
private theorem globalDepolarizedOrbitMatrix_mul_left
    (nu : PureVector x) (gamma : ℝ)
    (W U : Matrix.unitaryGroup x ℂ) :
    (W : CMatrix x) * globalDepolarizedOrbitMatrix nu gamma U *
        star (W : CMatrix x) =
      globalDepolarizedOrbitMatrix nu gamma (W * U) := by
  simp only [globalDepolarizedOrbitMatrix, Matrix.mul_add, Matrix.add_mul,
    Matrix.mul_smul, Matrix.smul_mul,
    globalHaarOrbitPureMatrix_mul_left]
  have hW : (W : CMatrix x) * star (W : CMatrix x) = 1 := by
    simpa [Matrix.star_eq_conjTranspose] using
      (Matrix.mem_unitaryGroup_iff.mp W.2)
  rw [show (W : CMatrix x) * 1 * star (W : CMatrix x) = 1 by
    simpa only [Matrix.mul_one] using hW]

omit [Nonempty x] in
private theorem globalDepolarizedOrbitMatrix_transpose_mul_left
    (nu : PureVector x) (gamma : ℝ)
    (W U : Matrix.unitaryGroup x ℂ) :
    localEntrywiseConjugate W *
        (globalDepolarizedOrbitMatrix nu gamma U).transpose *
        star (localEntrywiseConjugate W) =
      (globalDepolarizedOrbitMatrix nu gamma (W * U)).transpose := by
  have h := congrArg Matrix.transpose
    (globalDepolarizedOrbitMatrix_mul_left nu gamma W U)
  simpa only [Matrix.transpose_mul, transpose_star_eq_localEntrywiseConjugate,
    transpose_eq_star_localEntrywiseConjugate, Matrix.mul_assoc] using h

omit [Fintype x] [DecidableEq x] [Nonempty x] in
private theorem kronecker_self_transpose (A : CMatrix x) :
    (Matrix.kronecker A A).transpose =
      Matrix.kronecker A.transpose A.transpose := by
  ext p q
  rfl

omit [Fintype x] [DecidableEq x] [Nonempty x] in
private theorem star_kronecker_self (A : CMatrix x) :
    star (Matrix.kronecker A A) =
      Matrix.kronecker (star A) (star A) := by
  simpa [Matrix.star_eq_conjTranspose] using
    (Matrix.conjTranspose_kronecker A A)

omit [Nonempty x] in
private theorem globalEq986InputPair_conj
    (nu : PureVector x) (gamma : ℝ)
    (W U : Matrix.unitaryGroup x ℂ) :
    Matrix.kronecker (localEntrywiseConjugate W)
        (localEntrywiseConjugate W) *
        (Matrix.kronecker
          (globalDepolarizedOrbitMatrix nu gamma U)
          (globalDepolarizedOrbitMatrix nu gamma U)).transpose *
        star (Matrix.kronecker (localEntrywiseConjugate W)
          (localEntrywiseConjugate W)) =
      (Matrix.kronecker
        (globalDepolarizedOrbitMatrix nu gamma (W * U))
        (globalDepolarizedOrbitMatrix nu gamma (W * U))).transpose := by
  rw [kronecker_self_transpose, star_kronecker_self]
  calc
    Matrix.kronecker (localEntrywiseConjugate W)
          (localEntrywiseConjugate W) *
          Matrix.kronecker
            (globalDepolarizedOrbitMatrix nu gamma U).transpose
            (globalDepolarizedOrbitMatrix nu gamma U).transpose *
          Matrix.kronecker (star (localEntrywiseConjugate W))
            (star (localEntrywiseConjugate W)) =
        Matrix.kronecker
            (localEntrywiseConjugate W *
              (globalDepolarizedOrbitMatrix nu gamma U).transpose)
            (localEntrywiseConjugate W *
              (globalDepolarizedOrbitMatrix nu gamma U).transpose) *
          Matrix.kronecker (star (localEntrywiseConjugate W))
            (star (localEntrywiseConjugate W)) := by
              exact congrArg
                (fun X => X * Matrix.kronecker
                  (star (localEntrywiseConjugate W))
                  (star (localEntrywiseConjugate W)))
                (Matrix.mul_kronecker_mul
                  (localEntrywiseConjugate W)
                  (globalDepolarizedOrbitMatrix nu gamma U).transpose
                  (localEntrywiseConjugate W)
                  (globalDepolarizedOrbitMatrix nu gamma U).transpose).symm
    _ = Matrix.kronecker
          (localEntrywiseConjugate W *
            (globalDepolarizedOrbitMatrix nu gamma U).transpose *
            star (localEntrywiseConjugate W))
          (localEntrywiseConjugate W *
            (globalDepolarizedOrbitMatrix nu gamma U).transpose *
            star (localEntrywiseConjugate W)) := by
            exact (Matrix.mul_kronecker_mul
              (localEntrywiseConjugate W *
                (globalDepolarizedOrbitMatrix nu gamma U).transpose)
              (star (localEntrywiseConjugate W))
              (localEntrywiseConjugate W *
                (globalDepolarizedOrbitMatrix nu gamma U).transpose)
              (star (localEntrywiseConjugate W))).symm
    _ = Matrix.kronecker
          (globalDepolarizedOrbitMatrix nu gamma (W * U)).transpose
          (globalDepolarizedOrbitMatrix nu gamma (W * U)).transpose := by
            rw [globalDepolarizedOrbitMatrix_transpose_mul_left]
    _ = (Matrix.kronecker
          (globalDepolarizedOrbitMatrix nu gamma (W * U))
          (globalDepolarizedOrbitMatrix nu gamma (W * U))).transpose := by
            rw [kronecker_self_transpose]

omit [Nonempty x] in
private theorem globalEq986OutputFactor_conj
    (nu : PureVector x) (gamma : ℝ)
    (W U : Matrix.unitaryGroup x ℂ) :
    (W : CMatrix x) *
        (globalHaarOrbitPureMatrix nu U -
          globalNoiseFidelity (Fintype.card x : ℝ) gamma •
            (1 : CMatrix x)) *
        star (W : CMatrix x) =
      globalHaarOrbitPureMatrix nu (W * U) -
        globalNoiseFidelity (Fintype.card x : ℝ) gamma •
          (1 : CMatrix x) := by
  rw [Matrix.mul_sub, Matrix.sub_mul,
    globalHaarOrbitPureMatrix_mul_left]
  have hW : (W : CMatrix x) * star (W : CMatrix x) = 1 := by
    simpa [Matrix.star_eq_conjTranspose] using
      (Matrix.mem_unitaryGroup_iff.mp W.2)
  simp only [Matrix.mul_smul, Matrix.smul_mul, Matrix.mul_one, hW]

private theorem star_kronecker
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b]
    (A : CMatrix a) (B : CMatrix b) :
    star (Matrix.kronecker A B) =
      Matrix.kronecker (star A) (star B) := by
  simpa [Matrix.star_eq_conjTranspose] using
    (Matrix.conjTranspose_kronecker A B)

private theorem kronecker_conj
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b]
    (A X : CMatrix a) (B Y : CMatrix b) :
    Matrix.kronecker A B * Matrix.kronecker X Y *
        star (Matrix.kronecker A B) =
      Matrix.kronecker (A * X * star A) (B * Y * star B) := by
  rw [star_kronecker]
  calc
    Matrix.kronecker A B * Matrix.kronecker X Y *
        Matrix.kronecker (star A) (star B) =
      Matrix.kronecker (A * X) (B * Y) *
        Matrix.kronecker (star A) (star B) := by
          exact congrArg
            (fun Z => Z * Matrix.kronecker (star A) (star B))
            (Matrix.mul_kronecker_mul A X B Y).symm
    _ = Matrix.kronecker (A * X * star A)
        (B * Y * star B) := by
          exact (Matrix.mul_kronecker_mul
            (A * X) (star A) (B * Y) (star B)).symm

omit [Nonempty x] in
/-- Pointwise covariance of the unexpanded equation-986 integrand under the
mixed representation `bar W ⊗ bar W ⊗ W`. -/
theorem globalEq986Integrand_conj
    (nu : PureVector x) (gamma : ℝ)
    (W U : Matrix.unitaryGroup x ℂ) :
    localMixedSchurRepresentation W *
        globalEq986Integrand nu gamma U *
        star (localMixedSchurRepresentation W) =
      globalEq986Integrand nu gamma (W * U) := by
  unfold localMixedSchurRepresentation globalEq986Integrand
  rw [kronecker_conj, globalEq986InputPair_conj,
    globalEq986OutputFactor_conj]

private theorem continuous_matrix_kronecker
    {X : Type*} [TopologicalSpace X]
    {i j k l : Type*}
    {A : X → Matrix i j ℂ} {B : X → Matrix k l ℂ}
    (hA : Continuous A) (hB : Continuous B) :
    Continuous (fun z ↦ Matrix.kronecker (A z) (B z)) := by
  refine continuous_pi ?_
  intro p
  refine continuous_pi ?_
  intro q
  exact
    ((continuous_apply q.1).comp ((continuous_apply p.1).comp hA)).mul
      ((continuous_apply q.2).comp ((continuous_apply p.2).comp hB))

private theorem continuous_matrix_transpose
    {X : Type*} [TopologicalSpace X]
    {i j : Type*} {A : X → Matrix i j ℂ}
    (hA : Continuous A) :
    Continuous (fun z ↦ (A z).transpose) := by
  refine continuous_pi ?_
  intro p
  refine continuous_pi ?_
  intro q
  exact (continuous_apply p).comp ((continuous_apply q).comp hA)

omit [Nonempty x] in
private theorem globalHaarOrbitPureMatrix_continuous
    (nu : PureVector x) :
    Continuous (globalHaarOrbitPureMatrix nu) := by
  unfold globalHaarOrbitPureMatrix
  have hU : Continuous
      (fun U : Matrix.unitaryGroup x ℂ ↦ (U : CMatrix x)) :=
    continuous_subtype_val
  have hNu : Continuous
      (fun _ : Matrix.unitaryGroup x ℂ ↦ rankOneMatrix nu.amp) :=
    continuous_const
  simpa [Matrix.mul_assoc] using
    ((hU.matrix_mul hNu).matrix_mul (Continuous.star hU))

omit [Nonempty x] in
private theorem globalDepolarizedOrbitMatrix_continuous
    (nu : PureVector x) (gamma : ℝ) :
    Continuous (globalDepolarizedOrbitMatrix nu gamma) := by
  unfold globalDepolarizedOrbitMatrix
  exact
    (continuous_const.smul
      (globalHaarOrbitPureMatrix_continuous nu)).add continuous_const

omit [Nonempty x] in
/-- The equation-986 matrix integrand is continuous on the finite-dimensional
unitary group. -/
theorem globalEq986Integrand_continuous
    (nu : PureVector x) (gamma : ℝ) :
    Continuous (globalEq986Integrand nu gamma) := by
  unfold globalEq986Integrand
  have hPure := globalHaarOrbitPureMatrix_continuous nu
  have hNoise := globalDepolarizedOrbitMatrix_continuous nu gamma
  have hInputPair := continuous_matrix_kronecker hNoise hNoise
  have hInputPairTranspose := continuous_matrix_transpose hInputPair
  have hOutput : Continuous (fun U : Matrix.unitaryGroup x ℂ ↦
      globalHaarOrbitPureMatrix nu U -
        globalNoiseFidelity (Fintype.card x : ℝ) gamma •
          (1 : CMatrix x)) :=
    hPure.sub continuous_const
  exact continuous_matrix_kronecker hInputPairTranspose hOutput

/-- Consequently the equation-986 matrix integrand is Bochner integrable with
respect to normalized unitary Haar measure. -/
theorem globalEq986Integrand_integrable
    (nu : PureVector x) (gamma : ℝ) :
    Integrable (globalEq986Integrand nu gamma)
      (unitaryHaarMeasure (a := x)) :=
  (globalEq986Integrand_continuous nu gamma).integrable_of_hasCompactSupport
    (HasCompactSupport.of_compactSpace _)

private theorem matrix_mul_integral_mul
    {α : Type*} [MeasurableSpace α] {μ : Measure α}
    {i : Type uI} [Fintype i] [DecidableEq i]
    (L R : CMatrix i) {f : α → CMatrix i} (hf : Integrable f μ) :
    L * (∫ z, f z ∂μ) * R = ∫ z, L * f z * R ∂μ := by
  simpa [ContinuousLinearMap.mulLeftRight_apply] using
    ((ContinuousLinearMap.mulLeftRight ℝ (CMatrix i) L R).integral_comp_comm hf).symm

/-- The equation-986 performance operator is fixed by conjugation under the
full mixed representation `bar W ⊗ bar W ⊗ W`. -/
theorem globalEq986PerformanceOperator_conj_fixed
    (nu : PureVector x) (gamma : ℝ)
    (W : Matrix.unitaryGroup x ℂ) :
    localMixedSchurRepresentation W *
        globalEq986PerformanceOperator nu gamma *
        star (localMixedSchurRepresentation W) =
      globalEq986PerformanceOperator nu gamma := by
  have hf : Integrable (globalEq986Integrand nu gamma)
      (unitaryHaarMeasure (a := x)) :=
    globalEq986Integrand_integrable nu gamma
  calc
    localMixedSchurRepresentation W *
        globalEq986PerformanceOperator nu gamma *
        star (localMixedSchurRepresentation W) =
      ∫ U : Matrix.unitaryGroup x ℂ,
        localMixedSchurRepresentation W *
          globalEq986Integrand nu gamma U *
          star (localMixedSchurRepresentation W)
        ∂unitaryHaarMeasure (a := x) := by
          rw [globalEq986PerformanceOperator]
          exact matrix_mul_integral_mul
            (localMixedSchurRepresentation W)
            (star (localMixedSchurRepresentation W)) hf
    _ = ∫ U : Matrix.unitaryGroup x ℂ,
        globalEq986Integrand nu gamma (W * U)
        ∂unitaryHaarMeasure (a := x) := by
          congr 1
          funext U
          exact globalEq986Integrand_conj nu gamma W U
    _ = globalEq986PerformanceOperator nu gamma := by
      simpa [globalEq986PerformanceOperator] using
        (MeasureTheory.integral_mul_left_eq_self
          (μ := unitaryHaarMeasure (a := x))
          (globalEq986Integrand nu gamma) W)

/-- The same fixedness with the adjoint representation on the left. -/
theorem globalEq986PerformanceOperator_dual_fixed
    (nu : PureVector x) (gamma : ℝ)
    (W : Matrix.unitaryGroup x ℂ) :
    star (localMixedSchurRepresentation W) *
        globalEq986PerformanceOperator nu gamma *
        localMixedSchurRepresentation W =
      globalEq986PerformanceOperator nu gamma := by
  simpa [Matrix.star_eq_conjTranspose] using
    (globalEq986PerformanceOperator_conj_fixed nu gamma W⁻¹)

/-! ## Physical regrouping and the full resource-assisted pairing -/

variable {a : Type uA} {b : Type uB} {r : Type uR}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

/-- Product of independent local unitaries, viewed as a unitary on `A × B`. -/
private def localProductUnitary
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    Matrix.unitaryGroup (a × b) ℂ :=
  ⟨Matrix.kronecker (U : CMatrix a) (V : CMatrix b),
    Matrix.kronecker_mem_unitary (SetLike.coe_mem U) (SetLike.coe_mem V)⟩

/-- Regrouping the global mixed representation of `U ⊗ V` gives the
product of the two local mixed representations exactly. -/
private theorem physicalInsertedChoiMatrix_productRepresentation
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    physicalInsertedChoiMatrix
        (localMixedSchurRepresentation (localProductUnitary U V)) =
      jointContractionUnassistedPhysicalRepresentation U V := by
  ext p q
  rcases p with ⟨⟨⟨iA₁, iA₂⟩, oA⟩, ⟨⟨iB₁, iB₂⟩, oB⟩⟩
  rcases q with ⟨⟨⟨jA₁, jA₂⟩, pA⟩, ⟨⟨jB₁, jB₂⟩, pB⟩⟩
  simp [physicalInsertedChoiMatrix, Matrix.reindexAlgEquiv_apply,
    Matrix.reindex_apply, physicalInsertedChoiEquiv,
    localMixedSchurRepresentation, localEntrywiseConjugate,
    localProductUnitary, jointContractionUnassistedPhysicalRepresentation,
    Matrix.kronecker]
  ring

/-- The physical register permutation preserves adjoint conjugation. -/
private theorem physicalInsertedChoiMatrix_star_mul_mul
    (A K : CMatrix (PhysicalUnassistedChoiIndex a b)) :
    physicalInsertedChoiMatrix (star A * K * A) =
      star (physicalInsertedChoiMatrix A) *
        physicalInsertedChoiMatrix K * physicalInsertedChoiMatrix A := by
  unfold physicalInsertedChoiMatrix
  rw [Matrix.reindexAlgEquiv_mul, Matrix.reindexAlgEquiv_mul]
  congr 2

/-- The equation-986 performance operator in physical Alice/Bob register
order. -/
def physicalRegroupedEq986PerformanceOperator
    [Nonempty a] [Nonempty b]
    (nu : PureVector (a × b)) (gamma : ℝ) :
    CMatrix (JointContractionUnassistedPhysicalIndex a b) :=
  physicalInsertedChoiMatrix
    (globalEq986PerformanceOperator nu gamma)

/-- The regrouped equation-986 performance matrix is dual-fixed by every
product of local mixed representations. -/
theorem physicalRegroupedEq986PerformanceOperator_product_dual_fixed
    [Nonempty a] [Nonempty b]
    (nu : PureVector (a × b)) (gamma : ℝ)
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    star (jointContractionUnassistedPhysicalRepresentation U V) *
        physicalRegroupedEq986PerformanceOperator nu gamma *
        jointContractionUnassistedPhysicalRepresentation U V =
      physicalRegroupedEq986PerformanceOperator nu gamma := by
  let W := localProductUnitary U V
  have hraw :=
    globalEq986PerformanceOperator_dual_fixed nu gamma W
  have hphysical := congrArg
    (physicalInsertedChoiMatrix (a := a) (b := b)) hraw
  rw [physicalInsertedChoiMatrix_star_mul_mul] at hphysical
  simpa [physicalRegroupedEq986PerformanceOperator, W,
    physicalInsertedChoiMatrix_productRepresentation] using hphysical

/-- Alice's unassisted mixed representation dual-fixes the regrouped
equation-986 performance matrix. -/
theorem physicalRegroupedEq986PerformanceOperator_alice_dual_fixed
    [Nonempty a] [Nonempty b]
    (nu : PureVector (a × b)) (gamma : ℝ)
    (U : Matrix.unitaryGroup a ℂ) :
    star (physicalAliceUnassistedMixedRepresentation (b := b) U) *
        physicalRegroupedEq986PerformanceOperator nu gamma *
        physicalAliceUnassistedMixedRepresentation (b := b) U =
      physicalRegroupedEq986PerformanceOperator nu gamma := by
  simpa [physicalAliceUnassistedMixedRepresentation] using
    (physicalRegroupedEq986PerformanceOperator_product_dual_fixed
      nu gamma U (1 : Matrix.unitaryGroup b ℂ))

/-- Bob's unassisted mixed representation dual-fixes the regrouped
equation-986 performance matrix. -/
theorem physicalRegroupedEq986PerformanceOperator_bob_dual_fixed
    [Nonempty a] [Nonempty b]
    (nu : PureVector (a × b)) (gamma : ℝ)
    (V : Matrix.unitaryGroup b ℂ) :
    star (physicalBobUnassistedMixedRepresentation (a := a) V) *
        physicalRegroupedEq986PerformanceOperator nu gamma *
        physicalBobUnassistedMixedRepresentation (a := a) V =
      physicalRegroupedEq986PerformanceOperator nu gamma := by
  simpa [physicalBobUnassistedMixedRepresentation] using
    (physicalRegroupedEq986PerformanceOperator_product_dual_fixed
      nu gamma (1 : Matrix.unitaryGroup a ℂ) V)

/-- The full resource-assisted performance pairing
`M_Eq986,physical ⊗ omegaᵀ`. -/
def physicalEq986FixedResourcePairing
    [Nonempty a] [Nonempty b]
    (nu : PureVector (a × b)) (gamma : ℝ) (omega : CMatrix r) :
    CMatrix (JointContractionPhysicalIndex a b r) :=
  Matrix.kronecker
    (physicalRegroupedEq986PerformanceOperator nu gamma)
    omega.transpose

omit [DecidableEq a] [DecidableEq b] in
private theorem kronecker_fixed_resource
    (A P : CMatrix (JointContractionUnassistedPhysicalIndex a b))
    (Q : CMatrix r) (hfixed : star A * P * A = P) :
    star (Matrix.kronecker A (1 : CMatrix r)) *
        Matrix.kronecker P Q * Matrix.kronecker A (1 : CMatrix r) =
      Matrix.kronecker P Q := by
  rw [Matrix.star_eq_conjTranspose]
  unfold Matrix.kronecker
  rw [Matrix.conjTranspose_kronecker]
  simp only [Matrix.conjTranspose_one]
  rw [← Matrix.mul_kronecker_mul, ← Matrix.mul_kronecker_mul]
  rw [show Matrix.conjTranspose A * P * A = P by
    simpa [Matrix.star_eq_conjTranspose] using hfixed]
  simp

/-- Alice's assisted physical representation dual-fixes the full
equation-986/resource pairing for every resource matrix `omega`. -/
theorem physicalEq986FixedResourcePairing_alice_dual_fixed
    [Nonempty a] [Nonempty b]
    (nu : PureVector (a × b)) (gamma : ℝ) (omega : CMatrix r)
    (U : Matrix.unitaryGroup a ℂ) :
    star (physicalAliceMixedRepresentation (b := b) (r := r) U) *
        physicalEq986FixedResourcePairing nu gamma omega *
        physicalAliceMixedRepresentation (b := b) (r := r) U =
      physicalEq986FixedResourcePairing nu gamma omega := by
  let A := physicalAliceUnassistedMixedRepresentation (b := b) U
  let P := physicalRegroupedEq986PerformanceOperator nu gamma
  have hfixed : star A * P * A = P := by
    simpa [A, P] using
      (physicalRegroupedEq986PerformanceOperator_alice_dual_fixed
        nu gamma U)
  have h := kronecker_fixed_resource A P omega.transpose hfixed
  simpa [physicalEq986FixedResourcePairing, A, P,
    physicalAliceMixedRepresentation,
    physicalAliceUnassistedMixedRepresentation,
    jointContractionPhysicalRepresentation,
    jointContractionUnassistedPhysicalRepresentation] using h

/-- Bob's assisted physical representation dual-fixes the full
equation-986/resource pairing for every resource matrix `omega`. -/
theorem physicalEq986FixedResourcePairing_bob_dual_fixed
    [Nonempty a] [Nonempty b]
    (nu : PureVector (a × b)) (gamma : ℝ) (omega : CMatrix r)
    (V : Matrix.unitaryGroup b ℂ) :
    star (physicalBobMixedRepresentation (a := a) (r := r) V) *
        physicalEq986FixedResourcePairing nu gamma omega *
        physicalBobMixedRepresentation (a := a) (r := r) V =
      physicalEq986FixedResourcePairing nu gamma omega := by
  let A := physicalBobUnassistedMixedRepresentation (a := a) V
  let P := physicalRegroupedEq986PerformanceOperator nu gamma
  have hfixed : star A * P * A = P := by
    simpa [A, P] using
      (physicalRegroupedEq986PerformanceOperator_bob_dual_fixed
        nu gamma V)
  have h := kronecker_fixed_resource A P omega.transpose hfixed
  simpa [physicalEq986FixedResourcePairing, A, P,
    physicalBobMixedRepresentation,
    physicalBobUnassistedMixedRepresentation,
    jointContractionPhysicalRepresentation,
    jointContractionUnassistedPhysicalRepresentation] using h

private noncomputable def traceLeftMulCLM
    {i : Type uI} [Fintype i] [DecidableEq i]
    (P : CMatrix i) : CMatrix i →L[ℂ] ℂ :=
  LinearMap.toContinuousLinearMap
    { toFun := fun K ↦ (P * K).trace
      map_add' := by
        intro K L
        simp [Matrix.mul_add, Matrix.trace_add]
      map_smul' := by
        intro c K
        simp [Matrix.trace_smul] }

private theorem trace_mul_integral
    {α : Type*} [MeasurableSpace α] {μ : Measure α}
    {i : Type uI} [Fintype i] [DecidableEq i]
    (P : CMatrix i) {f : α → CMatrix i} (hf : Integrable f μ) :
    (P * (∫ z, f z ∂μ)).trace = ∫ z, (P * f z).trace ∂μ := by
  simpa [traceLeftMulCLM] using
    ((traceLeftMulCLM P).integral_comp_comm hf).symm

omit [DecidableEq x] [Nonempty x] in
private theorem trace_mul_conj_eq_of_dual_fixed
    (P R K : CMatrix x)
    (hfixed : star R * P * R = P) :
    (P * (R * K * star R)).trace = (P * K).trace := by
  calc
    (P * (R * K * star R)).trace =
        (((P * R) * K) * star R).trace := by
      simp only [Matrix.mul_assoc]
    _ = (star R * ((P * R) * K)).trace :=
      Matrix.trace_mul_comm _ _
    _ = ((star R * P * R) * K).trace := by
      simp only [Matrix.mul_assoc]
    _ = (P * K).trace := by rw [hfixed]

private theorem trace_mul_physicalAliceTwirl_eq_of_fixed
    [Nonempty a] [Nonempty b] [Nonempty r]
    (P K : CMatrix (JointContractionPhysicalIndex a b r))
    (hfixed : ∀ U : Matrix.unitaryGroup a ℂ,
      star (physicalAliceMixedRepresentation (b := b) (r := r) U) * P *
          physicalAliceMixedRepresentation (b := b) (r := r) U = P) :
    (P * physicalAliceTwirl K).trace = (P * K).trace := by
  rw [physicalAliceTwirl]
  rw [trace_mul_integral P (physicalAliceTwirlIntegrand_integrable K)]
  calc
    (∫ U : Matrix.unitaryGroup a ℂ,
        (P * physicalAliceTwirlIntegrand K U).trace
        ∂unitaryHaarMeasure (a := a)) =
        ∫ _ : Matrix.unitaryGroup a ℂ, (P * K).trace
          ∂unitaryHaarMeasure (a := a) := by
      apply integral_congr_ae
      filter_upwards [] with U
      exact trace_mul_conj_eq_of_dual_fixed P
        (physicalAliceMixedRepresentation (b := b) (r := r) U) K
        (hfixed U)
    _ = (P * K).trace := by simp

private theorem trace_mul_physicalBobTwirl_eq_of_fixed
    [Nonempty a] [Nonempty b] [Nonempty r]
    (P K : CMatrix (JointContractionPhysicalIndex a b r))
    (hfixed : ∀ V : Matrix.unitaryGroup b ℂ,
      star (physicalBobMixedRepresentation (a := a) (r := r) V) * P *
          physicalBobMixedRepresentation (a := a) (r := r) V = P) :
    (P * physicalBobTwirl K).trace = (P * K).trace := by
  rw [physicalBobTwirl]
  rw [trace_mul_integral P (physicalBobTwirlIntegrand_integrable K)]
  calc
    (∫ V : Matrix.unitaryGroup b ℂ,
        (P * physicalBobTwirlIntegrand K V).trace
        ∂unitaryHaarMeasure (a := b)) =
        ∫ _ : Matrix.unitaryGroup b ℂ, (P * K).trace
          ∂unitaryHaarMeasure (a := b) := by
      apply integral_congr_ae
      filter_upwards [] with V
      exact trace_mul_conj_eq_of_dual_fixed P
        (physicalBobMixedRepresentation (a := a) (r := r) V) K
        (hfixed V)
    _ = (P * K).trace := by simp

/-- The genuine two-sided physical local Haar twirl preserves the literal
complex equation-986/resource trace pairing for arbitrary `omega` and
arbitrary branch matrix `K`. -/
theorem trace_physicalEq986FixedResourcePairing_physicalLocalTwirl_eq
    [Nonempty a] [Nonempty b] [Nonempty r]
    (nu : PureVector (a × b)) (gamma : ℝ) (omega : CMatrix r)
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    (physicalEq986FixedResourcePairing nu gamma omega *
        physicalLocalTwirl K).trace =
      (physicalEq986FixedResourcePairing nu gamma omega * K).trace := by
  unfold physicalLocalTwirl
  rw [trace_mul_physicalAliceTwirl_eq_of_fixed
    (physicalEq986FixedResourcePairing nu gamma omega)
    (physicalBobTwirl K)
    (physicalEq986FixedResourcePairing_alice_dual_fixed
      nu gamma omega)]
  exact trace_mul_physicalBobTwirl_eq_of_fixed
    (physicalEq986FixedResourcePairing nu gamma omega) K
    (physicalEq986FixedResourcePairing_bob_dual_fixed
      nu gamma omega)

/-- Real-SDP-objective form of
`trace_physicalEq986FixedResourcePairing_physicalLocalTwirl_eq`. -/
theorem globalSDPObjective_physicalEq986FixedResourcePairing_physicalLocalTwirl_eq
    [Nonempty a] [Nonempty b] [Nonempty r]
    (nu : PureVector (a × b)) (gamma : ℝ) (omega : CMatrix r)
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    globalSDPObjective
        (physicalEq986FixedResourcePairing nu gamma omega)
        (physicalLocalTwirl K) =
      globalSDPObjective
        (physicalEq986FixedResourcePairing nu gamma omega) K := by
  exact congrArg Complex.re
    (trace_physicalEq986FixedResourcePairing_physicalLocalTwirl_eq
      nu gamma omega K)

/-! ## Pure-resource and raw input-first corollaries -/

omit [Fintype r] [DecidableEq r] in
/-- Extending an unassisted operator by a resource vector produces its
Kronecker product with that vector's rank-one matrix. -/
private theorem resourceEmbedding_mul_mul_conjTranspose
    (M : CMatrix (JointContractionUnassistedPhysicalIndex a b))
    (eta : r → ℂ) :
    physicalResourceInsertionEmbedding eta * M *
        Matrix.conjTranspose (physicalResourceInsertionEmbedding eta) =
      Matrix.kronecker M (rankOneMatrix eta) := by
  ext p q
  rcases p with ⟨p, u⟩
  rcases q with ⟨q, v⟩
  simp [physicalResourceInsertionEmbedding, Matrix.mul_apply,
    Matrix.conjTranspose_apply, Matrix.kronecker, rankOneMatrix_apply,
    apply_ite]
  ring

omit [DecidableEq r] in
/-- Trace pairing against `M` after a pure-resource sandwich equals the
full assisted trace pairing against `M ⊗ |eta><eta|`. -/
theorem trace_mul_physicalPureResourceInsert_eq_trace_kronecker_rankOne_mul
    (M : CMatrix (JointContractionUnassistedPhysicalIndex a b))
    (eta : r → ℂ)
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    (M * physicalPureResourceInsert eta K).trace =
      (Matrix.kronecker M (rankOneMatrix eta) * K).trace := by
  let E := physicalResourceInsertionEmbedding (a := a) (b := b) eta
  have hEME :
      E * M * Matrix.conjTranspose E =
        Matrix.kronecker M (rankOneMatrix eta) := by
    simpa [E] using
      (resourceEmbedding_mul_mul_conjTranspose
        (a := a) (b := b) M eta)
  unfold physicalPureResourceInsert
  change (M * (Matrix.conjTranspose E * K * E)).trace = _
  calc
    (M * (Matrix.conjTranspose E * K * E)).trace =
        ((M * Matrix.conjTranspose E * K) * E).trace := by
      simp only [Matrix.mul_assoc]
    _ = (E * (M * Matrix.conjTranspose E * K)).trace :=
      Matrix.trace_mul_comm _ _
    _ = ((E * M * Matrix.conjTranspose E) * K).trace := by
      simp only [Matrix.mul_assoc]
    _ = (Matrix.kronecker M (rankOneMatrix eta) * K).trace := by
      rw [hEME]

/-- Pure-resource complex trace form of local-twirl objective preservation. -/
theorem trace_physicalRegroupedEq986PerformanceOperator_pureResource_localTwirl_eq
    [Nonempty a] [Nonempty b] [Nonempty r]
    (nu : PureVector (a × b)) (gamma : ℝ)
    (eta : r → ℂ)
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    (physicalRegroupedEq986PerformanceOperator nu gamma *
        physicalPureResourceInsert eta (physicalLocalTwirl K)).trace =
      (physicalRegroupedEq986PerformanceOperator nu gamma *
        physicalPureResourceInsert eta K).trace := by
  let M := physicalRegroupedEq986PerformanceOperator nu gamma
  calc
    (M * physicalPureResourceInsert eta (physicalLocalTwirl K)).trace =
        (Matrix.kronecker M (rankOneMatrix eta) *
          physicalLocalTwirl K).trace :=
      trace_mul_physicalPureResourceInsert_eq_trace_kronecker_rankOne_mul
        M eta (physicalLocalTwirl K)
    _ = (Matrix.kronecker M (rankOneMatrix eta) * K).trace := by
      simpa [physicalEq986FixedResourcePairing, M] using
        (trace_physicalEq986FixedResourcePairing_physicalLocalTwirl_eq
          nu gamma (rankOneMatrix eta).transpose K)
    _ = (M * physicalPureResourceInsert eta K).trace :=
      (trace_mul_physicalPureResourceInsert_eq_trace_kronecker_rankOne_mul
        M eta K).symm

/-- Pure-resource real-SDP-objective form of local-twirl preservation. -/
theorem globalSDPObjective_physicalRegroupedEq986PerformanceOperator_pureResource_localTwirl_eq
    [Nonempty a] [Nonempty b] [Nonempty r]
    (nu : PureVector (a × b)) (gamma : ℝ)
    (eta : r → ℂ)
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    globalSDPObjective
        (physicalRegroupedEq986PerformanceOperator nu gamma)
        (physicalPureResourceInsert eta (physicalLocalTwirl K)) =
      globalSDPObjective
        (physicalRegroupedEq986PerformanceOperator nu gamma)
        (physicalPureResourceInsert eta K) := by
  exact congrArg Complex.re
    (trace_physicalRegroupedEq986PerformanceOperator_pureResource_localTwirl_eq
      nu gamma eta K)

private theorem trace_reindex_equiv
    {α β : Type*} [Fintype α] [DecidableEq α]
    [Fintype β] [DecidableEq β]
    (e : α ≃ β) (A : CMatrix α) :
    (Matrix.reindex e e A).trace = A.trace := by
  rw [Matrix.trace, Matrix.trace]
  exact Fintype.sum_equiv e.symm
    (fun p : β => Matrix.reindex e e A p p)
    (fun p : α => A p p)
    (by
      intro p
      simp [Matrix.reindex_apply, Matrix.submatrix_apply])

/-- Simultaneously regrouping a performance matrix and a Choi matrix from
input-first to physical Alice/Bob order preserves the real trace objective. -/
theorem globalSDPObjective_physicalInsertedChoiMatrix
    (M K : CMatrix (PhysicalUnassistedChoiIndex a b)) :
    globalSDPObjective
        (physicalInsertedChoiMatrix M)
        (physicalInsertedChoiMatrix K) =
      globalSDPObjective M K := by
  unfold globalSDPObjective physicalInsertedChoiMatrix
  rw [← Matrix.reindexAlgEquiv_mul]
  change
    ((Matrix.reindex
      (physicalInsertedChoiEquiv (a := a) (b := b))
      (physicalInsertedChoiEquiv (a := a) (b := b))
      (M * K)).trace).re = ((M * K).trace).re
  rw [trace_reindex_equiv]

/-- Raw input-first version of pure-resource local-twirl objective
preservation.  The left side uses the genuinely twirled physical Choi matrix;
the right side is the original raw Choi matrix after resource insertion. -/
theorem globalSDPObjective_physicalLocalTwirl_physicalInstrumentChoiMatrix_eq_raw
    {ra rb : Type*}
    [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]
    [Nonempty a] [Nonempty b] [Nonempty ra] [Nonempty rb]
    (nu : PureVector (a × b)) (gamma : ℝ)
    (eta : ra × rb → ℂ)
    (K : CMatrix
      (PhysicalInstrumentInput a b ra rb × PhysicalInstrumentOutput a b)) :
    globalSDPObjective
        (physicalRegroupedEq986PerformanceOperator nu gamma)
        (physicalPureResourceInsert eta
          (physicalLocalTwirl (physicalInstrumentChoiMatrix K))) =
      globalSDPObjective
        (globalEq986PerformanceOperator nu gamma)
        (pureResourceInsert eta K) := by
  rw [
    globalSDPObjective_physicalRegroupedEq986PerformanceOperator_pureResource_localTwirl_eq]
  rw [physicalPureResourceInsert_physicalInstrumentChoiMatrix]
  exact globalSDPObjective_physicalInsertedChoiMatrix
    (globalEq986PerformanceOperator nu gamma)
    (pureResourceInsert eta K)

/-- Map-level specialization of
`globalSDPObjective_physicalLocalTwirl_physicalInstrumentChoiMatrix_eq_raw`. -/
theorem globalSDPObjective_physicalLocalTwirl_physicalInstrumentChoi_eq_raw
    {ra rb : Type*}
    [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]
    [Nonempty a] [Nonempty b] [Nonempty ra] [Nonempty rb]
    (nu : PureVector (a × b)) (gamma : ℝ)
    (eta : ra × rb → ℂ)
    (Phi : MatrixMap (PhysicalInstrumentInput a b ra rb)
      (PhysicalInstrumentOutput a b)) :
    globalSDPObjective
        (physicalRegroupedEq986PerformanceOperator nu gamma)
        (physicalPureResourceInsert eta
          (physicalLocalTwirl (physicalInstrumentChoi Phi))) =
      globalSDPObjective
        (globalEq986PerformanceOperator nu gamma)
        (pureResourceInsert eta (MatrixMap.choi Phi)) := by
  rw [physicalInstrumentChoi_eq_physicalInstrumentChoiMatrix]
  exact
    globalSDPObjective_physicalLocalTwirl_physicalInstrumentChoiMatrix_eq_raw
      nu gamma eta (MatrixMap.choi Phi)

end

end EntanglementPurification
