import EntanglementPurification.JointContractionOutputTrace
import EntanglementPurification.PhysicalBranchContractionCertificate

/-!
# Physical output-trace contraction/residual certificate

This file combines the physical contraction/residual decomposition with the
explicit output trace of the contraction block.  Positivity and local-unitary
invariance remain hypotheses only where the paper actually uses them:

* invariance derives the Schur-factorized contraction block;
* branch PSD derives PSD of the orthogonal residual;
* output trace then preserves that residual PSD.

The sector coefficients and Loewner lower bounds are added below using the
canonical extractor from OutputTraceSectors.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b r : Type*}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

/-- Paper equations eq:branch_contraction_residual_decomposition and
eq:branch_sector_trace_decomposition before coefficient extraction: the
physical output trace is the explicit four-sector contraction contribution
plus a PSD traced residual. -/
theorem physicalInvariant_outputTrace_contractionResidual_decomposition
    [Nonempty a] [Nonempty b]
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K)
    (hK : K.PosSemidef) :
    physicalBranchOutputTrace K =
        (∑ z : LocalMultiplicitySector,
          (jointContractionOutputTraceRealScale a b z) •
            Matrix.kronecker
              (jointInputSectorProjector (a := a) (b := b) z)
              (resourceSectorBlock
                (jointContractionSchurCoefficient K) z z)) +
          physicalBranchOutputTrace (jointContractionResidual K) ∧
      (physicalBranchOutputTrace
        (jointContractionResidual K)).PosSemidef := by
  obtain ⟨hdecomp, hResidual⟩ :=
    jointContractionPhysicalInvariant_schur_residual_decomposition
      hcardA hcardB hInvariant hK
  constructor
  · calc
      physicalBranchOutputTrace K =
          physicalBranchOutputTrace
            (jointContractionEmbedding
                (Matrix.kronecker (jointContractionSchurCoefficient K)
                  (1 : CMatrix (a × b))) +
              jointContractionResidual K) :=
        congrArg physicalBranchOutputTrace hdecomp
      _ = _ := by
        rw [physicalBranchOutputTrace_add,
          jointContractionEmbedding_schur_outputTrace_sectorExpansion
            hcardA hcardB]
  · exact physicalBranchOutputTrace_posSemidef hResidual

/-- The traced residual has a PSD canonical coefficient in every one of the
four input sectors.  Residual invariance is derived elsewhere for the paper's
sector interpretation, but is not needed for this positivity implication. -/
theorem physicalInvariant_outputTrace_residualSectorCoefficient_posSemidef
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hK : K.PosSemidef) (z : LocalMultiplicitySector) :
    (outputTraceSectorCoefficient
      (physicalBranchOutputTrace (jointContractionResidual K)) z).PosSemidef := by
  exact outputTraceSectorCoefficient_posSemidef hcardA hcardB
    (physicalBranchOutputTrace_posSemidef
      (jointContractionResidual_posSemidef hK)) z

/-- Exact resource-valued coefficient identity behind all four inequalities
in eq:branch_sector_trace_decomposition. -/
theorem physicalInvariant_outputTrace_sectorCoefficient_decomposition
    [Nonempty a] [Nonempty b]
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K)
    (hK : K.PosSemidef) (z : LocalMultiplicitySector) :
    outputTraceSectorCoefficient (physicalBranchOutputTrace K) z =
      (jointContractionOutputTraceRealScale a b z) •
          resourceSectorBlock (jointContractionSchurCoefficient K) z z +
        outputTraceSectorCoefficient
          (physicalBranchOutputTrace (jointContractionResidual K)) z := by
  obtain ⟨hdecomp, _⟩ :=
    jointContractionPhysicalInvariant_schur_residual_decomposition
      hcardA hcardB hInvariant hK
  calc
    outputTraceSectorCoefficient (physicalBranchOutputTrace K) z =
        outputTraceSectorCoefficient
          (physicalBranchOutputTrace
            (jointContractionEmbedding
                (Matrix.kronecker (jointContractionSchurCoefficient K)
                  (1 : CMatrix (a × b))) +
              jointContractionResidual K)) z :=
      congrArg
        (fun X => outputTraceSectorCoefficient
          (physicalBranchOutputTrace X) z) hdecomp
    _ = outputTraceSectorCoefficient
          (physicalBranchOutputTrace
            (jointContractionEmbedding
              (Matrix.kronecker (jointContractionSchurCoefficient K)
                (1 : CMatrix (a × b))))) z +
        outputTraceSectorCoefficient
          (physicalBranchOutputTrace (jointContractionResidual K)) z := by
      rw [physicalBranchOutputTrace_add,
        outputTraceSectorCoefficient_add]
    _ = _ := by
      rw [outputTraceSectorCoefficient_jointContractionEmbedding_schur
        hcardA hcardB]

/-- Unequal-dimensional generalization of all four lower bounds in
eq:branch_sector_trace_lower_bounds.  The coefficient specializes to the
paper's alpha/beta formula when Alice and Bob have the same dimension. -/
theorem physicalInvariant_outputTrace_sectorCoefficient_lowerBound
    [Nonempty a] [Nonempty b]
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K)
    (hK : K.PosSemidef) (z : LocalMultiplicitySector) :
    (jointContractionOutputTraceRealScale a b z) •
        resourceSectorBlock (jointContractionSchurCoefficient K) z z ≤
      outputTraceSectorCoefficient (physicalBranchOutputTrace K) z := by
  have hdecomp :=
    physicalInvariant_outputTrace_sectorCoefficient_decomposition
      hcardA hcardB hInvariant hK z
  rw [Matrix.le_iff]
  have hdiff :
      outputTraceSectorCoefficient (physicalBranchOutputTrace K) z -
          (jointContractionOutputTraceRealScale a b z) •
            resourceSectorBlock (jointContractionSchurCoefficient K) z z =
        outputTraceSectorCoefficient
          (physicalBranchOutputTrace (jointContractionResidual K)) z := by
    rw [hdecomp]
    abel
  rw [hdiff]
  exact
    physicalInvariant_outputTrace_residualSectorCoefficient_posSemidef
      hcardA hcardB hK z

/-- Callable four-sector form of the preceding lower-bound theorem. -/
theorem physicalInvariant_outputTrace_allSectorCoefficient_lowerBounds
    [Nonempty a] [Nonempty b]
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K)
    (hK : K.PosSemidef) :
    ∀ z : LocalMultiplicitySector,
      (jointContractionOutputTraceRealScale a b z) •
          resourceSectorBlock (jointContractionSchurCoefficient K) z z ≤
        outputTraceSectorCoefficient (physicalBranchOutputTrace K) z := by
  intro z
  exact physicalInvariant_outputTrace_sectorCoefficient_lowerBound
    hcardA hcardB hInvariant hK z

variable {ra rb : Type*}
  [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]

/-- Physical branchwise Bob-PPT implies Bob-PPT of every canonical
output-trace resource coefficient.  No branch PSD assumption is needed:
positivity comes directly from the physical partial transpose. -/
theorem physicalPPT_outputTrace_sectorCoefficient_partialTransposeB_posSemidef
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {K : CMatrix (JointContractionPhysicalIndex a b (ra × rb))}
    (hKppt : (physicalBranchPartialTransposeB K).PosSemidef)
    (z : LocalMultiplicitySector) :
    (QIT.partialTransposeB
      (outputTraceSectorCoefficient (physicalBranchOutputTrace K) z)).PosSemidef := by
  have hOutputPPT :
      (physicalBranchOutputPartialTransposeB
        (physicalBranchOutputTrace K)).PosSemidef :=
    physicalBranchOutputPartialTransposeB_posSemidef_of_physical hKppt
  have hCoefficient :=
    outputTraceSectorCoefficient_posSemidef hcardA hcardB hOutputPPT z
  rw [outputTraceSectorCoefficient_physicalBranchOutputPartialTransposeB]
    at hCoefficient
  exact hCoefficient

/-- All four output-trace resource coefficients inherit Bob-PPT order from a
physical Bob-PPT branch. -/
theorem physicalPPT_outputTrace_allSectorCoefficients_partialTransposeB_posSemidef
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {K : CMatrix (JointContractionPhysicalIndex a b (ra × rb))}
    (hKppt : (physicalBranchPartialTransposeB K).PosSemidef) :
    ∀ z : LocalMultiplicitySector,
      (QIT.partialTransposeB
        (outputTraceSectorCoefficient
          (physicalBranchOutputTrace K) z)).PosSemidef := by
  intro z
  exact
    physicalPPT_outputTrace_sectorCoefficient_partialTransposeB_posSemidef
      hcardA hcardB hKppt z

end

end EntanglementPurification
