import EntanglementPurification.JointContractionCompression

/-!
# Reducing decomposition for the joint contraction range

This file isolates the purely finite-matrix part of the contraction-range
decomposition.  For the range projection `P = 𝒢𝒢†`, it assumes explicitly
that an operator `K` is range-reducing, meaning `P K = K P`.  From this
commutation relation and `P² = P`, it proves that the two off-diagonal blocks
vanish and splits `K` into its contraction block and its orthogonal residual.

Important scope boundary: this file does **not** prove that physical invariance
under the independent local twirls implies `P K = K P`.  That implication
requires the mixed-Schur statement that there are no intertwiners between the
contraction isotypic component and its complementary irreducible components.
Such a Hom-zero theorem must be supplied and proved upstream; it is not hidden
inside the range-reducing hypothesis below.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b r : Type*}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

/-- A physical operator is reducing for the joint contraction range when it
commutes with the orthogonal-range candidate `P = 𝒢𝒢†`.

This is deliberately an explicit matrix condition.  It does not assert that
local-twirl invariance automatically supplies the commutation relation. -/
def IsJointContractionRangeReducing
    (K : CMatrix (JointContractionPhysicalIndex a b r)) : Prop :=
  jointContractionRangeProjection (a := a) (b := b) (r := r) * K =
    K * jointContractionRangeProjection

/-- The block of `K` supported on the orthogonal complement of the joint
contraction range: `(I - P) K (I - P)`. -/
def jointContractionResidual
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    CMatrix (JointContractionPhysicalIndex a b r) :=
  (1 - jointContractionRangeProjection (a := a) (b := b) (r := r)) * K *
    (1 - jointContractionRangeProjection)

/-- The block from the contraction range to its orthogonal complement
vanishes for a range-reducing operator: `P K (I - P) = 0`. -/
theorem jointContractionRangeReducing_left_offDiagonal_zero
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hreduce : IsJointContractionRangeReducing K) :
    jointContractionRangeProjection (a := a) (b := b) (r := r) * K *
        (1 - jointContractionRangeProjection) = 0 := by
  let P := jointContractionRangeProjection (a := a) (b := b) (r := r)
  have hP : P * P = P :=
    jointContractionRangeProjection_idempotent hcardA hcardB
  have hcomm : P * K = K * P := by
    simpa [P, IsJointContractionRangeReducing] using hreduce
  change P * K * (1 - P) = 0
  noncomm_ring [hP, hcomm]

/-- The block from the orthogonal complement to the contraction range
vanishes for a range-reducing operator: `(I - P) K P = 0`. -/
theorem jointContractionRangeReducing_right_offDiagonal_zero
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hreduce : IsJointContractionRangeReducing K) :
    (1 - jointContractionRangeProjection (a := a) (b := b) (r := r)) * K *
        jointContractionRangeProjection = 0 := by
  let P := jointContractionRangeProjection (a := a) (b := b) (r := r)
  have hP : P * P = P :=
    jointContractionRangeProjection_idempotent hcardA hcardB
  have hcomm : P * K = K * P := by
    simpa [P, IsJointContractionRangeReducing] using hreduce
  change (1 - P) * K * P = 0
  noncomm_ring [hP, hcomm]

/-- A range-reducing physical operator is the sum of its pulled-back and
re-embedded contraction block and its orthogonal residual:

`K = 𝒢 (𝒢† K 𝒢) 𝒢† + (I - P) K (I - P)`.
-/
theorem jointContractionRangeReducing_decomposition
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hreduce : IsJointContractionRangeReducing K) :
    K = jointContractionEmbedding (jointContractionPullback K) +
      jointContractionResidual K := by
  let P := jointContractionRangeProjection (a := a) (b := b) (r := r)
  have hP : P * P = P :=
    jointContractionRangeProjection_idempotent hcardA hcardB
  have hcomm : P * K = K * P := by
    simpa [P, IsJointContractionRangeReducing] using hreduce
  rw [jointContractionEmbedding_pullback]
  change K = P * K * P + (1 - P) * K * (1 - P)
  noncomm_ring [hP, hcomm]

/-- Positivity of the physical operator passes to its orthogonal residual by
congruence with the Hermitian matrix `I - P`.

This fact needs neither the reducing condition nor the cardinality hypotheses;
those are needed for the block-decomposition interpretation, not for the PSD
congruence itself. -/
theorem jointContractionResidual_posSemidef
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hK : K.PosSemidef) :
    (jointContractionResidual K).PosSemidef := by
  let P := jointContractionRangeProjection (a := a) (b := b) (r := r)
  have hP : P.IsHermitian :=
    jointContractionRangeProjection_isHermitian
  have hPstar : Matrix.conjTranspose P = P := hP
  have hComplementStar : Matrix.conjTranspose (1 - P) = 1 - P := by
    simp [hPstar]
  have h := hK.conjTranspose_mul_mul_same (1 - P)
  rw [hComplementStar] at h
  simpa [jointContractionResidual, P] using h

end

end EntanglementPurification
