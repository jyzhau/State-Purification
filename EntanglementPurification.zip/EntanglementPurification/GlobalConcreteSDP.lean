import EntanglementPurification.GlobalContractions
import EntanglementPurification.GlobalCompressionBound
import EntanglementPurification.GlobalMomentExpansion
import EntanglementPurification.GlobalSectorUniqueness
import Mathlib.Tactic

/-!
# Concrete optimizer for the global CPTN SDP

This file instantiates the abstract four-sector optimization layer with the
explicit three-leg contractions from `GlobalContractions.lean`.  The final
theorem is the Lean counterpart of `lem:general_d_global_optimum` in
`main.tex`.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

/-- The Choi matrix claimed in the paper to be the unique global optimizer:
`J⋆ = (D+1) P_{W₊} / 2`. -/
def globalOptimalChoi
    {x : Type*} [Fintype x] [DecidableEq x] :
    CMatrix (GlobalThreeLeg x) :=
  (((Fintype.card x : ℝ) + 1) / 2) • globalPWPlus

/-- The two-copy symmetric input projector is bounded by the identity. -/
theorem globalInputPairPSym_le_one
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalInputPairPSym (x := x) ≤ (1 : CMatrix (x × x)) := by
  rw [Matrix.le_iff]
  exact MatrixMap.posSemidef_one_sub_of_posSemidef_idempotent
    globalInputPairPSym globalInputPairPSym_posSemidef
      globalInputPairPSym_idempotent

/-- The displayed optimizer is a feasible trace-nonincreasing CP Choi
matrix.  The key calculation is
`Tr_output J⋆ = P_sym,input ≤ I`. -/
theorem globalOptimalChoi_isGlobalCPTNChoi
    {x : Type*} [Fintype x] [DecidableEq x] :
    IsGlobalCPTNChoi (globalOptimalChoi (x := x)) := by
  constructor
  · exact globalPWPlus_posSemidef.smul (by positivity)
  · rw [globalOptimalChoi]
    change
      QIT.partialTraceB
          (((((Fintype.card x : ℝ) + 1) / 2 : ℝ) : ℂ) •
            globalPWPlus) ≤ 1
    rw [QIT.partialTraceB_smul,
      partialTraceB_globalPWPlus]
    have hdenom : (Fintype.card x : ℝ) + 1 ≠ 0 := by positivity
    have hscalar :
        (((((Fintype.card x : ℝ) + 1) / 2 : ℝ) : ℂ) *
            ((2 / ((Fintype.card x : ℝ) + 1) : ℝ) : ℂ)) = 1 := by
      push_cast
      field_simp [hdenom]
    rw [smul_smul, hscalar, one_smul]
    exact globalInputPairPSym_le_one

/-- The distinguished range is contained in the even input-swap sector. -/
theorem globalPWPlus_le_globalPSym
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPWPlus (x := x) ≤ globalPSym := by
  rw [Matrix.le_iff]
  simpa only [globalPLPlus] using globalPLPlus_posSemidef (x := x)

/-- Paper-facing form of the preceding containment:
`P_{W₊} ≤ P_sym,input ⊗ I_output`. -/
theorem globalPWPlus_le_inputPairPSym_kronecker_one
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPWPlus (x := x) ≤
      Matrix.kronecker globalInputPairPSym (1 : CMatrix x) := by
  rw [← globalPSym_eq_kronecker_inputPairPSym_one]
  exact globalPWPlus_le_globalPSym

/-- The rank/trace of `P_{W₊}` is the one-leg dimension `D`. -/
theorem globalPWPlus_trace
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalPWPlus (x := x)).trace = (Fintype.card x : ℂ) := by
  rw [globalPWPlus, Matrix.trace_mul_comm,
    globalWPlus_conjTranspose_mul_self, Matrix.trace_one]

/-- The input symmetric projector has dimension `D(D+1)/2`. -/
theorem globalInputPairPSym_trace_re
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalInputPairPSym (x := x)).trace.re =
      inputSymmetricDimension (Fintype.card x : ℝ) := by
  rw [globalInputPairPSym_trace]
  norm_num [inputSymmetricDimension, Complex.div_re, Complex.mul_re]

/-- The four concrete range/residual projectors are pairwise orthogonal in
the exact order consumed by the rigidity theorem. -/
theorem global_four_projectors_pairwise
    {x : Type*} [Fintype x] [DecidableEq x]
    (hcard : 2 ≤ Fintype.card x) :
    PairwiseOrthogonalFour
      (globalPWPlus (x := x)) globalPWMinus globalPLPlus globalPLMinus := by
  exact ⟨globalPWPlus_mul_globalPWMinus,
    globalPWPlus_mul_globalPLPlus,
    globalPWPlus_mul_globalPLMinus,
    globalPWMinus_mul_globalPLPlus,
    globalPWMinus_mul_globalPLMinus hcard,
    globalPLPlus_mul_globalPLMinus⟩

/-- The candidate saturates the full available `W₊` mass. -/
theorem globalOptimalChoi_WPlus_mass
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalSectorMass (globalPWPlus (x := x)) globalOptimalChoi =
      inputSymmetricDimension (Fintype.card x : ℝ) := by
  simp only [globalSectorMass, globalOptimalChoi, Matrix.mul_smul,
    globalPWPlus_idempotent, Matrix.trace_smul, globalPWPlus_trace,
    Complex.real_smul, inputSymmetricDimension]
  push_cast
  norm_num [Complex.add_re, Complex.mul_re, Complex.div_re]
  ring

/-- The candidate has no mass in the `W₋` sector. -/
theorem globalOptimalChoi_WMinus_mass
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalSectorMass (globalPWMinus (x := x)) globalOptimalChoi = 0 := by
  simp [globalSectorMass, globalOptimalChoi,
    globalPWMinus_mul_globalPWPlus]

/-- The candidate has no mass in the residual even sector. -/
theorem globalOptimalChoi_LPlus_mass
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalSectorMass (globalPLPlus (x := x)) globalOptimalChoi = 0 := by
  have hzero :
      globalPLPlus (x := x) * globalPWPlus = 0 := by
    rw [globalPLPlus, Matrix.sub_mul, globalPSym_mul_globalPWPlus,
      globalPWPlus_idempotent, sub_self]
  simp [globalSectorMass, globalOptimalChoi, hzero]

/-- The candidate has no mass in the residual odd sector. -/
theorem globalOptimalChoi_LMinus_mass
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalSectorMass (globalPLMinus (x := x)) globalOptimalChoi = 0 := by
  have hzero :
      globalPLMinus (x := x) * globalPWPlus = 0 := by
    rw [globalPLMinus, Matrix.sub_mul, globalPAsym_mul_globalPWPlus,
      globalPWMinus_mul_globalPWPlus, sub_zero]
  simp [globalSectorMass, globalOptimalChoi, hzero]

/-- The concrete four-sector performance operator. -/
def globalConcreteSectorPerformanceOperator
    {x : Type*} [Fintype x] [DecidableEq x] (gamma : ℝ) :
    CMatrix (GlobalThreeLeg x) :=
  globalSectorPerformanceOperator (Fintype.card x : ℝ) gamma
    globalPWPlus globalPWMinus globalPLPlus globalPLMinus

/-- The concrete four-sector performance operator is Hermitian. -/
theorem globalConcreteSectorPerformanceOperator_isHermitian
    {x : Type*} [Fintype x] [DecidableEq x] (gamma : ℝ) :
    (globalConcreteSectorPerformanceOperator (x := x) gamma).IsHermitian := by
  exact globalSectorPerformanceOperator_isHermitian
    globalPWPlus_isHermitian globalPWMinus_isHermitian
    globalPLPlus_isHermitian globalPLMinus_isHermitian

/-- The explicit contraction operators and the four concrete projectors obey
exactly the sector table displayed in the paper. -/
theorem globalConcretePerformanceSectorTable
    {x : Type*} [Fintype x] [DecidableEq x]
    (hcard : 2 ≤ Fintype.card x) :
    GlobalPerformanceSectorTable (Fintype.card x : ℝ)
      (globalInputSwap (x := x)) globalMomentCdiag globalMomentCcross
      globalPWPlus globalPWMinus globalPLPlus globalPLMinus := by
  constructor
  · exact global_four_projectors_sum
  · simp only [globalPLPlus, globalPLMinus, globalPSym, globalPAsym]
    module
  · exact globalMomentCdiag_eq_rangeProjectors hcard
  · exact globalMomentCcross_eq_rangeProjectors hcard

/-- The Haar-expanded raw performance operator, in the paper's concrete
three-leg ordering. -/
def globalConcreteRawPerformanceOperator
    {x : Type*} [Fintype x] [DecidableEq x] (gamma : ℝ) :
    CMatrix (GlobalThreeLeg x) :=
  globalRawPerformanceOperator (Fintype.card x : ℝ) gamma
    globalInputSwap globalMomentCdiag globalMomentCcross

/-- The paper's explicit dual certificate
`Y⋆ = λ_{W₊} P_sym,input`. -/
def globalConcreteDualCandidate
    {x : Type*} [Fintype x] [DecidableEq x] (gamma : ℝ) :
    CMatrix (x × x) :=
  globalSectorDualCandidate (Fintype.card x : ℝ) gamma
    globalInputPairPSym

/-- The raw contraction formula is exactly its four-sector spectral
decomposition. -/
theorem globalConcreteRawPerformanceOperator_eq_sector
    {x : Type*} [Fintype x] [DecidableEq x]
    {gamma : ℝ} (hcard : 4 ≤ (Fintype.card x : ℝ)) :
    globalConcreteRawPerformanceOperator (x := x) gamma =
      globalConcreteSectorPerformanceOperator (x := x) gamma := by
  apply globalRawPerformanceOperator_eq_sectorPerformance hcard
  apply globalConcretePerformanceSectorTable
  have hfour : 4 ≤ Fintype.card x := by exact_mod_cast hcard
  omega

/-- In the paper's dimension range, the raw Haar/contraction formula is
Hermitian because it equals the concrete four-sector spectral operator. -/
theorem globalConcreteRawPerformanceOperator_isHermitian
    {x : Type*} [Fintype x] [DecidableEq x]
    {gamma : ℝ} (hcard : 4 ≤ (Fintype.card x : ℝ)) :
    (globalConcreteRawPerformanceOperator (x := x) gamma).IsHermitian := by
  rw [globalConcreteRawPerformanceOperator_eq_sector hcard]
  exact globalConcreteSectorPerformanceOperator_isHermitian gamma

/-- The raw paper objective has zero imaginary part on every feasible Choi
matrix. -/
theorem globalConcreteRaw_trace_im_eq_zero
    {x : Type*} [Fintype x] [DecidableEq x]
    {gamma : ℝ} (hcard : 4 ≤ (Fintype.card x : ℝ))
    {J : CMatrix (GlobalThreeLeg x)} (hJ : IsGlobalCPTNChoi J) :
    ((globalConcreteRawPerformanceOperator (x := x) gamma * J).trace).im = 0 :=
  globalSDPObjective_trace_im_eq_zero
    (globalConcreteRawPerformanceOperator_isHermitian hcard) hJ

/-- Literal complex trace form of the raw paper objective on the feasible
set. -/
theorem globalConcreteRaw_trace_eq_coe_globalSDPObjective
    {x : Type*} [Fintype x] [DecidableEq x]
    {gamma : ℝ} (hcard : 4 ≤ (Fintype.card x : ℝ))
    {J : CMatrix (GlobalThreeLeg x)} (hJ : IsGlobalCPTNChoi J) :
    (globalConcreteRawPerformanceOperator (x := x) gamma * J).trace =
      (globalSDPObjective
        (globalConcreteRawPerformanceOperator (x := x) gamma) J : ℂ) :=
  trace_mul_eq_coe_globalSDPObjective
    (globalConcreteRawPerformanceOperator_isHermitian hcard) hJ

/-- The displayed feasible candidate attains exactly the value `G⋆` from
`lem:general_d_global_optimum`. -/
theorem globalOptimalChoi_objective_eq_globalOptimalGain
    {x : Type*} [Fintype x] [DecidableEq x]
    {gamma : ℝ} (hcard : 4 ≤ (Fintype.card x : ℝ)) :
    globalSDPObjective (globalConcreteSectorPerformanceOperator
        (x := x) gamma) globalOptimalChoi =
      globalOptimalGain (Fintype.card x : ℝ) gamma := by
  rw [globalConcreteSectorPerformanceOperator,
    globalSDPObjective_sectorPerformance,
    globalOptimalChoi_WPlus_mass, globalOptimalChoi_WMinus_mass,
    globalOptimalChoi_LPlus_mass, globalOptimalChoi_LMinus_mass]
  simp only [mul_zero, add_zero]
  exact lambdaWPlus_mul_symmetricDimension hcard

/-- Every feasible global CPTN Choi matrix is bounded by the displayed
value. -/
theorem globalConcreteSector_SDP_upper_bound
    {x : Type*} [Fintype x] [DecidableEq x]
    {gamma : ℝ} (hcard : 4 ≤ (Fintype.card x : ℝ))
    (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    {J : CMatrix (GlobalThreeLeg x)} (hJ : IsGlobalCPTNChoi J) :
    globalSDPObjective (globalConcreteSectorPerformanceOperator
        (x := x) gamma) J ≤
      globalOptimalGain (Fintype.card x : ℝ) gamma := by
  apply global_four_sector_SDP_upper_bound
      hcard hgamma0 hgamma1
      globalPWPlus_posSemidef globalPWMinus_posSemidef
      globalPLPlus_posSemidef
      (globalPLMinus_posSemidef (by
        have hfour : 4 ≤ Fintype.card x := by exact_mod_cast hcard
        omega))
      globalInputPairPSym_posSemidef
      globalPWPlus_le_inputPairPSym_kronecker_one
      globalInputPairPSym_trace_re hJ

/-- Every feasible global CPTN Choi matrix is bounded by `G⋆` for the raw
Haar/contraction performance operator itself. -/
theorem globalConcreteRaw_SDP_upper_bound
    {x : Type*} [Fintype x] [DecidableEq x]
    {gamma : ℝ} (hcard : 4 ≤ (Fintype.card x : ℝ))
    (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    {J : CMatrix (GlobalThreeLeg x)} (hJ : IsGlobalCPTNChoi J) :
    globalSDPObjective (globalConcreteRawPerformanceOperator
        (x := x) gamma) J ≤
      globalOptimalGain (Fintype.card x : ℝ) gamma := by
  rw [globalConcreteRawPerformanceOperator_eq_sector hcard]
  exact globalConcreteSector_SDP_upper_bound hcard hgamma0 hgamma1 hJ

/-- The candidate also attains `G⋆` when the objective is written in its raw
Haar/contraction form. -/
theorem globalOptimalChoi_raw_objective_eq_globalOptimalGain
    {x : Type*} [Fintype x] [DecidableEq x]
    {gamma : ℝ} (hcard : 4 ≤ (Fintype.card x : ℝ)) :
    globalSDPObjective (globalConcreteRawPerformanceOperator
        (x := x) gamma) globalOptimalChoi =
      globalOptimalGain (Fintype.card x : ℝ) gamma := by
  rw [globalConcreteRawPerformanceOperator_eq_sector hcard]
  exact globalOptimalChoi_objective_eq_globalOptimalGain hcard

/-- The displayed dual matrix is feasible for the raw concrete SDP. -/
theorem globalConcreteDualCandidate_feasible
    {x : Type*} [Fintype x] [DecidableEq x]
    {gamma : ℝ} (hcard : 4 ≤ (Fintype.card x : ℝ))
    (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) :
    IsGlobalCPTNDual (globalConcreteRawPerformanceOperator
        (x := x) gamma) (globalConcreteDualCandidate (x := x) gamma) := by
  rw [globalConcreteRawPerformanceOperator_eq_sector hcard]
  apply globalSectorDualCandidate_feasible hcard hgamma0 hgamma1
      globalPWMinus_posSemidef globalPLPlus_posSemidef
      (globalPLMinus_posSemidef (by
        have hfour : 4 ≤ Fintype.card x := by exact_mod_cast hcard
        omega))
      globalInputPairPSym_posSemidef
      globalPWPlus_le_inputPairPSym_kronecker_one

/-- The trace of the concrete dual certificate is exactly `G⋆`. -/
theorem globalConcreteDualCandidate_trace_eq_globalOptimalGain
    {x : Type*} [Fintype x] [DecidableEq x]
    {gamma : ℝ} (hcard : 4 ≤ (Fintype.card x : ℝ)) :
    (globalConcreteDualCandidate (x := x) gamma).trace.re =
      globalOptimalGain (Fintype.card x : ℝ) gamma := by
  exact globalSectorDualCandidate_trace_eq_optimalGain
    hcard globalInputPairPSym_trace_re

/-- Explicit matching primal/dual certificates for the concrete raw SDP. -/
theorem globalConcreteRaw_matching_primal_dual
    {x : Type*} [Fintype x] [DecidableEq x]
    {gamma : ℝ} (hcard : 4 ≤ (Fintype.card x : ℝ))
    (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) :
    IsGlobalCPTNChoi (globalOptimalChoi (x := x)) ∧
      IsGlobalCPTNDual (globalConcreteRawPerformanceOperator
        (x := x) gamma) (globalConcreteDualCandidate (x := x) gamma) ∧
      globalSDPObjective (globalConcreteRawPerformanceOperator
          (x := x) gamma) globalOptimalChoi =
        (globalConcreteDualCandidate (x := x) gamma).trace.re := by
  refine ⟨globalOptimalChoi_isGlobalCPTNChoi,
    globalConcreteDualCandidate_feasible hcard hgamma0 hgamma1, ?_⟩
  rw [globalOptimalChoi_raw_objective_eq_globalOptimalGain hcard,
    globalConcreteDualCandidate_trace_eq_globalOptimalGain hcard]

/-- Equality in the global SDP occurs exactly at the displayed Choi matrix.
This is the concrete uniqueness statement corresponding to the last part of
`lem:general_d_global_optimum`. -/
theorem globalConcreteRaw_objective_eq_optimalGain_iff
    {x : Type*} [Fintype x] [DecidableEq x]
    {gamma : ℝ} (hcard : 4 ≤ (Fintype.card x : ℝ))
    (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    {J : CMatrix (GlobalThreeLeg x)} (hJ : IsGlobalCPTNChoi J) :
    globalSDPObjective (globalConcreteRawPerformanceOperator
        (x := x) gamma) J =
        globalOptimalGain (Fintype.card x : ℝ) gamma ↔
      J = globalOptimalChoi (x := x) := by
  have hfourNat : 4 ≤ Fintype.card x := by exact_mod_cast hcard
  have htwoNat : 2 ≤ Fintype.card x := by omega
  constructor
  · intro hoptimalRaw
    have hoptimalSector :
        globalSDPObjective (globalConcreteSectorPerformanceOperator
            (x := x) gamma) J =
          globalOptimalGain (Fintype.card x : ℝ) gamma := by
      rw [← globalConcreteRawPerformanceOperator_eq_sector hcard]
      exact hoptimalRaw
    have hsupport := global_four_sector_optimizer_support
      hcard hgamma0 hgamma1
      globalPWPlus_posSemidef globalPWMinus_posSemidef
      globalPLPlus_posSemidef (globalPLMinus_posSemidef htwoNat)
      globalPWPlus_idempotent (globalPWMinus_idempotent htwoNat)
      globalPLPlus_idempotent (globalPLMinus_idempotent htwoNat)
      (global_four_projectors_pairwise htwoNat)
      global_four_projectors_sum
      globalInputPairPSym_posSemidef
      globalPWPlus_le_inputPairPSym_kronecker_one
      globalInputPairPSym_trace_re hJ hoptimalSector
    let A : CMatrix x :=
      Matrix.conjTranspose globalWPlus * J * globalWPlus
    have hA : A.PosSemidef := by
      exact hJ.1.conjTranspose_mul_mul_same globalWPlus
    have hWAJ :
        globalWPlus * A * Matrix.conjTranspose globalWPlus = J := by
      calc
        globalWPlus * A * Matrix.conjTranspose globalWPlus =
            globalPWPlus * J * globalPWPlus := by
          simp only [A, globalPWPlus, Matrix.mul_assoc]
        _ = J := hsupport.2.symm
    have hcompression :
        A ≤ (((Fintype.card x : ℝ) + 1) / 2) • (1 : CMatrix x) := by
      apply globalWPlus_compression_le hA
      rw [hWAJ]
      exact hJ.2
    have hmass :
        (((globalWPlus * Matrix.conjTranspose globalWPlus) * J).trace).re =
          (((Fintype.card x : ℝ) + 1) / 2) *
            (Fintype.card x : ℝ) := by
      change globalSectorMass (globalPWPlus (x := x)) J =
        (((Fintype.card x : ℝ) + 1) / 2) *
          (Fintype.card x : ℝ)
      rw [hsupport.1]
      simp only [inputSymmetricDimension]
      ring
    have hunique :=
      supported_psd_eq_scaled_rangeProjection_of_compression_bound
        (D := (Fintype.card x : ℝ))
        (c := ((Fintype.card x : ℝ) + 1) / 2)
        (W := globalWPlus) (J := J)
        rfl globalWPlus_conjTranspose_mul_self hJ.1 hsupport.2
        hcompression hmass
    simpa only [globalOptimalChoi, globalPWPlus] using hunique
  · intro hJstar
    subst J
    exact globalOptimalChoi_raw_objective_eq_globalOptimalGain hcard

/-- Complete finite-matrix statement: the candidate is feasible, has the
paper's value, bounds every feasible point, and is the unique optimizer. -/
theorem globalConcreteRaw_optimal_and_unique
    {x : Type*} [Fintype x] [DecidableEq x]
    {gamma : ℝ} (hcard : 4 ≤ (Fintype.card x : ℝ))
    (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) :
    IsGlobalCPTNChoi (globalOptimalChoi (x := x)) ∧
      globalSDPObjective (globalConcreteRawPerformanceOperator
          (x := x) gamma) globalOptimalChoi =
        globalOptimalGain (Fintype.card x : ℝ) gamma ∧
      (∀ J : CMatrix (GlobalThreeLeg x), IsGlobalCPTNChoi J →
        globalSDPObjective (globalConcreteRawPerformanceOperator
            (x := x) gamma) J ≤
          globalOptimalGain (Fintype.card x : ℝ) gamma) ∧
      (∀ J : CMatrix (GlobalThreeLeg x), IsGlobalCPTNChoi J →
        (globalSDPObjective (globalConcreteRawPerformanceOperator
              (x := x) gamma) J =
            globalOptimalGain (Fintype.card x : ℝ) gamma ↔
          J = globalOptimalChoi (x := x))) := by
  refine ⟨globalOptimalChoi_isGlobalCPTNChoi,
    globalOptimalChoi_raw_objective_eq_globalOptimalGain hcard, ?_, ?_⟩
  · intro J hJ
    exact globalConcreteRaw_SDP_upper_bound hcard hgamma0 hgamma1 hJ
  · intro J hJ
    exact globalConcreteRaw_objective_eq_optimalGain_iff
      hcard hgamma0 hgamma1 hJ

end

end EntanglementPurification
