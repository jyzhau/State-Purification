import EntanglementPurification.FullUnitaryCommutant
import EntanglementPurification.JointContractionCompression

/-!
# Schur coefficient of the joint contraction pullback

This module turns the joint-coordinate commutant relation into the unique
factorization

`G† K G = K_(M_AB R) ⊗ I_(A × B)`.

The factorization is derived from the concrete full-unitary commutant theorem;
it is not included as an assumption.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b r : Type*}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

@[simp]
theorem localEntrywiseConjugate_map_star
    (U : Matrix.unitaryGroup a ℂ) :
    localEntrywiseConjugate (Matrix.UnitaryGroup.map_star U) =
      (U : CMatrix a) := by
  ext i j
  simp [localEntrywiseConjugate, Matrix.UnitaryGroup.map_star]

@[simp]
theorem localEntrywiseConjugate_inv
    (U : Matrix.unitaryGroup a ℂ) :
    localEntrywiseConjugate U⁻¹ =
      Matrix.conjTranspose (localEntrywiseConjugate U) := by
  ext i j
  simp [localEntrywiseConjugate, Matrix.conjTranspose_apply]

@[simp]
theorem localMixedSchurRepresentation_inv
    (U : Matrix.unitaryGroup a ℂ) :
    localMixedSchurRepresentation U⁻¹ =
      Matrix.conjTranspose (localMixedSchurRepresentation U) := by
  ext ⟨⟨i₁, i₂⟩, i₃⟩ ⟨⟨j₁, j₂⟩, j₃⟩
  simp [localMixedSchurRepresentation, localEntrywiseConjugate,
    Matrix.kronecker, Matrix.conjTranspose_apply,
    Matrix.star_eq_conjTranspose]

@[simp]
theorem jointContractionPhysicalRepresentation_inv
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    jointContractionPhysicalRepresentation (r := r) U⁻¹ V⁻¹ =
      Matrix.conjTranspose
        (jointContractionPhysicalRepresentation (r := r) U V) := by
  simp [jointContractionPhysicalRepresentation,
    Matrix.conjTranspose_kronecker]

@[simp]
theorem jointContractionCoordinateRepresentation_inv
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    jointContractionCoordinateRepresentation (r := r) U⁻¹ V⁻¹ =
      Matrix.conjTranspose
        (jointContractionCoordinateRepresentation (r := r) U V) := by
  rw [jointContractionCoordinateRepresentation_eq,
    jointContractionCoordinateRepresentation_eq]
  simp [Matrix.conjTranspose_kronecker]

/-- Entrywise conjugation preserves unitarity.  We record the right-unitary
identity in the concrete matrix form needed below. -/
theorem localEntrywiseConjugate_mul_conjTranspose
    (U : Matrix.unitaryGroup a ℂ) :
    localEntrywiseConjugate U *
        Matrix.conjTranspose (localEntrywiseConjugate U) =
      (1 : CMatrix a) := by
  change (↑(Matrix.UnitaryGroup.map_star U) : CMatrix a) *
      Matrix.conjTranspose
        (↑(Matrix.UnitaryGroup.map_star U) : CMatrix a) = 1
  simpa [Matrix.star_eq_conjTranspose] using
    (Matrix.mem_unitaryGroup_iff.mp
      (SetLike.coe_mem (Matrix.UnitaryGroup.map_star U)))

/-- The coordinate action I tensor (bar U tensor bar V) is unitary. -/
theorem jointContractionCoordinateRepresentation_mul_conjTranspose
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    jointContractionCoordinateRepresentation (r := r) U V *
        Matrix.conjTranspose
          (jointContractionCoordinateRepresentation (r := r) U V) =
      (1 : CMatrix (JointContractionCoordinateIndex a b r)) := by
  rw [jointContractionCoordinateRepresentation_eq]
  have hOne :
      (1 : CMatrix (LocalMultiplicitySector × r)) ∈
        Matrix.unitaryGroup (LocalMultiplicitySector × r) ℂ := by
    exact SetLike.coe_mem
      (1 : Matrix.unitaryGroup (LocalMultiplicitySector × r) ℂ)
  have hU :
      localEntrywiseConjugate U ∈ Matrix.unitaryGroup a ℂ := by
    change (↑(Matrix.UnitaryGroup.map_star U) : CMatrix a) ∈
      Matrix.unitaryGroup a ℂ
    exact SetLike.coe_mem (Matrix.UnitaryGroup.map_star U)
  have hV :
      localEntrywiseConjugate V ∈ Matrix.unitaryGroup b ℂ := by
    change (↑(Matrix.UnitaryGroup.map_star V) : CMatrix b) ∈
      Matrix.unitaryGroup b ℂ
    exact SetLike.coe_mem (Matrix.UnitaryGroup.map_star V)
  have hUnitary :=
    Matrix.kronecker_mem_unitary hOne
      (Matrix.kronecker_mem_unitary hU hV)
  simpa [Matrix.star_eq_conjTranspose] using
    (Matrix.mem_unitaryGroup_iff.mp hUnitary)

/-- Paper-form local-unitary invariance of a physical joint operator:
P(U,V) K P(U,V) adjoint = K for every independent pair of local unitaries. -/
def JointContractionPhysicalInvariant
    (K : CMatrix (JointContractionPhysicalIndex a b r)) : Prop :=
  ∀ (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ),
    jointContractionPhysicalRepresentation (r := r) U V * K *
        Matrix.conjTranspose
          (jointContractionPhysicalRepresentation (r := r) U V) =
      K

/-- Physical conjugation invariance descends through the intertwining
isometry to conjugation invariance of the contraction pullback. -/
theorem jointContractionPullback_coordinate_conjugationInvariant
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K)
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    Matrix.conjTranspose
          (jointContractionCoordinateRepresentation (r := r) U V) *
        jointContractionPullback K *
        jointContractionCoordinateRepresentation (r := r) U V =
      jointContractionPullback K := by
  have hAdjoint :
      Matrix.conjTranspose
            (jointContractionCoordinateRepresentation (r := r) U V) *
          Matrix.conjTranspose
            (jointContractionIsometry (a := a) (b := b) (r := r)) =
        Matrix.conjTranspose
            (jointContractionIsometry (a := a) (b := b) (r := r)) *
          Matrix.conjTranspose
            (jointContractionPhysicalRepresentation (r := r) U V) := by
    simpa only [Matrix.conjTranspose_mul] using
      congrArg Matrix.conjTranspose
        (jointContractionIsometry_intertwines
          (r := r) U V).symm
  have hInverseInvariant :
      Matrix.conjTranspose
            (jointContractionPhysicalRepresentation (r := r) U V) *
          K *
          jointContractionPhysicalRepresentation (r := r) U V =
        K := by
    simpa only [jointContractionPhysicalRepresentation_inv,
      Matrix.conjTranspose_conjTranspose] using
        hInvariant U⁻¹ V⁻¹
  unfold jointContractionPullback
  calc
    Matrix.conjTranspose
          (jointContractionCoordinateRepresentation (r := r) U V) *
        (Matrix.conjTranspose
            (jointContractionIsometry (a := a) (b := b) (r := r)) * K *
          jointContractionIsometry (a := a) (b := b) (r := r)) *
        jointContractionCoordinateRepresentation (r := r) U V =
      (Matrix.conjTranspose
          (jointContractionCoordinateRepresentation (r := r) U V) *
        Matrix.conjTranspose
          (jointContractionIsometry (a := a) (b := b) (r := r))) *
        K *
        (jointContractionIsometry (a := a) (b := b) (r := r) *
          jointContractionCoordinateRepresentation (r := r) U V) := by
            simp only [Matrix.mul_assoc]
    _ =
      (Matrix.conjTranspose
          (jointContractionIsometry (a := a) (b := b) (r := r)) *
        Matrix.conjTranspose
          (jointContractionPhysicalRepresentation (r := r) U V)) *
        K *
        (jointContractionPhysicalRepresentation (r := r) U V *
          jointContractionIsometry (a := a) (b := b) (r := r)) := by
            rw [hAdjoint,
              ← jointContractionIsometry_intertwines (r := r) U V]
    _ = Matrix.conjTranspose
          (jointContractionIsometry (a := a) (b := b) (r := r)) *
        (Matrix.conjTranspose
            (jointContractionPhysicalRepresentation (r := r) U V) *
          K *
          jointContractionPhysicalRepresentation (r := r) U V) *
        jointContractionIsometry (a := a) (b := b) (r := r) := by
            simp only [Matrix.mul_assoc]
    _ = Matrix.conjTranspose
          (jointContractionIsometry (a := a) (b := b) (r := r)) * K *
        jointContractionIsometry (a := a) (b := b) (r := r) := by
            rw [hInverseInvariant]

/-- Commutant form of local invariance after pulling a physical operator into
the joint contraction coordinates. -/
def JointContractionCoordinateCommutant
    (K : CMatrix (JointContractionPhysicalIndex a b r)) : Prop :=
  ∀ (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ),
    jointContractionPullback K *
        jointContractionCoordinateRepresentation (r := r) U V =
      jointContractionCoordinateRepresentation (r := r) U V *
        jointContractionPullback K

/-- Therefore the physically invariant pullback lies in the coordinate
commutant.  This is the bridge from the paper's twirl-invariance equation to
the hypothesis of the finite-matrix Schur lemma. -/
theorem jointContractionCoordinateCommutant_of_physicalInvariant
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K) :
    JointContractionCoordinateCommutant K := by
  intro U V
  have hConj :=
    jointContractionPullback_coordinate_conjugationInvariant
      hInvariant U V
  have hUnit :=
    jointContractionCoordinateRepresentation_mul_conjTranspose
      (r := r) U V
  calc
    jointContractionPullback K *
        jointContractionCoordinateRepresentation (r := r) U V =
      (jointContractionCoordinateRepresentation (r := r) U V *
          Matrix.conjTranspose
            (jointContractionCoordinateRepresentation (r := r) U V)) *
        jointContractionPullback K *
        jointContractionCoordinateRepresentation (r := r) U V := by
          rw [hUnit, Matrix.one_mul]
    _ = jointContractionCoordinateRepresentation (r := r) U V *
        (Matrix.conjTranspose
            (jointContractionCoordinateRepresentation (r := r) U V) *
          jointContractionPullback K *
          jointContractionCoordinateRepresentation (r := r) U V) := by
            simp only [Matrix.mul_assoc]
    _ = jointContractionCoordinateRepresentation (r := r) U V *
        jointContractionPullback K := by
          rw [hConj]

/-- The unique coefficient `K_(M_AB R)` in the contraction pullback. -/
def jointContractionSchurCoefficient
    [Nonempty a] [Nonempty b]
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    CMatrix (LocalMultiplicitySector × r) :=
  productUnitaryCommutantCoefficient (jointContractionPullback K)

/-- Equations 2459--2487 of `main.tex`: the coordinate commutant relation
forces the contraction pullback to be the Schur coefficient tensored with the
identity on the irreducible Alice--Bob coordinate factor. -/
theorem jointContractionPullback_eq_schurCoefficient_kronecker_one
    [Nonempty a] [Nonempty b]
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (hcomm : JointContractionCoordinateCommutant K) :
    jointContractionPullback K =
      Matrix.kronecker (jointContractionSchurCoefficient K)
        (1 : CMatrix (a × b)) := by
  apply productUnitaryCommutant_eq_kronecker_coefficient
  intro U V
  have h := hcomm (Matrix.UnitaryGroup.map_star U)
    (Matrix.UnitaryGroup.map_star V)
  rw [jointContractionCoordinateRepresentation_eq] at h
  simpa using h

/-- Main physical endpoint for this part of task D.  The paper's local-twirl
invariance equation alone forces the compressed contraction block to have
the Schur form coefficient tensor identity; that form is not assumed. -/
theorem jointContractionPullback_eq_schurCoefficient_kronecker_one_of_physicalInvariant
    [Nonempty a] [Nonempty b]
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (hInvariant : JointContractionPhysicalInvariant K) :
    jointContractionPullback K =
      Matrix.kronecker (jointContractionSchurCoefficient K)
        (1 : CMatrix (a × b)) := by
  exact jointContractionPullback_eq_schurCoefficient_kronecker_one K
    (jointContractionCoordinateCommutant_of_physicalInvariant hInvariant)

/-- The coefficient in the preceding factorization is unique. -/
theorem jointContractionSchurCoefficient_unique
    [Nonempty a] [Nonempty b]
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (A : CMatrix (LocalMultiplicitySector × r))
    (hA : jointContractionPullback K =
      Matrix.kronecker A (1 : CMatrix (a × b))) :
    A = jointContractionSchurCoefficient K := by
  exact productUnitaryCommutant_coefficient_unique
    (jointContractionPullback K) A hA

/-- Physical positivity passes first through the isometric pullback and then
to the unique Schur coefficient. -/
theorem jointContractionSchurCoefficient_posSemidef
    [Nonempty a] [Nonempty b]
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hK : K.PosSemidef) :
    (jointContractionSchurCoefficient K).PosSemidef := by
  exact productUnitaryCommutantCoefficient_posSemidef
    (jointContractionPullback_posSemidef hK)

end

end EntanglementPurification
