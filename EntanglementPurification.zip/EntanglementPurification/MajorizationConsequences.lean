import EntanglementPurification.FiniteMajorization
import EntanglementPurification.ScalarBounds
import Mathlib.Algebra.BigOperators.Module
import Mathlib.Tactic

/-!
# Direct consequences of the comparison spectra

This module records the elementary probability and collision-probability
consequences used after the finite majorization step.  It deliberately does
not appeal to a general Karamata theorem: every quadratic estimate below is
proved directly from the stated coordinate bounds.
-/

namespace EntanglementPurification

noncomputable section

open scoped BigOperators

/-- Collision probability (the squared `ℓ²` norm) of a finite real vector. -/
def collisionProbability {n : ℕ} (p : Fin n → ℝ) : ℝ :=
  ((List.ofFn p).map fun x => x ^ 2).sum

/-- Append `r` zero coordinates to a finite vector. -/
def zeroPad {n : ℕ} (r : ℕ) (p : Fin n → ℝ) : Fin (n + r) → ℝ :=
  Fin.append p (fun _ => 0)

@[simp]
theorem list_ofFn_zeroPad {n : ℕ} (r : ℕ) (p : Fin n → ℝ) :
    List.ofFn (zeroPad r p) = List.ofFn p ++ List.replicate r 0 := by
  simp [zeroPad]

@[simp]
theorem zeroPad_total {n : ℕ} (r : ℕ) (p : Fin n → ℝ) :
    (List.ofFn (zeroPad r p)).sum = (List.ofFn p).sum := by
  simp

@[simp]
theorem collisionProbability_zeroPad {n : ℕ} (r : ℕ) (p : Fin n → ℝ) :
    collisionProbability (zeroPad r p) = collisionProbability p := by
  simp [collisionProbability]

@[simp]
theorem orderedPrefixSum_zeroPad {n : ℕ} (r : ℕ) (p : Fin n → ℝ) (k : ℕ) :
    orderedPrefixSum (zeroPad r p) k = orderedPrefixSum p k := by
  simp [orderedPrefixSum, List.take_append]

/-- Explicit ordered-prefix majorization is stable under common zero padding. -/
theorem prefixMajorizedBy_zeroPad {n : ℕ} {p q : Fin n → ℝ}
    (h : PrefixMajorizedBy p q) (r : ℕ) :
    PrefixMajorizedBy (zeroPad r p) (zeroPad r q) := by
  constructor
  · intro k
    simpa using h.1 k
  · simpa using h.2

/-- A reusable list estimate: if every entry lies in `[0,c]`, then the sum of
its squares is at most `c` times its sum. -/
theorem list_sum_sq_le_mul_sum_of_nonneg_le
    {l : List ℝ} {c : ℝ}
    (h : ∀ x ∈ l, 0 ≤ x ∧ x ≤ c) :
    (l.map fun x => x ^ 2).sum ≤ c * l.sum := by
  induction l with
  | nil => simp
  | cons a l ih =>
      have ha : 0 ≤ a ∧ a ≤ c := h a (by simp)
      have hl : ∀ x ∈ l, 0 ≤ x ∧ x ≤ c := by
        intro x hx
        exact h x (by simp [hx])
      have htail := ih hl
      have haSq : a ^ 2 ≤ c * a := by
        nlinarith
      simp only [List.map_cons, List.sum_cons]
      linarith

/-- Quadratic Abel lemma for finite prefixes.  This is the precise special
case of convexity needed for collision probability: if all prefix sums of
`p` are bounded by those of `q`, the totals agree, and `p+q` is
nonincreasing, then the squared sum of `p` is bounded by that of `q`.

The statement uses `ℕ`-indexed finite ranges so it is also reusable outside
the `Fin` representation of spectra. -/
theorem sum_range_sq_le_sum_range_sq_of_prefix
    (n : ℕ) (p q : ℕ → ℝ)
    (hprefix : ∀ k, k ≤ n →
      ∑ i ∈ Finset.range k, p i ≤ ∑ i ∈ Finset.range k, q i)
    (htotal : (∑ i ∈ Finset.range n, p i) =
      ∑ i ∈ Finset.range n, q i)
    (hweight : ∀ i, i + 1 < n →
      q (i + 1) + p (i + 1) ≤ q i + p i) :
    (∑ i ∈ Finset.range n, p i ^ 2) ≤
      ∑ i ∈ Finset.range n, q i ^ 2 := by
  let w : ℕ → ℝ := fun i => q i + p i
  let d : ℕ → ℝ := fun i => q i - p i
  have hpartial : ∀ k, k ≤ n →
      0 ≤ ∑ i ∈ Finset.range k, d i := by
    intro k hk
    rw [Finset.sum_sub_distrib]
    exact sub_nonneg.mpr (hprefix k hk)
  have htotalDiff : (∑ i ∈ Finset.range n, d i) = 0 := by
    rw [Finset.sum_sub_distrib, htotal, sub_self]
  have htermSum :
      (∑ i ∈ Finset.range (n - 1),
        (w (i + 1) - w i) * (∑ j ∈ Finset.range (i + 1), d j)) ≤ 0 := by
    apply Finset.sum_nonpos
    intro i hi
    have hiLt : i + 1 < n := by
      have := Finset.mem_range.mp hi
      omega
    have hdiff : w (i + 1) - w i ≤ 0 := by
      apply sub_nonpos.mpr
      exact hweight i hiLt
    have hsum : 0 ≤ ∑ j ∈ Finset.range (i + 1), d j :=
      hpartial (i + 1) (by omega)
    exact mul_nonpos_of_nonpos_of_nonneg hdiff hsum
  have hparts := Finset.sum_range_by_parts w d n
  simp only [smul_eq_mul] at hparts
  rw [htotalDiff, mul_zero, zero_sub] at hparts
  have hwd : 0 ≤ ∑ i ∈ Finset.range n, w i * d i := by
    rw [hparts]
    exact neg_nonneg.mpr htermSum
  have hsqDiff :
      (∑ i ∈ Finset.range n, w i * d i) =
        (∑ i ∈ Finset.range n, q i ^ 2) -
          ∑ i ∈ Finset.range n, p i ^ 2 := by
    rw [← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro i hi
    dsimp [w, d]
    ring
  rw [hsqDiff] at hwd
  exact sub_nonneg.mp hwd

/-- Extend a `Fin n` vector by zeros to a sequence on `ℕ`. -/
def finNatEntry {n : ℕ} (p : Fin n → ℝ) (i : ℕ) : ℝ :=
  if hi : i < n then p ⟨i, hi⟩ else 0

theorem sum_range_finNatEntry_eq_orderedPrefixSum
    {n k : ℕ} (p : Fin n → ℝ) (hk : k ≤ n) :
    (∑ i ∈ Finset.range k, finNatEntry p i) = orderedPrefixSum p k := by
  rw [← Fin.sum_univ_eq_sum_range, orderedPrefixSum, List.sum_take_ofFn]
  let e : Fin k ≃ {j : Fin n // j.val < k} :=
    { toFun := fun i => ⟨Fin.castLE hk i, i.isLt⟩
      invFun := fun j => ⟨j.1.val, j.2⟩
      left_inv := by
        intro i
        apply Fin.ext
        rfl
      right_inv := by
        intro j
        apply Subtype.ext
        apply Fin.ext
        rfl }
  calc
    (∑ i : Fin k, finNatEntry p i.val) =
        ∑ i : Fin k, p (Fin.castLE hk i) := by
      apply Finset.sum_congr rfl
      intro i hi
      simp [finNatEntry, Fin.castLE, lt_of_lt_of_le i.isLt hk]
    _ = ∑ j : {j : Fin n // j.val < k}, p j.1 := by
      apply Fintype.sum_equiv e
      intro i
      rfl
    _ = ∑ j : Fin n with j.val < k, p j := by
      symm
      exact Finset.sum_subtype _ (by intro j; simp) p

@[simp]
theorem sum_range_finNatEntry_sq_eq_collisionProbability
    {n : ℕ} (p : Fin n → ℝ) :
    (∑ i ∈ Finset.range n, (finNatEntry p i) ^ 2) =
      collisionProbability p := by
  rw [← Fin.sum_univ_eq_sum_range]
  simp only [collisionProbability, List.map_ofFn, List.sum_ofFn,
    Function.comp_apply]
  apply Finset.sum_congr rfl
  intro i hi
  simp [finNatEntry, i.isLt]

/-- For vectors already written in nonincreasing order, explicit prefix
majorization controls collision probability.  This is proved from the
quadratic Abel lemma above, not from an assumed Karamata result. -/
theorem collisionProbability_le_of_prefixMajorizedBy
    {n : ℕ} {p q : Fin n → ℝ}
    (hp : Antitone p) (hq : Antitone q)
    (hpq : PrefixMajorizedBy p q) :
    collisionProbability p ≤ collisionProbability q := by
  have hprefix : ∀ k, k ≤ n →
      (∑ i ∈ Finset.range k, finNatEntry p i) ≤
        ∑ i ∈ Finset.range k, finNatEntry q i := by
    intro k hk
    rw [sum_range_finNatEntry_eq_orderedPrefixSum p hk,
      sum_range_finNatEntry_eq_orderedPrefixSum q hk]
    exact hpq.1 k
  have htotal :
      (∑ i ∈ Finset.range n, finNatEntry p i) =
        ∑ i ∈ Finset.range n, finNatEntry q i := by
    have hpFull : orderedPrefixSum p n = (List.ofFn p).sum := by
      unfold orderedPrefixSum
      rw [List.take_of_length_le (by simp)]
    have hqFull : orderedPrefixSum q n = (List.ofFn q).sum := by
      unfold orderedPrefixSum
      rw [List.take_of_length_le (by simp)]
    rw [sum_range_finNatEntry_eq_orderedPrefixSum p le_rfl,
      sum_range_finNatEntry_eq_orderedPrefixSum q le_rfl, hpFull, hqFull]
    exact hpq.2
  have hweight : ∀ i, i + 1 < n →
      finNatEntry q (i + 1) + finNatEntry p (i + 1) ≤
        finNatEntry q i + finNatEntry p i := by
    intro i hi
    have hi0 : i < n := by omega
    have hfin : (⟨i, hi0⟩ : Fin n) ≤ ⟨i + 1, hi⟩ := by
      simp
    have hq' := hq hfin
    have hp' := hp hfin
    simp only [finNatEntry, dif_pos hi, dif_pos hi0]
    exact add_le_add hq' hp'
  have hsquare := sum_range_sq_le_sum_range_sq_of_prefix n
    (finNatEntry p) (finNatEntry q) hprefix htotal hweight
  rwa [sum_range_finNatEntry_sq_eq_collisionProbability,
    sum_range_finNatEntry_sq_eq_collisionProbability] at hsquare

/-- If every coordinate of a probability vector is at most `1/2`, its
collision probability is at most `1/2`. -/
theorem collisionProbability_le_half_of_probability_of_forall_le
    {n : ℕ} {p : Fin n → ℝ}
    (hnonneg : ∀ i, 0 ≤ p i)
    (htotal : (List.ofFn p).sum = 1)
    (hhalf : ∀ i, p i ≤ 1 / 2) :
    collisionProbability p ≤ 1 / 2 := by
  have hlist : ∀ x ∈ List.ofFn p, 0 ≤ x ∧ x ≤ (1 / 2 : ℝ) := by
    intro x hx
    rcases List.mem_ofFn.mp hx with ⟨i, rfl⟩
    exact ⟨hnonneg i, hhalf i⟩
  have hs := list_sum_sq_le_mul_sum_of_nonneg_le hlist
  rw [htotal, mul_one] at hs
  exact hs

/-- The small-head branch of the paper's purity bound, proved directly and
without any convex-majorization theorem. -/
theorem collisionProbability_le_half_of_ordered_head_le
    {m : ℕ} {p : Fin (m + 2) → ℝ}
    (hp : IsOrderedProbability p) (hhead : p 0 ≤ 1 / 2) :
    collisionProbability p ≤ 1 / 2 := by
  apply collisionProbability_le_half_of_probability_of_forall_le hp.2.1 hp.2.2
  intro i
  exact (hp.1 (Fin.zero_le i)).trans hhead

/-- The two-point endpoint is itself a nonincreasing probability vector. -/
theorem twoPointComparison_isOrderedProbability (m : ℕ) :
    IsOrderedProbability (twoPointComparison m) := by
  refine ⟨?_, ?_, twoPointComparison_total m⟩
  · rw [← List.sortedGE_ofFn_iff]
    rw [List.sortedGE_iff_pairwise]
    simp [twoPointComparison]
  · intro i
    refine Fin.cases (by simp [twoPointComparison]) ?_ i
    intro i
    refine Fin.cases (by simp [twoPointComparison]) ?_ i
    intro i
    simp [twoPointComparison]

@[simp]
theorem collisionProbability_twoPointComparison (m : ℕ) :
    collisionProbability (twoPointComparison m) = 1 / 2 := by
  simp [collisionProbability, twoPointComparison]
  norm_num

/-- On the relevant interval, the zero-padded three-point endpoint is itself
a nonincreasing probability vector. -/
theorem threePointComparison_isOrderedProbability_on_interval
    (m : ℕ) {x : ℝ} (hxLower : (1 / 2 : ℝ) ≤ x) (hxUpper : x ≤ 2 / 3) :
    IsOrderedProbability (threePointComparison m x (zStar x)) := by
  have hcert := boundary_spectrum_is_probability_on_interval hxLower hxUpper
  have hzx : zStar x ≤ x := hcert.2.1.2.trans hcert.2.1.1
  refine ⟨?_, ?_, threePointComparison_total m x (zStar x)⟩
  · rw [← List.sortedGE_ofFn_iff]
    rw [List.sortedGE_iff_pairwise]
    simp [threePointComparison, hcert.1.1, hcert.1.2.1,
      hcert.1.2.2, hcert.2.1.1, hcert.2.1.2, hzx]
  · intro i
    refine Fin.cases hcert.1.1 ?_ i
    intro i
    refine Fin.cases hcert.1.2.1 ?_ i
    intro i
    refine Fin.cases hcert.1.2.2 ?_ i
    intro i
    simp [threePointComparison]

@[simp]
theorem collisionProbability_threePointComparison_on_interval
    (m : ℕ) {x : ℝ} (hxLower : (1 / 2 : ℝ) ≤ x) (hxUpper : x ≤ 2 / 3) :
    collisionProbability (threePointComparison m x (zStar x)) = 1 / 2 := by
  simp [collisionProbability, threePointComparison]
  simpa [add_assoc] using boundary_purity_half_on_interval hxLower hxUpper

/-- A direct endpoint theorem for the two-point branch. -/
theorem collisionProbability_le_half_of_prefixMajorizedBy_twoPoint
    {m : ℕ} {p : Fin (m + 2) → ℝ}
    (hp : IsOrderedProbability p)
    (hpref : PrefixMajorizedBy p (twoPointComparison m)) :
    collisionProbability p ≤ 1 / 2 := by
  calc
    collisionProbability p ≤ collisionProbability (twoPointComparison m) :=
      collisionProbability_le_of_prefixMajorizedBy hp.1
        (twoPointComparison_isOrderedProbability m).1 hpref
    _ = 1 / 2 := collisionProbability_twoPointComparison m

/-- A direct endpoint theorem for the boundary three-point branch. -/
theorem collisionProbability_le_half_of_prefixMajorizedBy_threePoint
    {m : ℕ} {p : Fin (m + 3) → ℝ} {x : ℝ}
    (hp : IsOrderedProbability p)
    (hxLower : (1 / 2 : ℝ) ≤ x) (hxUpper : x ≤ 2 / 3)
    (hpref : PrefixMajorizedBy p
      (threePointComparison m x (zStar x))) :
    collisionProbability p ≤ 1 / 2 := by
  calc
    collisionProbability p ≤
        collisionProbability (threePointComparison m x (zStar x)) :=
      collisionProbability_le_of_prefixMajorizedBy hp.1
        (threePointComparison_isOrderedProbability_on_interval
          m hxLower hxUpper).1 hpref
    _ = 1 / 2 :=
      collisionProbability_threePointComparison_on_interval m hxLower hxUpper

/-- Single callable consequence for the paper's two-case comparison argument
on a common `Fin (m+3)` ambient space. -/
theorem collisionProbability_le_half_of_two_or_three_point_branch
    {m : ℕ} {p : Fin (m + 3) → ℝ} {x : ℝ}
    (hp : IsOrderedProbability p)
    (hxLower : (1 / 2 : ℝ) ≤ x) (hxUpper : x ≤ 2 / 3)
    (hbranch :
      PrefixMajorizedBy p (twoPointComparison (m + 1)) ∨
      PrefixMajorizedBy p (threePointComparison m x (zStar x))) :
    collisionProbability p ≤ 1 / 2 := by
  rcases hbranch with htwo | hthree
  · exact collisionProbability_le_half_of_prefixMajorizedBy_twoPoint hp htwo
  · exact collisionProbability_le_half_of_prefixMajorizedBy_threePoint
      hp hxLower hxUpper hthree

/-- The paper's large-head branch, with the effect-derived tail inequality as
its only nontrivial spectral input. -/
theorem collisionProbability_le_half_of_zStar_tail_ge
    {m : ℕ} {p : Fin (m + 3) → ℝ}
    (hp : IsOrderedProbability p)
    (hxLower : (1 / 2 : ℝ) < p 0) (hxUpper : p 0 ≤ 2 / 3)
    (htail : zStar (p 0) ≤ tailFromTwo p) :
    collisionProbability p ≤ 1 / 2 := by
  apply collisionProbability_le_half_of_prefixMajorizedBy_threePoint
    hp (le_of_lt hxLower) hxUpper
  exact prefixMajorizedBy_zStar_of_tail_ge hp hxLower hxUpper htail

end

end EntanglementPurification
