import EntanglementPurification.PhysicalOperationalEntropyConverse
import QIT.Classical.Ensemble
import QIT.Symmetry.DeFinetti.RennerProjectors

/-!
# Finite-ensemble entanglement of formation

This file gives the finite-dimensional convex-roof object used in the mixed
resource corollary of `main.tex`.  An ensemble stores normalized pure vectors
directly, while its average is exposed through Lean-QIT's native `State` and
`Ensemble` APIs.

The infimum ranges over `Fin (n + 1)`, which is a canonical presentation of
every nonempty finite ensemble.  The lower-bound theorem deliberately asks
for one representing ensemble; in the paper this witness is the displayed
pure-state decomposition of the mixed resource.
-/

namespace EntanglementPurification

open QIT
open scoped NNReal ComplexOrder MatrixOrder

noncomputable section

universe u v w

/-- A finite probability ensemble whose members are normalized bipartite pure
states. -/
structure BipartitePureEnsemble (ι : Type u) (a : Type v) (b : Type w)
    [Fintype ι] [Fintype a] [DecidableEq a] [Fintype b] [DecidableEq b] where
  probs : ι → ℝ≥0
  weights_sum : (∑ i, probs i) = 1
  pure : ι → PureVector (a × b)

namespace BipartitePureEnsemble

variable {ι : Type u} {a : Type v} {b : Type w}
  [Fintype ι] [Fintype a] [DecidableEq a] [Fintype b] [DecidableEq b]

/-- Forget that the members of a pure ensemble came with pure vectors. -/
def toEnsemble (E : BipartitePureEnsemble ι a b) : Ensemble ι (a × b) where
  probs := E.probs
  weights_sum := E.weights_sum
  states i := (E.pure i).state

/-- Density state represented by the finite pure ensemble. -/
def averageState (E : BipartitePureEnsemble ι a b) : State (a × b) :=
  E.toEnsemble.averageState

@[simp]
theorem averageState_matrix (E : BipartitePureEnsemble ι a b) :
    E.averageState.matrix =
      ∑ i, (E.probs i) • (E.pure i).state.matrix := by
  rfl

/-- Average entropy of entanglement of a finite pure ensemble, in bits. -/
def averageEntanglement (E : BipartitePureEnsemble ι a b) : ℝ :=
  ∑ i, (E.probs i : ℝ) * (E.pure i).entanglementEntropy

/-- Ensemble probabilities are nonnegative as real numbers. -/
theorem prob_nonneg (E : BipartitePureEnsemble ι a b) (i : ι) :
    0 ≤ (E.probs i : ℝ) :=
  NNReal.coe_nonneg _

/-- The real-valued probabilities sum to one. -/
theorem sum_coe_probs (E : BipartitePureEnsemble ι a b) :
    (∑ i, (E.probs i : ℝ)) = 1 := by
  exact_mod_cast E.weights_sum

/-- Saturation of a finite affine upper bound: if every component value is at
most `G` and their probability average is exactly `G`, every positive-weight
component already equals `G`.  This is the elementary convexity step used in
the paper's mixed-resource necessity proof. -/
theorem component_eq_of_weighted_average_eq_upperBound
    [DecidableEq ι] (E : BipartitePureEnsemble ι a b)
    (value : ι → ℝ) (G : ℝ)
    (hupper : ∀ i, value i ≤ G)
    (haverage : (∑ i, (E.probs i : ℝ) * value i) = G)
    (i : ι) (hi : 0 < (E.probs i : ℝ)) :
    value i = G := by
  have hgapNonneg : ∀ j : ι,
      0 ≤ (E.probs j : ℝ) * (G - value j) := by
    intro j
    exact mul_nonneg (E.prob_nonneg j) (sub_nonneg.mpr (hupper j))
  have hgapSum :
      (∑ j, (E.probs j : ℝ) * (G - value j)) = 0 := by
    calc
      (∑ j, (E.probs j : ℝ) * (G - value j)) =
          ∑ j, (G * (E.probs j : ℝ) -
            (E.probs j : ℝ) * value j) := by
        apply Finset.sum_congr rfl
        intro j _
        ring
      _ = (∑ j, G * (E.probs j : ℝ)) -
            ∑ j, (E.probs j : ℝ) * value j :=
        by rw [Finset.sum_sub_distrib]
      _ = G * (∑ j, (E.probs j : ℝ)) -
            ∑ j, (E.probs j : ℝ) * value j := by
        rw [Finset.mul_sum]
      _ = 0 := by rw [E.sum_coe_probs, haverage]; ring
  have hzeroFunction :
      (fun j => (E.probs j : ℝ) * (G - value j)) = 0 :=
    (Fintype.sum_eq_zero_iff_of_nonneg hgapNonneg).mp hgapSum
  have hterm : (E.probs i : ℝ) * (G - value i) = 0 := by
    simpa using congrFun hzeroFunction i
  rcases mul_eq_zero.mp hterm with hprob | hvalue
  · exact False.elim (ne_of_gt hi hprob)
  · linarith

end BipartitePureEnsemble

variable {a : Type v} {b : Type w}
  [Fintype a] [DecidableEq a] [Fintype b] [DecidableEq b]

/-- All average entanglement costs of nonempty finite pure decompositions of
`omega`. -/
def finitePureDecompositionCosts (omega : State (a × b)) : Set ℝ :=
  {c | ∃ (n : ℕ) (E : BipartitePureEnsemble (Fin (n + 1)) a b),
      E.averageState = omega ∧ E.averageEntanglement = c}

/-- Finite-dimensional entanglement of formation, defined as the convex-roof
infimum over nonempty finite pure ensembles. -/
def finiteEntanglementOfFormation (omega : State (a × b)) : ℝ :=
  sInf (finitePureDecompositionCosts omega)

/-- A displayed finite pure decomposition makes the convex-roof cost set
nonempty. -/
theorem finitePureDecompositionCosts_nonempty_of_representation
    (omega : State (a × b)) {n : ℕ}
    (E : BipartitePureEnsemble (Fin (n + 1)) a b)
    (hE : E.averageState = omega) :
    (finitePureDecompositionCosts omega).Nonempty := by
  refine ⟨E.averageEntanglement, n, E, hE, rfl⟩

/-- Every finite-dimensional state has a nonempty finite pure-state
decomposition.  The witness is its spectral decomposition, relabeled by a
canonical nonempty `Fin (n + 1)` index. -/
theorem finitePureDecompositionCosts_nonempty
    (omega : State (a × b)) :
    (finitePureDecompositionCosts omega).Nonempty := by
  have hnonempty : Nonempty (a × b) := by
    by_contra h
    haveI : IsEmpty (a × b) := not_nonempty_iff.mp h
    have htrace := omega.trace_eq_one
    simp [Matrix.trace] at htrace
  let n : ℕ := Fintype.card (a × b) - 1
  have hcardpos : 0 < Fintype.card (a × b) :=
    Fintype.card_pos_iff.mpr hnonempty
  have hn : n + 1 = Fintype.card (a × b) := by
    dsimp [n]
    omega
  let e : Fin (n + 1) ≃ (a × b) :=
    (finCongr hn).trans (Fintype.equivFin (a × b)).symm
  let probs : Fin (n + 1) → ℝ≥0 := fun i =>
    ⟨(omega.pos.isHermitian.eigenvalues (e i) : ℝ), by
      exact omega.pos.eigenvalues_nonneg (e i)⟩
  have hprobs : (∑ i, probs i) = 1 := by
    apply NNReal.eq
    simp only [NNReal.coe_sum, NNReal.coe_one]
    dsimp [probs]
    calc
      (∑ i : Fin (n + 1),
          omega.pos.isHermitian.eigenvalues (e i)) =
          ∑ x : a × b, omega.pos.isHermitian.eigenvalues x := by
        exact Fintype.sum_equiv e _ _ (fun _ => rfl)
      _ = 1 := omega.sum_eigenvalues_eq_one
  let pure : Fin (n + 1) → PureVector (a × b) := fun i =>
    omega.spectralPureVector (e i)
  let E : BipartitePureEnsemble (Fin (n + 1)) a b :=
    { probs := probs
      weights_sum := hprobs
      pure := pure }
  apply finitePureDecompositionCosts_nonempty_of_representation omega E
  apply State.ext
  rw [BipartitePureEnsemble.averageState_matrix,
    omega.matrix_eq_sum_spectralPureVector]
  apply Fintype.sum_equiv e
  intro i
  dsimp [E, probs, pure]
  ext p q
  rfl

/-- If every finite pure decomposition of `omega` costs at least `L`, then so
does its finite convex roof. -/
theorem le_finiteEntanglementOfFormation_of_all_decompositions
    (omega : State (a × b)) (L : ℝ)
    (hnonempty : (finitePureDecompositionCosts omega).Nonempty)
    (hlower : ∀ (n : ℕ) (E : BipartitePureEnsemble (Fin (n + 1)) a b),
      E.averageState = omega → L ≤ E.averageEntanglement) :
    L ≤ finiteEntanglementOfFormation omega := by
  apply le_csInf hnonempty
  intro c hc
  rcases hc with ⟨n, E, hE, rfl⟩
  exact hlower n E hE

/-- Paper-facing one-ebit specialization of the preceding convex-roof lemma. -/
theorem one_le_finiteEntanglementOfFormation_of_all_decompositions
    (omega : State (a × b))
    (hnonempty : (finitePureDecompositionCosts omega).Nonempty)
    (hlower : ∀ (n : ℕ) (E : BipartitePureEnsemble (Fin (n + 1)) a b),
      E.averageState = omega → 1 ≤ E.averageEntanglement) :
    1 ≤ finiteEntanglementOfFormation omega :=
  le_finiteEntanglementOfFormation_of_all_decompositions omega 1 hnonempty hlower

end

end EntanglementPurification
