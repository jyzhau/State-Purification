import EntanglementPurification.GlobalPaperDimension
import EntanglementPurification.GlobalSDPSemantics
import EntanglementPurification.GlobalChoiObjective

/-!
# Map-level form of the concrete global CPTN SDP

This file transports the finite Choi-matrix optimum to Lean-QIT's operational
predicate for completely positive trace-nonincreasing matrix maps.  The
objective here is still `globalConcreteRawPerformanceOperator`, namely the
explicit finite contraction formula.  No identification with a Haar-averaged
gain is asserted in this file.
-/

namespace EntanglementPurification

open QIT

noncomputable section

/-- A completely positive trace-nonincreasing map has a feasible Choi matrix
in the input-first convention used by the global SDP. -/
theorem traceNonincreasingCP_choi_isGlobalCPTNChoi
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    (Phi : MatrixMap x y) (hPhi : MatrixMap.TraceNonincreasingCP Phi) :
    IsGlobalCPTNChoi (MatrixMap.choi Phi) := by
  apply (isGlobalCPTNChoi_iff_traceNonincreasingCP
    (MatrixMap.choi Phi)).2
  simpa only [MatrixMap.ofChoiMatrix_choi] using hPhi

/-- Every operationally CPTN map is bounded by the optimum of the concrete
raw finite-matrix objective. -/
theorem globalRaw_map_objective_le
    {x : Type*} [Fintype x] [DecidableEq x]
    {gamma : ℝ} (hcard : 4 ≤ (Fintype.card x : ℝ))
    (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (Phi : MatrixMap (x × x) x)
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) :
    globalSDPObjective
        (globalConcreteRawPerformanceOperator (x := x) gamma)
        (MatrixMap.choi Phi) ≤
      globalOptimalGain (Fintype.card x : ℝ) gamma := by
  exact globalConcreteRaw_SDP_upper_bound hcard hgamma0 hgamma1
    (traceNonincreasingCP_choi_isGlobalCPTNChoi Phi hPhi)

/-- An operationally CPTN map reaches the concrete raw optimum exactly when
it is the map reconstructed from the displayed optimal Choi matrix. -/
theorem globalRaw_map_objective_eq_optimalGain_iff
    {x : Type*} [Fintype x] [DecidableEq x]
    {gamma : ℝ} (hcard : 4 ≤ (Fintype.card x : ℝ))
    (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (Phi : MatrixMap (x × x) x)
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) :
    (globalSDPObjective
          (globalConcreteRawPerformanceOperator (x := x) gamma)
          (MatrixMap.choi Phi) =
        globalOptimalGain (Fintype.card x : ℝ) gamma) ↔
      Phi = MatrixMap.ofChoiMatrix (globalOptimalChoi (x := x)) := by
  have hJ : IsGlobalCPTNChoi (MatrixMap.choi Phi) :=
    traceNonincreasingCP_choi_isGlobalCPTNChoi Phi hPhi
  rw [globalConcreteRaw_objective_eq_optimalGain_iff
    hcard hgamma0 hgamma1 hJ]
  constructor
  · intro hchoi
    calc
      Phi = MatrixMap.ofChoiMatrix (MatrixMap.choi Phi) :=
        (MatrixMap.ofChoiMatrix_choi Phi).symm
      _ = MatrixMap.ofChoiMatrix (globalOptimalChoi (x := x)) :=
        congrArg (fun J => MatrixMap.ofChoiMatrix J) hchoi
  · intro hmap
    have hchoi := congrArg MatrixMap.choi hmap
    simpa only [MatrixMap.choi_ofChoiMatrix] using hchoi

/-- Complete map-level optimum and uniqueness theorem for an arbitrary finite
one-leg type of cardinality at least four. -/
theorem globalRaw_map_optimal_and_unique
    {x : Type*} [Fintype x] [DecidableEq x]
    {gamma : ℝ} (hcard : 4 ≤ (Fintype.card x : ℝ))
    (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) :
    MatrixMap.TraceNonincreasingCP
        (MatrixMap.ofChoiMatrix (globalOptimalChoi (x := x))) ∧
      globalSDPObjective
          (globalConcreteRawPerformanceOperator (x := x) gamma)
          (MatrixMap.choi
            (MatrixMap.ofChoiMatrix (globalOptimalChoi (x := x)))) =
        globalOptimalGain (Fintype.card x : ℝ) gamma ∧
      (∀ Phi : MatrixMap (x × x) x,
        MatrixMap.TraceNonincreasingCP Phi →
          globalSDPObjective
              (globalConcreteRawPerformanceOperator (x := x) gamma)
              (MatrixMap.choi Phi) ≤
            globalOptimalGain (Fintype.card x : ℝ) gamma) ∧
      (∀ Phi : MatrixMap (x × x) x,
        MatrixMap.TraceNonincreasingCP Phi →
          (globalSDPObjective
                (globalConcreteRawPerformanceOperator (x := x) gamma)
                (MatrixMap.choi Phi) =
              globalOptimalGain (Fintype.card x : ℝ) gamma ↔
            Phi = MatrixMap.ofChoiMatrix
              (globalOptimalChoi (x := x)))) := by
  refine ⟨
    (isGlobalCPTNChoi_iff_traceNonincreasingCP
      (globalOptimalChoi (x := x))).1
        globalOptimalChoi_isGlobalCPTNChoi,
    ?_, ?_, ?_⟩
  · simpa only [MatrixMap.choi_ofChoiMatrix] using
      (globalOptimalChoi_raw_objective_eq_globalOptimalGain
        (x := x) (gamma := gamma) hcard)
  · intro Phi hPhi
    exact globalRaw_map_objective_le hcard hgamma0 hgamma1 Phi hPhi
  · intro Phi hPhi
    exact globalRaw_map_objective_eq_optimalGain_iff
      hcard hgamma0 hgamma1 Phi hPhi

/-- Paper-dimension specialization of operational Choi feasibility. -/
theorem globalPaper_traceNonincreasingCP_choi_isGlobalCPTNChoi
    {d : ℕ} (Phi : MatrixMap
      (GlobalPaperIndex d × GlobalPaperIndex d) (GlobalPaperIndex d))
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) :
    IsGlobalCPTNChoi (MatrixMap.choi Phi) :=
  traceNonincreasingCP_choi_isGlobalCPTNChoi Phi hPhi

/-- Paper-dimension map-level upper bound for the concrete raw objective. -/
theorem globalPaperRaw_map_objective_le
    {d : ℕ} (hd : 2 ≤ d)
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (Phi : MatrixMap
      (GlobalPaperIndex d × GlobalPaperIndex d) (GlobalPaperIndex d))
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) :
    globalSDPObjective
        (globalConcreteRawPerformanceOperator
          (x := GlobalPaperIndex d) gamma)
        (MatrixMap.choi Phi) ≤
      globalOptimalGain ((d : ℝ) ^ 2) gamma := by
  simpa [GlobalPaperIndex, pow_two] using
    (globalRaw_map_objective_le
      (x := GlobalPaperIndex d) (four_le_card_globalPaperIndex hd)
      hgamma0 hgamma1 Phi hPhi)

/-- In paper dimension, equality in the concrete raw objective characterizes
the reconstructed optimal map exactly. -/
theorem globalPaperRaw_map_objective_eq_optimalGain_iff
    {d : ℕ} (hd : 2 ≤ d)
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (Phi : MatrixMap
      (GlobalPaperIndex d × GlobalPaperIndex d) (GlobalPaperIndex d))
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) :
    (globalSDPObjective
          (globalConcreteRawPerformanceOperator
            (x := GlobalPaperIndex d) gamma)
          (MatrixMap.choi Phi) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) ↔
      Phi = MatrixMap.ofChoiMatrix
        (globalOptimalChoi (x := GlobalPaperIndex d)) := by
  simpa [GlobalPaperIndex, pow_two] using
    (globalRaw_map_objective_eq_optimalGain_iff
      (x := GlobalPaperIndex d) (four_le_card_globalPaperIndex hd)
      hgamma0 hgamma1 Phi hPhi)

/-- Complete paper-facing map-level optimum and uniqueness theorem for the
concrete raw objective, with `x = Fin d × Fin d` and `D = d²`. -/
theorem globalPaperRaw_map_optimal_and_unique
    {d : ℕ} (hd : 2 ≤ d)
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) :
    MatrixMap.TraceNonincreasingCP
        (MatrixMap.ofChoiMatrix
          (globalOptimalChoi (x := GlobalPaperIndex d))) ∧
      globalSDPObjective
          (globalConcreteRawPerformanceOperator
            (x := GlobalPaperIndex d) gamma)
          (MatrixMap.choi
            (MatrixMap.ofChoiMatrix
              (globalOptimalChoi (x := GlobalPaperIndex d)))) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma ∧
      (∀ Phi : MatrixMap
          (GlobalPaperIndex d × GlobalPaperIndex d) (GlobalPaperIndex d),
        MatrixMap.TraceNonincreasingCP Phi →
          globalSDPObjective
              (globalConcreteRawPerformanceOperator
                (x := GlobalPaperIndex d) gamma)
              (MatrixMap.choi Phi) ≤
            globalOptimalGain ((d : ℝ) ^ 2) gamma) ∧
      (∀ Phi : MatrixMap
          (GlobalPaperIndex d × GlobalPaperIndex d) (GlobalPaperIndex d),
        MatrixMap.TraceNonincreasingCP Phi →
          (globalSDPObjective
                (globalConcreteRawPerformanceOperator
                  (x := GlobalPaperIndex d) gamma)
                (MatrixMap.choi Phi) =
              globalOptimalGain ((d : ℝ) ^ 2) gamma ↔
            Phi = MatrixMap.ofChoiMatrix
              (globalOptimalChoi (x := GlobalPaperIndex d)))) := by
  simpa [GlobalPaperIndex, pow_two] using
    (globalRaw_map_optimal_and_unique
      (x := GlobalPaperIndex d) (four_le_card_globalPaperIndex hd)
      hgamma0 hgamma1)

end

end EntanglementPurification
