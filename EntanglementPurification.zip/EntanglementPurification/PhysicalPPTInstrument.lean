import EntanglementPurification.PhysicalBranchOutputTrace
import EntanglementPurification.ResourceInsertion
import EntanglementPurification.JointContractionSchur
import QIT.Protocols.LOCC.Core
import QIT.Core.Map.ChoiCharacterization
import Mathlib.Tactic

/-!
# Complete physical two-outcome PPT instruments

This file connects the operational `QIT.FiniteInstrument` interface to the
physical branch matrices used in the paper.  The input Choi index of a map is

`((((A₁ × B₁) × (A₂ × B₂)) × (R_A × R_B)) × (A' × B'))`.

The paper groups exactly the same registers as

`((((A₁ × A₂) × A') × ((B₁ × B₂) × B')) × (R_A × R_B))`.

The equivalences below perform only this register permutation.  Consequently,
complete positivity of a branch gives positivity of its physical Choi matrix,
and trace preservation of the sum of the two branches gives the physical
output-completeness identity.  PPT is genuinely additional physical data and
is therefore recorded explicitly for both branches.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b ra rb : Type*}
  [Fintype a] [Fintype b] [Fintype ra] [Fintype rb]
  [DecidableEq a] [DecidableEq b] [DecidableEq ra] [DecidableEq rb]

/-- The operational input of the two-copy, resource-assisted protocol. -/
abbrev PhysicalInstrumentInput (a b ra rb : Type*) :=
  (((a × b) × (a × b)) × (ra × rb))

/-- The operational quantum output of the protocol. -/
abbrev PhysicalInstrumentOutput (a b : Type*) := a × b

/-- Regroup the operational input into the input/resource order used after
tracing out the physical outputs. -/
def physicalInstrumentInputEquiv :
    PhysicalInstrumentInput a b ra rb ≃
      JointContractionInputResourceIndex a b (ra × rb) where
  toFun p := (((p.1.1.1, p.1.2.1), (p.1.1.2, p.1.2.2)), p.2)
  invFun p := (((p.1.1.1, p.1.2.1), (p.1.1.2, p.1.2.2)), p.2)
  left_inv _ := rfl
  right_inv _ := rfl

/-- Regroup a standard input-first Choi index into the physical Alice/Bob
three-leg order used by `JointContractionPhysicalIndex`. -/
def physicalInstrumentChoiEquiv :
    (PhysicalInstrumentInput a b ra rb × PhysicalInstrumentOutput a b) ≃
      JointContractionPhysicalIndex a b (ra × rb) where
  toFun p :=
    ((((p.1.1.1.1, p.1.1.2.1), p.2.1),
      ((p.1.1.1.2, p.1.1.2.2), p.2.2)), p.1.2)
  invFun p :=
    (((((p.1.1.1.1, p.1.2.1.1), (p.1.1.1.2, p.1.2.1.2)), p.2)),
      (p.1.1.2, p.1.2.2))
  left_inv _ := rfl
  right_inv _ := rfl

/-- A matrix map's Choi matrix, with registers permuted into the paper's
physical branch order. -/
def physicalInstrumentChoi
    (Φ : MatrixMap (PhysicalInstrumentInput a b ra rb)
      (PhysicalInstrumentOutput a b)) :
    CMatrix (JointContractionPhysicalIndex a b (ra × rb)) :=
  (Matrix.reindexAlgEquiv ℂ ℂ
    (physicalInstrumentChoiEquiv (a := a) (b := b) (ra := ra) (rb := rb)))
    (MatrixMap.choi Φ)

/-- Entrywise form of the operational-Choi to physical-Choi regrouping. -/
@[simp]
theorem physicalInstrumentChoi_apply
    (Φ : MatrixMap (PhysicalInstrumentInput a b ra rb)
      (PhysicalInstrumentOutput a b))
    (iA₁ iA₂ iAout kA₁ kA₂ kAout : a)
    (iB₁ iB₂ iBout kB₁ kB₂ kBout : b)
    (uA vA : ra) (uB vB : rb) :
    physicalInstrumentChoi Φ
        ((((iA₁, iA₂), iAout), ((iB₁, iB₂), iBout)), (uA, uB))
        ((((kA₁, kA₂), kAout), ((kB₁, kB₂), kBout)), (vA, vB)) =
      MatrixMap.choi Φ
        (((((iA₁, iB₁), (iA₂, iB₂)), (uA, uB)), (iAout, iBout)))
        (((((kA₁, kB₁), (kA₂, kB₂)), (vA, vB)), (kAout, kBout))) := by
  simp [physicalInstrumentChoi, Matrix.reindexAlgEquiv_apply,
    Matrix.reindex_apply, physicalInstrumentChoiEquiv]

/-- Complete positivity is unchanged by the register permutation. -/
theorem physicalInstrumentChoi_posSemidef
    (Φ : MatrixMap (PhysicalInstrumentInput a b ra rb)
      (PhysicalInstrumentOutput a b))
    (hΦ : MatrixMap.IsCompletelyPositive Φ) :
    (physicalInstrumentChoi Φ).PosSemidef := by
  let e := physicalInstrumentChoiEquiv
    (a := a) (b := b) (ra := ra) (rb := rb)
  change (Matrix.reindex e e (MatrixMap.choi Φ)).PosSemidef
  simpa [Matrix.reindex_apply, Matrix.submatrix_apply] using
    hΦ.submatrix e.symm

/-- Tracing out the physical outputs agrees with first taking the ordinary
Choi output trace and then regrouping the remaining input registers. -/
theorem physicalBranchOutputTrace_physicalInstrumentChoi
    (Φ : MatrixMap (PhysicalInstrumentInput a b ra rb)
      (PhysicalInstrumentOutput a b)) :
    physicalBranchOutputTrace (physicalInstrumentChoi Φ) =
      (Matrix.reindexAlgEquiv ℂ ℂ
        (physicalInstrumentInputEquiv
          (a := a) (b := b) (ra := ra) (rb := rb)))
        (QIT.partialTraceB (MatrixMap.choi Φ)) := by
  ext p q
  rcases p with ⟨⟨⟨iA₁, iA₂⟩, ⟨iB₁, iB₂⟩⟩, ⟨uA, uB⟩⟩
  rcases q with ⟨⟨⟨kA₁, kA₂⟩, ⟨kB₁, kB₂⟩⟩, ⟨vA, vB⟩⟩
  simp [QIT.partialTraceB, Matrix.reindexAlgEquiv_apply,
    Matrix.reindex_apply, physicalInstrumentInputEquiv,
    Fintype.sum_prod_type]

/-- A complete two-outcome physical instrument whose success and failure
branches are both PPT across the physical Alice/Bob cut.  `true` is the
success outcome and `false` is the failure outcome. -/
structure PhysicalPPTInstrument (a b ra rb : Type*)
    [Fintype a] [Fintype b] [Fintype ra] [Fintype rb]
    [DecidableEq a] [DecidableEq b] [DecidableEq ra] [DecidableEq rb] where
  instrument : FiniteInstrument
    (PhysicalInstrumentInput a b ra rb) (PhysicalInstrumentOutput a b) Bool
  success_ppt :
    (physicalBranchPartialTransposeB
      (physicalInstrumentChoi (instrument.branch true))).PosSemidef
  failure_ppt :
    (physicalBranchPartialTransposeB
      (physicalInstrumentChoi (instrument.branch false))).PosSemidef

namespace PhysicalPPTInstrument

/-- Physical Choi matrix of the success outcome. -/
def success (M : PhysicalPPTInstrument a b ra rb) :
    CMatrix (JointContractionPhysicalIndex a b (ra × rb)) :=
  physicalInstrumentChoi (M.instrument.branch true)

/-- Physical Choi matrix of the failure outcome. -/
def failure (M : PhysicalPPTInstrument a b ra rb) :
    CMatrix (JointContractionPhysicalIndex a b (ra × rb)) :=
  physicalInstrumentChoi (M.instrument.branch false)

/-- The physical success branch is positive because it is a branch of a
finite quantum instrument. -/
theorem success_posSemidef (M : PhysicalPPTInstrument a b ra rb) :
    M.success.PosSemidef :=
  physicalInstrumentChoi_posSemidef _
    (M.instrument.branch_completelyPositive true)

/-- The physical failure branch is positive because it is a branch of a
finite quantum instrument. -/
theorem failure_posSemidef (M : PhysicalPPTInstrument a b ra rb) :
    M.failure.PosSemidef :=
  physicalInstrumentChoi_posSemidef _
    (M.instrument.branch_completelyPositive false)

/-- Every outcome branch is positive; the Bool specialization merely selects
the corresponding result above. -/
theorem branch_posSemidef (M : PhysicalPPTInstrument a b ra rb)
    (outcome : Bool) :
    (physicalInstrumentChoi (M.instrument.branch outcome)).PosSemidef :=
  physicalInstrumentChoi_posSemidef _
    (M.instrument.branch_completelyPositive outcome)

/-- Every outcome branch satisfies the explicitly supplied physical Bob-PPT
condition. -/
theorem branch_ppt (M : PhysicalPPTInstrument a b ra rb)
    (outcome : Bool) :
    (physicalBranchPartialTransposeB
      (physicalInstrumentChoi (M.instrument.branch outcome))).PosSemidef := by
  cases outcome with
  | false => exact M.failure_ppt
  | true => exact M.success_ppt

/-- Before the register permutation, the two Choi matrices form precisely the
positive, trace-preserving success/failure pair used by resource insertion.
Thus this matrix-level premise is derived from `FiniteInstrument`. -/
theorem rawChoi_isChoiSuccessFailurePair
    (M : PhysicalPPTInstrument a b ra rb) :
    IsChoiSuccessFailurePair
      (MatrixMap.choi (M.instrument.branch true))
      (MatrixMap.choi (M.instrument.branch false)) := by
  refine ⟨M.instrument.branch_completelyPositive true,
    M.instrument.branch_completelyPositive false, ?_⟩
  have hmaps :
      M.instrument.branch true + M.instrument.branch false =
        M.instrument.total.map := by
    simpa [Fintype.sum_bool] using M.instrument.sum_branch_eq_total
  have hchoi :
      MatrixMap.choi (M.instrument.branch true) +
          MatrixMap.choi (M.instrument.branch false) =
        MatrixMap.choi M.instrument.total.map := by
    have h := congrArg MatrixMap.choi hmaps
    simpa [MatrixMap.choi] using h
  rw [hchoi]
  exact
    (MatrixMap.isTracePreserving_iff_partialTraceB_choi
      M.instrument.total.map).mp M.instrument.total.tracePreserving

/-- The two physical branches form a complete instrument after tracing out
the output registers.  This is derived from `FiniteInstrument`, not assumed. -/
theorem outputTrace_success_add_failure_eq_one
    (M : PhysicalPPTInstrument a b ra rb) :
    physicalBranchOutputTrace M.success +
        physicalBranchOutputTrace M.failure = 1 := by
  let e := physicalInstrumentInputEquiv
    (a := a) (b := b) (ra := ra) (rb := rb)
  have hmaps :
      M.instrument.branch true + M.instrument.branch false =
        M.instrument.total.map := by
    simpa [Fintype.sum_bool] using M.instrument.sum_branch_eq_total
  have hchoi :
      MatrixMap.choi (M.instrument.branch true) +
          MatrixMap.choi (M.instrument.branch false) =
        MatrixMap.choi M.instrument.total.map := by
    have h := congrArg MatrixMap.choi hmaps
    simpa [MatrixMap.choi] using h
  have hraw :
      QIT.partialTraceB (MatrixMap.choi (M.instrument.branch true)) +
          QIT.partialTraceB (MatrixMap.choi (M.instrument.branch false)) = 1 := by
    rw [← QIT.partialTraceB_add, hchoi]
    exact
      (MatrixMap.isTracePreserving_iff_partialTraceB_choi
        M.instrument.total.map).mp M.instrument.total.tracePreserving
  change
    physicalBranchOutputTrace
        (physicalInstrumentChoi (M.instrument.branch true)) +
      physicalBranchOutputTrace
        (physicalInstrumentChoi (M.instrument.branch false)) = 1
  rw [physicalBranchOutputTrace_physicalInstrumentChoi,
    physicalBranchOutputTrace_physicalInstrumentChoi]
  change (Matrix.reindexAlgEquiv ℂ ℂ e)
      (QIT.partialTraceB (MatrixMap.choi (M.instrument.branch true))) +
    (Matrix.reindexAlgEquiv ℂ ℂ e)
      (QIT.partialTraceB (MatrixMap.choi (M.instrument.branch false))) = 1
  rw [← map_add, hraw]
  exact map_one (Matrix.reindexAlgEquiv ℂ ℂ e)

/-- Both branches have already undergone the paper's local twirl.  This is a
predicate, not a consequence of an arbitrary finite instrument; the actual
Haar-twirl construction is supplied separately. -/
def IsLocallyInvariant (M : PhysicalPPTInstrument a b ra rb) : Prop :=
  ∀ outcome : Bool,
    JointContractionPhysicalInvariant
      (physicalInstrumentChoi (M.instrument.branch outcome))

/-- The exact three physical hypotheses consumed by the contraction and
output-trace certificate, for any branch of a locally invariant instrument. -/
theorem branch_certificate_inputs
    (M : PhysicalPPTInstrument a b ra rb)
    (hInvariant : M.IsLocallyInvariant) (outcome : Bool) :
    JointContractionPhysicalInvariant
        (physicalInstrumentChoi (M.instrument.branch outcome)) ∧
      (physicalInstrumentChoi
        (M.instrument.branch outcome)).PosSemidef ∧
      (physicalBranchPartialTransposeB
        (physicalInstrumentChoi
          (M.instrument.branch outcome))).PosSemidef :=
  ⟨hInvariant outcome, M.branch_posSemidef outcome, M.branch_ppt outcome⟩

/-- Success-branch specialization of `branch_certificate_inputs`. -/
theorem success_certificate_inputs
    (M : PhysicalPPTInstrument a b ra rb)
    (hInvariant : M.IsLocallyInvariant) :
    JointContractionPhysicalInvariant M.success ∧
      M.success.PosSemidef ∧
      (physicalBranchPartialTransposeB M.success).PosSemidef := by
  simpa [success] using M.branch_certificate_inputs hInvariant true

/-- Failure-branch specialization of `branch_certificate_inputs`. -/
theorem failure_certificate_inputs
    (M : PhysicalPPTInstrument a b ra rb)
    (hInvariant : M.IsLocallyInvariant) :
    JointContractionPhysicalInvariant M.failure ∧
      M.failure.PosSemidef ∧
      (physicalBranchPartialTransposeB M.failure).PosSemidef := by
  simpa [failure] using M.branch_certificate_inputs hInvariant false

end PhysicalPPTInstrument

end

end EntanglementPurification
