import QIT.Protocols.LOCC
import Mathlib.Tactic

/-!
# Coarse graining finite quantum instruments

This file packages the elementary operation of forgetting part of a finite
classical outcome.  If `M` has outcome type `outcome` and `f : outcome → flag`,
the branch labelled by `y : flag` is the sum of all original branches in the
fibre `f ⁻¹' {y}`.  The quantum channel obtained after forgetting every
classical label is unchanged.
-/

namespace QIT

open scoped ComplexOrder MatrixOrder

noncomputable section

universe u v w x

namespace MatrixMap

variable {input : Type u} {output : Type v} {index : Type w}
variable [Fintype input] [DecidableEq input]
variable [Fintype output] [DecidableEq output]
variable [Fintype index]

omit [Fintype index] in
/-- A finite sum of completely positive matrix maps is completely positive. -/
theorem isCompletelyPositive_finsetSum
    (s : Finset index) (Phi : index → MatrixMap input output)
    (hPhi : ∀ i ∈ s, IsCompletelyPositive (Phi i)) :
    IsCompletelyPositive (∑ i ∈ s, Phi i) := by
  rw [IsCompletelyPositive]
  have hchoi :
      choi (∑ i ∈ s, Phi i) = ∑ i ∈ s, choi (Phi i) := by
    ext ij kl
    simp [choi, LinearMap.sum_apply, Matrix.sum_apply]
  rw [hchoi]
  exact Matrix.posSemidef_sum s fun i hi => hPhi i hi

omit [Fintype index] in
/-- Real trace commutes with a finite sum of matrix maps. -/
theorem trace_re_finsetSum_apply
    (s : Finset index) (Phi : index → MatrixMap input output)
    (X : CMatrix input) :
    ((∑ i ∈ s, Phi i) X).trace.re =
      ∑ i ∈ s, (Phi i X).trace.re := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [Matrix.trace]
  | @insert i s hi ih =>
      simp [Finset.sum_insert, hi, LinearMap.add_apply, Matrix.trace_add]

end MatrixMap

namespace FiniteInstrument

variable {input : Type u} {output : Type v}
variable {outcome : Type w} {flag : Type x}
variable [Fintype input] [DecidableEq input]
variable [Fintype output] [DecidableEq output]
variable [Fintype outcome]
variable [Fintype flag] [DecidableEq flag]

/-- The branch obtained by merging all outcomes on which `f` has value `y`. -/
def coarseGrainBranch
    (M : FiniteInstrument input output outcome)
    (f : outcome → flag) (y : flag) : MatrixMap input output :=
  ∑ x ∈ Finset.univ.filter (fun x => f x = y), M.branch x

omit [Fintype flag] in theorem coarseGrainBranch_completelyPositive
    (M : FiniteInstrument input output outcome)
    (f : outcome → flag) (y : flag) :
    MatrixMap.IsCompletelyPositive (M.coarseGrainBranch f y) := by
  apply MatrixMap.isCompletelyPositive_finsetSum
  intro x hx
  exact M.branch_completelyPositive x

omit [Fintype flag] in
private theorem coarseGrainBranch_traceNonincreasing
    (M : FiniteInstrument input output outcome)
    (f : outcome → flag) (y : flag) :
    MatrixMap.IsTraceNonincreasing (M.coarseGrainBranch f y) := by
  intro X hX
  let s : Finset outcome := Finset.univ.filter (fun x => f x = y)
  have hnonneg :
      ∀ x ∈ (Finset.univ : Finset outcome),
        0 ≤ (M.branch x X).trace.re := by
    intro x hx
    exact (Matrix.PosSemidef.trace_nonneg
      ((M.branchTraceNonincreasingCP x).mapsPositive X hX)).1
  have hsubset : s ⊆ (Finset.univ : Finset outcome) := by
    intro x hx
    simp
  have hle :
      (∑ x ∈ s, (M.branch x X).trace.re) ≤
        ∑ x ∈ (Finset.univ : Finset outcome), (M.branch x X).trace.re := by
    exact Finset.sum_le_sum_of_subset_of_nonneg hsubset (by
      intro x hxuniv hxnots
      exact hnonneg x hxuniv)
  have hleft :
      (M.coarseGrainBranch f y X).trace.re =
        ∑ x ∈ s, (M.branch x X).trace.re := by
    simp [coarseGrainBranch, s]
  have hright :
      (∑ x ∈ (Finset.univ : Finset outcome), (M.branch x X).trace.re) =
        X.trace.re := by
    have htrace := M.total.tracePreserving X
    calc
      (∑ x ∈ (Finset.univ : Finset outcome), (M.branch x X).trace.re) =
          ((∑ x : outcome, M.branch x) X).trace.re := by
            exact (MatrixMap.trace_re_finsetSum_apply
              (Finset.univ : Finset outcome) M.branch X).symm
      _ = (M.total.map X).trace.re := by rw [M.sum_branch_eq_total]
      _ = X.trace.re := congrArg Complex.re htrace
  calc
    (M.coarseGrainBranch f y X).trace.re =
        ∑ x ∈ s, (M.branch x X).trace.re := hleft
    _ ≤ ∑ x ∈ (Finset.univ : Finset outcome),
        (M.branch x X).trace.re := hle
    _ = X.trace.re := hright

omit [Fintype flag] in
/-- Every merged branch remains completely positive and trace-nonincreasing. -/
theorem coarseGrainBranch_traceNonincreasingCP
    (M : FiniteInstrument input output outcome)
    (f : outcome → flag) (y : flag) :
    MatrixMap.TraceNonincreasingCP (M.coarseGrainBranch f y) where
  completelyPositive := M.coarseGrainBranch_completelyPositive f y
  traceNonincreasing := M.coarseGrainBranch_traceNonincreasing f y

/-- Coarse-grain the classical outcomes of a finite quantum instrument.

The total channel is definitionally reused from `M`; only its classical
labelling is changed.
-/
def coarseGrain
    (M : FiniteInstrument input output outcome)
    (f : outcome → flag) : FiniteInstrument input output flag where
  branch := M.coarseGrainBranch f
  branchTraceNonincreasingCP := M.coarseGrainBranch_traceNonincreasingCP f
  total := M.total
  sum_branch_eq_total := by
    rw [← M.sum_branch_eq_total]
    apply Finset.sum_fiberwise

@[simp]
theorem coarseGrain_branch
    (M : FiniteInstrument input output outcome)
    (f : outcome → flag) (y : flag) :
    (M.coarseGrain f).branch y = M.coarseGrainBranch f y :=
  rfl

@[simp]
theorem coarseGrain_total
    (M : FiniteInstrument input output outcome)
    (f : outcome → flag) :
    (M.coarseGrain f).total = M.total :=
  rfl

theorem coarseGrain_sum_branch_eq_total
    (M : FiniteInstrument input output outcome)
    (f : outcome → flag) :
    (∑ y : flag, (M.coarseGrain f).branch y) = M.total.map :=
  (M.coarseGrain f).sum_branch_eq_total

end FiniteInstrument

end

end QIT
