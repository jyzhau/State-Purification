import EntanglementPurification.ShannonCollisionBound
import Mathlib.Analysis.Convex.Jensen
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Tactic

/-!
# Equality in the Shannon--collision comparison

This module proves the rigidity statement used by the one-ebit equality case
in `main.tex`.  Equality between Shannon entropy and collision entropy forces
all positive probabilities to coincide.  At collision probability `1 / 2`,
an ordered probability vector therefore has exactly the spectrum
`(1 / 2, 1 / 2, 0, ...)`.
-/

namespace EntanglementPurification

noncomputable section

open scoped BigOperators

/-- Under the one-bit hypotheses, the collision probability itself is exactly
`1 / 2`. -/
theorem collisionProbability_eq_half_of_shannonEntropyBits_eq_one
    {n : ℕ} {p : Fin n → ℝ}
    (hnonneg : ∀ i, 0 ≤ p i)
    (htotal : (List.ofFn p).sum = 1)
    (hcollision : collisionProbability p ≤ 1 / 2)
    (hentropy : shannonEntropyBits p = 1) :
    collisionProbability p = 1 / 2 := by
  have hcollision_pos :=
    collisionProbability_pos_of_probability hnonneg htotal
  have hcomparison :=
    neg_log2_collisionProbability_le_shannonEntropyBits hnonneg htotal
  have hlog_le :
      QIT.log2 (collisionProbability p) ≤ QIT.log2 (1 / 2 : ℝ) :=
    QIT.log2_mono_of_pos hcollision_pos hcollision
  have hlog_half : QIT.log2 (1 / 2 : ℝ) = -1 := by
    rw [QIT.log2_one_div, QIT.log2_two]
  have hneglog : -QIT.log2 (collisionProbability p) = 1 := by
    rw [hentropy] at hcomparison
    rw [hlog_half] at hlog_le
    linarith
  have hlog2_eq :
      QIT.log2 (collisionProbability p) = QIT.log2 (1 / 2 : ℝ) := by
    rw [hlog_half]
    linarith
  have hlog_two_ne : Real.log 2 ≠ 0 :=
    (Real.log_pos (by norm_num)).ne'
  unfold QIT.log2 at hlog2_eq
  have hlog_eq :
      Real.log (collisionProbability p) = Real.log (1 / 2 : ℝ) := by
    field_simp [hlog_two_ne] at hlog2_eq
    exact hlog2_eq
  exact Real.log_injOn_pos hcollision_pos (by norm_num) hlog_eq

/-- Equality in the Shannon--collision comparison forces every positive
coordinate to equal the collision probability. -/
theorem probability_eq_collisionProbability_of_shannon_eq_neg_log2_collision
    {n : ℕ} {p : Fin n → ℝ}
    (hnonneg : ∀ i, 0 ≤ p i)
    (htotal : (List.ofFn p).sum = 1)
    (hequality :
      shannonEntropyBits p = -QIT.log2 (collisionProbability p)) :
    ∀ i, 0 < p i → p i = collisionProbability p := by
  classical
  let support : Finset (Fin n) := Finset.univ.filter fun i => 0 < p i
  have hzero_of_not_mem {i : Fin n} (hi : i ∉ support) : p i = 0 := by
    have hnotpos : ¬0 < p i := by
      simpa [support] using hi
    exact le_antisymm (le_of_not_gt hnotpos) (hnonneg i)
  have htotal' : ∑ i, p i = 1 :=
    (FiniteSchmidtData.sum_univ_eq_sum_ofFn p).trans htotal
  have hsupport_sum : ∑ i ∈ support, p i = 1 := by
    rw [← htotal']
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro i _ hi_not_mem
    exact hzero_of_not_mem hi_not_mem
  have hsupport_pos : ∀ i ∈ support, 0 < p i := by
    intro i hi
    exact (Finset.mem_filter.mp hi).2
  have hlog_sum_support :
      (∑ i, p i * Real.log (p i)) =
        ∑ i ∈ support, p i * Real.log (p i) := by
    symm
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro i _ hi_not_mem
    simp [hzero_of_not_mem hi_not_mem]
  have hsquare_sum_support :
      (∑ i, p i ^ 2) = ∑ i ∈ support, p i * p i := by
    calc
      (∑ i, p i ^ 2) = ∑ i ∈ support, p i ^ 2 := by
        symm
        apply Finset.sum_subset (Finset.filter_subset _ _)
        intro i _ hi_not_mem
        simp [hzero_of_not_mem hi_not_mem]
      _ = ∑ i ∈ support, p i * p i := by
        apply Finset.sum_congr rfl
        intro i _
        rw [pow_two]
  have hlog_two_pos : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hxlog_mul (x : ℝ) :
      QIT.xlog2 x * Real.log 2 = x * Real.log x := by
    rw [QIT.xlog2_eq_mul_log2]
    unfold QIT.log2
    field_simp [hlog_two_pos.ne']
  have hentropy_mul :
      shannonEntropyBits p * Real.log 2 =
        -(∑ i, p i * Real.log (p i)) := by
    rw [shannonEntropyBits]
    calc
      (-∑ i, QIT.xlog2 (p i)) * Real.log 2 =
          -((∑ i, QIT.xlog2 (p i)) * Real.log 2) := by ring
      _ = -(∑ i, QIT.xlog2 (p i) * Real.log 2) := by
        rw [Finset.sum_mul]
      _ = -(∑ i, p i * Real.log (p i)) := by
        congr 1
        apply Finset.sum_congr rfl
        intro i _
        exact hxlog_mul (p i)
  have hlog2_mul :
      QIT.log2 (collisionProbability p) * Real.log 2 =
        Real.log (collisionProbability p) := by
    unfold QIT.log2
    field_simp [hlog_two_pos.ne']
  have hglobal_jensen_eq :
      Real.log (collisionProbability p) =
        ∑ i, p i * Real.log (p i) := by
    have hscaled := congrArg (fun x : ℝ => x * Real.log 2) hequality
    change shannonEntropyBits p * Real.log 2 =
      (-QIT.log2 (collisionProbability p)) * Real.log 2 at hscaled
    rw [hentropy_mul] at hscaled
    nlinarith [hlog2_mul]
  have hsupport_jensen_eq :
      Real.log (∑ i ∈ support, p i * p i) =
        ∑ i ∈ support, p i * Real.log (p i) := by
    rw [← hlog_sum_support, ← hsquare_sum_support,
      ← collisionProbability_eq_sum_sq]
    exact hglobal_jensen_eq
  have hconstant :
      ∀ j ∈ support, p j = ∑ i ∈ support, p i • p i := by
    apply (strictConcaveOn_log_Ioi.map_sum_eq_iff
      hsupport_pos hsupport_sum hsupport_pos).mp
    simpa [smul_eq_mul] using hsupport_jensen_eq
  intro i hi
  have hi_support : i ∈ support := by
    simp [support, hi]
  calc
    p i = ∑ j ∈ support, p j • p j := hconstant i hi_support
    _ = ∑ j ∈ support, p j * p j := by simp [smul_eq_mul]
    _ = ∑ j, p j ^ 2 := hsquare_sum_support.symm
    _ = collisionProbability p := (collisionProbability_eq_sum_sq p).symm

/-- The exact equality case needed by the pure-resource one-ebit theorem. -/
theorem orderedProbability_eq_twoPoint_of_collision_le_half_of_shannon_eq_one
    {m : ℕ} {p : Fin (m + 3) → ℝ}
    (hp : IsOrderedProbability p)
    (hcollision : collisionProbability p ≤ 1 / 2)
    (hentropy : shannonEntropyBits p = 1) :
    p = twoPointComparison (m + 1) := by
  have hcollision_eq : collisionProbability p = 1 / 2 :=
    collisionProbability_eq_half_of_shannonEntropyBits_eq_one
      hp.2.1 hp.2.2 hcollision hentropy
  have hneglog : -QIT.log2 (collisionProbability p) = 1 := by
    rw [hcollision_eq, QIT.log2_one_div, QIT.log2_two]
    norm_num
  have hequality :
      shannonEntropyBits p = -QIT.log2 (collisionProbability p) := by
    rw [hentropy, hneglog]
  have huniform :=
    probability_eq_collisionProbability_of_shannon_eq_neg_log2_collision
      hp.2.1 hp.2.2 hequality
  have htotal : ∑ i, p i = 1 :=
    (FiniteSchmidtData.sum_univ_eq_sum_ofFn p).trans hp.2.2
  have hp0pos : 0 < p 0 := by
    by_contra h
    have hp0zero : p 0 = 0 :=
      le_antisymm (le_of_not_gt h) (hp.2.1 0)
    have hallzero : ∀ i, p i = 0 := by
      intro i
      exact le_antisymm ((hp.1 (Fin.zero_le i)).trans_eq hp0zero)
        (hp.2.1 i)
    simp [hallzero] at htotal
  have hp0 : p 0 = 1 / 2 := by
    rw [huniform 0 hp0pos, hcollision_eq]
  have hp1pos : 0 < p 1 := by
    by_contra h
    have hp1zero : p 1 = 0 :=
      le_antisymm (le_of_not_gt h) (hp.2.1 1)
    have htailzero : ∀ i, i ≠ 0 → p i = 0 := by
      intro i hi
      have hi_one : (1 : Fin (m + 3)) ≤ i :=
        Fin.one_le_of_ne_zero hi
      exact le_antisymm ((hp.1 hi_one).trans_eq hp1zero) (hp.2.1 i)
    have hsum_single : (∑ i, p i) = p 0 := by
      apply Finset.sum_eq_single 0
      · intro i _ hi
        exact htailzero i hi
      · simp
    rw [htotal, hp0] at hsum_single
    norm_num at hsum_single
  have hp1 : p 1 = 1 / 2 := by
    rw [huniform 1 hp1pos, hcollision_eq]
  have htail : ∀ i, i ≠ 0 → i ≠ 1 → p i = 0 := by
    intro i hi0 hi1
    have hsubset :
        (∑ j ∈ ({0, 1, i} : Finset (Fin (m + 3))), p j) ≤
          ∑ j, p j := by
      apply Finset.sum_le_sum_of_subset_of_nonneg
      · simp
      · intro j _ _
        exact hp.2.1 j
    have hpi_le : p 0 + p 1 + p i ≤ 1 := by
      rw [htotal] at hsubset
      simpa [hi0, hi1, Ne.symm hi0, Ne.symm hi1, add_assoc] using hsubset
    rw [hp0, hp1] at hpi_le
    exact le_antisymm (by linarith) (hp.2.1 i)
  funext i
  refine Fin.cases ?_ ?_ i
  · simpa [twoPointComparison] using hp0
  · intro i
    refine Fin.cases ?_ ?_ i
    · simpa [twoPointComparison] using hp1
    · intro i
      have hz := htail i.succ.succ (by simp) (by
        intro h
        have hv := congrArg Fin.val h
        simp at hv)
      simpa [twoPointComparison] using hz

end

end EntanglementPurification
