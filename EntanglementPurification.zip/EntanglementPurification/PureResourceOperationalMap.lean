import EntanglementPurification.ResourceInsertion
import QIT.Channels.Diamond
import Mathlib.Tactic

/-!
# Operational insertion of a pure resource

This module realizes the paper's fixed-resource insertion convention as an
ordinary composition of matrix maps.  The preliminary map appends the pure
resource state to an arbitrary input matrix.  Its Choi identity then identifies
operational composition with `pureResourceInsert`.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

universe u v w

variable {h : Type u} {r : Type v} {y : Type w}
  [Fintype h] [DecidableEq h]
  [Fintype r] [DecidableEq r]
  [Fintype y] [DecidableEq y]

/-- Append the rank-one resource operator `|eta><eta|` to an input matrix. -/
def appendPureResourceMap (eta : r → ℂ) : MatrixMap h (h × r) where
  toFun X := Matrix.kronecker X (rankOneMatrix eta)
  map_add' X Y := by
    ext i j
    simp [Matrix.kronecker, rankOneMatrix]
    ring
  map_smul' c X := by
    ext i j
    simp [Matrix.kronecker, rankOneMatrix]
    ring

@[simp]
theorem appendPureResourceMap_apply (eta : r → ℂ) (X : CMatrix h) :
    appendPureResourceMap eta X =
      Matrix.kronecker X (rankOneMatrix eta) :=
  rfl

/-- Choi vector of the operation which appends `|eta><eta|`. -/
def appendPureResourceChoiAmp (eta : r → ℂ) :
    (h × (h × r)) → ℂ :=
  fun q => if q.1 = q.2.1 then eta q.2.2 else 0

theorem choi_appendPureResourceMap (eta : r → ℂ) :
    MatrixMap.choi (appendPureResourceMap (h := h) eta) =
      rankOneMatrix (appendPureResourceChoiAmp (h := h) eta) := by
  ext ⟨i, ⟨j, u⟩⟩ ⟨k, ⟨l, v⟩⟩
  by_cases hij : i = j <;> by_cases hkl : k = l <;>
    simp [MatrixMap.choi, appendPureResourceMap, Matrix.kronecker,
      rankOneMatrix, Matrix.vecMulVec, appendPureResourceChoiAmp,
      Matrix.single, hij, hkl]

omit [Fintype h] in
/-- Expand a matrix unit tensored with a rank-one resource into product-index
matrix units. -/
theorem kronecker_single_rankOne_eq_sum_single
    (i j : h) (eta : r → ℂ) :
    Matrix.kronecker (Matrix.single i j (1 : ℂ)) (rankOneMatrix eta) =
      ∑ u : r, ∑ v : r,
        (eta u * star (eta v)) •
          Matrix.single (i, u) (j, v) (1 : ℂ) := by
  ext ⟨k, u⟩ ⟨l, v⟩
  simp only [Matrix.sum_apply, Matrix.smul_apply]
  rw [Finset.sum_eq_single u]
  · rw [Finset.sum_eq_single v]
    · simp [Matrix.kronecker, rankOneMatrix, Matrix.vecMulVec, Matrix.single]
    · intro v' _ hv'
      simp [Matrix.single, hv']
    · simp
  · intro u' _ hu'
    simp [Matrix.single, hu']
  · simp

theorem appendPureResourceMap_completelyPositive (eta : r → ℂ) :
    MatrixMap.IsCompletelyPositive (appendPureResourceMap (h := h) eta) := by
  rw [MatrixMap.IsCompletelyPositive, choi_appendPureResourceMap]
  exact Matrix.posSemidef_vecMulVec_self_star
    (appendPureResourceChoiAmp (h := h) eta)

/-- A normalized pure resource makes appending the resource trace preserving. -/
theorem appendPureResourceMap_tracePreserving
    (resource : PureVector r) :
    MatrixMap.IsTracePreserving
      (appendPureResourceMap (h := h) resource.amp) := by
  intro X
  rw [appendPureResourceMap_apply]
  calc
    (Matrix.kronecker X (rankOneMatrix resource.amp)).trace =
        X.trace * (rankOneMatrix resource.amp).trace :=
      Matrix.trace_kronecker X (rankOneMatrix resource.amp)
    _ = X.trace := by rw [resource.trace_rankOne_eq_one, mul_one]

/-- The channel which appends one fixed normalized pure resource. -/
def appendPureResourceChannel (resource : PureVector r) : Channel h (h × r) where
  map := appendPureResourceMap resource.amp
  completelyPositive := appendPureResourceMap_completelyPositive resource.amp
  tracePreserving := appendPureResourceMap_tracePreserving resource
  mapsPositive :=
    MatrixMap.isCompletelyPositive_mapsPositive _
      (appendPureResourceMap_completelyPositive resource.amp)

/-- Coordinatewise conjugation preserves pure-vector normalization. -/
def conjugatePureVector (resource : PureVector r) : PureVector r where
  amp i := star (resource.amp i)
  trace_rankOne_eq_one := by
    rw [rankOneMatrix_trace, dotProduct]
    have hnorm := resource.trace_rankOne_eq_one
    rw [rankOneMatrix_trace, dotProduct] at hnorm
    simpa [mul_comm] using hnorm

/-- Operational map induced after fixing the assisting pure resource. -/
def inducedByPureResource
    (Phi : MatrixMap (h × r) y) (resource : PureVector r) : MatrixMap h y :=
  Phi.comp (appendPureResourceMap resource.amp)

theorem inducedByPureResource_traceNonincreasingCP
    (Phi : MatrixMap (h × r) y) (resource : PureVector r)
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) :
    MatrixMap.TraceNonincreasingCP (inducedByPureResource Phi resource) where
  completelyPositive :=
    MatrixMap.isCompletelyPositive_comp Phi
      (appendPureResourceMap resource.amp) hPhi.completelyPositive
      (appendPureResourceMap_completelyPositive resource.amp)
  traceNonincreasing := by
    intro X hX
    have hAppendPos :
        (appendPureResourceMap resource.amp X).PosSemidef :=
      MatrixMap.isCompletelyPositive_mapsPositive _
        (appendPureResourceMap_completelyPositive resource.amp) X hX
    have hTNI := hPhi.traceNonincreasing
      (appendPureResourceMap resource.amp X) hAppendPos
    change
      (Phi (appendPureResourceMap resource.amp X)).trace.re ≤ X.trace.re
    calc
      (Phi (appendPureResourceMap resource.amp X)).trace.re ≤
          (appendPureResourceMap resource.amp X).trace.re := hTNI
      _ = X.trace.re := by
        exact congrArg Complex.re
          (appendPureResourceMap_tracePreserving (h := h) resource X)

/-- Operationally appending `|eta><eta|` gives the paper insertion with the
coordinatewise conjugate amplitude.  This is the transpose forced by the
input-first Choi convention. -/
theorem choi_inducedByPureResource
    (Phi : MatrixMap (h × r) y) (resource : PureVector r) :
    MatrixMap.choi (inducedByPureResource Phi resource) =
      pureResourceInsert (fun i => star (resource.amp i))
        (MatrixMap.choi Phi) := by
  ext ⟨i, a⟩ ⟨j, b⟩
  simp only [MatrixMap.choi, inducedByPureResource, LinearMap.comp_apply]
  rw [pureResourceInsert_apply]
  rw [show appendPureResourceMap resource.amp
        (Matrix.single i j (1 : ℂ)) =
      Matrix.kronecker (Matrix.single i j (1 : ℂ))
        (rankOneMatrix resource.amp) from rfl]
  rw [kronecker_single_rankOne_eq_sum_single]
  simp only [map_sum, map_smul, Matrix.sum_apply, Matrix.smul_apply]
  simp [MatrixMap.choi]
  apply Finset.sum_congr rfl
  intro u _
  apply Finset.sum_congr rfl
  intro v _
  ring

/-- The convention-aligned induced map pre-appends the coordinatewise
conjugate pure vector.  Its input-first Choi matrix is therefore literally the
existing `pureResourceInsert resource.amp` expression. -/
def inducedByPureResourceInsertionConvention
    (Phi : MatrixMap (h × r) y) (resource : PureVector r) : MatrixMap h y :=
  Phi.comp (appendPureResourceMap (conjugatePureVector resource).amp)

theorem inducedByPureResourceInsertionConvention_traceNonincreasingCP
    (Phi : MatrixMap (h × r) y) (resource : PureVector r)
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) :
    MatrixMap.TraceNonincreasingCP
      (inducedByPureResourceInsertionConvention Phi resource) := by
  exact inducedByPureResource_traceNonincreasingCP Phi
    (conjugatePureVector resource) hPhi

theorem choi_inducedByPureResourceInsertionConvention
    (Phi : MatrixMap (h × r) y) (resource : PureVector r) :
    MatrixMap.choi (inducedByPureResourceInsertionConvention Phi resource) =
      pureResourceInsert resource.amp (MatrixMap.choi Phi) := by
  ext ⟨i, a⟩ ⟨j, b⟩
  simp only [MatrixMap.choi, inducedByPureResourceInsertionConvention,
    LinearMap.comp_apply, conjugatePureVector]
  rw [pureResourceInsert_apply]
  rw [show appendPureResourceMap (fun i => star (resource.amp i))
        (Matrix.single i j (1 : ℂ)) =
      Matrix.kronecker (Matrix.single i j (1 : ℂ))
        (rankOneMatrix (fun i => star (resource.amp i))) from rfl]
  rw [kronecker_single_rankOne_eq_sum_single]
  simp only [map_sum, map_smul, Matrix.sum_apply, Matrix.smul_apply]
  simp [MatrixMap.choi]
  apply Finset.sum_congr rfl
  intro u _
  apply Finset.sum_congr rfl
  intro v _
  ring

end

end EntanglementPurification
