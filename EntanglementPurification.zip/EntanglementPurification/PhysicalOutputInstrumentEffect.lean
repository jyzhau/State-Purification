import EntanglementPurification.PaperOutputTraceCertificate

/-!
# From physical output traces to the compressed PPT instrument effect

This file connects the physical success/failure branches to the existing
`CompressedPPTInstrumentData` interface.  The sector matrices used below are
the canonical coefficients of the physical output traces; they are not new
free variables.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b r : Type*}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

/-- The four product parity projectors, extended by the resource identity,
resolve the identity on the retained input/resource space. -/
theorem sum_jointInputSectorProjector_kronecker_one :
    (∑ z : LocalMultiplicitySector,
      Matrix.kronecker
        (jointInputSectorProjector (a := a) (b := b) z)
        (1 : CMatrix r)) =
      (1 : CMatrix (JointContractionInputResourceIndex a b r)) := by
  have hA :
      localInputPairProjector (x := a) .plus +
          localInputPairProjector (x := a) .minus =
        (1 : CMatrix (a × a)) := by
    simpa [localInputPairProjector] using
      (globalInputPairPSym_add_localInputPairPAsym (x := a))
  have hB :
      localInputPairProjector (x := b) .plus +
          localInputPairProjector (x := b) .minus =
        (1 : CMatrix (b × b)) := by
    simpa [localInputPairProjector] using
      (globalInputPairPSym_add_localInputPairPAsym (x := b))
  have hfactor :
      (∑ z : LocalMultiplicitySector,
        Matrix.kronecker
          (jointInputSectorProjector (a := a) (b := b) z)
          (1 : CMatrix r)) =
        Matrix.kronecker
          (Matrix.kronecker
            (localInputPairProjector (x := a) .plus +
              localInputPairProjector (x := a) .minus)
            (localInputPairProjector (x := b) .plus +
              localInputPairProjector (x := b) .minus))
          (1 : CMatrix r) := by
    ext p q
    rcases p with ⟨⟨pA, pB⟩, u⟩
    rcases q with ⟨⟨qA, qB⟩, v⟩
    simp [Matrix.sum_apply, Fintype.sum_prod_type, sum_localParity,
      jointInputSectorProjector, Matrix.kronecker, Matrix.add_apply]
    ring
  rw [hfactor, hA, hB]
  ext p q
  rcases p with ⟨⟨pA, pB⟩, u⟩
  rcases q with ⟨⟨qA, qB⟩, v⟩
  by_cases huv : u = v <;>
    simp [Matrix.kronecker, Matrix.one_apply, Prod.ext_iff,
      and_assoc, huv]

/-- The normalized canonical extractor sends the retained-space identity to
the resource identity. -/
theorem outputTraceSectorCoefficient_one
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (z : LocalMultiplicitySector) :
    outputTraceSectorCoefficient
        (1 : CMatrix (JointContractionInputResourceIndex a b r)) z =
      (1 : CMatrix r) := by
  apply outputInputSectorDecomposition_coefficient_eq
    hcardA hcardB (fun _ => (1 : CMatrix r))
  exact sum_jointInputSectorProjector_kronecker_one.symm

variable {ra rb : Type*}
  [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]
  [Nonempty a] [Nonempty b]

/-- Construct the downstream compressed success/failure record directly from
two physical branches.

The completeness premise is the physical output-trace identity, not the
sectorwise complement field that is being constructed.  The latter is
derived by applying the canonical coefficient extractor and using
`outputTraceSectorCoefficient_one`.

The final three premises are precisely the still-upstream optimality inputs
from the paper: the inserted contraction block is the exposed optimum, and
the two mixed success sectors have zero expectation on the resource. -/
def physicalOutputCompressedData
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (hcardEq : Fintype.card b = Fintype.card a)
    (resource : PureVector (ra × rb))
    {S F : CMatrix (JointContractionPhysicalIndex a b (ra × rb))}
    (hSinvariant : JointContractionPhysicalInvariant S)
    (hSpos : S.PosSemidef) (hFpos : F.PosSemidef)
    (hSppt : (physicalBranchPartialTransposeB S).PosSemidef)
    (hFppt : (physicalBranchPartialTransposeB F).PosSemidef)
    (hcomplete :
      physicalBranchOutputTrace S + physicalBranchOutputTrace F =
        (1 : CMatrix
          (JointContractionInputResourceIndex a b (ra × rb))))
    (hinserted :
      insertPureResourceBlock resource.amp
          (jointContractionSchurCoefficient S) =
        rankOneMatrix
          (localOptimalMultiplicityVector (Fintype.card a)))
    (hzeroPM :
      dotProduct (star resource.amp)
        ((outputTraceSectorCoefficient
          (physicalBranchOutputTrace S) sectorPM).mulVec resource.amp) = 0)
    (hzeroMP :
      dotProduct (star resource.amp)
        ((outputTraceSectorCoefficient
          (physicalBranchOutputTrace S) sectorMP).mulVec resource.amp) = 0) :
    CompressedPPTInstrumentData (Fintype.card a) ra rb := by
  have hSuccessD2 : PaperOutputTraceD2Certificate S :=
    physicalInvariantPPT_outputTrace_D2_certificate_paper
      hcardA hcardB hcardEq hSinvariant hSpos hSppt
  have hContraction :=
    physicalInvariantPPTBranch_contractionCertificate
      hcardA hcardB hSinvariant hSpos hSppt
  have hCoefficientComplete (z : LocalMultiplicitySector) :
      outputTraceSectorCoefficient (physicalBranchOutputTrace S) z +
          outputTraceSectorCoefficient (physicalBranchOutputTrace F) z =
        (1 : CMatrix (ra × rb)) := by
    have h := congrArg
      (fun T => outputTraceSectorCoefficient T z) hcomplete
    change outputTraceSectorCoefficient
        (physicalBranchOutputTrace S + physicalBranchOutputTrace F) z =
      outputTraceSectorCoefficient
        (1 : CMatrix
          (JointContractionInputResourceIndex a b (ra × rb))) z at h
    rw [outputTraceSectorCoefficient_add,
      outputTraceSectorCoefficient_one hcardA hcardB] at h
    exact h
  refine
    { resource := resource
      success := jointContractionSchurCoefficient S
      outputSuccess := fun z =>
        outputTraceSectorCoefficient (physicalBranchOutputTrace S) z
      outputFailure := fun z =>
        outputTraceSectorCoefficient (physicalBranchOutputTrace F) z
      residualSuccess := fun z =>
        outputTraceSectorCoefficient
          (physicalBranchOutputTrace (jointContractionResidual S)) z
      success_branchPPT := hContraction.2.2.2.2
      outputSuccess_pos := hSuccessD2.sector_coefficient_posSemidef
      outputFailure_pos := ?_
      outputFailure_ppt := ?_
      output_complement := hCoefficientComplete
      success_trace_decomposition :=
        hSuccessD2.sector_coefficient_decomposition
      residualSuccess_pos :=
        hSuccessD2.residual_sector_coefficient_posSemidef
      inserted_optimal := hinserted
      zero_output_PM := hzeroPM
      zero_output_MP := hzeroMP }
  · intro z
    exact outputTraceSectorCoefficient_posSemidef hcardA hcardB
      (physicalBranchOutputTrace_posSemidef hFpos) z
  · intro z
    exact
      physicalPPT_outputTrace_sectorCoefficient_partialTransposeB_posSemidef
        hcardA hcardB hFppt z

/-- Consequently the auxiliary operator `N` attached to the constructed
physical success/failure data is an effect.  This is obtained from the
existing effect theorem; effecthood itself is not an input premise. -/
theorem physicalOutputCompressedData_auxiliaryEffect_isEffect
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (hcardEq : Fintype.card b = Fintype.card a)
    (resource : PureVector (ra × rb))
    {S F : CMatrix (JointContractionPhysicalIndex a b (ra × rb))}
    (hSinvariant : JointContractionPhysicalInvariant S)
    (hSpos : S.PosSemidef) (hFpos : F.PosSemidef)
    (hSppt : (physicalBranchPartialTransposeB S).PosSemidef)
    (hFppt : (physicalBranchPartialTransposeB F).PosSemidef)
    (hcomplete :
      physicalBranchOutputTrace S + physicalBranchOutputTrace F =
        (1 : CMatrix
          (JointContractionInputResourceIndex a b (ra × rb))))
    (hinserted :
      insertPureResourceBlock resource.amp
          (jointContractionSchurCoefficient S) =
        rankOneMatrix
          (localOptimalMultiplicityVector (Fintype.card a)))
    (hzeroPM :
      dotProduct (star resource.amp)
        ((outputTraceSectorCoefficient
          (physicalBranchOutputTrace S) sectorPM).mulVec resource.amp) = 0)
    (hzeroMP :
      dotProduct (star resource.amp)
        ((outputTraceSectorCoefficient
          (physicalBranchOutputTrace S) sectorMP).mulVec resource.amp) = 0) :
    IsEffectMatrix
      (physicalOutputCompressedData
        hcardA hcardB hcardEq resource hSinvariant hSpos hFpos hSppt hFppt
          hcomplete hinserted hzeroPM hzeroMP).auxiliaryEffect := by
  let data := physicalOutputCompressedData
    hcardA hcardB hcardEq resource hSinvariant hSpos hFpos hSppt hFppt
      hcomplete hinserted hzeroPM hzeroMP
  exact data.auxiliaryEffect_isEffect hcardA

end

end EntanglementPurification
