import EntanglementPurification.OrderedSchmidtIsometry
import EntanglementPurification.MajorizationConsequences
import EntanglementPurification.PPTSchmidtCertificate
import QIT.Channels.Diamond
import Mathlib.Tactic

/-!
# Zero padding and the signed Schmidt phase

This module supplies the elementary coordinate changes used to feed an
arbitrary finite Schmidt decomposition to the Appendix-B converse.  Three
zero coordinates are appended, and the paper's minus signs are absorbed by a
diagonal local phase isometry.
-/

namespace EntanglementPurification

open QIT

noncomputable section

open scoped BigOperators

/-- Appending zero coordinates preserves the ordered-probability property. -/
theorem zeroPad_isOrderedProbability {n : ℕ} (r : ℕ) (p : Fin n → ℝ)
    (hp : IsOrderedProbability p) :
    IsOrderedProbability (zeroPad r p) := by
  refine ⟨?_, ?_, zeroPad_total r p |>.trans hp.2.2⟩
  · intro i j hij
    cases i using Fin.addCases with
    | left i =>
        cases j using Fin.addCases with
        | left j =>
            simpa [zeroPad] using hp.1 (by simpa using hij)
        | right j =>
            simpa [zeroPad] using hp.2.1 i
    | right i =>
        cases j using Fin.addCases with
        | left j =>
            exfalso
            change n + i.val ≤ j.val at hij
            omega
        | right j => simp [zeroPad]
  · intro i
    cases i using Fin.addCases with
    | left i => simpa [zeroPad] using hp.2.1 i
    | right i => simp [zeroPad]

/-- The canonical inclusion of the old Schmidt basis into a zero-padded one. -/
def zeroPadReferenceIsometry (n r : ℕ) :
    ReferenceIsometry (Fin n) (Fin (n + r)) :=
  ReferenceIsometry.ofInjective (Fin.castAdd r) (Fin.castAdd_injective n r)

/-- Applying the canonical inclusion on both factors turns a positive Schmidt
vector into its zero-padded positive Schmidt vector. -/
theorem zeroPadReferenceIsometry_apply_orderedPositiveSchmidtResource
    {n : ℕ} (r : ℕ) (p : Fin n → ℝ) (hp : IsOrderedProbability p) :
    let hpPad := zeroPad_isOrderedProbability r p hp
    (zeroPadReferenceIsometry n r).applyPureVector
        ((zeroPadReferenceIsometry n r).applyPureVectorRight
          (orderedPositiveSchmidtResource p hp)) =
      orderedPositiveSchmidtResource (zeroPad r p) hpPad := by
  dsimp
  apply PureVector.ext_amp
  funext x
  rcases x with ⟨i, j⟩
  cases i using Fin.addCases with
  | left i =>
      cases j using Fin.addCases with
      | left j =>
          by_cases hij : i = j
          · subst j
            simp [zeroPadReferenceIsometry,
              ReferenceIsometry.applyPureVector_amp,
              ReferenceIsometry.applyPureVectorRight_amp,
              ReferenceIsometry.applyAmp, ReferenceIsometry.applyAmpRight,
              ReferenceIsometry.ofInjective, Matrix.mulVec, dotProduct,
              orderedPositiveSchmidtResource, orderedPositiveSchmidtAmp,
              zeroPad]
          · simp [zeroPadReferenceIsometry,
              ReferenceIsometry.applyPureVector_amp,
              ReferenceIsometry.applyPureVectorRight_amp,
              ReferenceIsometry.applyAmp, ReferenceIsometry.applyAmpRight,
              ReferenceIsometry.ofInjective, Matrix.mulVec, dotProduct,
              orderedPositiveSchmidtResource, orderedPositiveSchmidtAmp,
              zeroPad, hij]
      | right j =>
          have hdisjoint (x : Fin n) :
              Fin.natAdd n j ≠ Fin.castAdd r x := by
            intro h
            have := congrArg Fin.val h
            simp at this
            omega
          have hdisjoint' :
              Fin.castAdd r i ≠ Fin.natAdd n j := Ne.symm (hdisjoint i)
          simp [zeroPadReferenceIsometry,
            ReferenceIsometry.applyPureVector_amp,
            ReferenceIsometry.applyPureVectorRight_amp,
            ReferenceIsometry.applyAmp, ReferenceIsometry.applyAmpRight,
            ReferenceIsometry.ofInjective, Matrix.mulVec, dotProduct,
            orderedPositiveSchmidtResource, orderedPositiveSchmidtAmp,
            zeroPad, hdisjoint, hdisjoint']
  | right i =>
      cases j using Fin.addCases with
      | left j =>
          have hdisjoint :
              Fin.natAdd n i ≠ Fin.castAdd r j := by
            intro h
            have := congrArg Fin.val h
            simp at this
            omega
          simp [zeroPadReferenceIsometry,
            ReferenceIsometry.applyPureVector_amp,
            ReferenceIsometry.applyPureVectorRight_amp,
            ReferenceIsometry.applyAmp, ReferenceIsometry.applyAmpRight,
            ReferenceIsometry.ofInjective, Matrix.mulVec, dotProduct,
            orderedPositiveSchmidtResource, orderedPositiveSchmidtAmp,
            zeroPad, hdisjoint]
      | right j =>
          have hdisjoint (x : Fin n) :
              Fin.natAdd n j ≠ Fin.castAdd r x := by
            intro h
            have := congrArg Fin.val h
            simp at this
            omega
          simp [zeroPadReferenceIsometry,
            ReferenceIsometry.applyPureVector_amp,
            ReferenceIsometry.applyPureVectorRight_amp,
            ReferenceIsometry.applyAmp, ReferenceIsometry.applyAmpRight,
            ReferenceIsometry.ofInjective, Matrix.mulVec, dotProduct,
            orderedPositiveSchmidtResource, orderedPositiveSchmidtAmp,
            zeroPad, hdisjoint]

/-- The real diagonal phase `diag(1,-1,-1,...)`. -/
def signedSchmidtPhase (m : ℕ) :
    ReferenceIsometry (Fin (m + 3)) (Fin (m + 3)) where
  matrix i j := if i = j then if j = 0 then 1 else -1 else 0
  isometry := by
    ext i j
    by_cases hij : i = j
    · subst j
      rw [Matrix.mul_apply]
      rw [Finset.sum_eq_single i]
      · by_cases hi0 : i = 0 <;>
          simp [Matrix.conjTranspose, hi0]
      · intro k hk hki
        have hik : i ≠ k := Ne.symm hki
        simp [Matrix.conjTranspose, hki]
      · exact fun h => False.elim (h (Finset.mem_univ i))
    · rw [Matrix.mul_apply]
      rw [Finset.sum_eq_zero]
      · simp [hij]
      · intro k hk
        by_cases hki : k = i
        · subst k
          simp [Matrix.conjTranspose, hij]
        · simp [Matrix.conjTranspose, hki]

/-- The paper's signed Schmidt vector becomes the positive Schmidt vector
after applying `diag(1,-1,-1,...)` on the left factor. -/
theorem signedSchmidtPhase_apply_ambientSignedSchmidtResource
    {m : ℕ} (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p) :
    (signedSchmidtPhase m).applyPureVector
        ((ReferenceIsometry.ofEquiv (Equiv.refl (Fin (m + 3)))).applyPureVectorRight
          (ambientSignedSchmidtResource p hp)) =
      orderedPositiveSchmidtResource p hp := by
  apply PureVector.ext_amp
  funext x
  rcases x with ⟨i, j⟩
  by_cases hij : i = j
  · subst j
    by_cases hi0 : i = 0
    · subst i
      simp only [signedSchmidtPhase, ReferenceIsometry.applyPureVector_amp,
        ReferenceIsometry.applyPureVectorRight_amp,
        ReferenceIsometry.applyAmp, ReferenceIsometry.applyAmpRight,
        ReferenceIsometry.ofEquiv, Matrix.mulVec, dotProduct,
        ambientSignedSchmidtResource, ambientSignedSchmidtAmp,
        orderedPositiveSchmidtResource, orderedPositiveSchmidtAmp]
      rw [Finset.sum_eq_single 0]
      · simp
      · intro k hk hk0
        simp [hk0, Ne.symm hk0]
      · exact fun h => False.elim (h (Finset.mem_univ 0))
    · simp only [signedSchmidtPhase, ReferenceIsometry.applyPureVector_amp,
        ReferenceIsometry.applyPureVectorRight_amp,
        ReferenceIsometry.applyAmp, ReferenceIsometry.applyAmpRight,
        ReferenceIsometry.ofEquiv, Matrix.mulVec, dotProduct,
        ambientSignedSchmidtResource, ambientSignedSchmidtAmp,
        orderedPositiveSchmidtResource, orderedPositiveSchmidtAmp]
      rw [Finset.sum_eq_single i]
      · simp [hi0]
      · intro k hk hki
        have hik : i ≠ k := Ne.symm hki
        simp [hik]
      · exact fun h => False.elim (h (Finset.mem_univ i))
  · simp only [signedSchmidtPhase, ReferenceIsometry.applyPureVector_amp,
      ReferenceIsometry.applyPureVectorRight_amp,
      ReferenceIsometry.applyAmp, ReferenceIsometry.applyAmpRight,
      ReferenceIsometry.ofEquiv, Matrix.mulVec, dotProduct,
      ambientSignedSchmidtResource, ambientSignedSchmidtAmp,
      orderedPositiveSchmidtResource, orderedPositiveSchmidtAmp]
    rw [if_neg hij]
    apply Finset.sum_eq_zero
    intro k hk
    by_cases hki : k = i
    · subst k
      simp [Ne.symm hij]
    · have hik : i ≠ k := Ne.symm hki
      simp [hik]

end

end EntanglementPurification
