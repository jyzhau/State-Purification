import EntanglementPurification.GlobalHaarPerformance
import EntanglementPurification.GlobalChoiObjective
import Mathlib.Tactic

/-!
# The original Haar-integral performance operator (equation 986)

This file starts from the unexpanded noisy-state integrand in equation 986 of
`main.tex`.  It proves that its unitary-Haar integral is exactly the
moment-expanded operator used by the global SDP proof in
`GlobalHaarPerformance.lean`.
-/

namespace EntanglementPurification

open QIT
open MeasureTheory
open scoped ComplexOrder MatrixOrder Matrix.Norms.L2Operator

noncomputable section

universe u

variable {x : Type u} [Fintype x] [DecidableEq x] [Nonempty x]

/-- The pure state `U |nu><nu| U^dagger` sampled along a unitary Haar orbit. -/
def globalHaarOrbitPureMatrix (nu : PureVector x)
    (U : Matrix.unitaryGroup x ℂ) : CMatrix x :=
  (U : CMatrix x) * rankOneMatrix nu.amp *
    star (U : CMatrix x)

/-- Equation `eq:gd_noise_channel`, evaluated on a pure Haar-orbit state. -/
def globalDepolarizedOrbitMatrix (nu : PureVector x) (gamma : ℝ)
    (U : Matrix.unitaryGroup x ℂ) : CMatrix x :=
  (1 - gamma) • globalHaarOrbitPureMatrix nu U +
    (gamma / (Fintype.card x : ℝ)) • (1 : CMatrix x)

/-- The pointwise matrix integrand in equation `eq:gd_global_performance_operator`
(equation 986): `(N^gamma(psi) tensor N^gamma(psi))^T tensor (psi - F I)`. -/
def globalEq986Integrand (nu : PureVector x) (gamma : ℝ)
    (U : Matrix.unitaryGroup x ℂ) : CMatrix (GlobalThreeLeg x) :=
  Matrix.kronecker
      (Matrix.kronecker
        (globalDepolarizedOrbitMatrix nu gamma U)
        (globalDepolarizedOrbitMatrix nu gamma U)).transpose
      (globalHaarOrbitPureMatrix nu U -
        globalNoiseFidelity (Fintype.card x : ℝ) gamma •
          (1 : CMatrix x))

/-- The original, unexpanded performance operator from equation 986. -/
def globalEq986PerformanceOperator (nu : PureVector x) (gamma : ℝ) :
    CMatrix (GlobalThreeLeg x) :=
  ∫ U : Matrix.unitaryGroup x ℂ,
    globalEq986Integrand nu gamma U
      ∂unitaryHaarMeasure (a := x)

private theorem reindex_tensorPowerKroneckerTwo
    (P : CMatrix x) :
    reindexTensorPowerTwo (tensorPowerKroneckerTwo (a := x) P) =
      Matrix.kronecker P P := by
  ext p q
  rcases p with ⟨i, j⟩
  rcases q with ⟨k, l⟩
  simp [reindexTensorPowerTwo, Matrix.reindex_apply,
    tensorPowerTwoEquiv_symm_apply, Matrix.kronecker]

private theorem unitaryTensorPowerMatrix_two_eq
    (U : Matrix.unitaryGroup x ℂ) :
    (unitaryTensorPowerMatrix U 2 : CMatrix (TensorPower x 2)) =
      tensorPowerKroneckerTwo (a := x) (U : CMatrix x) := by
  ext p q
  simp [unitaryTensorPowerMatrix_apply_eq_fin_prod,
    tensorPowerKroneckerTwo]

private theorem rankOne_tensorPower_two_eq
    (nu : PureVector x) :
    rankOneMatrix (nu.tensorPower 2).amp =
      tensorPowerKroneckerTwo (a := x) (rankOneMatrix nu.amp) := by
  ext p q
  rw [rankOneMatrix_apply,
    PureVector.tensorPower_amp_eq_fin_prod nu 2 p,
    PureVector.tensorPower_amp_eq_fin_prod nu 2 q]
  simp [tensorPowerKroneckerTwo, rankOneMatrix_apply]
  ring

private theorem star_tensorPowerKroneckerTwo
    (P : CMatrix x) :
    star (tensorPowerKroneckerTwo (a := x) P) =
      tensorPowerKroneckerTwo (a := x) (star P) := by
  ext p q
  simp [tensorPowerKroneckerTwo]

private theorem orbit_pair_eq_reindex_renner
    (nu : PureVector x) (U : Matrix.unitaryGroup x ℂ) :
    Matrix.kronecker
        (globalHaarOrbitPureMatrix nu U)
        (globalHaarOrbitPureMatrix nu U) =
      reindexTensorPowerTwo
        (rennerMIIDProjectorZero (a := x) 2 nu U) := by
  rw [rennerMIIDProjectorZero_eq_unitary_rankOneTensorPower,
    unitaryTensorPowerMatrix_two_eq, rankOne_tensorPower_two_eq,
    star_tensorPowerKroneckerTwo,
    tensorPowerKroneckerTwo_mul, tensorPowerKroneckerTwo_mul,
    reindex_tensorPowerKroneckerTwo]
  rfl

private def tensorPowerKroneckerThree (P : CMatrix x) :
    CMatrix (TensorPower x 3) :=
  fun p q =>
    P (tensorPowerEquiv 3 p 0) (tensorPowerEquiv 3 q 0) *
      P (tensorPowerEquiv 3 p 1) (tensorPowerEquiv 3 q 1) *
      P (tensorPowerEquiv 3 p 2) (tensorPowerEquiv 3 q 2)

private theorem reindex_tensorPowerKroneckerThree
    (P : CMatrix x) :
    (Matrix.reindexAlgEquiv ℂ ℂ tensorPowerThreeEquiv)
        (tensorPowerKroneckerThree P) =
      Matrix.kronecker (Matrix.kronecker P P) P := by
  ext p q
  rcases p with ⟨⟨i, j⟩, k⟩
  rcases q with ⟨⟨l, m⟩, n⟩
  simp [Matrix.reindex_apply,
    tensorPowerThreeEquiv, tensorPowerThreeWord,
    tensorPowerKroneckerThree, Matrix.kronecker]

private theorem unitaryTensorPowerMatrix_three_eq
    (U : Matrix.unitaryGroup x ℂ) :
    (unitaryTensorPowerMatrix U 3 : CMatrix (TensorPower x 3)) =
      tensorPowerKroneckerThree (U : CMatrix x) := by
  ext p q
  rw [unitaryTensorPowerMatrix_apply_eq_fin_prod,
    Fin.prod_univ_three]
  rfl

private theorem rankOne_tensorPower_three_eq
    (nu : PureVector x) :
    rankOneMatrix (nu.tensorPower 3).amp =
      tensorPowerKroneckerThree (rankOneMatrix nu.amp) := by
  ext p q
  rw [rankOneMatrix_apply,
    PureVector.tensorPower_amp_eq_fin_prod nu 3 p,
    PureVector.tensorPower_amp_eq_fin_prod nu 3 q]
  rw [Fin.prod_univ_three, Fin.prod_univ_three]
  rw [star_mul', star_mul']
  simp only [tensorPowerKroneckerThree, rankOneMatrix_apply]
  ring

private theorem star_tensorPowerKroneckerThree
    (P : CMatrix x) :
    star (tensorPowerKroneckerThree P) =
      tensorPowerKroneckerThree (star P) := by
  ext p q
  simp [tensorPowerKroneckerThree]

private theorem orbit_triple_eq_reindex_renner
    (nu : PureVector x) (U : Matrix.unitaryGroup x ℂ) :
    Matrix.kronecker
        (Matrix.kronecker
          (globalHaarOrbitPureMatrix nu U)
          (globalHaarOrbitPureMatrix nu U))
        (globalHaarOrbitPureMatrix nu U) =
      reindexTensorPowerThree
        (rennerMIIDProjectorZero (a := x) 3 nu U) := by
  rw [rennerMIIDProjectorZero_eq_unitary_rankOneTensorPower,
    unitaryTensorPowerMatrix_three_eq, rankOne_tensorPower_three_eq,
    star_tensorPowerKroneckerThree]
  change _ = (Matrix.reindexAlgEquiv ℂ ℂ tensorPowerThreeEquiv)
    (tensorPowerKroneckerThree (U : CMatrix x) *
      tensorPowerKroneckerThree (rankOneMatrix nu.amp) *
      tensorPowerKroneckerThree (star (U : CMatrix x)))
  rw [map_mul, map_mul, reindex_tensorPowerKroneckerThree,
    reindex_tensorPowerKroneckerThree,
    reindex_tensorPowerKroneckerThree]
  have hmul1 :
      Matrix.kronecker
          (Matrix.kronecker (U : CMatrix x) (U : CMatrix x))
          (U : CMatrix x) *
        Matrix.kronecker
          (Matrix.kronecker (rankOneMatrix nu.amp) (rankOneMatrix nu.amp))
          (rankOneMatrix nu.amp) =
      Matrix.kronecker
          (Matrix.kronecker ((U : CMatrix x) * rankOneMatrix nu.amp)
            ((U : CMatrix x) * rankOneMatrix nu.amp))
          ((U : CMatrix x) * rankOneMatrix nu.amp) := by
    calc
      _ = Matrix.kronecker
          (Matrix.kronecker (U : CMatrix x) (U : CMatrix x) *
            Matrix.kronecker (rankOneMatrix nu.amp) (rankOneMatrix nu.amp))
          ((U : CMatrix x) * rankOneMatrix nu.amp) :=
        (Matrix.mul_kronecker_mul
          (Matrix.kronecker (U : CMatrix x) (U : CMatrix x))
          (Matrix.kronecker (rankOneMatrix nu.amp) (rankOneMatrix nu.amp))
          (U : CMatrix x) (rankOneMatrix nu.amp)).symm
      _ = _ := by
        congr 1
        exact (Matrix.mul_kronecker_mul
          (U : CMatrix x) (rankOneMatrix nu.amp)
          (U : CMatrix x) (rankOneMatrix nu.amp)).symm
  rw [hmul1]
  symm
  calc
    _ = Matrix.kronecker
        ((Matrix.kronecker
            ((U : CMatrix x) * rankOneMatrix nu.amp)
            ((U : CMatrix x) * rankOneMatrix nu.amp)) *
          Matrix.kronecker
            (star (U : CMatrix x)) (star (U : CMatrix x)))
        (((U : CMatrix x) * rankOneMatrix nu.amp) *
          star (U : CMatrix x)) :=
      (Matrix.mul_kronecker_mul
        (Matrix.kronecker
          ((U : CMatrix x) * rankOneMatrix nu.amp)
          ((U : CMatrix x) * rankOneMatrix nu.amp))
        (Matrix.kronecker (star (U : CMatrix x)) (star (U : CMatrix x)))
        ((U : CMatrix x) * rankOneMatrix nu.amp)
        (star (U : CMatrix x))).symm
    _ = _ := by
      congr 1
      exact (Matrix.mul_kronecker_mul
        ((U : CMatrix x) * rankOneMatrix nu.amp) (star (U : CMatrix x))
        ((U : CMatrix x) * rankOneMatrix nu.amp) (star (U : CMatrix x))).symm

/-- The cubic pure-state term in the pointwise expansion of equation 986. -/
def globalEq986ThreeTerm (rho : CMatrix x) :
    CMatrix (GlobalThreeLeg x) :=
  Matrix.kronecker (Matrix.kronecker rho rho).transpose rho

/-- The second moment on the two input legs in equation 986. -/
def globalEq986Pair12Term (rho : CMatrix x) :
    CMatrix (GlobalThreeLeg x) :=
  Matrix.kronecker (Matrix.kronecker rho rho).transpose (1 : CMatrix x)

/-- The second moment on the first input and output legs in equation 986. -/
def globalEq986Pair13Term (rho : CMatrix x) :
    CMatrix (GlobalThreeLeg x) :=
  Matrix.kronecker
    (Matrix.kronecker rho (1 : CMatrix x)).transpose rho

/-- The second moment on the second input and output legs in equation 986. -/
def globalEq986Pair23Term (rho : CMatrix x) :
    CMatrix (GlobalThreeLeg x) :=
  Matrix.kronecker
    (Matrix.kronecker (1 : CMatrix x) rho).transpose rho

/-- The first-moment term on the first input leg in equation 986. -/
def globalEq986Single1Term (rho : CMatrix x) :
    CMatrix (GlobalThreeLeg x) :=
  Matrix.kronecker
    (Matrix.kronecker rho (1 : CMatrix x)).transpose (1 : CMatrix x)

/-- The first-moment term on the second input leg in equation 986. -/
def globalEq986Single2Term (rho : CMatrix x) :
    CMatrix (GlobalThreeLeg x) :=
  Matrix.kronecker
    (Matrix.kronecker (1 : CMatrix x) rho).transpose (1 : CMatrix x)

/-- The first-moment term on the output leg in equation 986. -/
def globalEq986Single3Term (rho : CMatrix x) :
    CMatrix (GlobalThreeLeg x) :=
  Matrix.kronecker
    (Matrix.kronecker (1 : CMatrix x) (1 : CMatrix x)).transpose rho

/-- The three-leg identity written in the same Kronecker convention as
equation 986. -/
def globalEq986ConstantTerm : CMatrix (GlobalThreeLeg x) :=
  Matrix.kronecker
    (Matrix.kronecker (1 : CMatrix x) (1 : CMatrix x)).transpose
    (1 : CMatrix x)

omit [Nonempty x] in
/-- Pointwise eight-term expansion of the original equation-986 integrand. -/
theorem globalEq986Integrand_eight_term_expansion
    (nu : PureVector x) (gamma : ℝ) (U : Matrix.unitaryGroup x ℂ) :
    let rho := globalHaarOrbitPureMatrix nu U
    let a : ℝ := 1 - gamma
    let b : ℝ := gamma / (Fintype.card x : ℝ)
    let F : ℝ := globalNoiseFidelity (Fintype.card x : ℝ) gamma
    globalEq986Integrand nu gamma U =
      a ^ 2 • globalEq986ThreeTerm rho -
        (F * a ^ 2) • globalEq986Pair12Term rho +
      (a * b) • globalEq986Pair13Term rho +
      (a * b) • globalEq986Pair23Term rho -
        (F * a * b) • globalEq986Single1Term rho -
        (F * a * b) • globalEq986Single2Term rho +
      b ^ 2 • globalEq986Single3Term rho -
        (F * b ^ 2) • globalEq986ConstantTerm := by
  dsimp
  ext p q
  rcases p with ⟨⟨i₁, i₂⟩, o⟩
  rcases q with ⟨⟨j₁, j₂⟩, r⟩
  simp only [globalEq986Integrand, globalDepolarizedOrbitMatrix,
    globalEq986ThreeTerm, globalEq986Pair12Term,
    globalEq986Pair13Term, globalEq986Pair23Term,
    globalEq986Single1Term, globalEq986Single2Term,
    globalEq986Single3Term, globalEq986ConstantTerm,
    Matrix.kronecker, Matrix.kroneckerMap_apply,
    Matrix.transpose_apply, Matrix.add_apply, Matrix.sub_apply,
    Matrix.smul_apply, Complex.real_smul]
  push_cast
  ring

end

end EntanglementPurification
