import EntanglementPurification.PhysicalLocalTwirl
import EntanglementPurification.PhysicalResourceInsertion

/-!
# Pure-resource insertion and the physical local Haar twirl

The local mixed representations act trivially on the resource register.
Consequently sandwiching by a fixed resource vector commutes with every
pointwise local conjugation and, by continuity and linearity, with both Haar
integrals.
-/

namespace EntanglementPurification

open QIT
open MeasureTheory
open scoped ComplexOrder MatrixOrder Matrix.Norms.L2Operator

noncomputable section

universe uA uB uR uX

variable {a : Type uA} {b : Type uB} {r : Type uR}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

local instance physicalLocalTwirlResourceCMatrixContinuousENorm
    {i : Type uX} [Fintype i] [DecidableEq i] :
    ContinuousENorm (CMatrix i) :=
  SeminormedAddGroup.toContinuousENorm

/-- The local mixed representation after the resource register has been
inserted. -/
def jointContractionUnassistedPhysicalRepresentation
    (U : Matrix.unitaryGroup a Complex)
    (V : Matrix.unitaryGroup b Complex) :
    CMatrix (JointContractionUnassistedPhysicalIndex a b) :=
  Matrix.kronecker
    (localMixedSchurRepresentation U)
    (localMixedSchurRepresentation V)

def physicalAliceUnassistedMixedRepresentation
    (U : Matrix.unitaryGroup a Complex) :
    CMatrix (JointContractionUnassistedPhysicalIndex a b) :=
  jointContractionUnassistedPhysicalRepresentation U 1

def physicalBobUnassistedMixedRepresentation
    (V : Matrix.unitaryGroup b Complex) :
    CMatrix (JointContractionUnassistedPhysicalIndex a b) :=
  jointContractionUnassistedPhysicalRepresentation 1 V

def physicalAliceUnassistedTwirlIntegrand
    (J : CMatrix (JointContractionUnassistedPhysicalIndex a b))
    (U : Matrix.unitaryGroup a Complex) :
    CMatrix (JointContractionUnassistedPhysicalIndex a b) :=
  physicalAliceUnassistedMixedRepresentation (b := b) U * J *
    star (physicalAliceUnassistedMixedRepresentation (b := b) U)

def physicalBobUnassistedTwirlIntegrand
    (J : CMatrix (JointContractionUnassistedPhysicalIndex a b))
    (V : Matrix.unitaryGroup b Complex) :
    CMatrix (JointContractionUnassistedPhysicalIndex a b) :=
  physicalBobUnassistedMixedRepresentation (a := a) V * J *
    star (physicalBobUnassistedMixedRepresentation (a := a) V)

def physicalAliceUnassistedTwirl [Nonempty a] [Nonempty b]
    (J : CMatrix (JointContractionUnassistedPhysicalIndex a b)) :
    CMatrix (JointContractionUnassistedPhysicalIndex a b) :=
  ∫ U : Matrix.unitaryGroup a Complex,
    physicalAliceUnassistedTwirlIntegrand J U
      ∂unitaryHaarMeasure (a := a)

def physicalBobUnassistedTwirl [Nonempty a] [Nonempty b]
    (J : CMatrix (JointContractionUnassistedPhysicalIndex a b)) :
    CMatrix (JointContractionUnassistedPhysicalIndex a b) :=
  ∫ V : Matrix.unitaryGroup b Complex,
    physicalBobUnassistedTwirlIntegrand J V
      ∂unitaryHaarMeasure (a := b)

def physicalLocalUnassistedTwirl [Nonempty a] [Nonempty b]
    (J : CMatrix (JointContractionUnassistedPhysicalIndex a b)) :
    CMatrix (JointContractionUnassistedPhysicalIndex a b) :=
  physicalAliceUnassistedTwirl (physicalBobUnassistedTwirl J)

private theorem resourceExtension_mul_embedding
    (eta : r → Complex)
    (A : CMatrix (JointContractionUnassistedPhysicalIndex a b)) :
    Matrix.kronecker A (1 : CMatrix r) *
        physicalResourceInsertionEmbedding eta =
      physicalResourceInsertionEmbedding eta * A := by
  ext p q
  rcases p with ⟨p, z⟩
  simp [Matrix.mul_apply, Matrix.kronecker,
    physicalResourceInsertionEmbedding, Fintype.sum_prod_type,
    Matrix.one_apply]
  ring

/-- A resource sandwich commutes with conjugation by an arbitrary operator
on the non-resource physical space. -/
theorem physicalPureResourceInsert_resourceExtension_conj
    (eta : r → Complex)
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (A : CMatrix (JointContractionUnassistedPhysicalIndex a b)) :
    physicalPureResourceInsert eta
        (Matrix.kronecker A (1 : CMatrix r) * K *
          Matrix.conjTranspose (Matrix.kronecker A (1 : CMatrix r))) =
      A * physicalPureResourceInsert eta K * Matrix.conjTranspose A := by
  let E : Matrix (JointContractionPhysicalIndex a b r)
      (JointContractionUnassistedPhysicalIndex a b) Complex :=
    physicalResourceInsertionEmbedding (a := a) (b := b) eta
  let G : CMatrix (JointContractionPhysicalIndex a b r) :=
    Matrix.kronecker A (1 : CMatrix r)
  have hright :
      Matrix.conjTranspose G * E =
        E * Matrix.conjTranspose A := by
    dsimp only [G]
    unfold Matrix.kronecker
    rw [Matrix.conjTranspose_kronecker]
    simp only [Matrix.conjTranspose_one]
    exact resourceExtension_mul_embedding (r := r) eta
      (a := a) (b := b) (Matrix.conjTranspose A)
  have hleft :
      Matrix.conjTranspose E * G =
        A * Matrix.conjTranspose E := by
    have h := congrArg Matrix.conjTranspose hright
    simpa [Matrix.conjTranspose_mul] using h
  unfold physicalPureResourceInsert
  change Matrix.conjTranspose E *
      (G * K * Matrix.conjTranspose G) * E =
    A * (Matrix.conjTranspose E * K * E) * Matrix.conjTranspose A
  calc
    Matrix.conjTranspose E *
        (G * K * Matrix.conjTranspose G) * E =
      Matrix.conjTranspose E * ((G * K * Matrix.conjTranspose G) * E) :=
        Matrix.mul_assoc _ _ _
    _ = Matrix.conjTranspose E *
        ((G * K) * (Matrix.conjTranspose G * E)) :=
      congrArg (fun X => Matrix.conjTranspose E * X)
        (Matrix.mul_assoc (G * K) (Matrix.conjTranspose G) E)
    _ = Matrix.conjTranspose E *
        (G * (K * (Matrix.conjTranspose G * E))) :=
      congrArg (fun X => Matrix.conjTranspose E * X)
        (Matrix.mul_assoc G K (Matrix.conjTranspose G * E))
    _ = (Matrix.conjTranspose E * G) *
        (K * (Matrix.conjTranspose G * E)) :=
      (Matrix.mul_assoc _ _ _).symm
    _ = (A * Matrix.conjTranspose E) * K *
        (Matrix.conjTranspose G * E) := by
      rw [hleft]
      exact (Matrix.mul_assoc _ _ _).symm
    _ = (A * Matrix.conjTranspose E) * K *
        (E * Matrix.conjTranspose A) := by rw [hright]
    _ = A * (Matrix.conjTranspose E *
        (K * (E * Matrix.conjTranspose A))) := by
      rw [Matrix.mul_assoc, Matrix.mul_assoc]
    _ = A * (Matrix.conjTranspose E *
        ((K * E) * Matrix.conjTranspose A)) := by
      rw [← Matrix.mul_assoc K E (Matrix.conjTranspose A)]
    _ = A * ((Matrix.conjTranspose E * (K * E)) *
        Matrix.conjTranspose A) := by
      simp only [Matrix.mul_assoc]
    _ = A * (((Matrix.conjTranspose E * K) * E) *
        Matrix.conjTranspose A) := by
      rw [← Matrix.mul_assoc (Matrix.conjTranspose E) K E]
    _ = A * (Matrix.conjTranspose E * K * E) *
        Matrix.conjTranspose A := by
      rw [Matrix.mul_assoc A]

theorem physicalPureResourceInsert_physicalAliceTwirlIntegrand
    (eta : r → Complex)
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (U : Matrix.unitaryGroup a Complex) :
    physicalPureResourceInsert eta
        (physicalAliceTwirlIntegrand (b := b) K U) =
      physicalAliceUnassistedTwirlIntegrand
        (physicalPureResourceInsert eta K) U := by
  simpa [physicalAliceTwirlIntegrand,
    physicalAliceMixedRepresentation,
    physicalAliceUnassistedTwirlIntegrand,
    physicalAliceUnassistedMixedRepresentation,
    jointContractionPhysicalRepresentation,
    jointContractionUnassistedPhysicalRepresentation,
    Matrix.star_eq_conjTranspose] using
      (physicalPureResourceInsert_resourceExtension_conj
        (a := a) (b := b) eta K
        (physicalAliceUnassistedMixedRepresentation (b := b) U))

theorem physicalPureResourceInsert_physicalBobTwirlIntegrand
    (eta : r → Complex)
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (V : Matrix.unitaryGroup b Complex) :
    physicalPureResourceInsert eta
        (physicalBobTwirlIntegrand (a := a) K V) =
      physicalBobUnassistedTwirlIntegrand
        (physicalPureResourceInsert eta K) V := by
  simpa [physicalBobTwirlIntegrand,
    physicalBobMixedRepresentation,
    physicalBobUnassistedTwirlIntegrand,
    physicalBobUnassistedMixedRepresentation,
    jointContractionPhysicalRepresentation,
    jointContractionUnassistedPhysicalRepresentation,
    Matrix.star_eq_conjTranspose] using
      (physicalPureResourceInsert_resourceExtension_conj
        (a := a) (b := b) eta K
        (physicalBobUnassistedMixedRepresentation (a := a) V))

private noncomputable def physicalPureResourceInsertCLM
    [Nonempty a] [Nonempty b] [Nonempty r]
    (eta : r → Complex) :
    CMatrix (JointContractionPhysicalIndex a b r) →L[Complex]
      CMatrix (JointContractionUnassistedPhysicalIndex a b) :=
  LinearMap.toContinuousLinearMap
    { toFun := physicalPureResourceInsert eta
      map_add' := by
        intro X Y
        simp [physicalPureResourceInsert, Matrix.mul_add, Matrix.add_mul]
      map_smul' := by
        intro c X
        simp [physicalPureResourceInsert, Matrix.mul_smul, Matrix.smul_mul] }

private theorem physicalPureResourceInsert_integral
    [Nonempty a] [Nonempty b] [Nonempty r]
    {x : Type uX} [MeasurableSpace x] {mu : Measure x}
    (eta : r → Complex)
    {f : x → CMatrix (JointContractionPhysicalIndex a b r)}
    (hf : Integrable f mu) :
    physicalPureResourceInsert eta (∫ t, f t ∂mu) =
      ∫ t, physicalPureResourceInsert eta (f t) ∂mu := by
  simpa [physicalPureResourceInsertCLM] using
    ((physicalPureResourceInsertCLM (a := a) (b := b) eta).integral_comp_comm hf).symm

theorem physicalPureResourceInsert_physicalAliceTwirl
    [Nonempty a] [Nonempty b] [Nonempty r]
    (eta : r → Complex)
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    physicalPureResourceInsert eta (physicalAliceTwirl K) =
      physicalAliceUnassistedTwirl (physicalPureResourceInsert eta K) := by
  rw [physicalAliceTwirl]
  rw [physicalPureResourceInsert_integral eta
    (physicalAliceTwirlIntegrand_integrable K)]
  apply integral_congr_ae
  filter_upwards [] with U
  exact physicalPureResourceInsert_physicalAliceTwirlIntegrand eta K U

theorem physicalPureResourceInsert_physicalBobTwirl
    [Nonempty a] [Nonempty b] [Nonempty r]
    (eta : r → Complex)
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    physicalPureResourceInsert eta (physicalBobTwirl K) =
      physicalBobUnassistedTwirl (physicalPureResourceInsert eta K) := by
  rw [physicalBobTwirl]
  rw [physicalPureResourceInsert_integral eta
    (physicalBobTwirlIntegrand_integrable K)]
  apply integral_congr_ae
  filter_upwards [] with V
  exact physicalPureResourceInsert_physicalBobTwirlIntegrand eta K V

/-- Headline commuting square: inserting a pure resource before or after the
genuine two-sided local Haar twirl gives the same unassisted twirl. -/
theorem physicalPureResourceInsert_physicalLocalTwirl
    [Nonempty a] [Nonempty b] [Nonempty r]
    (eta : r → Complex)
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    physicalPureResourceInsert eta (physicalLocalTwirl K) =
      physicalLocalUnassistedTwirl (physicalPureResourceInsert eta K) := by
  unfold physicalLocalTwirl physicalLocalUnassistedTwirl
  rw [physicalPureResourceInsert_physicalAliceTwirl]
  rw [physicalPureResourceInsert_physicalBobTwirl]

end

end EntanglementPurification
