import EntanglementPurification.OneEPRProjectorBridge
import QIT.Protocols.LOCC
import Mathlib.Tactic

/-!
# Local-operator certificate for Algorithm 1

The complete-outcome module packages the four terminal outcomes as a genuine
`QIT.FiniteInstrument`.  This file supplies the complementary locality
certificate: after regrouping the two bipartite copies into Alice's two
systems and Bob's two systems, every controlled-copy permutation is a tensor
product of one operator on Alice and one operator on Bob.  Contracting these
local operators with the standard EPR amplitudes and the two local Hadamard
measurement amplitudes gives exactly the Kraus operator used by the complete
instrument.

This is deliberately called a `ParallelLocalEPRCertificate`, rather than a
`QIT.OneWayLOCC`.  The current Lean-QIT `OneWayLOCC` structure records only
Alice's outcome and requires Bob's conditioned operation to be trace
preserving; Algorithm 1 records terminal measurements on both sides.  The
certificate below proves the relevant local tensor factorization without
misrepresenting that more restrictive library syntax.
-/

namespace EntanglementPurification

open QIT

noncomputable section

/-- Regroup two bipartite copies from copy order
`((A1,B1),(A2,B2))` to party order `((A1,A2),(B1,B2))`. -/
def twoCopyPartyRegroupEquiv (a b : Type*) :
    ((a × b) × (a × b)) ≃ ((a × a) × (b × b)) where
  toFun p := ((p.1.1, p.2.1), (p.1.2, p.2.2))
  invFun p := ((p.1.1, p.2.1), (p.1.2, p.2.2))
  left_inv p := by rcases p with ⟨⟨a1, b1⟩, ⟨a2, b2⟩⟩; rfl
  right_inv p := by rcases p with ⟨⟨a1, a2⟩, ⟨b1, b2⟩⟩; rfl

/-- The permutation of one party's two copies selected by a classical
control bit. -/
def onePartyControlledCopySwapIndex {q : Type*}
    (control : Bool) (p : q × q) : q × q :=
  (cond control p.2 p.1, cond control p.1 p.2)

/-- Matrix of a controlled copy swap on one party only. -/
def onePartyControlledCopySwap {q : Type*} [DecidableEq q]
    (control : Bool) : CMatrix (q × q) :=
  fun row col =>
    if col = onePartyControlledCopySwapIndex control row then 1 else 0

/-- A false control leaves one party's copies unchanged. -/
theorem onePartyControlledCopySwap_false
    {q : Type*} [DecidableEq q] :
    onePartyControlledCopySwap (q := q) false = 1 := by
  ext row col
  rcases row with ⟨r1, r2⟩
  rcases col with ⟨c1, c2⟩
  simp [onePartyControlledCopySwap, onePartyControlledCopySwapIndex,
    Matrix.one_apply, Prod.ext_iff, eq_comm]

/-- A true control swaps one party's two copies. -/
theorem onePartyControlledCopySwap_true_apply
    {q : Type*} [DecidableEq q] (row col : q × q) :
    onePartyControlledCopySwap (q := q) true row col =
      if col = (row.2, row.1) then 1 else 0 := by
  simp [onePartyControlledCopySwap, onePartyControlledCopySwapIndex]

/-- A true local control is the standard swap of the party's two copies. -/
theorem onePartyControlledCopySwap_true
    {q : Type*} [DecidableEq q] :
    onePartyControlledCopySwap (q := q) true =
      globalInputPairSwap (x := q) := by
  ext row col
  simp [onePartyControlledCopySwap_true_apply, globalInputPairSwap]

/-- Every fixed-control local copy permutation is Hermitian. -/
theorem onePartyControlledCopySwap_isHermitian
    {q : Type*} [Fintype q] [DecidableEq q] (control : Bool) :
    (onePartyControlledCopySwap (q := q) control).IsHermitian := by
  cases control
  · rw [onePartyControlledCopySwap_false]
    exact Matrix.isHermitian_one
  · rw [onePartyControlledCopySwap_true]
    exact globalInputPairSwap_isHermitian

/-- Every fixed-control local copy permutation is unitary in the concrete
matrix sense needed for Kraus normalization. -/
theorem onePartyControlledCopySwap_adjoint_mul_self
    {q : Type*} [Fintype q] [DecidableEq q] (control : Bool) :
    Matrix.conjTranspose (onePartyControlledCopySwap (q := q) control) *
        onePartyControlledCopySwap control = 1 := by
  have hHerm := onePartyControlledCopySwap_isHermitian
    (q := q) control
  rw [Matrix.IsHermitian] at hHerm
  rw [hHerm]
  cases control
  · rw [onePartyControlledCopySwap_false]
    simp
  · rw [onePartyControlledCopySwap_true]
    exact globalInputPairSwap_sq

/-- The two controlled local swaps in Algorithm 1 factor as an Alice/Bob
tensor product after the explicit copy-to-party wire regrouping. -/
theorem locallyControlledCopySwap_eq_local_tensor
    {a b : Type*} [DecidableEq a] [DecidableEq b]
    (controlA controlB : Bool) :
    locallyControlledCopySwap (a := a) (b := b) controlA controlB =
      Matrix.reindex (twoCopyPartyRegroupEquiv a b).symm
        (twoCopyPartyRegroupEquiv a b).symm
        (Matrix.kronecker
          (onePartyControlledCopySwap (q := a) controlA)
          (onePartyControlledCopySwap (q := b) controlB)) := by
  cases controlA <;> cases controlB <;>
    ext ⟨⟨a1, b1⟩, ⟨a2, b2⟩⟩ ⟨⟨a1', b1'⟩, ⟨a2', b2'⟩⟩ <;>
    simp [locallyControlledCopySwap, locallyControlledCopySwapIndex,
      onePartyControlledCopySwap, onePartyControlledCopySwapIndex,
      Matrix.reindex_apply, Matrix.kronecker, Matrix.kroneckerMap_apply,
      twoCopyPartyRegroupEquiv, Prod.ext_iff, and_assoc, and_left_comm] <;>
    split_ifs <;> simp_all

/-- The local terminal operator for one party, before contraction with the
shared EPR resource.  It is the controlled copy permutation multiplied by
the corresponding Hadamard measurement amplitude. -/
def onePartyHadamardOutcomeOperator
    {q : Type*} [DecidableEq q] (outcome control : Bool) :
    CMatrix (q × q) :=
  hadamardAmp outcome control • onePartyControlledCopySwap control

/-- For either fixed input-control value, the two local Hadamard outcomes
form a complete Kraus family on that party's two-copy system. -/
theorem onePartyHadamardOutcomeOperator_krausAdjoint_one
    {q : Type*} [Fintype q] [DecidableEq q] (control : Bool) :
    MatrixMap.krausAdjoint
        (fun outcome : Bool =>
          onePartyHadamardOutcomeOperator (q := q) outcome control)
        (1 : CMatrix (q × q)) = 1 := by
  have hU := onePartyControlledCopySwap_adjoint_mul_self
    (q := q) control
  have hs' :
      TwoQubit.invSqrtTwo * star TwoQubit.invSqrtTwo =
        (1 / 2 : ℂ) := by
    rw [TwoQubit.star_invSqrtTwo,
      TwoQubit.invSqrtTwo_mul_self]
  have hstarNeg :
      star (-TwoQubit.invSqrtTwo) = -TwoQubit.invSqrtTwo := by
    rw [star_neg, TwoQubit.star_invSqrtTwo]
  cases control
  · simp only [MatrixMap.krausAdjoint, Fintype.sum_bool,
      onePartyHadamardOutcomeOperator, hadamardAmp,
      Matrix.conjTranspose_smul, Matrix.mul_one, Matrix.smul_mul,
      Matrix.mul_smul, smul_smul]
    rw [hU]
    rw [hs']
    module
  · simp only [MatrixMap.krausAdjoint, Fintype.sum_bool,
      onePartyHadamardOutcomeOperator, hadamardAmp,
      Matrix.conjTranspose_smul, Matrix.mul_one, Matrix.smul_mul,
      Matrix.mul_smul, smul_smul]
    rw [hU]
    rw [hstarNeg, hs', neg_mul_neg,
      TwoQubit.invSqrtTwo_mul_self]
    module

/-- The amplitudes used for the shared control pair form a normalized
standard EPR vector. -/
theorem standardEPRAmp_normalized :
    (∑ controls : Bool × Bool,
      star (standardEPRAmp controls) * standardEPRAmp controls) = 1 := by
  simp only [Fintype.sum_prod_type, Fintype.sum_bool, standardEPRAmp,
    star_zero, zero_mul, add_zero, zero_add]
  change
    star TwoQubit.invSqrtTwo * TwoQubit.invSqrtTwo +
        star TwoQubit.invSqrtTwo * TwoQubit.invSqrtTwo = 1
  rw [TwoQubit.star_invSqrtTwo,
    TwoQubit.invSqrtTwo_mul_self]
  norm_num

/-- Joint Kraus operator obtained solely by contracting Alice's and Bob's
local terminal operators against the shared standard-EPR amplitudes. -/
def locallyFactoredOneEPROutcomeKraus
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b]
    (outcomeA outcomeB : Bool) :
    CMatrix ((a × b) × (a × b)) :=
  ∑ controlA : Bool, ∑ controlB : Bool,
    standardEPRAmp (controlA, controlB) •
      Matrix.reindex (twoCopyPartyRegroupEquiv a b).symm
        (twoCopyPartyRegroupEquiv a b).symm
        (Matrix.kronecker
          (onePartyHadamardOutcomeOperator (q := a) outcomeA controlA)
          (onePartyHadamardOutcomeOperator (q := b) outcomeB controlB))

/-- The locally factored construction is exactly the Kraus family used by
the complete four-outcome Algorithm 1 instrument. -/
theorem locallyFactoredOneEPROutcomeKraus_eq_algorithm
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b]
    (outcomeA outcomeB : Bool) :
    locallyFactoredOneEPROutcomeKraus (a := a) (b := b)
        outcomeA outcomeB =
      oneEPRHadamardOutcomeKraus (a := a) (b := b)
        outcomeA outcomeB := by
  simp only [locallyFactoredOneEPROutcomeKraus,
    oneEPRHadamardOutcomeKraus]
  apply Finset.sum_congr rfl
  intro controlA _
  apply Finset.sum_congr rfl
  intro controlB _
  rw [locallyControlledCopySwap_eq_local_tensor]
  ext row col
  simp [onePartyHadamardOutcomeOperator, Matrix.reindex_apply,
    Matrix.kronecker, Matrix.kroneckerMap_apply]
  ring

/-- A compact, checkable witness that the complete outcome Kraus family has
the Alice/Bob local structure claimed by Algorithm 1. -/
structure ParallelLocalEPRCertificate
    (a b : Type*) [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] where
  aliceOperator : Bool → Bool → CMatrix (a × a)
  bobOperator : Bool → Bool → CMatrix (b × b)
  resourceAmplitude : Bool × Bool → ℂ
  aliceOperator_eq : aliceOperator = onePartyHadamardOutcomeOperator
  bobOperator_eq : bobOperator = onePartyHadamardOutcomeOperator
  resourceAmplitude_eq : resourceAmplitude = standardEPRAmp
  resource_normalized :
    (∑ controls : Bool × Bool,
      star (resourceAmplitude controls) * resourceAmplitude controls) = 1
  alice_complete : ∀ control,
    MatrixMap.krausAdjoint
        (fun outcome : Bool => aliceOperator outcome control)
        (1 : CMatrix (a × a)) = 1
  bob_complete : ∀ control,
    MatrixMap.krausAdjoint
        (fun outcome : Bool => bobOperator outcome control)
        (1 : CMatrix (b × b)) = 1
  jointKraus_eq : ∀ outcomeA outcomeB,
    oneEPRHadamardOutcomeKraus (a := a) (b := b) outcomeA outcomeB =
      ∑ controlA : Bool, ∑ controlB : Bool,
        resourceAmplitude (controlA, controlB) •
          Matrix.reindex (twoCopyPartyRegroupEquiv a b).symm
            (twoCopyPartyRegroupEquiv a b).symm
            (Matrix.kronecker
              (aliceOperator outcomeA controlA)
              (bobOperator outcomeB controlB))

/-- The explicit local-operator witness for Algorithm 1. -/
def oneEPRParallelLocalCertificate
    (a b : Type*) [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    ParallelLocalEPRCertificate a b where
  aliceOperator := onePartyHadamardOutcomeOperator
  bobOperator := onePartyHadamardOutcomeOperator
  resourceAmplitude := standardEPRAmp
  aliceOperator_eq := rfl
  bobOperator_eq := rfl
  resourceAmplitude_eq := rfl
  resource_normalized := standardEPRAmp_normalized
  alice_complete := onePartyHadamardOutcomeOperator_krausAdjoint_one
  bob_complete := onePartyHadamardOutcomeOperator_krausAdjoint_one
  jointKraus_eq outcomeA outcomeB := by
    symm
    exact locallyFactoredOneEPROutcomeKraus_eq_algorithm outcomeA outcomeB

/-- CP map generated by one separately recorded, locally factored terminal
outcome. -/
def locallyFactoredOneEPROutcomeMap
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] (outcome : Bool × Bool) :
    MatrixMap ((a × b) × (a × b)) ((a × b) × (a × b)) :=
  MatrixMap.ofKraus (fun _ : Unit =>
    locallyFactoredOneEPROutcomeKraus (a := a) (b := b)
      outcome.1 outcome.2)

/-- At map level, the local certificate produces exactly the single-Kraus
branch used by the complete Algorithm 1 outcome instrument. -/
theorem locallyFactoredOneEPROutcomeMap_eq_algorithmKrausMap
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] (outcome : Bool × Bool) :
    locallyFactoredOneEPROutcomeMap (a := a) (b := b) outcome =
      MatrixMap.ofKraus (fun _ : Unit =>
        oneEPRHadamardOutcomeKraus (a := a) (b := b)
          outcome.1 outcome.2) := by
  simp only [locallyFactoredOneEPROutcomeMap,
    locallyFactoredOneEPROutcomeKraus_eq_algorithm]

/-- Every locally factored terminal branch is completely positive. -/
theorem locallyFactoredOneEPROutcomeMap_completelyPositive
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] (outcome : Bool × Bool) :
    MatrixMap.IsCompletelyPositive
      (locallyFactoredOneEPROutcomeMap (a := a) (b := b) outcome) :=
  MatrixMap.ofKraus_isCompletelyPositive _

end

end EntanglementPurification
