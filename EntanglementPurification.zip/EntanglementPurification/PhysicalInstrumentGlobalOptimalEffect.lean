import EntanglementPurification.PhysicalInstrumentOptimality
import EntanglementPurification.PhysicalOptimalOutputZeros
import EntanglementPurification.GlobalOptimalLocalBlock
import EntanglementPurification.PhysicalInstrumentEffect

/-!
# The canonical effect of a globally optimal physical instrument

This file assembles the operational optimality, resource-insertion, local
contraction-block, and output-sector results.  The resulting compressed data
is built from an actual `PhysicalPPTInstrument`; its inserted optimal block
and its two vanishing mixed output sectors are derived rather than supplied as
premises.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {d : ℕ} {ra rb : Type*}
  [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]

private theorem physicalInstrument_insertedSuccessBlock_eq_localOptimal
    [Nonempty (Fin d)]
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d)
    (resource : PureVector (ra × rb))
    (hraw :
      pureResourceInsert resource.amp
          (MatrixMap.choi (M.instrument.branch true)) =
        globalOptimalChoi (x := GlobalPaperIndex d)) :
    insertPureResourceBlock resource.amp
        (jointContractionSchurCoefficient M.success) =
      rankOneMatrix (localOptimalMultiplicityVector d) := by
  calc
    insertPureResourceBlock resource.amp
        (jointContractionSchurCoefficient M.success) =
      jointContractionUnassistedCoefficient
        (physicalInsertedChoiMatrix
          (globalOptimalChoi (x := GlobalPaperIndex d))) := by
            simpa [PhysicalPPTInstrument.success] using
              (insertPureResourceBlock_jointContractionSchurCoefficient_of_choi
                resource.amp (M.instrument.branch true)
                  (globalOptimalChoi (x := GlobalPaperIndex d)) hraw)
    _ = rankOneMatrix (localOptimalMultiplicityVector d) := by
      simpa using
        (globalOptimizer_localBlock
          (a := Fin d) (b := Fin d) (by simpa using hd) (by simp))

/-- The canonical compressed instrument data obtained from an operational
physical PPT instrument which exactly attains the exposed global optimum.

The inserted rank-one contraction block and the two vanishing mixed output
quadratics are consequences of exact attainment; they are not arguments of
this constructor. -/
def physicalInstrumentGlobalOptimalCompressedData
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d)
    (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (resource : PureVector (ra × rb))
    (hSinvariant : JointContractionPhysicalInvariant M.success)
    (hattains :
      globalSDPObjective
          (globalPaperEq986PerformanceOperator hd nu gamma)
          (pureResourceInsert resource.amp
            (MatrixMap.choi (M.instrument.branch true))) =
        globalOptimalGain ((d : ℕ) ^ 2) gamma) :
    CompressedPPTInstrumentData d ra rb := by
  letI : Nonempty (Fin d) := Fin.pos_iff_nonempty.mp (by omega)
  have hraw :
      pureResourceInsert resource.amp
          (MatrixMap.choi (M.instrument.branch true)) =
        globalOptimalChoi (x := GlobalPaperIndex d) :=
    M.insertedSuccess_eq_globalOptimalChoi
      hd nu hgamma0 hgamma1 resource hattains
  have hinserted :
      insertPureResourceBlock resource.amp
          (jointContractionSchurCoefficient M.success) =
        rankOneMatrix (localOptimalMultiplicityVector d) :=
    physicalInstrument_insertedSuccessBlock_eq_localOptimal
      M hd resource hraw
  have hphysicalInserted :
      physicalPureResourceInsert resource.amp M.success =
        physicalInsertedChoiMatrix
          (globalOptimalChoi (x := GlobalPaperIndex d)) := by
    change physicalPureResourceInsert resource.amp
        (physicalInstrumentChoi (M.instrument.branch true)) = _
    rw [physicalPureResourceInsert_physicalInstrumentChoi, hraw]
  have hzeroMixed :=
    outputTrace_mixedSector_quadratics_zero_of_physicalInserted_globalOptimalChoi
      (a := Fin d) (b := Fin d) (r := ra × rb)
      (by simpa using hd) (by simpa using hd) resource.amp
      hSinvariant hphysicalInserted
  exact physicalInstrumentCompressedData
    d hd (by simp) (by simp) M hSinvariant resource
      hinserted hzeroMixed.1 hzeroMixed.2

/-- The auxiliary operator canonically extracted from an exactly globally
optimal operational physical PPT instrument is an effect.  Positivity, PPT,
branch completeness, the inserted optimal block, and both mixed-sector zeros
are all derived upstream from the displayed inputs. -/
theorem physicalInstrumentGlobalOptimalCompressedData_auxiliaryEffect_isEffect
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d)
    (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (resource : PureVector (ra × rb))
    (hSinvariant : JointContractionPhysicalInvariant M.success)
    (hattains :
      globalSDPObjective
          (globalPaperEq986PerformanceOperator hd nu gamma)
          (pureResourceInsert resource.amp
            (MatrixMap.choi (M.instrument.branch true))) =
        globalOptimalGain ((d : ℕ) ^ 2) gamma) :
    IsEffectMatrix
      (physicalInstrumentGlobalOptimalCompressedData M hd nu
        hgamma0 hgamma1 resource hSinvariant hattains).auxiliaryEffect := by
  exact
    (physicalInstrumentGlobalOptimalCompressedData M hd nu
      hgamma0 hgamma1 resource hSinvariant hattains).auxiliaryEffect_isEffect hd

end

end EntanglementPurification
