import EntanglementPurification.EffectBounds
import EntanglementPurification.EffectScalar
import EntanglementPurification.FiniteMajorization
import EntanglementPurification.MajorizationConsequences
import EntanglementPurification.SchmidtEffect

/-!
# Effect constraints imply Schmidt-spectrum bounds

This module assembles the operator, scalar, and finite-majorization layers of
Appendix B.  Its hypotheses expose the projected two-vector Gram data
explicitly; a coordinate construction of those vectors is kept in
`SchmidtEffect.lean`.
-/

namespace EntanglementPurification

open QIT

noncomputable section

/-- The explicit signed Schmidt vector and projected-coordinate package
associated with an ordered probability vector. -/
def schmidtDataOfOrderedProbability
    {m : ℕ} (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p) :
    FiniteSchmidtData (m + 1) :=
  FiniteSchmidtData.ofOrderedProbability (k := m + 1) p hp

/-- The core converse in a form that states exactly the projected Gram data
used by the paper.  It proves the head bound, both branches of the comparison
spectrum, and the strict quadratic tail gap in the three-point branch. -/
theorem effectConstraints_imply_schmidt_majorization
    {m : ℕ}
    {p : Fin (m + 3) → ℝ}
    (hp : IsOrderedProbability p)
    {r : Type*} [Fintype r] [DecidableEq r]
    {N : CMatrix r} (hN : IsEffectMatrix N)
    (u v w : r → ℂ)
    (hu : cVecNormSq u = 1 - p 0)
    (hv : v =
      ((Real.sqrt (p 0 * p 1) / (1 - p 0) : ℝ) : ℂ) • u + w)
    (horth : cVecInnerRe u w = 0)
    (hw : cVecNormSq w = tailFromTwo p / (1 - p 0))
    (hdiag : (1 / 3 : ℝ) ≤ quadraticRe N u)
    (hcross : effectCrossRe N u v ≤ 1 / 3) :
    p 0 ≤ 2 / 3 ∧
      (p 0 ≤ 1 / 2 →
        PrefixMajorizedBy p (twoPointComparison (m + 1))) ∧
      (1 / 2 < p 0 →
        zStar (p 0) ≤ tailFromTwo p ∧
        2 * (p 0 - 1 / 2) ^ 2 < tailFromTwo p ∧
        PrefixMajorizedBy p
          (threePointComparison m (p 0) (zStar (p 0)))) := by
  have hhead : p 0 ≤ 2 / 3 :=
    schmidtHead_le_two_thirds_of_effect hN u (p 0) hu hdiag
  have htailNonneg : 0 ≤ tailFromTwo p := by
    apply list_sum_nonneg_of_forall_nonneg
    intro x hx
    have hxmem : x ∈ List.ofFn p := List.mem_of_mem_drop hx
    rcases List.mem_ofFn.mp hxmem with ⟨i, rfl⟩
    exact hp.2.1 i
  have hpOne :
      p 1 = 1 - p 0 - tailFromTwo p := by
    have hsplit := prefix_two_add_tail p
    rw [orderedPrefixSum_two_three, hp.2.2] at hsplit
    linarith
  refine ⟨hhead, ?_, ?_⟩
  · intro hsmall
    exact
      prefixMajorizedBy_twoPoint_of_head_le_half
        (m := m + 1) hp hsmall
  · intro hlarge
    have hxlt : p 0 < 1 := by linarith
    let mu : ℝ := quadraticRe N u / (1 - p 0)
    have hxden : 1 - p 0 ≠ 0 := by linarith
    have hmean :
        quadraticRe N u = mu * (1 - p 0) := by
      dsimp [mu]
      field_simp [hxden]
    have hmuBounds :=
      normalized_effect_mean_bounds
        hN u (p 0) mu hxlt hu hdiag hmean
    have hmuNonneg : 0 ≤ mu := by
      have hdenPos : 0 < 3 * (1 - p 0) := by nlinarith
      have hendpointNonneg :
          0 ≤ 1 / (3 * (1 - p 0)) :=
        le_of_lt (one_div_pos.mpr hdenPos)
      exact hendpointNonneg.trans hmuBounds.1
    have hcrossLower :=
      effectCrossRe_lower_bound_of_gram_data
        hN u v w (p 0) (p 1) (tailFromTwo p) mu
        hxlt hmuNonneg hmuBounds.2 hu hv horth hw hmean
    rw [hpOne] at hcrossLower
    have hpOneNonneg : 0 ≤ 1 - p 0 - tailFromTwo p := by
      rw [← hpOne]
      exact hp.2.1 1
    have htail :
        zStar (p 0) ≤ tailFromTwo p :=
      tail_ge_zStar_of_mu_cross_bounds
        (le_of_lt hlarge) hhead htailNonneg hpOneNonneg
        hmuBounds.1 hmuBounds.2 hcross hcrossLower
    have hstrictBoundary :
        2 * (p 0 - 1 / 2) ^ 2 < zStar (p 0) :=
      zStar_gt_twice_square_on_interval
        (le_of_lt hlarge) hhead hlarge
    have hstrictTail :
        2 * (p 0 - 1 / 2) ^ 2 < tailFromTwo p :=
      hstrictBoundary.trans_le htail
    have hmajorized :
        PrefixMajorizedBy p
          (threePointComparison m (p 0) (zStar (p 0))) :=
      prefixMajorizedBy_zStar_of_tail_ge hp hlarge hhead htail
    exact ⟨htail, hstrictTail, hmajorized⟩

/-- Collision-probability consequence of the effect constraints, equation
`eq:schmidt_purity_half` in `main.tex`.  This uses the directly proved
quadratic Abel lemma rather than assuming a general Karamata theorem. -/
theorem effectConstraints_imply_collisionProbability_le_half
    {m : ℕ}
    {p : Fin (m + 3) → ℝ}
    (hp : IsOrderedProbability p)
    {r : Type*} [Fintype r] [DecidableEq r]
    {N : CMatrix r} (hN : IsEffectMatrix N)
    (u v w : r → ℂ)
    (hu : cVecNormSq u = 1 - p 0)
    (hv : v =
      ((Real.sqrt (p 0 * p 1) / (1 - p 0) : ℝ) : ℂ) • u + w)
    (horth : cVecInnerRe u w = 0)
    (hw : cVecNormSq w = tailFromTwo p / (1 - p 0))
    (hdiag : (1 / 3 : ℝ) ≤ quadraticRe N u)
    (hcross : effectCrossRe N u v ≤ 1 / 3) :
    collisionProbability p ≤ 1 / 2 := by
  have hmain :=
    effectConstraints_imply_schmidt_majorization
      hp hN u v w hu hv horth hw hdiag hcross
  by_cases hsmall : p 0 ≤ 1 / 2
  · exact collisionProbability_le_half_of_prefixMajorizedBy_twoPoint
      hp (hmain.2.1 hsmall)
  · have hlarge : 1 / 2 < p 0 := lt_of_not_ge hsmall
    exact collisionProbability_le_half_of_prefixMajorizedBy_threePoint
      hp (le_of_lt hlarge) hmain.1 (hmain.2.2 hlarge).2.2

/-- Fully instantiated version of the Appendix-B lemma.

`N` acts on the diagonal Schmidt support.  Equivalently, it may be read as
the compression of the paper's ambient effect to that support.  The two
remaining assumptions are exactly the diagonal and off-diagonal inequalities
in `eq:abstract_effect_hypotheses`. -/
theorem projectedSchmidtEffectConstraints_imply_majorization
    {m : ℕ}
    {p : Fin (m + 3) → ℝ}
    (hp : IsOrderedProbability p)
    {N : CMatrix (Fin (m + 3))} (hN : IsEffectMatrix N)
    (hdiag :
      (1 / 3 : ℝ) ≤ quadraticRe N
        (schmidtDataOfOrderedProbability p hp).v0Coordinates)
    (hcross :
      effectCrossRe N
        (schmidtDataOfOrderedProbability p hp).v0Coordinates
        (schmidtDataOfOrderedProbability p hp).v1Coordinates ≤ 1 / 3) :
    p 0 ≤ 2 / 3 ∧
      (p 0 ≤ 1 / 2 →
        PrefixMajorizedBy p (twoPointComparison (m + 1))) ∧
      (1 / 2 < p 0 →
        zStar (p 0) ≤ tailFromTwo p ∧
        2 * (p 0 - 1 / 2) ^ 2 < tailFromTwo p ∧
        PrefixMajorizedBy p
          (threePointComparison m (p 0) (zStar (p 0)))) := by
  let data : FiniteSchmidtData (m + 1) :=
    schmidtDataOfOrderedProbability p hp
  have hu : cVecNormSq data.v0Coordinates = 1 - p 0 := by
    simpa [data, schmidtDataOfOrderedProbability,
      FiniteSchmidtData.p0] using data.cVecNormSq_v0Coordinates
  have hhead : p 0 ≤ 2 / 3 :=
    schmidtHead_le_two_thirds_of_effect
      hN data.v0Coordinates (p 0) hu (by
        simpa [data] using hdiag)
  have hp0lt : p 0 < 1 := by linarith
  have hgram :=
    FiniteSchmidtData.orderedProbability_rawGramData hp hp0lt
  have hgram' :
      cVecNormSq data.v0Coordinates = 1 - p 0 ∧
        data.v1Coordinates =
          ((Real.sqrt (p 0 * p 1) / (1 - p 0) : ℝ) : ℂ) •
            data.v0Coordinates + data.residualCoordinates ∧
        cVecInnerRe data.v0Coordinates data.residualCoordinates = 0 ∧
        cVecNormSq data.residualCoordinates =
          tailFromTwo p / (1 - p 0) := by
    simpa [data, schmidtDataOfOrderedProbability] using hgram
  exact effectConstraints_imply_schmidt_majorization
    hp hN data.v0Coordinates data.v1Coordinates data.residualCoordinates
    hgram'.1 hgram'.2.1 hgram'.2.2.1 hgram'.2.2.2
    (by simpa [data] using hdiag)
    (by simpa [data] using hcross)

/-- Fully instantiated collision-probability consequence:
`∑ j, p_j² ≤ 1/2`. -/
theorem projectedSchmidtEffectConstraints_imply_collisionProbability_le_half
    {m : ℕ}
    {p : Fin (m + 3) → ℝ}
    (hp : IsOrderedProbability p)
    {N : CMatrix (Fin (m + 3))} (hN : IsEffectMatrix N)
    (hdiag :
      (1 / 3 : ℝ) ≤ quadraticRe N
        (schmidtDataOfOrderedProbability p hp).v0Coordinates)
    (hcross :
      effectCrossRe N
        (schmidtDataOfOrderedProbability p hp).v0Coordinates
        (schmidtDataOfOrderedProbability p hp).v1Coordinates ≤ 1 / 3) :
    collisionProbability p ≤ 1 / 2 := by
  have hmain :=
    projectedSchmidtEffectConstraints_imply_majorization
      hp hN hdiag hcross
  by_cases hsmall : p 0 ≤ 1 / 2
  · exact collisionProbability_le_half_of_prefixMajorizedBy_twoPoint
      hp (hmain.2.1 hsmall)
  · have hlarge : 1 / 2 < p 0 := lt_of_not_ge hsmall
    exact collisionProbability_le_half_of_prefixMajorizedBy_threePoint
      hp (le_of_lt hlarge) hmain.1 (hmain.2.2 hlarge).2.2

/-- The same conclusion exposed through Lean-QIT's native `Majorizes`
predicate.  QIT writes `Majorizes q p` for the paper's `p ≺ q`. -/
theorem projectedSchmidtEffectConstraints_imply_qitMajorizes
    {m : ℕ}
    {p : Fin (m + 3) → ℝ}
    (hp : IsOrderedProbability p)
    {N : CMatrix (Fin (m + 3))} (hN : IsEffectMatrix N)
    (hdiag :
      (1 / 3 : ℝ) ≤ quadraticRe N
        (schmidtDataOfOrderedProbability p hp).v0Coordinates)
    (hcross :
      effectCrossRe N
        (schmidtDataOfOrderedProbability p hp).v0Coordinates
        (schmidtDataOfOrderedProbability p hp).v1Coordinates ≤ 1 / 3) :
    p 0 ≤ 2 / 3 ∧
      (p 0 ≤ 1 / 2 →
        QIT.Majorizes (twoPointComparison (m + 1)) p) ∧
      (1 / 2 < p 0 →
        QIT.Majorizes
          (threePointComparison m (p 0) (zStar (p 0))) p) := by
  have hmain :=
    projectedSchmidtEffectConstraints_imply_majorization
      hp hN hdiag hcross
  refine ⟨hmain.1, ?_, ?_⟩
  · intro hsmall
    apply (prefixMajorizedBy_iff_qitMajorizes_of_antitone
      hp.1 (twoPointComparison_isOrderedProbability (m + 1)).1).mp
    exact hmain.2.1 hsmall
  · intro hlarge
    apply (prefixMajorizedBy_iff_qitMajorizes_of_antitone
      hp.1
      (threePointComparison_isOrderedProbability_on_interval
        m (le_of_lt hlarge) hmain.1).1).mp
    exact (hmain.2.2 hlarge).2.2

end

end EntanglementPurification
