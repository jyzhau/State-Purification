import EntanglementPurification.GlobalConcreteSDP

/-!
# Haar-defined global performance operator

This file keeps the Haar moments themselves in the definition of the global
performance operator from main.tex, equations 1369--1392. It then evaluates
the three kinds of moment term and identifies the resulting matrix with the
closed contraction formula used by the concrete SDP.
-/

namespace EntanglementPurification

open QIT

noncomputable section

universe u

variable {x : Type u} [Fintype x] [DecidableEq x]

/-- Embed an operator on tensor legs (1,2) and put the identity on leg 3. -/
def globalEmbedPair12 (A : CMatrix (x × x)) :
    CMatrix (GlobalThreeLeg x) :=
  fun p q => A p.1 q.1 * (1 : CMatrix x) p.2 q.2

/-- Embed an operator on tensor legs (1,3) and put the identity on leg 2. -/
def globalEmbedPair13 (A : CMatrix (x × x)) :
    CMatrix (GlobalThreeLeg x) :=
  fun p q =>
    A (p.1.1, p.2) (q.1.1, q.2) *
      (1 : CMatrix x) p.1.2 q.1.2

/-- Embed an operator on tensor legs (2,3) and put the identity on leg 1. -/
def globalEmbedPair23 (A : CMatrix (x × x)) :
    CMatrix (GlobalThreeLeg x) :=
  fun p q =>
    (1 : CMatrix x) p.1.1 q.1.1 *
      A (p.1.2, p.2) (q.1.2, q.2)

@[simp]
theorem globalEmbedPair12_add (A B : CMatrix (x × x)) :
    globalEmbedPair12 (A + B) =
      globalEmbedPair12 A + globalEmbedPair12 B := by
  ext p q
  simp [globalEmbedPair12]
  ring

@[simp]
theorem globalEmbedPair13_add (A B : CMatrix (x × x)) :
    globalEmbedPair13 (A + B) =
      globalEmbedPair13 A + globalEmbedPair13 B := by
  ext p q
  simp [globalEmbedPair13, add_mul]

@[simp]
theorem globalEmbedPair23_add (A B : CMatrix (x × x)) :
    globalEmbedPair23 (A + B) =
      globalEmbedPair23 A + globalEmbedPair23 B := by
  ext p q
  simp [globalEmbedPair23, mul_add]

@[simp]
theorem globalEmbedPair12_smul (c : ℂ) (A : CMatrix (x × x)) :
    globalEmbedPair12 (c • A) = c • globalEmbedPair12 A := by
  ext p q
  simp [globalEmbedPair12, mul_assoc]

@[simp]
theorem globalEmbedPair13_smul (c : ℂ) (A : CMatrix (x × x)) :
    globalEmbedPair13 (c • A) = c • globalEmbedPair13 A := by
  ext p q
  simp [globalEmbedPair13, mul_assoc]

@[simp]
theorem globalEmbedPair23_smul (c : ℂ) (A : CMatrix (x × x)) :
    globalEmbedPair23 (c • A) = c • globalEmbedPair23 A := by
  ext p q
  simp [globalEmbedPair23]
  ring

@[simp]
theorem globalEmbedPair12_one :
    globalEmbedPair12 (1 : CMatrix (x × x)) =
      (1 : CMatrix (GlobalThreeLeg x)) := by
  ext p q
  simp [globalEmbedPair12, Matrix.one_apply, Prod.ext_iff]
  split_ifs <;> simp_all

@[simp]
theorem globalEmbedPair13_one :
    globalEmbedPair13 (1 : CMatrix (x × x)) =
      (1 : CMatrix (GlobalThreeLeg x)) := by
  ext p q
  simp [globalEmbedPair13, Matrix.one_apply, Prod.ext_iff,
    and_comm, and_left_comm]
  split_ifs <;> simp_all

@[simp]
theorem globalEmbedPair23_one :
    globalEmbedPair23 (1 : CMatrix (x × x)) =
      (1 : CMatrix (GlobalThreeLeg x)) := by
  ext p q
  simp [globalEmbedPair23, Matrix.one_apply, Prod.ext_iff,
    and_comm, and_left_comm]
  split_ifs <;> simp_all

/-- The pair (1,2) swap is the input-copy swap on the three-leg space. -/
theorem globalEmbedPair12_inputPairSwap :
    globalEmbedPair12 (globalInputPairSwap (x := x)) =
      globalInputSwap := by
  ext p q
  rcases p with ⟨⟨a, b⟩, c⟩
  rcases q with ⟨⟨d, e⟩, f⟩
  simp [globalEmbedPair12, globalInputPairSwap, globalInputSwap,
    globalSwapIndex, Matrix.one_apply, Prod.ext_iff, eq_comm, and_comm]
  split_ifs <;> simp_all

/-- The pair (1,3) swap is tensor permutation (0 2). -/
theorem globalEmbedPair13_inputPairSwap :
    globalEmbedPair13 (globalInputPairSwap (x := x)) =
      globalThreePermutationMatrix globalFinThreeSwap02 := by
  ext p q
  rcases p with ⟨⟨a, b⟩, c⟩
  rcases q with ⟨⟨d, e⟩, f⟩
  simp [globalEmbedPair13, globalInputPairSwap,
    globalThreePermutationMatrix_apply,
    globalThreeLegPerm_swap02_apply, Matrix.one_apply,
    Prod.ext_iff, eq_comm, and_comm, and_left_comm]
  split_ifs <;> simp_all

/-- The pair (2,3) swap is tensor permutation (1 2). -/
theorem globalEmbedPair23_inputPairSwap :
    globalEmbedPair23 (globalInputPairSwap (x := x)) =
      globalThreePermutationMatrix globalFinThreeSwap12 := by
  ext p q
  rcases p with ⟨⟨a, b⟩, c⟩
  rcases q with ⟨⟨d, e⟩, f⟩
  simp [globalEmbedPair23, globalInputPairSwap,
    globalThreePermutationMatrix_apply,
    globalThreeLegPerm_swap12_apply, Matrix.one_apply,
    Prod.ext_iff, eq_comm, and_comm, and_assoc]
  split_ifs <;> simp_all

/-- The actual three-copy Haar term in equations 1369--1373. -/
def globalHaarMomentThreeTerm [Nonempty x] (ν : PureVector x) :
    CMatrix (GlobalThreeLeg x) :=
  QIT.partialTransposeA (a := x × x) (b := x)
    (reindexTensorPowerThree (pureHaarOrbitMoment 3 ν))

/-- The actual two-copy Haar term on tensor legs (1,2). -/
def globalHaarMomentPair12Term [Nonempty x] (ν : PureVector x) :
    CMatrix (GlobalThreeLeg x) :=
  QIT.partialTransposeA (a := x × x) (b := x)
    (globalEmbedPair12
      (reindexTensorPowerTwo (pureHaarOrbitMoment 2 ν)))

/-- The actual two-copy Haar term on tensor legs (1,3). -/
def globalHaarMomentPair13Term [Nonempty x] (ν : PureVector x) :
    CMatrix (GlobalThreeLeg x) :=
  QIT.partialTransposeA (a := x × x) (b := x)
    (globalEmbedPair13
      (reindexTensorPowerTwo (pureHaarOrbitMoment 2 ν)))

/-- The actual two-copy Haar term on tensor legs (2,3). -/
def globalHaarMomentPair23Term [Nonempty x] (ν : PureVector x) :
    CMatrix (GlobalThreeLeg x) :=
  QIT.partialTransposeA (a := x × x) (b := x)
    (globalEmbedPair23
      (reindexTensorPowerTwo (pureHaarOrbitMoment 2 ν)))

@[simp]
theorem partialTransposeA_one_globalThreeLeg :
    QIT.partialTransposeA (a := x × x) (b := x)
        (1 : CMatrix (GlobalThreeLeg x)) =
      1 := by
  calc
    QIT.partialTransposeA (a := x × x) (b := x)
        (1 : CMatrix (GlobalThreeLeg x)) =
        QIT.partialTransposeA
          (globalThreePermutationMatrix (x := x) 1) := by
            rw [globalThreePermutationMatrix_one]
    _ = 1 := partialTransposeA_globalThreePermutationMatrix_one

@[simp]
theorem partialTransposeA_globalInputSwap :
    QIT.partialTransposeA (a := x × x) (b := x)
        (globalInputSwap (x := x)) =
      globalInputSwap := by
  calc
    QIT.partialTransposeA (a := x × x) (b := x)
        (globalInputSwap (x := x)) =
        QIT.partialTransposeA
          (globalThreePermutationMatrix (x := x)
            globalFinThreeSwap01) := by
              rw [globalThreePermutationMatrix_swap01]
    _ = globalInputSwap :=
      partialTransposeA_globalThreePermutationMatrix_swap01

/-- Closed form of the genuine three-copy Haar term, equation 1445--1454. -/
theorem globalHaarMomentThreeTerm_eq_closed
    [Nonempty x] (ν : PureVector x) :
    globalHaarMomentThreeTerm ν =
      (((Fintype.card x : ℂ) *
          ((Fintype.card x : ℂ) + 1) *
          ((Fintype.card x : ℂ) + 2))⁻¹ : ℂ) •
        (1 + globalInputSwap + globalMomentCdiag + globalMomentCcross) := by
  exact partialTransposeA_reindex_pureHaarOrbitMoment_three ν

/-- Closed form of the genuine Haar moment on legs (1,2),
equation 1455--1462. -/
theorem globalHaarMomentPair12Term_eq_closed
    [Nonempty x] (ν : PureVector x) :
    globalHaarMomentPair12Term ν =
      (((Fintype.card x : ℂ) *
          ((Fintype.card x : ℂ) + 1))⁻¹ : ℂ) •
        (1 + globalInputSwap) := by
  rw [globalHaarMomentPair12Term,
    reindex_pureHaarOrbitMoment_two_eq_one_add_swap,
    globalEmbedPair12_smul, partialTransposeA_smul_globalThreeLeg,
    globalEmbedPair12_add, partialTransposeA_add_globalThreeLeg,
    globalEmbedPair12_one, globalEmbedPair12_inputPairSwap,
    partialTransposeA_one_globalThreeLeg,
    partialTransposeA_globalInputSwap]

/-- Closed form of the genuine Haar moment on legs (1,3). -/
theorem globalHaarMomentPair13Term_eq_closed
    [Nonempty x] (ν : PureVector x) :
    globalHaarMomentPair13Term ν =
      (((Fintype.card x : ℂ) *
          ((Fintype.card x : ℂ) + 1))⁻¹ : ℂ) •
        (1 + globalGamma1 * Matrix.conjTranspose globalGamma1) := by
  rw [globalHaarMomentPair13Term,
    reindex_pureHaarOrbitMoment_two_eq_one_add_swap,
    globalEmbedPair13_smul, partialTransposeA_smul_globalThreeLeg,
    globalEmbedPair13_add, partialTransposeA_add_globalThreeLeg,
    globalEmbedPair13_one, globalEmbedPair13_inputPairSwap,
    partialTransposeA_one_globalThreeLeg,
    partialTransposeA_globalThreePermutationMatrix_swap02]

/-- Closed form of the genuine Haar moment on legs (2,3). -/
theorem globalHaarMomentPair23Term_eq_closed
    [Nonempty x] (ν : PureVector x) :
    globalHaarMomentPair23Term ν =
      (((Fintype.card x : ℂ) *
          ((Fintype.card x : ℂ) + 1))⁻¹ : ℂ) •
        (1 + globalGamma2 * Matrix.conjTranspose globalGamma2) := by
  rw [globalHaarMomentPair23Term,
    reindex_pureHaarOrbitMoment_two_eq_one_add_swap,
    globalEmbedPair23_smul, partialTransposeA_smul_globalThreeLeg,
    globalEmbedPair23_add, partialTransposeA_add_globalThreeLeg,
    globalEmbedPair23_one, globalEmbedPair23_inputPairSwap,
    partialTransposeA_one_globalThreeLeg,
    partialTransposeA_globalThreePermutationMatrix_swap12]

/-- The sum of the two mixed two-copy Haar terms, equation 1463--1471. -/
theorem globalHaarMomentPair13_add_pair23_eq_closed
    [Nonempty x] (ν : PureVector x) :
    globalHaarMomentPair13Term ν + globalHaarMomentPair23Term ν =
      (((Fintype.card x : ℂ) *
          ((Fintype.card x : ℂ) + 1))⁻¹ : ℂ) •
        ((2 : ℂ) • (1 : CMatrix (GlobalThreeLeg x)) +
          globalMomentCdiag) := by
  rw [globalHaarMomentPair13Term_eq_closed,
    globalHaarMomentPair23Term_eq_closed]
  simp only [globalMomentCdiag]
  module

/-- The performance operator of equations 1369--1392, defined with the
actual second and third Haar orbit moments rather than their evaluated
closed forms. -/
def globalHaarPerformanceOperator
    [Nonempty x] (ν : PureVector x) (gamma : ℝ) :
    CMatrix (GlobalThreeLeg x) :=
  (1 - gamma) ^ 2 •
      (globalHaarMomentThreeTerm ν -
        globalNoiseFidelity (Fintype.card x : ℝ) gamma •
          globalHaarMomentPair12Term ν) +
    (gamma * (1 - gamma) / (Fintype.card x : ℝ)) •
      ((globalHaarMomentPair13Term ν +
          globalHaarMomentPair23Term ν) -
        ((2 / (Fintype.card x : ℝ)) *
            globalNoiseFidelity (Fintype.card x : ℝ) gamma) •
          (1 : CMatrix (GlobalThreeLeg x))) -
    (gamma ^ 2 * (1 - gamma) / (Fintype.card x : ℝ) ^ 2 *
        (1 - 1 / (Fintype.card x : ℝ))) •
      (1 : CMatrix (GlobalThreeLeg x))

/-- Evaluating the genuine Haar moments gives exactly the concrete raw
performance operator consumed by the finite-dimensional SDP proof. -/
theorem globalHaarPerformanceOperator_eq_globalConcreteRawPerformanceOperator
    [Nonempty x] (ν : PureVector x) (gamma : ℝ) :
    globalHaarPerformanceOperator ν gamma =
      globalConcreteRawPerformanceOperator (x := x) gamma := by
  rw [globalHaarPerformanceOperator,
    globalHaarMomentThreeTerm_eq_closed,
    globalHaarMomentPair12Term_eq_closed,
    globalHaarMomentPair13_add_pair23_eq_closed]
  simp only [globalConcreteRawPerformanceOperator,
    globalRawPerformanceOperator]
  ext p q
  simp only [Matrix.add_apply, Matrix.sub_apply, Matrix.smul_apply,
    Matrix.one_apply, Complex.real_smul]
  push_cast
  ring

/-- The Haar-moment performance operator is Hermitian in the dimension range
of the global SDP theorem. -/
theorem globalHaarPerformanceOperator_isHermitian
    [Nonempty x] (ν : PureVector x) {gamma : ℝ}
    (hcard : 4 ≤ (Fintype.card x : ℝ)) :
    (globalHaarPerformanceOperator ν gamma).IsHermitian := by
  rw [globalHaarPerformanceOperator_eq_globalConcreteRawPerformanceOperator]
  exact globalConcreteRawPerformanceOperator_isHermitian hcard

end

end EntanglementPurification
