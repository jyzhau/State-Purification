import EntanglementPurification.JointContractionSchur
import QIT.Symmetry.UnitaryTwirl

/-!
# Physical local Haar twirl

This module defines the genuine, normalized Haar average of a physical branch
under the independent local mixed representations
`bar U ⊗ bar U ⊗ U` and `bar V ⊗ bar V ⊗ V`.  The resource leg is
left fixed.  The two averages are taken successively; no invariance assumption
is built into the definition.
-/

namespace EntanglementPurification

open QIT
open MeasureTheory
open scoped ComplexOrder MatrixOrder Matrix.Norms.L2Operator

noncomputable section

universe uA uB uR uI

local instance physicalLocalTwirlCMatrixContinuousENorm
    {ι : Type uI} [Fintype ι] [DecidableEq ι] :
    ContinuousENorm (CMatrix ι) :=
  SeminormedAddGroup.toContinuousENorm

variable {a : Type uA} {b : Type uB} {r : Type uR}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

/-- Alice's mixed physical representation, with Bob and the resource fixed. -/
def physicalAliceMixedRepresentation
    (U : Matrix.unitaryGroup a ℂ) :
    CMatrix (JointContractionPhysicalIndex a b r) :=
  jointContractionPhysicalRepresentation (r := r) U 1

/-- Bob's mixed physical representation, with Alice and the resource fixed. -/
def physicalBobMixedRepresentation
    (V : Matrix.unitaryGroup b ℂ) :
    CMatrix (JointContractionPhysicalIndex a b r) :=
  jointContractionPhysicalRepresentation (r := r) 1 V

/-- The pointwise integrand of the Alice physical Haar twirl. -/
def physicalAliceTwirlIntegrand
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (U : Matrix.unitaryGroup a ℂ) :
    CMatrix (JointContractionPhysicalIndex a b r) :=
  physicalAliceMixedRepresentation (b := b) (r := r) U * K *
    star (physicalAliceMixedRepresentation (b := b) (r := r) U)

/-- The pointwise integrand of the Bob physical Haar twirl. -/
def physicalBobTwirlIntegrand
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (V : Matrix.unitaryGroup b ℂ) :
    CMatrix (JointContractionPhysicalIndex a b r) :=
  physicalBobMixedRepresentation (a := a) (r := r) V * K *
    star (physicalBobMixedRepresentation (a := a) (r := r) V)

private theorem continuous_matrix_kronecker
    {X : Type*} [TopologicalSpace X]
    {i j k l : Type*}
    {A : X → Matrix i j ℂ} {B : X → Matrix k l ℂ}
    (hA : Continuous A) (hB : Continuous B) :
    Continuous (fun x ↦ Matrix.kronecker (A x) (B x)) := by
  refine continuous_pi ?_
  intro p
  refine continuous_pi ?_
  intro q
  exact
    ((continuous_apply q.1).comp ((continuous_apply p.1).comp hA)).mul
      ((continuous_apply q.2).comp ((continuous_apply p.2).comp hB))

private theorem localEntrywiseConjugate_continuous :
    Continuous
      (fun U : Matrix.unitaryGroup a ℂ ↦ localEntrywiseConjugate U) := by
  refine continuous_pi ?_
  intro i
  refine continuous_pi ?_
  intro j
  exact Complex.continuous_conj.comp
    ((continuous_apply j).comp
      ((continuous_apply i).comp continuous_subtype_val))

private theorem localMixedSchurRepresentation_continuous :
    Continuous
      (fun U : Matrix.unitaryGroup a ℂ ↦
        localMixedSchurRepresentation U) := by
  unfold localMixedSchurRepresentation
  exact continuous_matrix_kronecker
    (continuous_matrix_kronecker
      (localEntrywiseConjugate_continuous (a := a))
      (localEntrywiseConjugate_continuous (a := a)))
    continuous_subtype_val

@[simp]
theorem localEntrywiseConjugate_one :
    localEntrywiseConjugate (1 : Matrix.unitaryGroup a ℂ) =
      (1 : CMatrix a) := by
  ext i j
  simp [localEntrywiseConjugate, Matrix.one_apply]

@[simp]
theorem localEntrywiseConjugate_mul
    (U V : Matrix.unitaryGroup a ℂ) :
    localEntrywiseConjugate (U * V) =
      localEntrywiseConjugate U * localEntrywiseConjugate V := by
  ext i j
  simp [localEntrywiseConjugate, Matrix.mul_apply]

@[simp]
theorem localMixedSchurRepresentation_one :
    localMixedSchurRepresentation (1 : Matrix.unitaryGroup a ℂ) =
      (1 : CMatrix (LocalMixedSchurSpace a)) := by
  simp [localMixedSchurRepresentation]

theorem localMixedSchurRepresentation_mul
    (U V : Matrix.unitaryGroup a ℂ) :
    localMixedSchurRepresentation (U * V) =
      localMixedSchurRepresentation U * localMixedSchurRepresentation V := by
  unfold localMixedSchurRepresentation
  rw [localEntrywiseConjugate_mul]
  change Matrix.kronecker
      (Matrix.kronecker
        (localEntrywiseConjugate U * localEntrywiseConjugate V)
        (localEntrywiseConjugate U * localEntrywiseConjugate V))
      ((U : CMatrix a) * (V : CMatrix a)) = _
  unfold Matrix.kronecker
  rw [← Matrix.mul_kronecker_mul]
  rw [← Matrix.mul_kronecker_mul]

omit [Fintype r] in
@[simp]
theorem jointContractionPhysicalRepresentation_one :
    jointContractionPhysicalRepresentation (r := r)
        (1 : Matrix.unitaryGroup a ℂ)
        (1 : Matrix.unitaryGroup b ℂ) =
      (1 : CMatrix (JointContractionPhysicalIndex a b r)) := by
  simp [jointContractionPhysicalRepresentation]

theorem jointContractionPhysicalRepresentation_mul
    (U₁ U₂ : Matrix.unitaryGroup a ℂ)
    (V₁ V₂ : Matrix.unitaryGroup b ℂ) :
    jointContractionPhysicalRepresentation (r := r) (U₁ * U₂) (V₁ * V₂) =
      jointContractionPhysicalRepresentation (r := r) U₁ V₁ *
        jointContractionPhysicalRepresentation (r := r) U₂ V₂ := by
  unfold jointContractionPhysicalRepresentation
  rw [localMixedSchurRepresentation_mul,
    localMixedSchurRepresentation_mul]
  nth_rewrite 1 [show (1 : CMatrix r) = 1 * 1 by simp]
  unfold Matrix.kronecker
  rw [← Matrix.mul_kronecker_mul]
  rw [← Matrix.mul_kronecker_mul]

theorem physicalAliceMixedRepresentation_mul
    (U V : Matrix.unitaryGroup a ℂ) :
    physicalAliceMixedRepresentation (b := b) (r := r) (U * V) =
      physicalAliceMixedRepresentation (b := b) (r := r) U *
        physicalAliceMixedRepresentation (b := b) (r := r) V := by
  simpa [physicalAliceMixedRepresentation] using
    (jointContractionPhysicalRepresentation_mul (r := r)
      U V (1 : Matrix.unitaryGroup b ℂ) 1)

theorem physicalBobMixedRepresentation_mul
    (U V : Matrix.unitaryGroup b ℂ) :
    physicalBobMixedRepresentation (a := a) (r := r) (U * V) =
      physicalBobMixedRepresentation (a := a) (r := r) U *
        physicalBobMixedRepresentation (a := a) (r := r) V := by
  simpa [physicalBobMixedRepresentation] using
    (jointContractionPhysicalRepresentation_mul (r := r)
      (1 : Matrix.unitaryGroup a ℂ) 1 U V)

theorem physicalAliceMixedRepresentation_mul_physicalBobMixedRepresentation
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    physicalAliceMixedRepresentation (b := b) (r := r) U *
        physicalBobMixedRepresentation (a := a) (r := r) V =
      jointContractionPhysicalRepresentation (r := r) U V := by
  symm
  simpa [physicalAliceMixedRepresentation, physicalBobMixedRepresentation] using
    (jointContractionPhysicalRepresentation_mul (r := r)
      U (1 : Matrix.unitaryGroup a ℂ)
      (1 : Matrix.unitaryGroup b ℂ) V)

theorem physicalBobMixedRepresentation_mul_physicalAliceMixedRepresentation
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    physicalBobMixedRepresentation (a := a) (r := r) V *
        physicalAliceMixedRepresentation (b := b) (r := r) U =
      jointContractionPhysicalRepresentation (r := r) U V := by
  symm
  simpa [physicalAliceMixedRepresentation, physicalBobMixedRepresentation] using
    (jointContractionPhysicalRepresentation_mul (r := r)
      (1 : Matrix.unitaryGroup a ℂ) U
      V (1 : Matrix.unitaryGroup b ℂ))

theorem physicalAliceMixedRepresentation_commutes_physicalBobMixedRepresentation
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    physicalAliceMixedRepresentation (b := b) (r := r) U *
        physicalBobMixedRepresentation (a := a) (r := r) V =
      physicalBobMixedRepresentation (a := a) (r := r) V *
        physicalAliceMixedRepresentation (b := b) (r := r) U := by
  rw [physicalAliceMixedRepresentation_mul_physicalBobMixedRepresentation,
    physicalBobMixedRepresentation_mul_physicalAliceMixedRepresentation]

omit [Fintype r] in
private theorem physicalAliceMixedRepresentation_continuous :
    Continuous
      (physicalAliceMixedRepresentation (a := a) (b := b) (r := r)) := by
  unfold physicalAliceMixedRepresentation jointContractionPhysicalRepresentation
  exact continuous_matrix_kronecker
    (continuous_matrix_kronecker
      (localMixedSchurRepresentation_continuous (a := a)) continuous_const)
    continuous_const

omit [Fintype r] in
private theorem physicalBobMixedRepresentation_continuous :
    Continuous
      (physicalBobMixedRepresentation (a := a) (b := b) (r := r)) := by
  unfold physicalBobMixedRepresentation jointContractionPhysicalRepresentation
  exact continuous_matrix_kronecker
    (continuous_matrix_kronecker continuous_const
      (localMixedSchurRepresentation_continuous (a := b)))
    continuous_const

theorem physicalAliceTwirlIntegrand_continuous
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    Continuous (physicalAliceTwirlIntegrand K) := by
  unfold physicalAliceTwirlIntegrand
  simpa [mul_assoc] using
    ((physicalAliceMixedRepresentation_continuous
      (a := a) (b := b) (r := r)).matrix_mul continuous_const).matrix_mul
      (Continuous.star
        (physicalAliceMixedRepresentation_continuous
          (a := a) (b := b) (r := r)))

theorem physicalBobTwirlIntegrand_continuous
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    Continuous (physicalBobTwirlIntegrand K) := by
  unfold physicalBobTwirlIntegrand
  simpa [mul_assoc] using
    ((physicalBobMixedRepresentation_continuous
      (a := a) (b := b) (r := r)).matrix_mul continuous_const).matrix_mul
      (Continuous.star
        (physicalBobMixedRepresentation_continuous
          (a := a) (b := b) (r := r)))

theorem physicalAliceTwirlIntegrand_integrable
    [Nonempty a] [Nonempty b] [Nonempty r]
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    Integrable (physicalAliceTwirlIntegrand K)
      (unitaryHaarMeasure (a := a)) :=
  (physicalAliceTwirlIntegrand_continuous K).integrable_of_hasCompactSupport
    (HasCompactSupport.of_compactSpace _)

theorem physicalBobTwirlIntegrand_integrable
    [Nonempty a] [Nonempty b] [Nonempty r]
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    Integrable (physicalBobTwirlIntegrand K)
      (unitaryHaarMeasure (a := b)) :=
  (physicalBobTwirlIntegrand_continuous K).integrable_of_hasCompactSupport
    (HasCompactSupport.of_compactSpace _)

/-- Haar average under Alice's physical mixed representation. -/
def physicalAliceTwirl [Nonempty a] [Nonempty b] [Nonempty r]
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    CMatrix (JointContractionPhysicalIndex a b r) :=
  ∫ U : Matrix.unitaryGroup a ℂ,
    physicalAliceTwirlIntegrand K U ∂unitaryHaarMeasure (a := a)

/-- Haar average under Bob's physical mixed representation. -/
def physicalBobTwirl [Nonempty a] [Nonempty b] [Nonempty r]
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    CMatrix (JointContractionPhysicalIndex a b r) :=
  ∫ V : Matrix.unitaryGroup b ℂ,
    physicalBobTwirlIntegrand K V ∂unitaryHaarMeasure (a := b)

/-- The genuine independent local Haar twirl.  Bob is averaged first and
Alice second. -/
def physicalLocalTwirl [Nonempty a] [Nonempty b] [Nonempty r]
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    CMatrix (JointContractionPhysicalIndex a b r) :=
  physicalAliceTwirl (physicalBobTwirl K)

private theorem matrix_mul_integral_mul
    {α : Type*} [MeasurableSpace α] {μ : Measure α}
    {ι : Type uI} [Fintype ι] [DecidableEq ι]
    (L R : CMatrix ι) {f : α → CMatrix ι} (hf : Integrable f μ) :
    L * (∫ x, f x ∂μ) * R = ∫ x, L * f x * R ∂μ := by
  simpa [ContinuousLinearMap.mulLeftRight_apply] using
    ((ContinuousLinearMap.mulLeftRight ℝ (CMatrix ι) L R).integral_comp_comm hf).symm

private theorem integral_matrix_conjTranspose
    {α : Type*} [MeasurableSpace α] {μ : Measure α}
    {ι : Type uI} [Fintype ι] [DecidableEq ι]
    {f : α → CMatrix ι} (hf : Integrable f μ) :
    (∫ x, f x ∂μ).conjTranspose =
      ∫ x, (f x).conjTranspose ∂μ := by
  simpa using
    ((cMatrixConjTransposeCLM (ι := ι)).integral_comp_comm hf).symm

private theorem integral_dotProduct_mulVec
    {α : Type*} [MeasurableSpace α] {μ : Measure α}
    {ι : Type uI} [Fintype ι] [DecidableEq ι]
    {f : α → CMatrix ι} (hf : Integrable f μ) (x : ι → ℂ) :
    dotProduct (star x) (Matrix.mulVec (∫ y, f y ∂μ) x) =
      ∫ y, dotProduct (star x) (Matrix.mulVec (f y) x) ∂μ := by
  simp_rw [← cMatrixQuadraticCLM_apply x]
  exact ((cMatrixQuadraticCLM x).integral_comp_comm hf).symm

private theorem physicalAliceTwirlIntegrand_translate
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (W U : Matrix.unitaryGroup a ℂ) :
    physicalAliceMixedRepresentation (b := b) (r := r) W *
        physicalAliceTwirlIntegrand K U *
        star (physicalAliceMixedRepresentation (b := b) (r := r) W) =
      physicalAliceTwirlIntegrand K (W * U) := by
  rw [physicalAliceTwirlIntegrand, physicalAliceTwirlIntegrand,
    physicalAliceMixedRepresentation_mul, star_mul]
  simp only [mul_assoc]

private theorem physicalBobTwirlIntegrand_translate
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (W V : Matrix.unitaryGroup b ℂ) :
    physicalBobMixedRepresentation (a := a) (r := r) W *
        physicalBobTwirlIntegrand K V *
        star (physicalBobMixedRepresentation (a := a) (r := r) W) =
      physicalBobTwirlIntegrand K (W * V) := by
  rw [physicalBobTwirlIntegrand, physicalBobTwirlIntegrand,
    physicalBobMixedRepresentation_mul, star_mul]
  simp only [mul_assoc]

theorem physicalAliceTwirl_conj_invariant
    [Nonempty a] [Nonempty b] [Nonempty r]
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (W : Matrix.unitaryGroup a ℂ) :
    physicalAliceMixedRepresentation (b := b) (r := r) W *
        physicalAliceTwirl K *
        star (physicalAliceMixedRepresentation (b := b) (r := r) W) =
      physicalAliceTwirl K := by
  have hf : Integrable (physicalAliceTwirlIntegrand K)
      (unitaryHaarMeasure (a := a)) :=
    physicalAliceTwirlIntegrand_integrable K
  have htranslate :
      (∫ U : Matrix.unitaryGroup a ℂ,
          physicalAliceMixedRepresentation (b := b) (r := r) W *
            physicalAliceTwirlIntegrand K U *
            star (physicalAliceMixedRepresentation (b := b) (r := r) W)
          ∂unitaryHaarMeasure (a := a)) =
        ∫ U : Matrix.unitaryGroup a ℂ,
          physicalAliceTwirlIntegrand K (W * U)
          ∂unitaryHaarMeasure (a := a) := by
    congr 1
    funext U
    exact physicalAliceTwirlIntegrand_translate K W U
  calc
    physicalAliceMixedRepresentation (b := b) (r := r) W *
        physicalAliceTwirl K *
        star (physicalAliceMixedRepresentation (b := b) (r := r) W) =
        ∫ U : Matrix.unitaryGroup a ℂ,
          physicalAliceMixedRepresentation (b := b) (r := r) W *
            physicalAliceTwirlIntegrand K U *
            star (physicalAliceMixedRepresentation (b := b) (r := r) W)
          ∂unitaryHaarMeasure (a := a) := by
      rw [physicalAliceTwirl]
      exact matrix_mul_integral_mul
        (physicalAliceMixedRepresentation (b := b) (r := r) W)
        (star (physicalAliceMixedRepresentation (b := b) (r := r) W)) hf
    _ = ∫ U : Matrix.unitaryGroup a ℂ,
          physicalAliceTwirlIntegrand K (W * U)
          ∂unitaryHaarMeasure (a := a) := htranslate
    _ = physicalAliceTwirl K := by
      simpa [physicalAliceTwirl] using
        (MeasureTheory.integral_mul_left_eq_self
          (μ := unitaryHaarMeasure (a := a))
          (physicalAliceTwirlIntegrand K) W)

theorem physicalBobTwirl_conj_invariant
    [Nonempty a] [Nonempty b] [Nonempty r]
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (W : Matrix.unitaryGroup b ℂ) :
    physicalBobMixedRepresentation (a := a) (r := r) W *
        physicalBobTwirl K *
        star (physicalBobMixedRepresentation (a := a) (r := r) W) =
      physicalBobTwirl K := by
  have hf : Integrable (physicalBobTwirlIntegrand K)
      (unitaryHaarMeasure (a := b)) :=
    physicalBobTwirlIntegrand_integrable K
  have htranslate :
      (∫ V : Matrix.unitaryGroup b ℂ,
          physicalBobMixedRepresentation (a := a) (r := r) W *
            physicalBobTwirlIntegrand K V *
            star (physicalBobMixedRepresentation (a := a) (r := r) W)
          ∂unitaryHaarMeasure (a := b)) =
        ∫ V : Matrix.unitaryGroup b ℂ,
          physicalBobTwirlIntegrand K (W * V)
          ∂unitaryHaarMeasure (a := b) := by
    congr 1
    funext V
    exact physicalBobTwirlIntegrand_translate K W V
  calc
    physicalBobMixedRepresentation (a := a) (r := r) W *
        physicalBobTwirl K *
        star (physicalBobMixedRepresentation (a := a) (r := r) W) =
        ∫ V : Matrix.unitaryGroup b ℂ,
          physicalBobMixedRepresentation (a := a) (r := r) W *
            physicalBobTwirlIntegrand K V *
            star (physicalBobMixedRepresentation (a := a) (r := r) W)
          ∂unitaryHaarMeasure (a := b) := by
      rw [physicalBobTwirl]
      exact matrix_mul_integral_mul
        (physicalBobMixedRepresentation (a := a) (r := r) W)
        (star (physicalBobMixedRepresentation (a := a) (r := r) W)) hf
    _ = ∫ V : Matrix.unitaryGroup b ℂ,
          physicalBobTwirlIntegrand K (W * V)
          ∂unitaryHaarMeasure (a := b) := htranslate
    _ = physicalBobTwirl K := by
      simpa [physicalBobTwirl] using
        (MeasureTheory.integral_mul_left_eq_self
          (μ := unitaryHaarMeasure (a := b))
          (physicalBobTwirlIntegrand K) W)

private theorem physicalAliceTwirlIntegrand_bob_conjugation
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    physicalBobMixedRepresentation (a := a) (r := r) V *
        physicalAliceTwirlIntegrand K U *
        star (physicalBobMixedRepresentation (a := a) (r := r) V) =
      physicalAliceTwirlIntegrand
        (physicalBobMixedRepresentation (a := a) (r := r) V * K *
          star (physicalBobMixedRepresentation (a := a) (r := r) V)) U := by
  let A := physicalAliceMixedRepresentation (b := b) (r := r) U
  let B := physicalBobMixedRepresentation (a := a) (r := r) V
  have hcomm : B * A = A * B := by
    simpa [A, B] using
      (physicalAliceMixedRepresentation_commutes_physicalBobMixedRepresentation
        (r := r) U V).symm
  have hcommStar : star A * star B = star B * star A := by
    simpa only [star_mul] using congrArg star hcomm
  change B * (A * K * star A) * star B =
    A * (B * K * star B) * star A
  calc
    B * (A * K * star A) * star B =
        (B * A) * K * (star A * star B) := by
      simp only [mul_assoc]
    _ = (A * B) * K * (star B * star A) := by
      rw [hcomm, hcommStar]
    _ = A * (B * K * star B) * star A := by
      simp only [mul_assoc]

theorem physicalAliceTwirl_bob_conjugation
    [Nonempty a] [Nonempty b] [Nonempty r]
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (V : Matrix.unitaryGroup b ℂ) :
    physicalBobMixedRepresentation (a := a) (r := r) V *
        physicalAliceTwirl K *
        star (physicalBobMixedRepresentation (a := a) (r := r) V) =
      physicalAliceTwirl
        (physicalBobMixedRepresentation (a := a) (r := r) V * K *
          star (physicalBobMixedRepresentation (a := a) (r := r) V)) := by
  have hf : Integrable (physicalAliceTwirlIntegrand K)
      (unitaryHaarMeasure (a := a)) :=
    physicalAliceTwirlIntegrand_integrable K
  calc
    physicalBobMixedRepresentation (a := a) (r := r) V *
          physicalAliceTwirl K *
          star (physicalBobMixedRepresentation (a := a) (r := r) V) =
        ∫ U : Matrix.unitaryGroup a ℂ,
          physicalBobMixedRepresentation (a := a) (r := r) V *
            physicalAliceTwirlIntegrand K U *
            star (physicalBobMixedRepresentation (a := a) (r := r) V)
          ∂unitaryHaarMeasure (a := a) := by
      rw [physicalAliceTwirl]
      exact matrix_mul_integral_mul
        (physicalBobMixedRepresentation (a := a) (r := r) V)
        (star (physicalBobMixedRepresentation (a := a) (r := r) V)) hf
    _ = ∫ U : Matrix.unitaryGroup a ℂ,
          physicalAliceTwirlIntegrand
            (physicalBobMixedRepresentation (a := a) (r := r) V * K *
              star (physicalBobMixedRepresentation (a := a) (r := r) V)) U
          ∂unitaryHaarMeasure (a := a) := by
      congr 1
      funext U
      exact physicalAliceTwirlIntegrand_bob_conjugation K U V
    _ = physicalAliceTwirl
          (physicalBobMixedRepresentation (a := a) (r := r) V * K *
            star (physicalBobMixedRepresentation (a := a) (r := r) V)) := by
      rw [physicalAliceTwirl]

theorem physicalLocalTwirl_alice_conj_invariant
    [Nonempty a] [Nonempty b] [Nonempty r]
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (U : Matrix.unitaryGroup a ℂ) :
    physicalAliceMixedRepresentation (b := b) (r := r) U *
        physicalLocalTwirl K *
        star (physicalAliceMixedRepresentation (b := b) (r := r) U) =
      physicalLocalTwirl K := by
  exact physicalAliceTwirl_conj_invariant (physicalBobTwirl K) U

theorem physicalLocalTwirl_bob_conj_invariant
    [Nonempty a] [Nonempty b] [Nonempty r]
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (V : Matrix.unitaryGroup b ℂ) :
    physicalBobMixedRepresentation (a := a) (r := r) V *
        physicalLocalTwirl K *
        star (physicalBobMixedRepresentation (a := a) (r := r) V) =
      physicalLocalTwirl K := by
  rw [physicalLocalTwirl, physicalAliceTwirl_bob_conjugation,
    physicalBobTwirl_conj_invariant]

theorem physicalLocalTwirl_jointContractionPhysicalInvariant
    [Nonempty a] [Nonempty b] [Nonempty r]
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    JointContractionPhysicalInvariant (physicalLocalTwirl K) := by
  intro U V
  let A := physicalAliceMixedRepresentation (b := b) (r := r) U
  let B := physicalBobMixedRepresentation (a := a) (r := r) V
  let X := physicalLocalTwirl K
  have hR : A * B = jointContractionPhysicalRepresentation (r := r) U V := by
    simpa [A, B] using
      physicalAliceMixedRepresentation_mul_physicalBobMixedRepresentation
        (r := r) U V
  have hA : A * X * Matrix.conjTranspose A = X := by
    simpa [A, X, Matrix.star_eq_conjTranspose] using
      physicalLocalTwirl_alice_conj_invariant K U
  have hB : B * X * Matrix.conjTranspose B = X := by
    simpa [B, X, Matrix.star_eq_conjTranspose] using
      physicalLocalTwirl_bob_conj_invariant K V
  rw [← hR]
  calc
    (A * B) * X * Matrix.conjTranspose (A * B) =
        A * (B * X * Matrix.conjTranspose B) * Matrix.conjTranspose A := by
      simp only [Matrix.conjTranspose_mul, mul_assoc]
    _ = A * X * Matrix.conjTranspose A := by rw [hB]
    _ = X := hA

theorem physicalAliceTwirl_conjTranspose
    [Nonempty a] [Nonempty b] [Nonempty r]
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    (physicalAliceTwirl K).conjTranspose =
      physicalAliceTwirl K.conjTranspose := by
  rw [physicalAliceTwirl, physicalAliceTwirl]
  have hf : Integrable (physicalAliceTwirlIntegrand K)
      (unitaryHaarMeasure (a := a)) :=
    physicalAliceTwirlIntegrand_integrable K
  rw [integral_matrix_conjTranspose (hf := hf)]
  congr 1
  funext U
  simp [physicalAliceTwirlIntegrand, Matrix.conjTranspose_mul,
    Matrix.star_eq_conjTranspose, mul_assoc]

theorem physicalBobTwirl_conjTranspose
    [Nonempty a] [Nonempty b] [Nonempty r]
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    (physicalBobTwirl K).conjTranspose =
      physicalBobTwirl K.conjTranspose := by
  rw [physicalBobTwirl, physicalBobTwirl]
  have hf : Integrable (physicalBobTwirlIntegrand K)
      (unitaryHaarMeasure (a := b)) :=
    physicalBobTwirlIntegrand_integrable K
  rw [integral_matrix_conjTranspose (hf := hf)]
  congr 1
  funext V
  simp [physicalBobTwirlIntegrand, Matrix.conjTranspose_mul,
    Matrix.star_eq_conjTranspose, mul_assoc]

theorem physicalAliceTwirl_isHermitian_of_isHermitian
    [Nonempty a] [Nonempty b] [Nonempty r]
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hK : K.IsHermitian) :
    (physicalAliceTwirl K).IsHermitian := by
  rw [Matrix.IsHermitian, physicalAliceTwirl_conjTranspose, hK.eq]

theorem physicalBobTwirl_isHermitian_of_isHermitian
    [Nonempty a] [Nonempty b] [Nonempty r]
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hK : K.IsHermitian) :
    (physicalBobTwirl K).IsHermitian := by
  rw [Matrix.IsHermitian, physicalBobTwirl_conjTranspose, hK.eq]

private theorem physicalAliceTwirlIntegrand_posSemidef
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hK : K.PosSemidef) (U : Matrix.unitaryGroup a ℂ) :
    (physicalAliceTwirlIntegrand K U).PosSemidef := by
  simpa [physicalAliceTwirlIntegrand, Matrix.star_eq_conjTranspose,
    mul_assoc] using
    hK.mul_mul_conjTranspose_same
      (physicalAliceMixedRepresentation (b := b) (r := r) U)

private theorem physicalBobTwirlIntegrand_posSemidef
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hK : K.PosSemidef) (V : Matrix.unitaryGroup b ℂ) :
    (physicalBobTwirlIntegrand K V).PosSemidef := by
  simpa [physicalBobTwirlIntegrand, Matrix.star_eq_conjTranspose,
    mul_assoc] using
    hK.mul_mul_conjTranspose_same
      (physicalBobMixedRepresentation (a := a) (r := r) V)

theorem physicalAliceTwirl_posSemidef
    [Nonempty a] [Nonempty b] [Nonempty r]
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hK : K.PosSemidef) :
    (physicalAliceTwirl K).PosSemidef := by
  refine Matrix.PosSemidef.of_dotProduct_mulVec_nonneg
    (physicalAliceTwirl_isHermitian_of_isHermitian hK.isHermitian) ?_
  intro x
  have hf : Integrable (physicalAliceTwirlIntegrand K)
      (unitaryHaarMeasure (a := a)) :=
    physicalAliceTwirlIntegrand_integrable K
  rw [physicalAliceTwirl, integral_dotProduct_mulVec (hf := hf) x]
  refine integral_nonneg fun U ↦ ?_
  exact (physicalAliceTwirlIntegrand_posSemidef hK U).dotProduct_mulVec_nonneg x

theorem physicalBobTwirl_posSemidef
    [Nonempty a] [Nonempty b] [Nonempty r]
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hK : K.PosSemidef) :
    (physicalBobTwirl K).PosSemidef := by
  refine Matrix.PosSemidef.of_dotProduct_mulVec_nonneg
    (physicalBobTwirl_isHermitian_of_isHermitian hK.isHermitian) ?_
  intro x
  have hf : Integrable (physicalBobTwirlIntegrand K)
      (unitaryHaarMeasure (a := b)) :=
    physicalBobTwirlIntegrand_integrable K
  rw [physicalBobTwirl, integral_dotProduct_mulVec (hf := hf) x]
  refine integral_nonneg fun V ↦ ?_
  exact (physicalBobTwirlIntegrand_posSemidef hK V).dotProduct_mulVec_nonneg x

theorem physicalLocalTwirl_posSemidef
    [Nonempty a] [Nonempty b] [Nonempty r]
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hK : K.PosSemidef) :
    (physicalLocalTwirl K).PosSemidef := by
  exact physicalAliceTwirl_posSemidef (physicalBobTwirl_posSemidef hK)

theorem physicalAliceTwirl_add [Nonempty a] [Nonempty b] [Nonempty r]
    (K L : CMatrix (JointContractionPhysicalIndex a b r)) :
    physicalAliceTwirl (K + L) =
      physicalAliceTwirl K + physicalAliceTwirl L := by
  rw [physicalAliceTwirl, physicalAliceTwirl, physicalAliceTwirl]
  rw [← MeasureTheory.integral_add
    (physicalAliceTwirlIntegrand_integrable K)
    (physicalAliceTwirlIntegrand_integrable L)]
  congr 1
  funext U
  simp [physicalAliceTwirlIntegrand, Matrix.mul_add, Matrix.add_mul]

theorem physicalBobTwirl_add [Nonempty a] [Nonempty b] [Nonempty r]
    (K L : CMatrix (JointContractionPhysicalIndex a b r)) :
    physicalBobTwirl (K + L) =
      physicalBobTwirl K + physicalBobTwirl L := by
  rw [physicalBobTwirl, physicalBobTwirl, physicalBobTwirl]
  rw [← MeasureTheory.integral_add
    (physicalBobTwirlIntegrand_integrable K)
    (physicalBobTwirlIntegrand_integrable L)]
  congr 1
  funext V
  simp [physicalBobTwirlIntegrand, Matrix.mul_add, Matrix.add_mul]

theorem physicalLocalTwirl_add [Nonempty a] [Nonempty b] [Nonempty r]
    (K L : CMatrix (JointContractionPhysicalIndex a b r)) :
    physicalLocalTwirl (K + L) =
      physicalLocalTwirl K + physicalLocalTwirl L := by
  simp only [physicalLocalTwirl, physicalBobTwirl_add,
    physicalAliceTwirl_add]

theorem physicalAliceTwirl_smul [Nonempty a] [Nonempty b] [Nonempty r]
    (c : ℂ) (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    physicalAliceTwirl (c • K) = c • physicalAliceTwirl K := by
  rw [physicalAliceTwirl, physicalAliceTwirl]
  calc
    (∫ U : Matrix.unitaryGroup a ℂ,
        physicalAliceTwirlIntegrand (c • K) U
        ∂unitaryHaarMeasure (a := a)) =
      ∫ U : Matrix.unitaryGroup a ℂ,
        c • physicalAliceTwirlIntegrand K U
        ∂unitaryHaarMeasure (a := a) := by
      congr 1
      funext U
      simp [physicalAliceTwirlIntegrand]
    _ = c • ∫ U : Matrix.unitaryGroup a ℂ,
        physicalAliceTwirlIntegrand K U
        ∂unitaryHaarMeasure (a := a) := by
      exact MeasureTheory.integral_smul c _

theorem physicalBobTwirl_smul [Nonempty a] [Nonempty b] [Nonempty r]
    (c : ℂ) (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    physicalBobTwirl (c • K) = c • physicalBobTwirl K := by
  rw [physicalBobTwirl, physicalBobTwirl]
  calc
    (∫ V : Matrix.unitaryGroup b ℂ,
        physicalBobTwirlIntegrand (c • K) V
        ∂unitaryHaarMeasure (a := b)) =
      ∫ V : Matrix.unitaryGroup b ℂ,
        c • physicalBobTwirlIntegrand K V
        ∂unitaryHaarMeasure (a := b) := by
      congr 1
      funext V
      simp [physicalBobTwirlIntegrand]
    _ = c • ∫ V : Matrix.unitaryGroup b ℂ,
        physicalBobTwirlIntegrand K V
        ∂unitaryHaarMeasure (a := b) := by
      exact MeasureTheory.integral_smul c _

theorem physicalLocalTwirl_smul [Nonempty a] [Nonempty b] [Nonempty r]
    (c : ℂ) (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    physicalLocalTwirl (c • K) = c • physicalLocalTwirl K := by
  simp only [physicalLocalTwirl, physicalBobTwirl_smul,
    physicalAliceTwirl_smul]

/-- The physical local Haar twirl as a complex-linear endomorphism. -/
def physicalLocalTwirlLinearMap [Nonempty a] [Nonempty b] [Nonempty r] :
    CMatrix (JointContractionPhysicalIndex a b r) →ₗ[ℂ]
      CMatrix (JointContractionPhysicalIndex a b r) where
  toFun := physicalLocalTwirl
  map_add' := physicalLocalTwirl_add
  map_smul' := physicalLocalTwirl_smul

end

end EntanglementPurification
