import EntanglementPurification.ShannonCollisionEquality
import Mathlib.Tactic

namespace EntanglementPurification

noncomputable section

open scoped BigOperators

/-- Finite Abel lemma in weighted-difference form, the algebraic core of
finite Karamata for concave functions on ordered vectors. -/
theorem sum_range_weighted_diff_nonneg_of_prefix
    (n : ℕ) (p q w : ℕ → ℝ)
    (hprefix : ∀ k, k ≤ n →
      ∑ i ∈ Finset.range k, p i ≤ ∑ i ∈ Finset.range k, q i)
    (htotal : (∑ i ∈ Finset.range n, p i) =
      ∑ i ∈ Finset.range n, q i)
    (hweight : ∀ i, i + 1 < n → w i ≤ w (i + 1)) :
    0 ≤ ∑ i ∈ Finset.range n, w i * (p i - q i) := by
  let d : ℕ → ℝ := fun i => q i - p i
  have hpartial : ∀ k, k ≤ n → 0 ≤ ∑ i ∈ Finset.range k, d i := by
    intro k hk
    rw [Finset.sum_sub_distrib]
    exact sub_nonneg.mpr (hprefix k hk)
  have htotalDiff : (∑ i ∈ Finset.range n, d i) = 0 := by
    rw [Finset.sum_sub_distrib, ← htotal, sub_self]
  have hterm : 0 ≤ ∑ i ∈ Finset.range (n - 1),
      (w (i + 1) - w i) * (∑ j ∈ Finset.range (i + 1), d j) := by
    apply Finset.sum_nonneg
    intro i hi
    have hiLt : i + 1 < n := by
      have := Finset.mem_range.mp hi
      omega
    exact mul_nonneg (sub_nonneg.mpr (hweight i hiLt))
      (hpartial (i + 1) (by omega))
  have hparts := Finset.sum_range_by_parts w d n
  simp only [smul_eq_mul] at hparts
  rw [htotalDiff, mul_zero, zero_sub] at hparts
  have hwd : (∑ i ∈ Finset.range n, w i * d i) ≤ 0 := by
    rw [hparts]
    exact neg_nonpos.mpr hterm
  have hrewrite :
      (∑ i ∈ Finset.range n, w i * (p i - q i)) =
        -(∑ i ∈ Finset.range n, w i * d i) := by
    rw [← Finset.sum_neg_distrib]
    apply Finset.sum_congr rfl
    intro i hi
    dsimp [d]
    ring
  rw [hrewrite]
  exact neg_nonneg.mpr hwd

/-- For `p₀ > 1/2`, the three-point boundary spectrum has strictly more than
one bit of Shannon entropy. -/
theorem one_lt_shannonEntropyBits_threePointComparison_on_interval
    (m : ℕ) {x : ℝ} (hxLower : (1 / 2 : ℝ) < x) (hxUpper : x ≤ 2 / 3) :
    1 < shannonEntropyBits (threePointComparison m x (zStar x)) := by
  let q := threePointComparison m x (zStar x)
  have hq : IsOrderedProbability q :=
    threePointComparison_isOrderedProbability_on_interval
      m (le_of_lt hxLower) hxUpper
  have hcollision : collisionProbability q ≤ 1 / 2 := by
    rw [collisionProbability_threePointComparison_on_interval
      m (le_of_lt hxLower) hxUpper]
  have hone : 1 ≤ shannonEntropyBits q :=
    one_le_shannonEntropyBits_of_orderedProbability_of_collisionProbability_le_half
      hq hcollision
  apply lt_of_le_of_ne hone
  intro heq
  have hqeq : q = twoPointComparison (m + 1) :=
    orderedProbability_eq_twoPoint_of_collision_le_half_of_shannon_eq_one
      hq hcollision heq.symm
  have hhead := congrFun hqeq (0 : Fin (m + 3))
  simp [q, threePointComparison, twoPointComparison] at hhead
  linarith

/-- Any ordered Schmidt spectrum with collision probability at most one half
and largest weight strictly above one half has Shannon entropy strictly above
one bit.  This is the equality-rigidity form of the Shannon--collision bound. -/
theorem one_lt_shannonEntropyBits_of_orderedProbability_of_collision_le_half_of_head_gt_half
    {m : ℕ} {p : Fin (m + 3) → ℝ}
    (hp : IsOrderedProbability p)
    (hcollision : collisionProbability p ≤ 1 / 2)
    (hhead : (1 / 2 : ℝ) < p 0) :
    1 < shannonEntropyBits p := by
  have hlower : 1 ≤ shannonEntropyBits p :=
    one_le_shannonEntropyBits_of_orderedProbability_of_collisionProbability_le_half
      hp hcollision
  by_contra hnot
  have heq : shannonEntropyBits p = 1 :=
    le_antisymm (le_of_not_gt hnot) hlower
  have hspectrum :
      p = twoPointComparison (m + 1) :=
    orderedProbability_eq_twoPoint_of_collision_le_half_of_shannon_eq_one
      hp hcollision heq
  have hzero := congrFun hspectrum (0 : Fin (m + 3))
  simp [twoPointComparison] at hzero
  linarith

end

end EntanglementPurification
