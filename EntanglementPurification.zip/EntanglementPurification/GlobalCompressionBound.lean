import EntanglementPurification.GlobalContractions
import EntanglementPurification.GlobalSectorUniqueness
import EntanglementPurification.EffectBounds
import Mathlib.Tactic

/-!
# Compression bound on the distinguished global sector

This file proves the matrix inequality used in the uniqueness step of the
global CPTN SDP.  The key input is an explicit coordinate formula for the
output partial trace of `W₊ A W₊ᴴ`.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

private theorem globalWPlus_normalizer_mul_self
    {x : Type*} [Fintype x] :
    (1 / Real.sqrt (2 * ((Fintype.card x : ℝ) + 1))) *
        (1 / Real.sqrt (2 * ((Fintype.card x : ℝ) + 1))) =
      1 / (2 * ((Fintype.card x : ℝ) + 1)) := by
  have harg : 0 < 2 * ((Fintype.card x : ℝ) + 1) := by positivity
  have hsqrtNe : Real.sqrt (2 * ((Fintype.card x : ℝ) + 1)) ≠ 0 :=
    ne_of_gt (Real.sqrt_pos.2 harg)
  have hsquare :
      (Real.sqrt (2 * ((Fintype.card x : ℝ) + 1))) ^ 2 =
        2 * ((Fintype.card x : ℝ) + 1) :=
    Real.sq_sqrt harg.le
  have hr :
      (1 / Real.sqrt (2 * ((Fintype.card x : ℝ) + 1))) *
          (1 / Real.sqrt (2 * ((Fintype.card x : ℝ) + 1))) =
        1 / (2 * ((Fintype.card x : ℝ) + 1)) := by
    rw [one_div, one_div, ← mul_inv, ← pow_two, hsquare]
  exact hr

set_option maxHeartbeats 1000000 in
private theorem partialTraceB_globalGammaPlus_compression_apply
    {x : Type*} [Fintype x] [DecidableEq x]
    (A : CMatrix x) (a b c d : x) :
    QIT.partialTraceB (a := x × x) (b := x)
        (globalGammaPlus * A * Matrix.conjTranspose globalGammaPlus)
        (a, b) (c, d) =
      (if a = c then A b d else 0) +
        (if a = d then A b c else 0) +
        (if b = c then A a d else 0) +
        (if b = d then A a c else 0) := by
  by_cases hac : a = c <;> by_cases had : a = d <;>
    by_cases hbc : b = c <;> by_cases hbd : b = d
  all_goals simp_all [QIT.partialTraceB, Matrix.mul_apply,
    globalGammaPlus, globalGamma1, globalGamma2,
    mul_add, add_mul, Finset.sum_add_distrib, eq_comm] <;> ring

/-- General-`A` output partial-trace formula for the distinguished
intertwiner.  This is the four Kronecker-delta contraction used in the paper. -/
theorem partialTraceB_globalWPlus_compression_apply
    {x : Type*} [Fintype x] [DecidableEq x]
    (A : CMatrix x) (a b c d : x) :
    QIT.partialTraceB (a := x × x) (b := x)
        (globalWPlus * A * Matrix.conjTranspose globalWPlus)
        (a, b) (c, d) =
      (1 / (2 * ((Fintype.card x : ℝ) + 1)) : ℂ) *
        ((if a = c then A b d else 0) +
          (if a = d then A b c else 0) +
          (if b = c then A a d else 0) +
          (if b = d then A a c else 0)) := by
  have hmatrix :
      globalWPlus * A * Matrix.conjTranspose globalWPlus =
        (1 / (2 * ((Fintype.card x : ℝ) + 1)) : ℂ) •
          (globalGammaPlus * A * Matrix.conjTranspose globalGammaPlus) := by
    simp only [globalWPlus, Matrix.conjTranspose_smul, star_trivial,
      Matrix.smul_mul, Matrix.mul_smul, smul_smul]
    rw [globalWPlus_normalizer_mul_self]
    ext p q
    simp [Complex.real_smul]
  rw [hmatrix, QIT.partialTraceB_smul]
  simp [partialTraceB_globalGammaPlus_compression_apply]

/-- Product vector `u ⊗ u` on the two-copy input space. -/
def globalProductVector
    {x : Type*} (u : x → ℂ) : x × x → ℂ :=
  fun p => u p.1 * u p.2

/-- The squared norm of `u ⊗ u` is the square of the squared norm of `u`. -/
theorem globalProductVector_dotProduct_self
    {x : Type*} [Fintype x] (u : x → ℂ) :
    star (globalProductVector u) ⬝ᵥ globalProductVector u =
      (star u ⬝ᵥ u) ^ 2 := by
  simp [globalProductVector, dotProduct, Fintype.sum_prod_type, Pi.star_apply,
    star_mul, pow_two, Finset.sum_mul, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i hi
  apply Finset.sum_congr rfl
  intro j hj
  ring_nf

/-- Real squared-norm form of `globalProductVector_dotProduct_self`. -/
theorem cVecNormSq_globalProductVector
    {x : Type*} [Fintype x] (u : x → ℂ) :
    cVecNormSq (globalProductVector u) = (cVecNormSq u) ^ 2 := by
  have hn := dotProduct_star_self_nonneg u
  have hself : star u ⬝ᵥ u = ((cVecNormSq u : ℝ) : ℂ) := by
    apply Complex.ext
    · rfl
    · simpa [cVecNormSq] using (Complex.nonneg_iff.mp hn).2.symm
  change (star (globalProductVector u) ⬝ᵥ globalProductVector u).re =
    (star u ⬝ᵥ u).re ^ 2
  rw [globalProductVector_dotProduct_self, hself]
  norm_cast

private theorem globalCompression_sum_same_scaled
    {x : Type*} [Fintype x]
    (A : CMatrix x) (u : x → ℂ) (c : ℂ) :
    (∑ i : x, ∑ j : x, ∑ k : x,
        star (u i) * star (u j) * c * A j k * u i * u k) =
      c * (star u ⬝ᵥ u) * (star u ⬝ᵥ A.mulVec u) := by
  symm
  simp only [Matrix.mulVec, dotProduct]
  conv_lhs =>
    lhs
    rw [Finset.mul_sum]
  rw [Finset.sum_mul]
  simp_rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i hi
  apply Finset.sum_congr rfl
  intro j hj
  apply Finset.sum_congr rfl
  intro k hk
  simp only [Pi.star_apply]
  ring_nf

private theorem globalCompression_sum_swap_scaled
    {x : Type*} [Fintype x]
    (A : CMatrix x) (u : x → ℂ) (c : ℂ) :
    (∑ i : x, ∑ j : x, ∑ k : x,
        star (u i) * star (u j) * c * A i k * u j * u k) =
      c * (star u ⬝ᵥ u) * (star u ⬝ᵥ A.mulVec u) := by
  rw [Finset.sum_comm]
  simpa only [mul_comm, mul_left_comm, mul_assoc] using
    globalCompression_sum_same_scaled A u c

private theorem globalCompression_four_sums_scaled
    {x : Type*} [Fintype x]
    (A : CMatrix x) (u : x → ℂ) (c : ℂ) :
    (∑ i : x, ∑ j : x, ∑ k : x,
        star (u i) * star (u j) * c * A j k * u i * u k) +
      (∑ i : x, ∑ j : x, ∑ k : x,
        c * star (u i) * star (u j) * A j k * u k * u i) +
      (∑ i : x, ∑ j : x, ∑ k : x,
        c * star (u i) * star (u j) * A i k * u j * u k) +
      (∑ i : x, ∑ j : x, ∑ k : x,
        c * star (u i) * star (u j) * A i k * u k * u j) =
      (4 * c) * (star u ⬝ᵥ u) * (star u ⬝ᵥ A.mulVec u) := by
  have h1 := globalCompression_sum_same_scaled A u c
  have h2 :
      (∑ i : x, ∑ j : x, ∑ k : x,
          c * star (u i) * star (u j) * A j k * u k * u i) =
        c * (star u ⬝ᵥ u) * (star u ⬝ᵥ A.mulVec u) := by
    simpa only [mul_comm, mul_left_comm, mul_assoc] using h1
  have h3 :
      (∑ i : x, ∑ j : x, ∑ k : x,
          c * star (u i) * star (u j) * A i k * u j * u k) =
        c * (star u ⬝ᵥ u) * (star u ⬝ᵥ A.mulVec u) := by
    simpa only [mul_comm, mul_left_comm, mul_assoc] using
      globalCompression_sum_swap_scaled A u c
  have h4 :
      (∑ i : x, ∑ j : x, ∑ k : x,
          c * star (u i) * star (u j) * A i k * u k * u j) =
        c * (star u ⬝ᵥ u) * (star u ⬝ᵥ A.mulVec u) := by
    simpa only [mul_comm, mul_left_comm, mul_assoc] using
      globalCompression_sum_swap_scaled A u c
  rw [h1, h2, h3, h4]
  ring

/-- Arbitrary-vector (homogeneous) contraction identity.  No unit-vector
normalization is assumed. -/
theorem globalProductVector_partialTraceB_globalWPlus_compression
    {x : Type*} [Fintype x] [DecidableEq x]
    (A : CMatrix x) (u : x → ℂ) :
    star (globalProductVector u) ⬝ᵥ
        (QIT.partialTraceB (a := x × x) (b := x)
          (globalWPlus * A * Matrix.conjTranspose globalWPlus)).mulVec
          (globalProductVector u) =
      (2 / ((Fintype.card x : ℝ) + 1) : ℂ) *
        (star u ⬝ᵥ u) * (star u ⬝ᵥ A.mulVec u) := by
  let c : ℂ := 1 / (2 * ((Fintype.card x : ℝ) + 1))
  calc
    star (globalProductVector u) ⬝ᵥ
          (QIT.partialTraceB (a := x × x) (b := x)
            (globalWPlus * A * Matrix.conjTranspose globalWPlus)).mulVec
            (globalProductVector u) =
        (∑ i : x, ∑ j : x, ∑ k : x,
            star (u i) * star (u j) * (c * A j k * (u i * u k))) +
          (∑ i : x, ∑ j : x, ∑ k : x,
            star (u i) * star (u j) * (c * A j k * (u k * u i))) +
          (∑ i : x, ∑ j : x, ∑ k : x,
            star (u i) * star (u j) * (c * A i k * (u j * u k))) +
          (∑ i : x, ∑ j : x, ∑ k : x,
            star (u i) * star (u j) * (c * A i k * (u k * u j))) := by
              simp [Matrix.mulVec, dotProduct, Fintype.sum_prod_type,
                globalProductVector, partialTraceB_globalWPlus_compression_apply,
                c, Finset.mul_sum,
                mul_add, add_mul, Finset.sum_add_distrib]
    _ = (4 * c) * (star u ⬝ᵥ u) * (star u ⬝ᵥ A.mulVec u) := by
      simpa only [mul_comm, mul_left_comm, mul_assoc] using
        globalCompression_four_sums_scaled A u c
    _ = (2 / ((Fintype.card x : ℝ) + 1) : ℂ) *
          (star u ⬝ᵥ u) * (star u ⬝ᵥ A.mulVec u) := by
      have hdenR : (Fintype.card x : ℝ) + 1 ≠ 0 := by positivity
      have hdenC : (((Fintype.card x : ℝ) + 1 : ℝ) : ℂ) ≠ 0 := by
        exact_mod_cast hdenR
      have hc : 4 * c = (2 / ((Fintype.card x : ℝ) + 1) : ℂ) := by
        dsimp [c]
        field_simp [hdenC]
        ring
      rw [hc]

/-- Real quadratic-form version of the arbitrary-vector contraction
identity.  Hermiticity is used only to discard the imaginary part of the
quadratic form of `A`. -/
theorem quadraticRe_partialTraceB_globalWPlus_compression
    {x : Type*} [Fintype x] [DecidableEq x]
    (A : CMatrix x) (hA : A.IsHermitian) (u : x → ℂ) :
    quadraticRe
        (QIT.partialTraceB (a := x × x) (b := x)
          (globalWPlus * A * Matrix.conjTranspose globalWPlus))
        (globalProductVector u) =
      (2 / ((Fintype.card x : ℝ) + 1)) *
        cVecNormSq u * quadraticRe A u := by
  have hcomplex :=
    globalProductVector_partialTraceB_globalWPlus_compression A u
  have hn := dotProduct_star_self_nonneg u
  have hnIm : (star u ⬝ᵥ u).im = 0 :=
    (Complex.nonneg_iff.mp hn).2.symm
  have hAIm : (star u ⬝ᵥ A.mulVec u).im = 0 :=
    hA.im_star_dotProduct_mulVec_self u
  have hcoef :
      (2 / ((Fintype.card x : ℝ) + 1) : ℂ) =
        ((2 / ((Fintype.card x : ℝ) + 1) : ℝ) : ℂ) := by
    norm_cast
  have hre := congrArg Complex.re hcomplex
  rw [hcoef] at hre
  simpa only [quadraticRe, cVecNormSq, Complex.mul_re,
    Complex.ofReal_re, Complex.ofReal_im, hnIm, hAIm, mul_zero,
    zero_mul, sub_zero] using hre

/-- The distinguished-sector compression bound.  The trace-nonincreasing
constraint on `W₊ A W₊ᴴ` forces every eigenvalue of the Hermitian compression
`A` to be at most `(D+1)/2`. -/
theorem globalWPlus_compression_le_of_isHermitian
    {x : Type*} [Fintype x] [DecidableEq x]
    {A : CMatrix x} (hA : A.IsHermitian)
    (htrace :
      QIT.partialTraceB (a := x × x) (b := x)
          (globalWPlus * A * Matrix.conjTranspose globalWPlus) ≤
        (1 : CMatrix (x × x))) :
    A ≤ (((Fintype.card x : ℝ) + 1) / 2) • (1 : CMatrix x) := by
  rw [Matrix.le_iff]
  let alpha : ℝ := ((Fintype.card x : ℝ) + 1) / 2
  let B : CMatrix x := alpha • (1 : CMatrix x) - A
  change B.PosSemidef
  have hBherm : B.IsHermitian := by
    exact (Matrix.isHermitian_one.smul (IsSelfAdjoint.all alpha)).sub hA
  refine Matrix.PosSemidef.of_dotProduct_mulVec_nonneg hBherm ?_
  intro u
  apply Complex.nonneg_iff.mpr
  constructor
  · by_cases hu : u = 0
    · subst u
      simp
    · let n : ℝ := cVecNormSq u
      let q : ℝ := quadraticRe A u
      let d : ℝ := (Fintype.card x : ℝ) + 1
      have hdpos : 0 < d := by
        dsimp [d]
        positivity
      have hnpos : 0 < n := by
        dsimp [n]
        rw [cVecNormSq_eq_norm_toLp_sq]
        have htoLp :
            (WithLp.toLp 2 u : EuclideanSpace ℂ x) ≠ 0 := by
          intro hzero
          apply hu
          exact (WithLp.toLp_eq_zero 2).mp hzero
        exact sq_pos_of_pos (norm_pos_iff.mpr htoLp)
      have htraceQ :=
        quadraticRe_le_of_le htrace (globalProductVector u)
      have hone :
          quadraticRe (1 : CMatrix (x × x)) (globalProductVector u) =
            cVecNormSq (globalProductVector u) := by
        simp [quadraticRe, cVecNormSq]
      rw [quadraticRe_partialTraceB_globalWPlus_compression A hA u,
        hone, cVecNormSq_globalProductVector] at htraceQ
      change (2 / d) * n * q ≤ n ^ 2 at htraceQ
      have hmul : 2 * n * q ≤ n ^ 2 * d := by
        calc
          2 * n * q = d * ((2 / d) * n * q) := by
            field_simp [ne_of_gt hdpos]
          _ ≤ d * (n ^ 2) :=
            mul_le_mul_of_nonneg_left htraceQ hdpos.le
          _ = n ^ 2 * d := by ring
      have hq : q ≤ d / 2 * n := by
        have hscaled : (2 * n) * q ≤ (2 * n) * (d / 2 * n) := by
          calc
            (2 * n) * q ≤ n ^ 2 * d := by simpa [mul_assoc] using hmul
            _ = (2 * n) * (d / 2 * n) := by ring
        exact le_of_mul_le_mul_left hscaled (show 0 < 2 * n by positivity)
      have hform :
          (star u ⬝ᵥ B.mulVec u).re = alpha * n - q := by
        simp [B, alpha, n, q, quadraticRe, cVecNormSq,
          Matrix.sub_mulVec, Matrix.smul_mulVec, dotProduct_sub,
          dotProduct_smul, Complex.real_smul]
      rw [hform]
      exact sub_nonneg.mpr hq
  · exact (hBherm.im_star_dotProduct_mulVec_self u).symm

/-- PSD-specialized form used when `A` is obtained by compressing a feasible
Choi matrix. -/
theorem globalWPlus_compression_le
    {x : Type*} [Fintype x] [DecidableEq x]
    {A : CMatrix x} (hA : A.PosSemidef)
    (htrace :
      QIT.partialTraceB (a := x × x) (b := x)
          (globalWPlus * A * Matrix.conjTranspose globalWPlus) ≤
        (1 : CMatrix (x × x))) :
    A ≤ (((Fintype.card x : ℝ) + 1) / 2) • (1 : CMatrix x) :=
  globalWPlus_compression_le_of_isHermitian hA.isHermitian htrace

end

end EntanglementPurification
