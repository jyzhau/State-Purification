import QIT.Symmetry.UnitaryTwirl
import Mathlib.Tactic

/-!
# Finite-matrix commutants of full unitary groups

This module proves the concrete Schur-lemma statement needed by the local
mixed-Schur reduction.  The proof uses diagonal sign unitaries to eliminate
off-diagonal entries and permutation unitaries to identify diagonal entries.
It therefore does not assume the desired tensor-factorization conclusion.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {c x : Type*}
  [Fintype c] [Fintype x] [DecidableEq c] [DecidableEq x]

/-- A diagonal sign unitary which flips exactly one coordinate. -/
def coordinateSignUnitary (k : x) : Matrix.unitaryGroup x ℂ :=
  diagonalPhaseUnitary (fun i => if i = k then -1 else 1) (by
    intro i
    by_cases h : i = k <;> simp [h])

@[simp]
theorem coordinateSignUnitary_apply (k i j : x) :
    (coordinateSignUnitary k : CMatrix x) i j =
      if i = j then (if i = k then -1 else 1) else 0 := by
  simp [coordinateSignUnitary]

/-- A permutation matrix regarded as a unitary matrix. -/
def permutationUnitary (σ : Equiv.Perm x) : Matrix.unitaryGroup x ℂ :=
  ⟨σ.permMatrix ℂ, by
    rw [Matrix.mem_unitaryGroup_iff]
    change σ.permMatrix ℂ * Matrix.conjTranspose (σ.permMatrix ℂ) = 1
    rw [Matrix.conjTranspose_permMatrix]
    rw [← Matrix.permMatrix_mul]
    simp⟩

@[simp]
theorem permutationUnitary_apply (σ : Equiv.Perm x) (i j : x) :
    (permutationUnitary σ : CMatrix x) i j = σ.permMatrix ℂ i j := rfl

/-- Operators on `c × x` which commute with every unitary on the `x` factor
have no matrix entries between distinct `x` coordinates. -/
theorem fullUnitaryCommutant_offdiag_eq_zero
    (Q : CMatrix (c × x))
    (hcomm : ∀ U : Matrix.unitaryGroup x ℂ,
      Q * Matrix.kronecker (1 : CMatrix c) (U : CMatrix x) =
        Matrix.kronecker (1 : CMatrix c) (U : CMatrix x) * Q)
    (a b : c) (i j : x) (hij : i ≠ j) :
    Q (a, i) (b, j) = 0 := by
  have h := congrFun (congrFun (hcomm (coordinateSignUnitary i)) (a, i)) (b, j)
  simp [Matrix.mul_apply, Matrix.kronecker, Matrix.one_apply,
    coordinateSignUnitary, Fintype.sum_prod_type, Ne.symm hij] at h
  have htwo : Q (a, i) (b, j) + Q (a, i) (b, j) = 0 := by
    linear_combination h
  calc
    Q (a, i) (b, j) =
        (1 / 2 : ℂ) * (Q (a, i) (b, j) + Q (a, i) (b, j)) := by ring
    _ = 0 := by rw [htwo, mul_zero]

/-- All diagonal `x` entries in a full-unitary commutant block are equal. -/
theorem fullUnitaryCommutant_diag_eq
    (Q : CMatrix (c × x))
    (hcomm : ∀ U : Matrix.unitaryGroup x ℂ,
      Q * Matrix.kronecker (1 : CMatrix c) (U : CMatrix x) =
        Matrix.kronecker (1 : CMatrix c) (U : CMatrix x) * Q)
    (a b : c) (i j : x) :
    Q (a, i) (b, i) = Q (a, j) (b, j) := by
  let σ : Equiv.Perm x := Equiv.swap i j
  have h := congrFun (congrFun (hcomm (permutationUnitary σ)) (a, i)) (b, j)
  have hswap (z : x) : i = (Equiv.swap i j) z ↔ z = j := by
    rw [eq_comm, Equiv.apply_eq_iff_eq_symm_apply]
    simp
  simp [Matrix.mul_apply, Matrix.kronecker, Matrix.one_apply,
    permutationUnitary, Equiv.Perm.permMatrix, PEquiv.toMatrix,
    Fintype.sum_prod_type, Equiv.apply_eq_iff_eq_symm_apply,
    hswap, σ] at h
  exact h

/-- The coefficient on the spectator factor, read from any fixed `x`
coordinate.  The preceding lemma makes this independent of that choice. -/
def fullUnitaryCommutantCoefficient [Nonempty x]
    (Q : CMatrix (c × x)) : CMatrix c :=
  fun a b =>
    let x0 : x := Classical.choice (inferInstance : Nonempty x)
    Q (a, x0) (b, x0)

/-- Finite-matrix Schur lemma for the defining representation of the full
unitary group: its amplified commutant is exactly `B(c) ⊗ I_x`. -/
theorem fullUnitaryCommutant_eq_kronecker_coefficient
    [Nonempty x] (Q : CMatrix (c × x))
    (hcomm : ∀ U : Matrix.unitaryGroup x ℂ,
      Q * Matrix.kronecker (1 : CMatrix c) (U : CMatrix x) =
        Matrix.kronecker (1 : CMatrix c) (U : CMatrix x) * Q) :
    Q = Matrix.kronecker (fullUnitaryCommutantCoefficient Q)
      (1 : CMatrix x) := by
  ext q q'
  rcases q with ⟨a, i⟩
  rcases q' with ⟨b, j⟩
  by_cases hij : i = j
  · subst j
    simpa [Matrix.kronecker, Matrix.kroneckerMap_apply, Matrix.one_apply,
      fullUnitaryCommutantCoefficient] using
        (fullUnitaryCommutant_diag_eq Q hcomm a b i
          (Classical.choice (inferInstance : Nonempty x)))
  · rw [fullUnitaryCommutant_offdiag_eq_zero Q hcomm a b i j hij]
    simp [Matrix.kronecker, Matrix.kroneckerMap_apply, hij]

/-- The Schur coefficient is unique. -/
theorem fullUnitaryCommutant_coefficient_unique
    [Nonempty x] (Q : CMatrix (c × x)) (A : CMatrix c)
    (hA : Q = Matrix.kronecker A (1 : CMatrix x)) :
    A = fullUnitaryCommutantCoefficient Q := by
  ext a b
  let x0 : x := Classical.choice (inferInstance : Nonempty x)
  have hentry := congrFun (congrFun hA (a, x0)) (b, x0)
  simpa [fullUnitaryCommutantCoefficient, x0, Matrix.kronecker,
    Matrix.one_apply] using hentry.symm

/-- Positivity of the amplified operator passes to its Schur coefficient. -/
theorem fullUnitaryCommutantCoefficient_posSemidef
    [Nonempty x] {Q : CMatrix (c × x)} (hQ : Q.PosSemidef) :
    (fullUnitaryCommutantCoefficient Q).PosSemidef := by
  let x0 : x := Classical.choice (inferInstance : Nonempty x)
  have hsub := hQ.submatrix (fun a : c => (a, x0))
  simpa [fullUnitaryCommutantCoefficient, x0, Matrix.submatrix] using hsub

section ProductUnitary

variable {a b : Type*}
  [Fintype a] [Fintype b] [DecidableEq a] [DecidableEq b]

/-- Independent full-unitary invariance kills entries whose Alice coordinate
differs. -/
theorem productUnitaryCommutant_offdiag_left_eq_zero
    (Q : CMatrix (c × (a × b)))
    (hcomm : ∀ (U : Matrix.unitaryGroup a ℂ)
        (V : Matrix.unitaryGroup b ℂ),
      Q * Matrix.kronecker (1 : CMatrix c)
          (Matrix.kronecker (U : CMatrix a) (V : CMatrix b)) =
        Matrix.kronecker (1 : CMatrix c)
            (Matrix.kronecker (U : CMatrix a) (V : CMatrix b)) * Q)
    (s t : c) (i k : a) (j l : b) (hik : i ≠ k) :
    Q (s, (i, j)) (t, (k, l)) = 0 := by
  have h := congrFun (congrFun
    (hcomm (coordinateSignUnitary i) 1) (s, (i, j))) (t, (k, l))
  simp [Matrix.mul_apply, Matrix.kronecker, Matrix.kroneckerMap_apply,
    Matrix.one_apply, coordinateSignUnitary, Fintype.sum_prod_type,
    Ne.symm hik] at h
  have htwo :
      Q (s, (i, j)) (t, (k, l)) + Q (s, (i, j)) (t, (k, l)) = 0 := by
    linear_combination h
  calc
    Q (s, (i, j)) (t, (k, l)) =
        (1 / 2 : ℂ) *
          (Q (s, (i, j)) (t, (k, l)) + Q (s, (i, j)) (t, (k, l))) := by
            ring
    _ = 0 := by rw [htwo, mul_zero]

/-- Independent full-unitary invariance also kills entries whose Bob
coordinate differs. -/
theorem productUnitaryCommutant_offdiag_right_eq_zero
    (Q : CMatrix (c × (a × b)))
    (hcomm : ∀ (U : Matrix.unitaryGroup a ℂ)
        (V : Matrix.unitaryGroup b ℂ),
      Q * Matrix.kronecker (1 : CMatrix c)
          (Matrix.kronecker (U : CMatrix a) (V : CMatrix b)) =
        Matrix.kronecker (1 : CMatrix c)
            (Matrix.kronecker (U : CMatrix a) (V : CMatrix b)) * Q)
    (s t : c) (i k : a) (j l : b) (hjl : j ≠ l) :
    Q (s, (i, j)) (t, (k, l)) = 0 := by
  have h := congrFun (congrFun
    (hcomm 1 (coordinateSignUnitary j)) (s, (i, j))) (t, (k, l))
  simp [Matrix.mul_apply, Matrix.kronecker, Matrix.kroneckerMap_apply,
    Matrix.one_apply, coordinateSignUnitary, Fintype.sum_prod_type,
    Ne.symm hjl] at h
  have htwo :
      Q (s, (i, j)) (t, (k, l)) + Q (s, (i, j)) (t, (k, l)) = 0 := by
    linear_combination h
  calc
    Q (s, (i, j)) (t, (k, l)) =
        (1 / 2 : ℂ) *
          (Q (s, (i, j)) (t, (k, l)) + Q (s, (i, j)) (t, (k, l))) := by
            ring
    _ = 0 := by rw [htwo, mul_zero]

/-- Diagonal Alice coordinates are constant; Bob row/column coordinates are
left untouched. -/
theorem productUnitaryCommutant_diag_left_eq
    (Q : CMatrix (c × (a × b)))
    (hcomm : ∀ (U : Matrix.unitaryGroup a ℂ)
        (V : Matrix.unitaryGroup b ℂ),
      Q * Matrix.kronecker (1 : CMatrix c)
          (Matrix.kronecker (U : CMatrix a) (V : CMatrix b)) =
        Matrix.kronecker (1 : CMatrix c)
            (Matrix.kronecker (U : CMatrix a) (V : CMatrix b)) * Q)
    (s t : c) (i k : a) (j l : b) :
    Q (s, (i, j)) (t, (i, l)) = Q (s, (k, j)) (t, (k, l)) := by
  let σ : Equiv.Perm a := Equiv.swap i k
  have h := congrFun (congrFun
    (hcomm (permutationUnitary σ) 1) (s, (i, j))) (t, (k, l))
  have hswap (z : a) : i = (Equiv.swap i k) z ↔ z = k := by
    rw [eq_comm, Equiv.apply_eq_iff_eq_symm_apply]
    simp
  simp [Matrix.mul_apply, Matrix.kronecker, Matrix.kroneckerMap_apply,
    Matrix.one_apply, permutationUnitary, Equiv.Perm.permMatrix,
    PEquiv.toMatrix, Fintype.sum_prod_type,
    Equiv.apply_eq_iff_eq_symm_apply, hswap, σ] at h
  exact h

/-- Diagonal Bob coordinates are constant; Alice row/column coordinates are
left untouched. -/
theorem productUnitaryCommutant_diag_right_eq
    (Q : CMatrix (c × (a × b)))
    (hcomm : ∀ (U : Matrix.unitaryGroup a ℂ)
        (V : Matrix.unitaryGroup b ℂ),
      Q * Matrix.kronecker (1 : CMatrix c)
          (Matrix.kronecker (U : CMatrix a) (V : CMatrix b)) =
        Matrix.kronecker (1 : CMatrix c)
            (Matrix.kronecker (U : CMatrix a) (V : CMatrix b)) * Q)
    (s t : c) (i k : a) (j l : b) :
    Q (s, (i, j)) (t, (k, j)) = Q (s, (i, l)) (t, (k, l)) := by
  let σ : Equiv.Perm b := Equiv.swap j l
  have h := congrFun (congrFun
    (hcomm 1 (permutationUnitary σ)) (s, (i, j))) (t, (k, l))
  have hswap (z : b) : j = (Equiv.swap j l) z ↔ z = l := by
    rw [eq_comm, Equiv.apply_eq_iff_eq_symm_apply]
    simp
  simp [Matrix.mul_apply, Matrix.kronecker, Matrix.kroneckerMap_apply,
    Matrix.one_apply, permutationUnitary, Equiv.Perm.permMatrix,
    PEquiv.toMatrix, Fintype.sum_prod_type,
    Equiv.apply_eq_iff_eq_symm_apply, hswap, σ] at h
  exact h

/-- Coefficient of the independent-product-unitary commutant. -/
def productUnitaryCommutantCoefficient [Nonempty a] [Nonempty b]
    (Q : CMatrix (c × (a × b))) : CMatrix c :=
  fun s t =>
    let a0 : a := Classical.choice (inferInstance : Nonempty a)
    let b0 : b := Classical.choice (inferInstance : Nonempty b)
    Q (s, (a0, b0)) (t, (a0, b0))

/-- Product-group Schur lemma in the exact tensor order used by the joint
contraction coordinates. -/
theorem productUnitaryCommutant_eq_kronecker_coefficient
    [Nonempty a] [Nonempty b] (Q : CMatrix (c × (a × b)))
    (hcomm : ∀ (U : Matrix.unitaryGroup a ℂ)
        (V : Matrix.unitaryGroup b ℂ),
      Q * Matrix.kronecker (1 : CMatrix c)
          (Matrix.kronecker (U : CMatrix a) (V : CMatrix b)) =
        Matrix.kronecker (1 : CMatrix c)
            (Matrix.kronecker (U : CMatrix a) (V : CMatrix b)) * Q) :
    Q = Matrix.kronecker (productUnitaryCommutantCoefficient Q)
      (1 : CMatrix (a × b)) := by
  ext q q'
  rcases q with ⟨s, i, j⟩
  rcases q' with ⟨t, k, l⟩
  by_cases hik : i = k
  · subst k
    by_cases hjl : j = l
    · subst l
      have hleft := productUnitaryCommutant_diag_left_eq
        Q hcomm s t i (Classical.choice (inferInstance : Nonempty a)) j j
      have hright := productUnitaryCommutant_diag_right_eq
        Q hcomm s t
          (Classical.choice (inferInstance : Nonempty a))
          (Classical.choice (inferInstance : Nonempty a)) j
          (Classical.choice (inferInstance : Nonempty b))
      simpa [Matrix.kronecker, Matrix.kroneckerMap_apply, Matrix.one_apply,
        productUnitaryCommutantCoefficient] using hleft.trans hright
    · rw [productUnitaryCommutant_offdiag_right_eq_zero
        Q hcomm s t i i j l hjl]
      simp [Matrix.kronecker, Matrix.kroneckerMap_apply, hjl]
  · rw [productUnitaryCommutant_offdiag_left_eq_zero
      Q hcomm s t i k j l hik]
    simp [Matrix.kronecker, Matrix.kroneckerMap_apply, hik]

/-- The product-group Schur coefficient is unique. -/
theorem productUnitaryCommutant_coefficient_unique
    [Nonempty a] [Nonempty b] (Q : CMatrix (c × (a × b))) (A : CMatrix c)
    (hA : Q = Matrix.kronecker A (1 : CMatrix (a × b))) :
    A = productUnitaryCommutantCoefficient Q := by
  ext s t
  let a0 : a := Classical.choice (inferInstance : Nonempty a)
  let b0 : b := Classical.choice (inferInstance : Nonempty b)
  have hentry := congrFun (congrFun hA (s, (a0, b0))) (t, (a0, b0))
  simpa [productUnitaryCommutantCoefficient, a0, b0, Matrix.kronecker,
    Matrix.kroneckerMap_apply, Matrix.one_apply] using hentry.symm

/-- Positivity passes from the product-group amplified operator to its unique
coefficient. -/
theorem productUnitaryCommutantCoefficient_posSemidef
    [Nonempty a] [Nonempty b] {Q : CMatrix (c × (a × b))}
    (hQ : Q.PosSemidef) :
    (productUnitaryCommutantCoefficient Q).PosSemidef := by
  let a0 : a := Classical.choice (inferInstance : Nonempty a)
  let b0 : b := Classical.choice (inferInstance : Nonempty b)
  have hsub := hQ.submatrix (fun s : c => (s, (a0, b0)))
  simpa [productUnitaryCommutantCoefficient, a0, b0, Matrix.submatrix] using hsub

end ProductUnitary

end

end EntanglementPurification
