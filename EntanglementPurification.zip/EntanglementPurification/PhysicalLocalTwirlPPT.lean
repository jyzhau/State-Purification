import EntanglementPurification.PhysicalLocalTwirl
import EntanglementPurification.PhysicalPPTCompression

/-!
# Bob-PPT preservation of the physical local Haar twirl

This module proves that the concrete physical Bob partial transpose commutes
with the two genuine Haar averages from `PhysicalLocalTwirl`.  On the Bob
integrand, partial transpose changes the integration variable from `V` to its
entrywise conjugate `Matrix.UnitaryGroup.map_star V`; preservation of normalized
Haar measure under that continuous group automorphism is proved below.
-/

namespace EntanglementPurification

open QIT
open MeasureTheory
open scoped ComplexOrder MatrixOrder Matrix.Norms.L2Operator

noncomputable section

universe uA uB uRA uRB uX

local instance physicalLocalTwirlPPTCMatrixContinuousENorm
    {ι : Type uX} [Fintype ι] [DecidableEq ι] :
    ContinuousENorm (CMatrix ι) :=
  SeminormedAddGroup.toContinuousENorm

variable {a : Type uA} {b : Type uB} {ra : Type uRA} {rb : Type uRB}
  [Fintype a] [Fintype b] [Fintype ra] [Fintype rb]
  [DecidableEq a] [DecidableEq b] [DecidableEq ra] [DecidableEq rb]

private instance physicalLocalTwirlPPTUnitaryGroupSecondCountableTopology
    {ι : Type uX} [Fintype ι] [DecidableEq ι] :
    SecondCountableTopology (Matrix.unitaryGroup ι ℂ) := by
  haveI : SecondCountableTopology (Matrix ι ι ℂ) := by
    change SecondCountableTopology (ι → ι → ℂ)
    infer_instance
  change SecondCountableTopology
    ({X // X ∈ (Matrix.unitaryGroup ι ℂ : Set (Matrix ι ι ℂ))})
  infer_instance

/-- Physical Bob partial transpose as a continuous complex-linear map. -/
noncomputable def physicalBranchPartialTransposeBCLM :
    CMatrix (JointContractionPhysicalIndex a b (ra × rb)) →L[ℂ]
      CMatrix (JointContractionPhysicalIndex a b (ra × rb)) :=
  LinearMap.toContinuousLinearMap
    ({ toFun := physicalBranchPartialTransposeB
       map_add' := by
         intro K L
         ext p q
         rcases p with ⟨⟨uA, uB⟩, i, j⟩
         rcases q with ⟨⟨vA, vB⟩, k, l⟩
         simp
       map_smul' := by
         intro c K
         ext p q
         rcases p with ⟨⟨uA, uB⟩, i, j⟩
         rcases q with ⟨⟨vA, vB⟩, k, l⟩
         simp } :
      CMatrix (JointContractionPhysicalIndex a b (ra × rb)) →ₗ[ℂ]
        CMatrix (JointContractionPhysicalIndex a b (ra × rb)))

@[simp]
theorem physicalBranchPartialTransposeBCLM_apply
    (K : CMatrix (JointContractionPhysicalIndex a b (ra × rb))) :
    physicalBranchPartialTransposeBCLM K =
      physicalBranchPartialTransposeB K :=
  rfl

/-- Physical Bob partial transpose passes through every Bochner integral of
physical matrices. -/
theorem physicalBranchPartialTransposeB_integral
    {α : Type*} [MeasurableSpace α] {μ : Measure α}
    {f : α → CMatrix (JointContractionPhysicalIndex a b (ra × rb))}
    (hf : Integrable f μ) :
    physicalBranchPartialTransposeB (∫ x, f x ∂μ) =
      ∫ x, physicalBranchPartialTransposeB (f x) ∂μ := by
  simpa only [physicalBranchPartialTransposeBCLM_apply] using
    ((physicalBranchPartialTransposeBCLM
      (a := a) (b := b) (ra := ra) (rb := rb)).integral_comp_comm hf).symm

private theorem partialTransposeB_kronecker_sandwich
    {A B : Type*} [Fintype A] [Fintype B]
    (LA RA : CMatrix A) (LB RB : CMatrix B)
    (X : CMatrix (A × B)) :
    QIT.partialTransposeB
        (Matrix.kronecker LA LB * X * Matrix.kronecker RA RB) =
      Matrix.kronecker LA (Matrix.transpose RB) *
        QIT.partialTransposeB X *
          Matrix.kronecker RA (Matrix.transpose LB) := by
  unfold Matrix.kronecker
  ext ⟨i, j⟩ ⟨k, l⟩
  simp only [QIT.partialTransposeB_apply, Matrix.mul_apply,
    Fintype.sum_prod_type, Matrix.kroneckerMap_apply, Matrix.transpose_apply]
  simp_rw [Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro x hx
  rw [Finset.sum_comm]
  conv_rhs => rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro y hy
  conv_rhs => rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro q hq
  apply Finset.sum_congr rfl
  intro s hs
  ring

private theorem conjTranspose_matrix_kronecker
    {A B : Type*} (X : CMatrix A) (Y : CMatrix B) :
    Matrix.conjTranspose (Matrix.kronecker X Y) =
      Matrix.kronecker (Matrix.conjTranspose X) (Matrix.conjTranspose Y) := by
  unfold Matrix.kronecker
  exact Matrix.conjTranspose_kronecker X Y

private theorem reindex_physicalAliceMixedRepresentation_bobGrouping
    (U : Matrix.unitaryGroup a ℂ) :
    (Matrix.reindexAlgEquiv ℂ ℂ
      (jointPhysicalBobGroupingEquiv
        (a := a) (b := b) (ra := ra) (rb := rb)))
        (physicalAliceMixedRepresentation (b := b) (r := ra × rb) U) =
      Matrix.kronecker
        (Matrix.kronecker (localMixedSchurRepresentation U) (1 : CMatrix ra))
        (Matrix.kronecker (1 : CMatrix (LocalMixedSchurSpace b))
          (1 : CMatrix rb)) := by
  ext ⟨uA, i⟩ ⟨uB, j⟩
  simp [Matrix.reindexAlgEquiv_apply, Matrix.reindex_apply,
    jointPhysicalBobGroupingEquiv, physicalAliceMixedRepresentation,
    jointContractionPhysicalRepresentation, Matrix.kronecker,
    Matrix.one_apply, Prod.ext_iff, and_comm, and_left_comm, and_assoc]
  split_ifs <;> simp_all

private theorem reindex_physicalBobMixedRepresentation_bobGrouping
    (V : Matrix.unitaryGroup b ℂ) :
    (Matrix.reindexAlgEquiv ℂ ℂ
      (jointPhysicalBobGroupingEquiv
        (a := a) (b := b) (ra := ra) (rb := rb)))
        (physicalBobMixedRepresentation (a := a) (r := ra × rb) V) =
      Matrix.kronecker
        (Matrix.kronecker (1 : CMatrix (LocalMixedSchurSpace a))
          (1 : CMatrix ra))
        (Matrix.kronecker (localMixedSchurRepresentation V) (1 : CMatrix rb)) := by
  ext ⟨uA, i⟩ ⟨uB, j⟩
  simp [Matrix.reindexAlgEquiv_apply, Matrix.reindex_apply,
    jointPhysicalBobGroupingEquiv, physicalBobMixedRepresentation,
    jointContractionPhysicalRepresentation, Matrix.kronecker,
    Matrix.one_apply, Prod.ext_iff, and_comm, and_left_comm, and_assoc]
  split_ifs <;> simp_all

/-- Pointwise, Alice conjugation commutes with the physical Bob partial
transpose because Alice acts trivially on both Bob registers. -/
theorem physicalBranchPartialTransposeB_physicalAliceTwirlIntegrand
    (K : CMatrix (JointContractionPhysicalIndex a b (ra × rb)))
    (U : Matrix.unitaryGroup a ℂ) :
    physicalBranchPartialTransposeB (physicalAliceTwirlIntegrand K U) =
      physicalAliceTwirlIntegrand (physicalBranchPartialTransposeB K) U := by
  let e := jointPhysicalBobGroupingEquiv
    (a := a) (b := b) (ra := ra) (rb := rb)
  let E := Matrix.reindexAlgEquiv ℂ ℂ e
  let LA : CMatrix (LocalMixedSchurSpace a × ra) :=
    Matrix.kronecker (localMixedSchurRepresentation U) (1 : CMatrix ra)
  let LB : CMatrix (LocalMixedSchurSpace b × rb) :=
    Matrix.kronecker (1 : CMatrix (LocalMixedSchurSpace b)) (1 : CMatrix rb)
  let A := physicalAliceMixedRepresentation (b := b) (r := ra × rb) U
  have hEA : E A = Matrix.kronecker LA LB := by
    simpa [E, e, LA, LB, A] using
      (reindex_physicalAliceMixedRepresentation_bobGrouping
        (a := a) (b := b) (ra := ra) (rb := rb) U)
  have hEstar (X : CMatrix (JointContractionPhysicalIndex a b (ra × rb))) :
      E (star X) = star (E X) := by
    ext p q
    simp [E, e, Matrix.reindexAlgEquiv_apply, Matrix.reindex_apply,
      jointPhysicalBobGroupingEquiv, Matrix.star_eq_conjTranspose,
      Matrix.conjTranspose_apply]
  have hEPT (X : CMatrix (JointContractionPhysicalIndex a b (ra × rb))) :
      E (physicalBranchPartialTransposeB X) =
        QIT.partialTransposeB (E X) := by
    change E (E.symm (QIT.partialTransposeB (E X))) = _
    exact E.apply_symm_apply _
  apply E.injective
  change E (physicalBranchPartialTransposeB (A * K * star A)) =
    E (A * physicalBranchPartialTransposeB K * star A)
  rw [hEPT]
  simp only [map_mul]
  rw [hEA, hEstar, hEA, hEPT]
  simpa [LB, Matrix.star_eq_conjTranspose,
    Matrix.conjTranspose_kronecker] using
    (partialTransposeB_kronecker_sandwich
      LA (star LA) LB (star LB) (E K))

/-- Physical Bob partial transpose commutes with Alice's genuine Haar twirl. -/
theorem physicalBranchPartialTransposeB_physicalAliceTwirl
    [Nonempty a] [Nonempty b] [Nonempty ra] [Nonempty rb]
    (K : CMatrix (JointContractionPhysicalIndex a b (ra × rb))) :
    physicalBranchPartialTransposeB (physicalAliceTwirl K) =
      physicalAliceTwirl (physicalBranchPartialTransposeB K) := by
  rw [physicalAliceTwirl, physicalAliceTwirl,
    physicalBranchPartialTransposeB_integral
      (physicalAliceTwirlIntegrand_integrable K)]
  congr 1
  funext U
  exact physicalBranchPartialTransposeB_physicalAliceTwirlIntegrand K U

private theorem localMixedSchurRepresentation_map_star
    (V : Matrix.unitaryGroup b ℂ) :
    localMixedSchurRepresentation (Matrix.UnitaryGroup.map_star V) =
      Matrix.transpose (star (localMixedSchurRepresentation V)) := by
  ext ⟨⟨i₁, i₂⟩, i₃⟩ ⟨⟨j₁, j₂⟩, j₃⟩
  simp [localMixedSchurRepresentation, localEntrywiseConjugate,
    Matrix.UnitaryGroup.map_star, Matrix.kronecker,
    Matrix.transpose_apply, Matrix.star_eq_conjTranspose,
    Matrix.conjTranspose_apply]

omit [Fintype rb] in
private theorem bobGroupedRepresentation_map_star
    (V : Matrix.unitaryGroup b ℂ) :
    Matrix.kronecker
        (localMixedSchurRepresentation (Matrix.UnitaryGroup.map_star V))
        (1 : CMatrix rb) =
      Matrix.transpose
        (star (Matrix.kronecker (localMixedSchurRepresentation V)
          (1 : CMatrix rb))) := by
  ext ⟨u, j⟩ ⟨v, l⟩
  simp [localMixedSchurRepresentation_map_star, Matrix.kronecker,
    Matrix.one_apply, Matrix.transpose_apply,
    Matrix.star_eq_conjTranspose, Matrix.conjTranspose_apply]
  by_cases h : j = l <;> simp [h]

omit [Fintype rb] in
private theorem star_bobGroupedRepresentation_map_star
    (V : Matrix.unitaryGroup b ℂ) :
    star (Matrix.kronecker
        (localMixedSchurRepresentation (Matrix.UnitaryGroup.map_star V))
        (1 : CMatrix rb)) =
      Matrix.transpose
        (Matrix.kronecker (localMixedSchurRepresentation V)
          (1 : CMatrix rb)) := by
  rw [bobGroupedRepresentation_map_star]
  ext p q
  simp only [Matrix.transpose_apply, Matrix.star_eq_conjTranspose,
    Matrix.conjTranspose_apply, star_star]

/-- Pointwise, Bob partial transpose changes the Bob twirl variable from `V`
to its entrywise conjugate `map_star V`. -/
theorem physicalBranchPartialTransposeB_physicalBobTwirlIntegrand
    (K : CMatrix (JointContractionPhysicalIndex a b (ra × rb)))
    (V : Matrix.unitaryGroup b ℂ) :
    physicalBranchPartialTransposeB (physicalBobTwirlIntegrand K V) =
      physicalBobTwirlIntegrand (physicalBranchPartialTransposeB K)
        (Matrix.UnitaryGroup.map_star V) := by
  let e := jointPhysicalBobGroupingEquiv
    (a := a) (b := b) (ra := ra) (rb := rb)
  let E := Matrix.reindexAlgEquiv ℂ ℂ e
  let IA : CMatrix (LocalMixedSchurSpace a × ra) :=
    Matrix.kronecker (1 : CMatrix (LocalMixedSchurSpace a)) (1 : CMatrix ra)
  let BB : CMatrix (LocalMixedSchurSpace b × rb) :=
    Matrix.kronecker (localMixedSchurRepresentation V) (1 : CMatrix rb)
  let BBstar : CMatrix (LocalMixedSchurSpace b × rb) :=
    Matrix.kronecker
      (localMixedSchurRepresentation (Matrix.UnitaryGroup.map_star V))
      (1 : CMatrix rb)
  let B := physicalBobMixedRepresentation (a := a) (r := ra × rb) V
  let Bstar := physicalBobMixedRepresentation (a := a) (r := ra × rb)
    (Matrix.UnitaryGroup.map_star V)
  have hEB : E B = Matrix.kronecker IA BB := by
    simpa [E, e, IA, BB, B] using
      (reindex_physicalBobMixedRepresentation_bobGrouping
        (a := a) (b := b) (ra := ra) (rb := rb) V)
  have hEBstar : E Bstar = Matrix.kronecker IA BBstar := by
    simpa [E, e, IA, BBstar, Bstar] using
      (reindex_physicalBobMixedRepresentation_bobGrouping
        (a := a) (b := b) (ra := ra) (rb := rb)
        (Matrix.UnitaryGroup.map_star V))
  have hBBleft : BBstar = Matrix.transpose (star BB) := by
    simpa [BBstar, BB] using
      (bobGroupedRepresentation_map_star (rb := rb) V)
  have hBBright : Matrix.conjTranspose BBstar = Matrix.transpose BB := by
    simpa [BBstar, BB, Matrix.star_eq_conjTranspose] using
      (star_bobGroupedRepresentation_map_star (rb := rb) V)
  have hEstar (X : CMatrix (JointContractionPhysicalIndex a b (ra × rb))) :
      E (star X) = star (E X) := by
    ext p q
    simp [E, e, Matrix.reindexAlgEquiv_apply, Matrix.reindex_apply,
      jointPhysicalBobGroupingEquiv, Matrix.star_eq_conjTranspose,
      Matrix.conjTranspose_apply]
  have hEPT (X : CMatrix (JointContractionPhysicalIndex a b (ra × rb))) :
      E (physicalBranchPartialTransposeB X) =
        QIT.partialTransposeB (E X) := by
    change E (E.symm (QIT.partialTransposeB (E X))) = _
    exact E.apply_symm_apply _
  apply E.injective
  change E (physicalBranchPartialTransposeB (B * K * star B)) =
    E (Bstar * physicalBranchPartialTransposeB K * star Bstar)
  rw [hEPT]
  simp only [map_mul]
  rw [hEB, hEstar, hEB, hEPT, hEBstar, hEstar, hEBstar]
  simp only [Matrix.star_eq_conjTranspose]
  rw [conjTranspose_matrix_kronecker IA BB,
    conjTranspose_matrix_kronecker IA BBstar]
  rw [hBBright, hBBleft]
  simpa [IA, Matrix.star_eq_conjTranspose,
    Matrix.conjTranspose_kronecker] using
    (partialTransposeB_kronecker_sandwich
      IA (star IA) BB (star BB) (E K))

/-- Entrywise conjugation is an involutive multiplicative equivalence of the
finite-dimensional unitary group. -/
private def unitaryGroupMapStarMulEquiv :
    Matrix.unitaryGroup b ℂ ≃* Matrix.unitaryGroup b ℂ where
  toFun := Matrix.UnitaryGroup.map_star
  invFun := Matrix.UnitaryGroup.map_star
  left_inv := by
    intro V
    ext i j
    simp [Matrix.UnitaryGroup.map_star]
  right_inv := by
    intro V
    ext i j
    simp [Matrix.UnitaryGroup.map_star]
  map_mul' := by
    intro V W
    ext i j
    simp [Matrix.UnitaryGroup.map_star, Matrix.mul_apply]

private theorem unitaryGroupMapStarMulEquiv_continuous :
    Continuous (unitaryGroupMapStarMulEquiv (b := b) :
      Matrix.unitaryGroup b ℂ → Matrix.unitaryGroup b ℂ) := by
  apply Continuous.subtype_mk
  · refine continuous_pi ?_
    intro i
    refine continuous_pi ?_
    intro j
    exact Complex.continuous_conj.comp
      ((continuous_apply j).comp
        ((continuous_apply i).comp continuous_subtype_val))

/-- The normalized unitary Haar measure is fixed by entrywise conjugation. -/
private theorem unitaryHaarMeasure_map_unitaryGroupMapStar
    [Nonempty b] :
    Measure.map (unitaryGroupMapStarMulEquiv (b := b))
        (unitaryHaarMeasure (a := b)) =
      unitaryHaarMeasure (a := b) := by
  let e := unitaryGroupMapStarMulEquiv (b := b)
  have he : Continuous (e : Matrix.unitaryGroup b ℂ →
      Matrix.unitaryGroup b ℂ) :=
    unitaryGroupMapStarMulEquiv_continuous (b := b)
  change Measure.map e.toMonoidHom (unitaryHaarMeasure (a := b)) =
    unitaryHaarMeasure (a := b)
  letI : Measure.IsHaarMeasure (unitaryHaarMeasure (a := b)) := by
    unfold unitaryHaarMeasure
    infer_instance
  letI : Measure.IsHaarMeasure
      (Measure.map e.toMonoidHom (unitaryHaarMeasure (a := b))) :=
    e.isHaarMeasure_map (unitaryHaarMeasure (a := b)) he he
  letI : IsProbabilityMeasure
      (Measure.map e.toMonoidHom (unitaryHaarMeasure (a := b))) :=
    Measure.isProbabilityMeasure_map he.measurable.aemeasurable
  have htop :
      (Measure.map e.toMonoidHom (unitaryHaarMeasure (a := b)))
          (↑(⊤ : TopologicalSpace.PositiveCompacts
            (Matrix.unitaryGroup b ℂ)) : Set (Matrix.unitaryGroup b ℂ)) = 1 := by
    simpa using (IsProbabilityMeasure.measure_univ :
      (Measure.map e.toMonoidHom (unitaryHaarMeasure (a := b))) Set.univ = 1)
  have h := Measure.haarMeasure_unique
      (Measure.map e.toMonoidHom (unitaryHaarMeasure (a := b)))
      (⊤ : TopologicalSpace.PositiveCompacts (Matrix.unitaryGroup b ℂ))
  rw [htop, one_smul] at h
  simpa [unitaryHaarMeasure] using h

/-- Physical Bob partial transpose commutes with Bob's genuine Haar twirl.
The pointwise `map_star` change is removed using invariance of normalized Haar
measure under that continuous group automorphism. -/
theorem physicalBranchPartialTransposeB_physicalBobTwirl
    [Nonempty a] [Nonempty b] [Nonempty ra] [Nonempty rb]
    (K : CMatrix (JointContractionPhysicalIndex a b (ra × rb))) :
    physicalBranchPartialTransposeB (physicalBobTwirl K) =
      physicalBobTwirl (physicalBranchPartialTransposeB K) := by
  rw [physicalBobTwirl, physicalBobTwirl,
    physicalBranchPartialTransposeB_integral
      (physicalBobTwirlIntegrand_integrable K)]
  let e := unitaryGroupMapStarMulEquiv (b := b)
  let f := physicalBobTwirlIntegrand
    (physicalBranchPartialTransposeB K)
  have he : Continuous (e : Matrix.unitaryGroup b ℂ →
      Matrix.unitaryGroup b ℂ) :=
    unitaryGroupMapStarMulEquiv_continuous (b := b)
  have hmap : Measure.map e (unitaryHaarMeasure (a := b)) =
      unitaryHaarMeasure (a := b) := by
    simpa [e] using unitaryHaarMeasure_map_unitaryGroupMapStar (b := b)
  have hf : Integrable f (unitaryHaarMeasure (a := b)) := by
    exact physicalBobTwirlIntegrand_integrable
      (physicalBranchPartialTransposeB K)
  have hfmap : AEStronglyMeasurable f
      (Measure.map e (unitaryHaarMeasure (a := b))) := by
    rw [hmap]
    exact hf.aestronglyMeasurable
  calc
    (∫ V : Matrix.unitaryGroup b ℂ,
        physicalBranchPartialTransposeB (physicalBobTwirlIntegrand K V)
        ∂unitaryHaarMeasure (a := b)) =
        ∫ V : Matrix.unitaryGroup b ℂ, f (e V)
          ∂unitaryHaarMeasure (a := b) := by
      congr 1
      funext V
      exact physicalBranchPartialTransposeB_physicalBobTwirlIntegrand K V
    _ = ∫ V : Matrix.unitaryGroup b ℂ, f V
          ∂Measure.map e (unitaryHaarMeasure (a := b)) := by
      symm
      exact MeasureTheory.integral_map he.measurable.aemeasurable hfmap
    _ = ∫ V : Matrix.unitaryGroup b ℂ, f V
          ∂unitaryHaarMeasure (a := b) := by
      rw [hmap]

/-- Physical Bob partial transpose commutes with the full successive local
Haar twirl. -/
theorem physicalBranchPartialTransposeB_physicalLocalTwirl
    [Nonempty a] [Nonempty b] [Nonempty ra] [Nonempty rb]
    (K : CMatrix (JointContractionPhysicalIndex a b (ra × rb))) :
    physicalBranchPartialTransposeB (physicalLocalTwirl K) =
      physicalLocalTwirl (physicalBranchPartialTransposeB K) := by
  rw [physicalLocalTwirl,
    physicalBranchPartialTransposeB_physicalAliceTwirl,
    physicalBranchPartialTransposeB_physicalBobTwirl]
  rfl

/-- The genuine local Haar twirl preserves physical Bob-PPT positivity. -/
theorem physicalLocalTwirl_preserves_physicalBobPPT
    [Nonempty a] [Nonempty b] [Nonempty ra] [Nonempty rb]
    {K : CMatrix (JointContractionPhysicalIndex a b (ra × rb))}
    (hKppt : (physicalBranchPartialTransposeB K).PosSemidef) :
    (physicalBranchPartialTransposeB (physicalLocalTwirl K)).PosSemidef := by
  rw [physicalBranchPartialTransposeB_physicalLocalTwirl]
  exact physicalLocalTwirl_posSemidef hKppt

end

end EntanglementPurification
