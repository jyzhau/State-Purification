import EntanglementPurification.LocalMixedSchurCompleteness
import EntanglementPurification.LocalContractionCoordinates

/-!
# Amplified one-side mixed-Schur reducing theorem

This file proves a reusable one-side statement with an arbitrary finite
spectator register `s`.  The local representation, contraction-coordinate
isometry, and its range projection are amplified by `I_s`.

The main theorem derives commutation with the amplified contraction-range
projection from conjugation invariance and Hermiticity.  Its essential step is
not an assumed Hom-zero or reducing property: for every pair of spectator
indices and every input parity, it forms a concrete rectangular matrix slice
and applies `localMixedIntertwiner_eq_span_contractions` to that slice.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {x s : Type*}
  [Fintype x] [Fintype s] [DecidableEq x] [DecidableEq s]

/-- The one-side physical mixed-Schur space with a spectator register. -/
abbrev LocalAmplifiedMixedSchurSpace (x s : Type*) :=
  LocalMixedSchurSpace x × s

/-- The amplified contraction-coordinate space. -/
abbrev LocalAmplifiedContractionCoordinateSpace (x s : Type*) :=
  (LocalParity × x) × s

/-- The local action `π_x(U) ⊗ I_s`. -/
def localAmplifiedMixedSchurRepresentation
    (U : Matrix.unitaryGroup x ℂ) :
    CMatrix (LocalAmplifiedMixedSchurSpace x s) :=
  Matrix.kronecker (localMixedSchurRepresentation U) (1 : CMatrix s)

/-- The spectator-amplified contraction isometry `G_x ⊗ I_s`. -/
def localAmplifiedContractionIsometry :
    Matrix (LocalAmplifiedMixedSchurSpace x s)
      (LocalAmplifiedContractionCoordinateSpace x s) ℂ :=
  Matrix.kronecker (localContractionCoordinates (x := x)) (1 : CMatrix s)

/-- The unamplified orthogonal-range candidate `G_x G_x†`. -/
def localContractionRangeProjection : CMatrix (LocalMixedSchurSpace x) :=
  localContractionCoordinates * Matrix.conjTranspose localContractionCoordinates

/-- The amplified contraction-range projection candidate
`(G_x ⊗ I_s)(G_x ⊗ I_s)†`. -/
def localAmplifiedContractionRangeProjection :
    CMatrix (LocalAmplifiedMixedSchurSpace x s) :=
  localAmplifiedContractionIsometry *
    Matrix.conjTranspose localAmplifiedContractionIsometry

/-- The amplified range projection is `G_x G_x† ⊗ I_s`. -/
theorem localAmplifiedContractionRangeProjection_eq_kronecker :
    localAmplifiedContractionRangeProjection (x := x) (s := s) =
      Matrix.kronecker (localContractionRangeProjection (x := x))
        (1 : CMatrix s) := by
  unfold localAmplifiedContractionRangeProjection
    localAmplifiedContractionIsometry localContractionRangeProjection
  unfold Matrix.kronecker
  rw [Matrix.conjTranspose_kronecker, ← Matrix.mul_kronecker_mul]
  simp

/-- Conjugation invariance under every amplified local action. -/
def IsLocalAmplifiedMixedSchurInvariant
    (K : CMatrix (LocalAmplifiedMixedSchurSpace x s)) : Prop :=
  ∀ U : Matrix.unitaryGroup x ℂ,
    localAmplifiedMixedSchurRepresentation (s := s) U * K *
        Matrix.conjTranspose
          (localAmplifiedMixedSchurRepresentation (s := s) U) =
      K

/-- The `(u,v)` spectator matrix slice of an amplified operator. -/
def localAmplifiedSpectatorSlice
    (K : CMatrix (LocalAmplifiedMixedSchurSpace x s)) (u v : s) :
    CMatrix (LocalMixedSchurSpace x) :=
  fun p q => K (p, u) (q, v)

private theorem localMixedSchurRepresentation_mem_unitary
    (U : Matrix.unitaryGroup x ℂ) :
    localMixedSchurRepresentation U ∈
      Matrix.unitaryGroup (LocalMixedSchurSpace x) ℂ := by
  have hBar :
      localEntrywiseConjugate U ∈ Matrix.unitaryGroup x ℂ := by
    change (↑(Matrix.UnitaryGroup.map_star U) : CMatrix x) ∈
      Matrix.unitaryGroup x ℂ
    exact SetLike.coe_mem (Matrix.UnitaryGroup.map_star U)
  exact Matrix.kronecker_mem_unitary
    (Matrix.kronecker_mem_unitary hBar hBar) (SetLike.coe_mem U)

private theorem localAmplifiedMixedSchurRepresentation_mem_unitary
    (U : Matrix.unitaryGroup x ℂ) :
    localAmplifiedMixedSchurRepresentation (s := s) U ∈
      Matrix.unitaryGroup (LocalAmplifiedMixedSchurSpace x s) ℂ := by
  exact Matrix.kronecker_mem_unitary
    (localMixedSchurRepresentation_mem_unitary U)
    (SetLike.coe_mem (1 : Matrix.unitaryGroup s ℂ))

private theorem localAmplified_invariant_commutes_representation
    {K : CMatrix (LocalAmplifiedMixedSchurSpace x s)}
    (hInvariant : IsLocalAmplifiedMixedSchurInvariant K)
    (U : Matrix.unitaryGroup x ℂ) :
    localAmplifiedMixedSchurRepresentation (s := s) U * K =
      K * localAmplifiedMixedSchurRepresentation (s := s) U := by
  let R := localAmplifiedMixedSchurRepresentation (s := s) U
  have hRmem : R ∈ Matrix.unitaryGroup (LocalAmplifiedMixedSchurSpace x s) ℂ :=
    localAmplifiedMixedSchurRepresentation_mem_unitary U
  have hRleft : Matrix.conjTranspose R * R = 1 := by
    simpa [Matrix.star_eq_conjTranspose] using
      (Matrix.mem_unitaryGroup_iff'.mp hRmem)
  have hInv : R * K * Matrix.conjTranspose R = K := by
    simpa [R, IsLocalAmplifiedMixedSchurInvariant] using hInvariant U
  calc
    R * K = R * K * 1 := by rw [Matrix.mul_one]
    _ = R * K * (Matrix.conjTranspose R * R) := by rw [hRleft]
    _ = (R * K * Matrix.conjTranspose R) * R := by
      simp only [Matrix.mul_assoc]
    _ = K * R := by rw [hInv]

private theorem localAmplifiedSpectatorSlice_commutes
    {K : CMatrix (LocalAmplifiedMixedSchurSpace x s)}
    (hInvariant : IsLocalAmplifiedMixedSchurInvariant K)
    (u v : s) (U : Matrix.unitaryGroup x ℂ) :
    localMixedSchurRepresentation U * localAmplifiedSpectatorSlice K u v =
      localAmplifiedSpectatorSlice K u v * localMixedSchurRepresentation U := by
  have hcomm := localAmplified_invariant_commutes_representation hInvariant U
  ext p q
  have hentry := congrFun (congrFun hcomm (p, u)) (q, v)
  simpa [localAmplifiedMixedSchurRepresentation,
    localAmplifiedSpectatorSlice, Matrix.mul_apply, Matrix.kronecker,
    Fintype.sum_prod_type, Matrix.one_apply] using hentry

/-- The `G_x G_x†` definition agrees with the sum of the two normalized
contraction-range projectors used by the completeness theorem. -/
theorem localContractionRangeProjection_eq_isotypicProjection :
    localContractionRangeProjection (x := x) =
      localContractionIsotypicProjection (x := x) := by
  ext p q
  simp [localContractionRangeProjection,
    localContractionIsotypicProjection, localContractionCoordinates,
    localWByParity, localPWPlus, localPWMinus, globalPWPlus, globalPWMinus,
    Matrix.mul_apply, Fintype.sum_prod_type, sum_localParity,
    Matrix.conjTranspose_apply]

private theorem localMixedIntertwiner_mem_contractionRange
    (hcard : 2 ≤ Fintype.card x)
    (T : Matrix (LocalMixedSchurSpace x) x ℂ)
    (hT : ∀ U : Matrix.unitaryGroup x ℂ,
      localMixedSchurRepresentation U * T =
        T * localEntrywiseConjugate U) :
    localContractionRangeProjection (x := x) * T = T := by
  obtain ⟨c₁, c₂, hSpan⟩ :=
    localMixedIntertwiner_eq_span_contractions hcard T hT
  rw [localContractionRangeProjection_eq_isotypicProjection, hSpan,
    Matrix.mul_add, Matrix.mul_smul, Matrix.mul_smul,
    localContractionIsotypicProjection_mul_gamma1 hcard,
    localContractionIsotypicProjection_mul_gamma2 hcard]

private theorem localAmplified_K_mul_isometry_apply
    (K : CMatrix (LocalAmplifiedMixedSchurSpace x s))
    (p : LocalMixedSchurSpace x) (u v : s)
    (t : LocalParity) (a : x) :
    (K * localAmplifiedContractionIsometry (x := x) (s := s))
        (p, u) ((t, a), v) =
      (localAmplifiedSpectatorSlice (x := x) K u v *
        localWByParity (x := x) t) p a := by
  simp [localAmplifiedContractionIsometry,
    localAmplifiedSpectatorSlice, localContractionCoordinates,
    Matrix.mul_apply, Matrix.kronecker, Fintype.sum_prod_type,
    Matrix.one_apply]

private theorem kronecker_one_mul_apply
    {j : Type*}
    (A : CMatrix (LocalMixedSchurSpace x))
    (B : Matrix (LocalAmplifiedMixedSchurSpace x s) j ℂ)
    (p : LocalMixedSchurSpace x) (u : s) (k : j) :
    (Matrix.kronecker A (1 : CMatrix s) * B) (p, u) k =
      ∑ q, A p q * B (q, u) k := by
  simp [Matrix.mul_apply, Matrix.kronecker, Fintype.sum_prod_type,
    Matrix.one_apply]

private theorem localAmplified_rangeProjection_mul_K_mul_isometry
    (hcard : 2 ≤ Fintype.card x)
    {K : CMatrix (LocalAmplifiedMixedSchurSpace x s)}
    (hInvariant : IsLocalAmplifiedMixedSchurInvariant K) :
    localAmplifiedContractionRangeProjection (x := x) (s := s) * K *
        localAmplifiedContractionIsometry (x := x) (s := s) =
      K * localAmplifiedContractionIsometry (x := x) (s := s) := by
  rw [localAmplifiedContractionRangeProjection_eq_kronecker]
  ext ⟨p, u⟩ ⟨⟨t, a⟩, v⟩
  let S := localAmplifiedSpectatorSlice (x := x) K u v
  let T : Matrix (LocalMixedSchurSpace x) x ℂ :=
    S * localWByParity (x := x) t
  have hSlice : ∀ U : Matrix.unitaryGroup x ℂ,
      localMixedSchurRepresentation U * S =
        S * localMixedSchurRepresentation U :=
    fun U => localAmplifiedSpectatorSlice_commutes hInvariant u v U
  have hIntertwines : ∀ U : Matrix.unitaryGroup x ℂ,
      localMixedSchurRepresentation U * T =
        T * localEntrywiseConjugate U := by
    intro U
    unfold T
    rw [← Matrix.mul_assoc, hSlice U, Matrix.mul_assoc]
    cases t
    · change S * (localMixedSchurRepresentation U * localWPlus) =
        S * localWPlus * localEntrywiseConjugate U
      rw [localWPlus_intertwines]
      simp only [Matrix.mul_assoc]
    · change S * (localMixedSchurRepresentation U * localWMinus) =
        S * localWMinus * localEntrywiseConjugate U
      rw [localWMinus_intertwines]
      simp only [Matrix.mul_assoc]
  have hRange :=
    localMixedIntertwiner_mem_contractionRange hcard T hIntertwines
  have hEntry := congrFun (congrFun hRange p) a
  rw [Matrix.mul_assoc]
  rw [kronecker_one_mul_apply]
  simp_rw [localAmplified_K_mul_isometry_apply]
  simpa [S, T, Matrix.mul_apply] using hEntry

/-- Conjugation invariance and Hermiticity force an amplified local operator
to reduce the contraction isotypic range.

The conclusion is derived by applying
`localMixedIntertwiner_eq_span_contractions` separately to every spectator
slice; no Hom-zero or reducing condition is assumed. -/
theorem localAmplifiedInvariant_commutes_contractionRangeProjection
    (hcard : 2 ≤ Fintype.card x)
    {K : CMatrix (LocalAmplifiedMixedSchurSpace x s)}
    (hInvariant : IsLocalAmplifiedMixedSchurInvariant K)
    (hHermitian : K.IsHermitian) :
    localAmplifiedContractionRangeProjection (x := x) (s := s) * K =
      K * localAmplifiedContractionRangeProjection := by
  let G := localAmplifiedContractionIsometry (x := x) (s := s)
  let P := localAmplifiedContractionRangeProjection (x := x) (s := s)
  have hRange : P * K * G = K * G :=
    localAmplified_rangeProjection_mul_K_mul_isometry
      hcard hInvariant
  have hRight : P * K * P = K * P := by
    change P * K * (G * Matrix.conjTranspose G) =
      K * (G * Matrix.conjTranspose G)
    simpa only [Matrix.mul_assoc] using
      congrArg (fun A => A * Matrix.conjTranspose G) hRange
  have hP : P.IsHermitian := by
    change (G * Matrix.conjTranspose G).IsHermitian
    rw [Matrix.IsHermitian]
    simp [Matrix.conjTranspose_mul]
  have hPstar : Matrix.conjTranspose P = P := hP
  have hKstar : Matrix.conjTranspose K = K := hHermitian
  have hLeft : P * K * P = P * K := by
    have hStar := congrArg Matrix.conjTranspose hRight
    simpa [Matrix.conjTranspose_mul, hPstar, hKstar,
      Matrix.mul_assoc] using hStar
  calc
    P * K = P * K * P := hLeft.symm
    _ = K * P := hRight

end

end EntanglementPurification
