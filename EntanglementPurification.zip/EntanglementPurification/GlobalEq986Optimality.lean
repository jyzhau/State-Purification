import EntanglementPurification.GlobalEq986Integral
import EntanglementPurification.GlobalHaarOptimality

/-!
# Equation-986 optimum and uniqueness theorem

This file specializes the original noisy-channel Haar integral to the paper's
one-leg space `Fin d × Fin d` (so `D = d²`) and transfers the completed global
CPTN SDP optimum and uniqueness theorem to that literal equation-986 operator.
-/

namespace EntanglementPurification

open QIT

noncomputable section

/-- The literal equation-986 performance operator on the paper's
`D = d²` one-leg space. -/
def globalPaperEq986PerformanceOperator
    {d : ℕ} (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    (gamma : ℝ) : CMatrix (GlobalThreeLeg (GlobalPaperIndex d)) := by
  letI : Nonempty (GlobalPaperIndex d) := globalPaperIndexNonempty hd
  exact globalEq986PerformanceOperator nu gamma

/-- The paper-indexed original equation-986 integral is exactly the
Haar-moment operator used by the completed SDP proof. -/
theorem globalPaperEq986PerformanceOperator_eq_globalPaperHaarPerformanceOperator
    {d : ℕ} (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    (gamma : ℝ) :
    globalPaperEq986PerformanceOperator hd nu gamma =
      globalPaperHaarPerformanceOperator hd nu gamma := by
  letI : Nonempty (GlobalPaperIndex d) := globalPaperIndexNonempty hd
  change globalEq986PerformanceOperator nu gamma =
    globalHaarPerformanceOperator nu gamma
  exact globalEq986PerformanceOperator_eq_globalHaarPerformanceOperator
    nu gamma

/-- The literal equation-986 performance operator is Hermitian. -/
theorem globalPaperEq986PerformanceOperator_isHermitian
    {d : ℕ} (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    (gamma : ℝ) :
    (globalPaperEq986PerformanceOperator hd nu gamma).IsHermitian := by
  rw [globalPaperEq986PerformanceOperator_eq_globalPaperHaarPerformanceOperator]
  exact globalPaperHaarPerformanceOperator_isHermitian hd nu gamma

/-- For a feasible Choi matrix, the literal equation-986 trace objective is
real. -/
theorem globalPaperEq986_trace_im_eq_zero
    {d : ℕ} (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    (gamma : ℝ) {J : CMatrix (GlobalThreeLeg (GlobalPaperIndex d))}
    (hJ : IsGlobalCPTNChoi J) :
    ((globalPaperEq986PerformanceOperator hd nu gamma * J).trace).im = 0 := by
  rw [globalPaperEq986PerformanceOperator_eq_globalPaperHaarPerformanceOperator]
  exact globalPaperHaar_trace_im_eq_zero hd nu gamma hJ

/-- On the feasible set, the paper's literal complex `Tr(MJ)` for equation
986 is the complex coercion of Lean's real SDP objective. -/
theorem globalPaperEq986_trace_eq_coe_globalSDPObjective
    {d : ℕ} (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    (gamma : ℝ) {J : CMatrix (GlobalThreeLeg (GlobalPaperIndex d))}
    (hJ : IsGlobalCPTNChoi J) :
    (globalPaperEq986PerformanceOperator hd nu gamma * J).trace =
      (globalSDPObjective
        (globalPaperEq986PerformanceOperator hd nu gamma) J : ℂ) := by
  rw [globalPaperEq986PerformanceOperator_eq_globalPaperHaarPerformanceOperator]
  exact globalPaperHaar_trace_eq_coe_globalSDPObjective hd nu gamma hJ

/-- Paper-facing endpoint starting from the original equation-986 integral.
It states feasibility, attainment, the universal upper bound, and the exact
equality condition `J = J⋆`. -/
theorem globalPaperEq986_optimal_and_unique
    {d : ℕ} (hd : 2 ≤ d)
    (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) :
    IsGlobalCPTNChoi
        (globalOptimalChoi (x := GlobalPaperIndex d)) ∧
      globalSDPObjective
          (globalPaperEq986PerformanceOperator hd nu gamma)
          globalOptimalChoi =
        globalOptimalGain ((d : ℝ) ^ 2) gamma ∧
      (∀ J : CMatrix (GlobalThreeLeg (GlobalPaperIndex d)),
        IsGlobalCPTNChoi J →
          globalSDPObjective
              (globalPaperEq986PerformanceOperator hd nu gamma) J ≤
            globalOptimalGain ((d : ℝ) ^ 2) gamma) ∧
      (∀ J : CMatrix (GlobalThreeLeg (GlobalPaperIndex d)),
        IsGlobalCPTNChoi J →
          (globalSDPObjective
                (globalPaperEq986PerformanceOperator hd nu gamma) J =
              globalOptimalGain ((d : ℝ) ^ 2) gamma ↔
            J = globalOptimalChoi (x := GlobalPaperIndex d))) := by
  rw [globalPaperEq986PerformanceOperator_eq_globalPaperHaarPerformanceOperator]
  exact globalPaperHaar_optimal_and_unique hd nu hgamma0 hgamma1

/-- CPTN-map-level form of the equation-986 optimum and uniqueness theorem. -/
theorem globalPaperEq986_map_optimal_and_unique
    {d : ℕ} (hd : 2 ≤ d)
    (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) :
    MatrixMap.TraceNonincreasingCP
        (MatrixMap.ofChoiMatrix
          (globalOptimalChoi (x := GlobalPaperIndex d))) ∧
      globalSDPObjective
          (globalPaperEq986PerformanceOperator hd nu gamma)
          (MatrixMap.choi
            (MatrixMap.ofChoiMatrix
              (globalOptimalChoi (x := GlobalPaperIndex d)))) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma ∧
      (∀ Phi : MatrixMap
          (GlobalPaperIndex d × GlobalPaperIndex d) (GlobalPaperIndex d),
        MatrixMap.TraceNonincreasingCP Phi →
          globalSDPObjective
              (globalPaperEq986PerformanceOperator hd nu gamma)
              (MatrixMap.choi Phi) ≤
            globalOptimalGain ((d : ℝ) ^ 2) gamma) ∧
      (∀ Phi : MatrixMap
          (GlobalPaperIndex d × GlobalPaperIndex d) (GlobalPaperIndex d),
        MatrixMap.TraceNonincreasingCP Phi →
          (globalSDPObjective
                (globalPaperEq986PerformanceOperator hd nu gamma)
                (MatrixMap.choi Phi) =
              globalOptimalGain ((d : ℝ) ^ 2) gamma ↔
            Phi = MatrixMap.ofChoiMatrix
              (globalOptimalChoi (x := GlobalPaperIndex d)))) := by
  rw [globalPaperEq986PerformanceOperator_eq_globalPaperHaarPerformanceOperator]
  exact globalPaperHaar_map_optimal_and_unique hd nu hgamma0 hgamma1

end

end EntanglementPurification
