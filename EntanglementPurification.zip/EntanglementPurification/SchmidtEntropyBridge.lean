import EntanglementPurification.PhysicalOperationalEq986
import QIT.Information.Entropy.PureEntanglement
import QIT.Information.Entropy.EntropyTensorPower
import Mathlib.Tactic

/-!
# Schmidt probabilities and pure-state entanglement entropy

This module identifies the paper's signed Schmidt resource with the standard
entropy API in Lean-QIT.  Its first marginal is diagonal with entries `p`, so
its pure-state entanglement entropy is exactly the base-two Shannon entropy of
the Schmidt probability vector.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

/-- The first reduced state of the signed Schmidt resource is diagonal with
the prescribed Schmidt probabilities. -/
theorem ambientSignedSchmidtResource_marginalA_matrix
    {m : ℕ} (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p) :
    (ambientSignedSchmidtResource p hp).state.marginalA.matrix =
      Matrix.diagonal (fun i => (p i : ℂ)) := by
  ext i j
  simp only [State.marginalA_matrix, partialTraceB, PureVector.state_matrix,
    rankOneMatrix_apply, Matrix.diagonal_apply]
  by_cases hij : i = j
  · subst j
    rw [Finset.sum_eq_single i]
    · by_cases hi0 : i = 0 <;>
        simp [ambientSignedSchmidtResource, ambientSignedSchmidtAmp, hi0] <;>
        norm_cast <;>
        simpa [pow_two, hi0] using Real.sq_sqrt (hp.2.1 i)
    · intro k _ hki
      have hik : i ≠ k := Ne.symm hki
      simp [ambientSignedSchmidtResource, ambientSignedSchmidtAmp, hik]
    · simp
  · rw [if_neg hij]
    apply Finset.sum_eq_zero
    intro k _
    by_cases hik : i = k
    · have hjk : j ≠ k := by
        intro hjk
        exact hij (hik.trans hjk.symm)
      simp [ambientSignedSchmidtResource, ambientSignedSchmidtAmp, hik, hjk]
    · simp [ambientSignedSchmidtResource, ambientSignedSchmidtAmp, hik]

/-- The Lean-QIT entanglement entropy of the paper's signed Schmidt resource
is the Shannon entropy in bits of its Schmidt probability vector. -/
theorem ambientSignedSchmidtResource_entanglementEntropy
    {m : ℕ} (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p) :
    (ambientSignedSchmidtResource p hp).entanglementEntropy =
      -(∑ i, QIT.xlog2 (p i)) := by
  rw [PureVector.entanglementEntropy_eq_marginalA]
  exact State.vonNeumann_eq_neg_sum_xlog2_of_diagonal _ _
    (ambientSignedSchmidtResource_marginalA_matrix p hp)

end

end EntanglementPurification
