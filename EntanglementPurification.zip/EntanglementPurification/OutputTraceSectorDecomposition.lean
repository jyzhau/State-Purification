import EntanglementPurification.OutputTraceSectors
import EntanglementPurification.LocalMixedSchurCompleteness
import EntanglementPurification.PhysicalBranchOutputInvariant

/-!
# Exact four-sector decomposition of invariant output traces

This module closes the distinction between the canonical coefficient extractor
in `OutputTraceSectors` and the paper's bracket notation.  The latter denotes
the unique resource-valued coefficient in an exact decomposition into the
four product two-copy sectors.

The proof first establishes a spectator-amplified, one-side version of the
ordinary two-copy symmetric/antisymmetric commutant theorem.  It then applies
that result successively to Alice and Bob.  The exact expansion is a derived
conclusion of product-unitary invariance; it is not an input hypothesis.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {x s : Type*}
  [Fintype x] [Fintype s] [DecidableEq x] [DecidableEq s]

/-- The ordinary two-copy action `U ⊗ U` on an input pair.  Using `U` rather
than `bar U` does not change the invariant class, since entrywise conjugation
permutes the unitary group. -/
def outputInputPairRepresentation
    (U : Matrix.unitaryGroup x ℂ) : CMatrix (x × x) :=
  Matrix.kronecker (U : CMatrix x) (U : CMatrix x)

/-- The two-copy action amplified by an arbitrary finite spectator. -/
def outputInputPairAmplifiedRepresentation
    (U : Matrix.unitaryGroup x ℂ) : CMatrix ((x × x) × s) :=
  Matrix.kronecker (outputInputPairRepresentation U) (1 : CMatrix s)

/-- Conjugation invariance under the amplified ordinary two-copy action. -/
def IsOutputInputPairAmplifiedInvariant
    (T : CMatrix ((x × x) × s)) : Prop :=
  ∀ U : Matrix.unitaryGroup x ℂ,
    outputInputPairAmplifiedRepresentation (s := s) U * T *
        Matrix.conjTranspose
          (outputInputPairAmplifiedRepresentation (s := s) U) =
      T

/-- A spectator matrix slice of an amplified two-copy operator. -/
def outputInputPairSpectatorSlice
    (T : CMatrix ((x × x) × s)) (u v : s) : CMatrix (x × x) :=
  fun p q => T (p, u) (q, v)

private theorem reindexTensorPowerTwo_antisymmetricProjectionMatrix_two :
    reindexTensorPowerTwo
        (QIT.antisymmetricProjectionMatrix_two (a := x)) =
      localInputPairPAsym := by
  have hone :
      reindexTensorPowerTwo
          (1 : CMatrix (TensorPower x 2)) =
        (1 : CMatrix (x × x)) := by
    ext p q
    simp [reindexTensorPowerTwo, Matrix.reindex_apply, Matrix.one_apply]
  have hsub :
      reindexTensorPowerTwo
          ((1 : CMatrix (TensorPower x 2)) -
            QIT.symmetricProjectionMatrix (a := x) 2) =
        reindexTensorPowerTwo (1 : CMatrix (TensorPower x 2)) -
          reindexTensorPowerTwo
            (QIT.symmetricProjectionMatrix (a := x) 2) := by
    rfl
  rw [QIT.antisymmetricProjectionMatrix_two, hsub, hone,
    reindex_symmetricProjectionMatrix_two_eq_globalInputPairPSym,
    ← localInputPairPAsym_eq_one_sub_globalInputPairPSym]

/-- Unamplified pair-space form of the ordinary two-copy commutant theorem. -/
private theorem outputInputPairInvariant_exists_decomposition
    [Nontrivial x]
    (B : CMatrix (x × x))
    (hB : ∀ U : Matrix.unitaryGroup x ℂ,
      outputInputPairRepresentation U * B *
          Matrix.conjTranspose (outputInputPairRepresentation U) = B) :
    ∃ lamPlus lamMinus : ℂ,
      B = lamPlus • localInputPairProjector (x := x) .plus +
        lamMinus • localInputPairProjector (x := x) .minus := by
  let A : CMatrix (TensorPower x 2) :=
    Matrix.reindex tensorPowerTwoEquiv.symm tensorPowerTwoEquiv.symm B
  have hA : ∀ U : Matrix.unitaryGroup x ℂ,
      (unitaryTensorPowerMatrix U 2 : CMatrix (TensorPower x 2)) * A *
          Matrix.conjTranspose
            (unitaryTensorPowerMatrix U 2 : CMatrix (TensorPower x 2)) =
        A := by
    intro U
    let e := tensorPowerTwoEquiv (x := x).symm
    let R := outputInputPairRepresentation U
    have hPair : R * B * Matrix.conjTranspose R = B := hB U
    have hRB :
        Matrix.reindex e e R * Matrix.reindex e e B =
          Matrix.reindex e e (R * B) := by
      simp
    have hRBR :
        Matrix.reindex e e (R * B) *
            Matrix.reindex e e (Matrix.conjTranspose R) =
          Matrix.reindex e e (R * B * Matrix.conjTranspose R) := by
      simp
    have hR :
        Matrix.reindex e e R =
          (unitaryTensorPowerMatrix U 2 : CMatrix (TensorPower x 2)) := by
      simpa [e, R, outputInputPairRepresentation] using
        (reindex_pairKronecker_eq_unitaryTensorPowerMatrix_two U)
    rw [← hR]
    change Matrix.reindex e e R * Matrix.reindex e e B *
        Matrix.conjTranspose (Matrix.reindex e e R) =
      Matrix.reindex e e B
    rw [Matrix.conjTranspose_reindex, hRB, hRBR, hPair]
  obtain ⟨lamPlus, lamMinus, hDecomp⟩ :=
    unitaryInvariant_two_exists_symmetric_antisymmetric_decomposition A hA
  refine ⟨lamPlus, lamMinus, ?_⟩
  have hBack :
      reindexTensorPowerTwo A =
        lamPlus • reindexTensorPowerTwo
            (QIT.symmetricProjectionMatrix (a := x) 2) +
          lamMinus • reindexTensorPowerTwo
            (QIT.antisymmetricProjectionMatrix_two (a := x)) := by
    ext p q
    have hEntry := congrFun (congrFun hDecomp
      (tensorPowerTwoEquiv.symm p)) (tensorPowerTwoEquiv.symm q)
    simpa [reindexTensorPowerTwo, Matrix.reindex_apply] using hEntry
  have hAback : reindexTensorPowerTwo A = B := by
    ext p q
    simp [A, reindexTensorPowerTwo, Matrix.reindex_apply]
  rw [hAback,
    reindex_symmetricProjectionMatrix_two_eq_globalInputPairPSym,
    reindexTensorPowerTwo_antisymmetricProjectionMatrix_two] at hBack
  simpa [localInputPairProjector] using hBack

private theorem outputInputPairRepresentation_mem_unitary
    (U : Matrix.unitaryGroup x ℂ) :
    outputInputPairRepresentation U ∈ Matrix.unitaryGroup (x × x) ℂ := by
  exact Matrix.kronecker_mem_unitary (SetLike.coe_mem U) (SetLike.coe_mem U)

private theorem outputInputPairAmplifiedRepresentation_mem_unitary
    (U : Matrix.unitaryGroup x ℂ) :
    outputInputPairAmplifiedRepresentation (s := s) U ∈
      Matrix.unitaryGroup ((x × x) × s) ℂ := by
  exact Matrix.kronecker_mem_unitary
    (outputInputPairRepresentation_mem_unitary U)
    (SetLike.coe_mem (1 : Matrix.unitaryGroup s ℂ))

private theorem outputInputPairAmplified_invariant_commutes
    {T : CMatrix ((x × x) × s)}
    (hT : IsOutputInputPairAmplifiedInvariant T)
    (U : Matrix.unitaryGroup x ℂ) :
    outputInputPairAmplifiedRepresentation (s := s) U * T =
      T * outputInputPairAmplifiedRepresentation (s := s) U := by
  let R := outputInputPairAmplifiedRepresentation (s := s) U
  have hRmem : R ∈ Matrix.unitaryGroup ((x × x) × s) ℂ :=
    outputInputPairAmplifiedRepresentation_mem_unitary U
  have hRleft : Matrix.conjTranspose R * R = 1 := by
    simpa [Matrix.star_eq_conjTranspose] using
      (Matrix.mem_unitaryGroup_iff'.mp hRmem)
  have hInv : R * T * Matrix.conjTranspose R = T := by
    simpa [R, IsOutputInputPairAmplifiedInvariant] using hT U
  calc
    R * T = R * T * 1 := by rw [Matrix.mul_one]
    _ = R * T * (Matrix.conjTranspose R * R) := by rw [hRleft]
    _ = (R * T * Matrix.conjTranspose R) * R := by
      simp only [Matrix.mul_assoc]
    _ = T * R := by rw [hInv]

private theorem outputInputPairSpectatorSlice_commutes
    {T : CMatrix ((x × x) × s)}
    (hT : IsOutputInputPairAmplifiedInvariant T) (u v : s)
    (U : Matrix.unitaryGroup x ℂ) :
    outputInputPairRepresentation U * outputInputPairSpectatorSlice T u v =
      outputInputPairSpectatorSlice T u v * outputInputPairRepresentation U := by
  have hcomm := outputInputPairAmplified_invariant_commutes hT U
  ext p q
  have hEntry := congrFun (congrFun hcomm (p, u)) (q, v)
  simpa [outputInputPairAmplifiedRepresentation,
    outputInputPairSpectatorSlice, Matrix.mul_apply, Matrix.kronecker,
    Fintype.sum_prod_type, Matrix.one_apply] using hEntry

private theorem outputInputPairSpectatorSlice_invariant
    {T : CMatrix ((x × x) × s)}
    (hT : IsOutputInputPairAmplifiedInvariant T) (u v : s) :
    ∀ U : Matrix.unitaryGroup x ℂ,
      outputInputPairRepresentation U *
          outputInputPairSpectatorSlice T u v *
          Matrix.conjTranspose (outputInputPairRepresentation U) =
        outputInputPairSpectatorSlice T u v := by
  intro U
  have hcomm := outputInputPairSpectatorSlice_commutes hT u v U
  have hRmem := outputInputPairRepresentation_mem_unitary U
  have hRright : outputInputPairRepresentation U *
      Matrix.conjTranspose (outputInputPairRepresentation U) = 1 := by
    simpa [Matrix.star_eq_conjTranspose] using
      (Matrix.mem_unitaryGroup_iff.mp hRmem)
  calc
    outputInputPairRepresentation U * outputInputPairSpectatorSlice T u v *
        Matrix.conjTranspose (outputInputPairRepresentation U) =
      (outputInputPairSpectatorSlice T u v * outputInputPairRepresentation U) *
        Matrix.conjTranspose (outputInputPairRepresentation U) := by rw [hcomm]
    _ = outputInputPairSpectatorSlice T u v *
        (outputInputPairRepresentation U *
          Matrix.conjTranspose (outputInputPairRepresentation U)) := by
      simp only [Matrix.mul_assoc]
    _ = outputInputPairSpectatorSlice T u v := by rw [hRright, Matrix.mul_one]

/-- Spectator-amplified ordinary two-copy Schur decomposition.  Invariance
alone produces resource/spectator-valued symmetric and antisymmetric
coefficients. -/
theorem outputInputPairAmplifiedInvariant_exists_decomposition
    (hcard : 2 ≤ Fintype.card x)
    {T : CMatrix ((x × x) × s)}
    (hT : IsOutputInputPairAmplifiedInvariant T) :
    ∃ Cplus Cminus : CMatrix s,
      T = Matrix.kronecker (localInputPairProjector (x := x) .plus) Cplus +
        Matrix.kronecker (localInputPairProjector (x := x) .minus) Cminus := by
  have hSlice (u v : s) : ∃ lamPlus lamMinus : ℂ,
      outputInputPairSpectatorSlice T u v =
        lamPlus • localInputPairProjector (x := x) .plus +
          lamMinus • localInputPairProjector (x := x) .minus := by
    letI : Nontrivial x :=
      Fintype.one_lt_card_iff_nontrivial.mp (by omega)
    exact outputInputPairInvariant_exists_decomposition
      (outputInputPairSpectatorSlice T u v)
      (outputInputPairSpectatorSlice_invariant hT u v)
  let Cplus : CMatrix s := fun u v => Classical.choose (hSlice u v)
  let Cminus : CMatrix s := fun u v =>
    Classical.choose (Classical.choose_spec (hSlice u v))
  refine ⟨Cplus, Cminus, ?_⟩
  ext p q
  rcases p with ⟨p, u⟩
  rcases q with ⟨q, v⟩
  have hDecomp :=
    Classical.choose_spec (Classical.choose_spec (hSlice u v))
  have hEntry := congrFun (congrFun hDecomp p) q
  simpa [Cplus, Cminus, outputInputPairSpectatorSlice,
    Matrix.kronecker, Matrix.add_apply, Matrix.smul_apply, mul_comm] using hEntry

/-- The two spectator-valued coefficients in the amplified decomposition are
unique when both parity sectors are nonzero. -/
theorem outputInputPairAmplified_decomposition_unique
    (hcard : 2 ≤ Fintype.card x)
    {T : CMatrix ((x × x) × s)}
    {Cplus Cminus Dplus Dminus : CMatrix s}
    (hC : T =
      Matrix.kronecker (localInputPairProjector (x := x) .plus) Cplus +
        Matrix.kronecker (localInputPairProjector (x := x) .minus) Cminus)
    (hD : T =
      Matrix.kronecker (localInputPairProjector (x := x) .plus) Dplus +
        Matrix.kronecker (localInputPairProjector (x := x) .minus) Dminus) :
    Cplus = Dplus ∧ Cminus = Dminus := by
  have hEq := hC.symm.trans hD
  letI : Nontrivial x :=
    Fintype.one_lt_card_iff_nontrivial.mp (by omega)
  obtain ⟨i, j, hij⟩ := exists_pair_ne x
  have hji : j ≠ i := Ne.symm hij
  have hplus : Cplus = Dplus := by
    ext u v
    have hEntry := congrFun (congrFun hEq ((i, i), u)) ((i, i), v)
    simpa [localInputPairProjector, globalInputPairPSym,
      localInputPairPAsym, globalInputPairSwap, Matrix.kronecker,
      Matrix.one_apply] using hEntry
  have hminus : Cminus = Dminus := by
    ext u v
    have hEntry := congrFun (congrFun hEq ((i, j), u)) ((i, j), v)
    have hplusEntry := congrFun (congrFun hplus u) v
    simp [localInputPairProjector, globalInputPairPSym,
      localInputPairPAsym, globalInputPairSwap, Matrix.kronecker,
      hij, hji] at hEntry
    rw [hplusEntry] at hEntry
    linear_combination 2 * hEntry
  exact ⟨hplus, hminus⟩

/-! ## Successive Alice/Bob decomposition -/

variable {a b r : Type*}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

/-- The input/resource space reassociated so Alice's two-copy input pair is
the first factor and Bob's pair together with the resource is the spectator. -/
abbrev AliceGroupedInputResourceIndex (a b r : Type*) :=
  (a × a) × ((b × b) × r)

/-- Bob's two-copy action, amplified first by the resource and then by
Alice's whole two-copy input pair. -/
def outputInputSecondPairAmplifiedRepresentation
    (V : Matrix.unitaryGroup b ℂ) :
    CMatrix (AliceGroupedInputResourceIndex a b r) :=
  Matrix.kronecker (1 : CMatrix (a × a))
    (outputInputPairAmplifiedRepresentation (x := b) (s := r) V)

/-- Conjugation invariance of the second pair in Alice-grouped coordinates. -/
def IsOutputInputSecondPairAmplifiedInvariant
    (T : CMatrix (AliceGroupedInputResourceIndex a b r)) : Prop :=
  ∀ V : Matrix.unitaryGroup b ℂ,
    outputInputSecondPairAmplifiedRepresentation (a := a) (r := r) V * T *
        Matrix.conjTranspose
          (outputInputSecondPairAmplifiedRepresentation (a := a) (r := r) V) =
      T

private theorem secondPair_conjugates_firstPair_decomposition
    (V : Matrix.unitaryGroup b ℂ)
    (Cplus Cminus : CMatrix ((b × b) × r)) :
    outputInputSecondPairAmplifiedRepresentation (a := a) (r := r) V *
          (Matrix.kronecker (localInputPairProjector (x := a) .plus) Cplus +
            Matrix.kronecker (localInputPairProjector (x := a) .minus) Cminus) *
        Matrix.conjTranspose
          (outputInputSecondPairAmplifiedRepresentation (a := a) (r := r) V) =
      Matrix.kronecker (localInputPairProjector (x := a) .plus)
          (outputInputPairAmplifiedRepresentation (x := b) (s := r) V * Cplus *
            Matrix.conjTranspose
              (outputInputPairAmplifiedRepresentation (x := b) (s := r) V)) +
        Matrix.kronecker (localInputPairProjector (x := a) .minus)
          (outputInputPairAmplifiedRepresentation (x := b) (s := r) V * Cminus *
            Matrix.conjTranspose
              (outputInputPairAmplifiedRepresentation (x := b) (s := r) V)) := by
  unfold outputInputSecondPairAmplifiedRepresentation
  unfold Matrix.kronecker
  rw [Matrix.conjTranspose_kronecker]
  simp only [Matrix.mul_add, Matrix.add_mul]
  repeat' rw [← Matrix.mul_kronecker_mul]
  simp

/-- If an Alice-grouped matrix is invariant under both amplified pair
actions, successive one-side Schur decompositions produce four resource
coefficients. -/
theorem outputInputTwoPairInvariant_exists_nested_decomposition
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {T : CMatrix (AliceGroupedInputResourceIndex a b r)}
    (hA : IsOutputInputPairAmplifiedInvariant (x := a)
      (s := ((b × b) × r)) T)
    (hB : IsOutputInputSecondPairAmplifiedInvariant (a := a) (b := b)
      (r := r) T) :
    ∃ Cpp Cpm Cmp Cmm : CMatrix r,
      T =
        Matrix.kronecker (localInputPairProjector (x := a) .plus)
            (Matrix.kronecker (localInputPairProjector (x := b) .plus) Cpp +
              Matrix.kronecker (localInputPairProjector (x := b) .minus) Cpm) +
          Matrix.kronecker (localInputPairProjector (x := a) .minus)
            (Matrix.kronecker (localInputPairProjector (x := b) .plus) Cmp +
              Matrix.kronecker (localInputPairProjector (x := b) .minus) Cmm) := by
  obtain ⟨Cplus, Cminus, hADecomp⟩ :=
    outputInputPairAmplifiedInvariant_exists_decomposition hcardA hA
  have hCplus : IsOutputInputPairAmplifiedInvariant (x := b) (s := r) Cplus := by
    intro V
    have hAlt : T =
        Matrix.kronecker (localInputPairProjector (x := a) .plus)
            (outputInputPairAmplifiedRepresentation (x := b) (s := r) V * Cplus *
              Matrix.conjTranspose
                (outputInputPairAmplifiedRepresentation (x := b) (s := r) V)) +
          Matrix.kronecker (localInputPairProjector (x := a) .minus)
            (outputInputPairAmplifiedRepresentation (x := b) (s := r) V * Cminus *
              Matrix.conjTranspose
                (outputInputPairAmplifiedRepresentation (x := b) (s := r) V)) := by
      calc
        T = outputInputSecondPairAmplifiedRepresentation (a := a) (r := r) V * T *
              Matrix.conjTranspose
                (outputInputSecondPairAmplifiedRepresentation (a := a) (r := r) V) :=
          (hB V).symm
        _ = _ := by rw [hADecomp, secondPair_conjugates_firstPair_decomposition]
    exact (outputInputPairAmplified_decomposition_unique hcardA
      hADecomp hAlt).1.symm
  have hCminus : IsOutputInputPairAmplifiedInvariant (x := b) (s := r) Cminus := by
    intro V
    have hAlt : T =
        Matrix.kronecker (localInputPairProjector (x := a) .plus)
            (outputInputPairAmplifiedRepresentation (x := b) (s := r) V * Cplus *
              Matrix.conjTranspose
                (outputInputPairAmplifiedRepresentation (x := b) (s := r) V)) +
          Matrix.kronecker (localInputPairProjector (x := a) .minus)
            (outputInputPairAmplifiedRepresentation (x := b) (s := r) V * Cminus *
              Matrix.conjTranspose
                (outputInputPairAmplifiedRepresentation (x := b) (s := r) V)) := by
      calc
        T = outputInputSecondPairAmplifiedRepresentation (a := a) (r := r) V * T *
              Matrix.conjTranspose
                (outputInputSecondPairAmplifiedRepresentation (a := a) (r := r) V) :=
          (hB V).symm
        _ = _ := by rw [hADecomp, secondPair_conjugates_firstPair_decomposition]
    exact (outputInputPairAmplified_decomposition_unique hcardA
      hADecomp hAlt).2.symm
  obtain ⟨Cpp, Cpm, hPlus⟩ :=
    outputInputPairAmplifiedInvariant_exists_decomposition hcardB hCplus
  obtain ⟨Cmp, Cmm, hMinus⟩ :=
    outputInputPairAmplifiedInvariant_exists_decomposition hcardB hCminus
  exact ⟨Cpp, Cpm, Cmp, Cmm, hADecomp.trans (by rw [hPlus, hMinus])⟩

/-! ## Product invariance in the physical output-trace index order -/

/-- Reassociate the retained input/resource index so that Alice's pair is the
outer factor used by the first amplified decomposition. -/
def outputInputAliceGroupingEquiv :
    JointContractionInputResourceIndex a b r ≃
      AliceGroupedInputResourceIndex a b r where
  toFun p := (p.1.1, (p.1.2, p.2))
  invFun p := ((p.1, p.2.1), p.2.2)
  left_inv _ := rfl
  right_inv _ := rfl

private def ordinaryOutputInputProductGroupedRepresentation
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    CMatrix (AliceGroupedInputResourceIndex a b r) :=
  Matrix.kronecker (outputInputPairRepresentation U)
    (outputInputPairAmplifiedRepresentation (x := b) (s := r) V)

private theorem reindex_ordinaryOutputInputProductRepresentation
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    (Matrix.reindexAlgEquiv ℂ ℂ
        (outputInputAliceGroupingEquiv (a := a) (b := b) (r := r)))
      (Matrix.kronecker
        (Matrix.kronecker
          (Matrix.kronecker (U : CMatrix a) (U : CMatrix a))
          (Matrix.kronecker (V : CMatrix b) (V : CMatrix b)))
        (1 : CMatrix r)) =
      ordinaryOutputInputProductGroupedRepresentation (r := r) U V := by
  ext p q
  rcases p with ⟨⟨iA₁, iA₂⟩, ⟨⟨iB₁, iB₂⟩, u⟩⟩
  rcases q with ⟨⟨jA₁, jA₂⟩, ⟨⟨jB₁, jB₂⟩, v⟩⟩
  simp [Matrix.reindexAlgEquiv_apply, Matrix.reindex_apply,
    outputInputAliceGroupingEquiv,
    ordinaryOutputInputProductGroupedRepresentation,
    outputInputPairAmplifiedRepresentation, outputInputPairRepresentation,
    Matrix.kronecker, Matrix.one_apply]

private theorem productInvariant_reindexed_ordinary
    {T : CMatrix (JointContractionInputResourceIndex a b r)}
    (hT : IsOutputInputProductTwoCopyInvariant T) :
    ∀ (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ),
      ordinaryOutputInputProductGroupedRepresentation (r := r) U V *
          (Matrix.reindexAlgEquiv ℂ ℂ
            (outputInputAliceGroupingEquiv (a := a) (b := b) (r := r))) T *
          Matrix.conjTranspose
            (ordinaryOutputInputProductGroupedRepresentation (r := r) U V) =
        (Matrix.reindexAlgEquiv ℂ ℂ
          (outputInputAliceGroupingEquiv (a := a) (b := b) (r := r))) T := by
  intro U V
  let e := outputInputAliceGroupingEquiv (a := a) (b := b) (r := r)
  let E := Matrix.reindexAlgEquiv ℂ ℂ e
  let R : CMatrix (JointContractionInputResourceIndex a b r) :=
    Matrix.kronecker
      (Matrix.kronecker
        (Matrix.kronecker (U : CMatrix a) (U : CMatrix a))
        (Matrix.kronecker (V : CMatrix b) (V : CMatrix b)))
      (1 : CMatrix r)
  have h := congrArg E (hT.ordinary U V)
  have hAdjoint : E (Matrix.conjTranspose R) =
      Matrix.conjTranspose (E R) := by
    rfl
  change E (R * T * Matrix.conjTranspose R) = E T at h
  simp only [map_mul] at h
  rw [hAdjoint] at h
  have hR : E R =
      ordinaryOutputInputProductGroupedRepresentation (r := r) U V := by
    simpa [E, e, R] using
      (reindex_ordinaryOutputInputProductRepresentation (r := r) U V)
  simpa [E, e, hR] using h

private theorem ordinaryGroupedRepresentation_right_one
    (U : Matrix.unitaryGroup a ℂ) :
    ordinaryOutputInputProductGroupedRepresentation (r := r) U
        (1 : Matrix.unitaryGroup b ℂ) =
      outputInputPairAmplifiedRepresentation (x := a)
        (s := ((b × b) × r)) U := by
  ext p q
  rcases p with ⟨⟨i₁, i₂⟩, ⟨⟨k₁, k₂⟩, u⟩⟩
  rcases q with ⟨⟨j₁, j₂⟩, ⟨⟨l₁, l₂⟩, v⟩⟩
  simp [ordinaryOutputInputProductGroupedRepresentation,
    outputInputPairAmplifiedRepresentation, outputInputPairRepresentation,
    Matrix.kronecker, Matrix.one_apply]

private theorem ordinaryGroupedRepresentation_left_one
    (V : Matrix.unitaryGroup b ℂ) :
    ordinaryOutputInputProductGroupedRepresentation (a := a) (r := r)
        (1 : Matrix.unitaryGroup a ℂ) V =
      outputInputSecondPairAmplifiedRepresentation (a := a) (r := r) V := by
  ext p q
  rcases p with ⟨⟨i₁, i₂⟩, ⟨⟨k₁, k₂⟩, u⟩⟩
  rcases q with ⟨⟨j₁, j₂⟩, ⟨⟨l₁, l₂⟩, v⟩⟩
  simp [ordinaryOutputInputProductGroupedRepresentation,
    outputInputSecondPairAmplifiedRepresentation,
    outputInputPairAmplifiedRepresentation, outputInputPairRepresentation,
    Matrix.kronecker, Matrix.one_apply]

private theorem ungroup_nested_kronecker
    (A : CMatrix (a × a)) (B : CMatrix (b × b)) (C : CMatrix r) :
    (Matrix.reindexAlgEquiv ℂ ℂ
        (outputInputAliceGroupingEquiv (a := a) (b := b) (r := r))).symm
      (Matrix.kronecker A (Matrix.kronecker B C)) =
      Matrix.kronecker (Matrix.kronecker A B) C := by
  ext p q
  rcases p with ⟨⟨⟨iA₁, iA₂⟩, ⟨iB₁, iB₂⟩⟩, u⟩
  rcases q with ⟨⟨⟨jA₁, jA₂⟩, ⟨jB₁, jB₂⟩⟩, v⟩
  simp [Matrix.reindexAlgEquiv_apply, Matrix.reindex_apply,
    outputInputAliceGroupingEquiv, Matrix.kronecker]
  ring

/-- Product two-copy invariance gives an exact four-term sector expansion
with resource-valued coefficients.  At this stage the coefficients are
existential; the canonical extractor is identified below. -/
theorem IsOutputInputProductTwoCopyInvariant.exists_sector_decomposition
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {T : CMatrix (JointContractionInputResourceIndex a b r)}
    (hT : IsOutputInputProductTwoCopyInvariant T) :
    ∃ Cpp Cpm Cmp Cmm : CMatrix r,
      T =
        Matrix.kronecker
            (jointInputSectorProjector (a := a) (b := b) (.plus, .plus)) Cpp +
          Matrix.kronecker
            (jointInputSectorProjector (a := a) (b := b) (.plus, .minus)) Cpm +
          Matrix.kronecker
            (jointInputSectorProjector (a := a) (b := b) (.minus, .plus)) Cmp +
          Matrix.kronecker
            (jointInputSectorProjector (a := a) (b := b) (.minus, .minus)) Cmm := by
  let E := Matrix.reindexAlgEquiv ℂ ℂ
    (outputInputAliceGroupingEquiv (a := a) (b := b) (r := r))
  let Tg := E T
  have hProduct := productInvariant_reindexed_ordinary hT
  have hA : IsOutputInputPairAmplifiedInvariant (x := a)
      (s := ((b × b) × r)) Tg := by
    intro U
    simpa [Tg, E, ordinaryGroupedRepresentation_right_one] using
      hProduct U (1 : Matrix.unitaryGroup b ℂ)
  have hB : IsOutputInputSecondPairAmplifiedInvariant
      (a := a) (b := b) (r := r) Tg := by
    intro V
    simpa [Tg, E, ordinaryGroupedRepresentation_left_one] using
      hProduct (1 : Matrix.unitaryGroup a ℂ) V
  obtain ⟨Cpp, Cpm, Cmp, Cmm, hNested⟩ :=
    outputInputTwoPairInvariant_exists_nested_decomposition
      hcardA hcardB hA hB
  unfold Matrix.kronecker at hNested
  rw [Matrix.kronecker_add, Matrix.kronecker_add] at hNested
  change Tg =
    Matrix.kronecker (localInputPairProjector (x := a) .plus)
        (Matrix.kronecker (localInputPairProjector (x := b) .plus) Cpp) +
      Matrix.kronecker (localInputPairProjector (x := a) .plus)
        (Matrix.kronecker (localInputPairProjector (x := b) .minus) Cpm) +
      (Matrix.kronecker (localInputPairProjector (x := a) .minus)
          (Matrix.kronecker (localInputPairProjector (x := b) .plus) Cmp) +
        Matrix.kronecker (localInputPairProjector (x := a) .minus)
          (Matrix.kronecker (localInputPairProjector (x := b) .minus) Cmm)) at hNested
  have hBack := congrArg E.symm hNested
  have hLeft : E.symm (E T) = T := E.symm_apply_apply T
  rw [hLeft] at hBack
  simp only [map_add] at hBack
  have hE : E = Matrix.reindexAlgEquiv ℂ ℂ
      (outputInputAliceGroupingEquiv (a := a) (b := b) (r := r)) := rfl
  rw [hE] at hBack
  rw [ungroup_nested_kronecker, ungroup_nested_kronecker,
    ungroup_nested_kronecker, ungroup_nested_kronecker] at hBack
  refine ⟨Cpp, Cpm, Cmp, Cmm, ?_⟩
  simpa only [Tg, jointInputSectorProjector, add_assoc] using hBack

/-! ## Canonical coefficients and uniqueness -/

/-- In any exact four-sector sum, the normalized partial-trace extractor
returns the coefficient of the selected sector. -/
theorem outputInputSectorDecomposition_coefficient_eq
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {T : CMatrix (JointContractionInputResourceIndex a b r)}
    (C : LocalMultiplicitySector → CMatrix r)
    (hC : T = ∑ z : LocalMultiplicitySector,
      Matrix.kronecker
        (jointInputSectorProjector (a := a) (b := b) z) (C z))
    (z : LocalMultiplicitySector) :
    outputTraceSectorCoefficient T z = C z := by
  classical
  rw [hC, outputTraceSectorCoefficient_sum]
  rw [Finset.sum_eq_single z]
  · exact outputTraceSectorCoefficient_kronecker_self hcardA hcardB z (C z)
  · intro w _ hwz
    exact outputTraceSectorCoefficient_kronecker_of_ne
      z w (Ne.symm hwz) (C w)
  · simp

/-- Resource-valued coefficients in an exact four-sector expansion are
unique.  No invariance hypothesis is needed once both expansions exist. -/
theorem outputInputSectorDecomposition_unique
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {T : CMatrix (JointContractionInputResourceIndex a b r)}
    {C D : LocalMultiplicitySector → CMatrix r}
    (hC : T = ∑ z : LocalMultiplicitySector,
      Matrix.kronecker
        (jointInputSectorProjector (a := a) (b := b) z) (C z))
    (hD : T = ∑ z : LocalMultiplicitySector,
      Matrix.kronecker
        (jointInputSectorProjector (a := a) (b := b) z) (D z)) :
    C = D := by
  funext z
  have hCz := outputInputSectorDecomposition_coefficient_eq
    hcardA hcardB C hC z
  have hDz := outputInputSectorDecomposition_coefficient_eq
    hcardA hcardB D hD z
  exact hCz.symm.trans hDz

/-- The exact canonical four-sector expansion.  Product two-copy invariance
is the only representation-theoretic hypothesis; the coefficients are the
normalized sector compressions defined in `OutputTraceSectors`. -/
theorem IsOutputInputProductTwoCopyInvariant.eq_sum_outputTraceSectorCoefficient
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {T : CMatrix (JointContractionInputResourceIndex a b r)}
    (hT : IsOutputInputProductTwoCopyInvariant T) :
    T = ∑ z : LocalMultiplicitySector,
      Matrix.kronecker
        (jointInputSectorProjector (a := a) (b := b) z)
        (outputTraceSectorCoefficient T z) := by
  obtain ⟨Cpp, Cpm, Cmp, Cmm, hExplicit⟩ :=
    hT.exists_sector_decomposition hcardA hcardB
  let C : LocalMultiplicitySector → CMatrix r := fun z =>
    match z with
    | (.plus, .plus) => Cpp
    | (.plus, .minus) => Cpm
    | (.minus, .plus) => Cmp
    | (.minus, .minus) => Cmm
  have hSum : T = ∑ z : LocalMultiplicitySector,
      Matrix.kronecker
        (jointInputSectorProjector (a := a) (b := b) z) (C z) := by
    rw [hExplicit]
    ext p q
    simp only [Matrix.sum_apply, Fintype.sum_prod_type, sum_localParity]
    simp [C]
    ring
  have hCoeff (z : LocalMultiplicitySector) :
      outputTraceSectorCoefficient T z = C z :=
    outputInputSectorDecomposition_coefficient_eq
      hcardA hcardB C hSum z
  calc
    T = ∑ z : LocalMultiplicitySector,
        Matrix.kronecker
          (jointInputSectorProjector (a := a) (b := b) z) (C z) := hSum
    _ = ∑ z : LocalMultiplicitySector,
        Matrix.kronecker
          (jointInputSectorProjector (a := a) (b := b) z)
          (outputTraceSectorCoefficient T z) := by
      apply Finset.sum_congr rfl
      intro z _
      rw [hCoeff z]

/-- Direct physical-branch form: local-unitary invariance before discarding
`A'B'` yields the canonical exact four-sector expansion after the output
trace. -/
theorem physicalBranchOutputTrace_eq_sum_outputTraceSectorCoefficient
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K) :
    physicalBranchOutputTrace K =
      ∑ z : LocalMultiplicitySector,
        Matrix.kronecker
          (jointInputSectorProjector (a := a) (b := b) z)
          (outputTraceSectorCoefficient (physicalBranchOutputTrace K) z) := by
  exact
    (physicalBranchOutputTrace_isOutputInputProductTwoCopyInvariant hInvariant).eq_sum_outputTraceSectorCoefficient
      hcardA hcardB

end

end EntanglementPurification
