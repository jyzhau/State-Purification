import EntanglementPurification.GlobalSDP
import EntanglementPurification.GlobalSDPScalar
import Mathlib.Tactic

/-!
# Four-sector optimization layer for the global CPTN SDP

This file turns the four spectral coefficients proved in
`GlobalSDPScalar.lean` into matrix-level primal bounds and an explicit dual
certificate.  The concrete contraction projectors are supplied by the later
operator module.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

/-- Performance operator written in its four-sector spectral decomposition. -/
def globalSectorPerformanceOperator
    {h : Type*} [Fintype h]
    (D gamma : ℝ) (PWPlus PWMinus PLPlus PLMinus : CMatrix h) : CMatrix h :=
  lambdaWPlus D gamma • PWPlus +
    lambdaWMinus D gamma • PWMinus +
    lambdaLPlus D gamma • PLPlus +
    lambdaLMinus D gamma • PLMinus

/-- A real linear combination of four Hermitian sector projectors is
Hermitian. -/
theorem globalSectorPerformanceOperator_isHermitian
    {h : Type*} [Fintype h]
    {D gamma : ℝ} {PWPlus PWMinus PLPlus PLMinus : CMatrix h}
    (hPWPlus : PWPlus.IsHermitian)
    (hPWMinus : PWMinus.IsHermitian)
    (hPLPlus : PLPlus.IsHermitian)
    (hPLMinus : PLMinus.IsHermitian) :
    (globalSectorPerformanceOperator D gamma
      PWPlus PWMinus PLPlus PLMinus).IsHermitian := by
  simp only [globalSectorPerformanceOperator]
  exact (((hPWPlus.smul (IsSelfAdjoint.all _)).add
      (hPWMinus.smul (IsSelfAdjoint.all _))).add
      (hPLPlus.smul (IsSelfAdjoint.all _))).add
      (hPLMinus.smul (IsSelfAdjoint.all _))

/-- Real trace mass of a PSD matrix in one sector. -/
def globalSectorMass
    {h : Type*} [Fintype h] (P J : CMatrix h) : ℝ :=
  ((P * J).trace).re

theorem globalSectorMass_nonneg
    {h : Type*} [Fintype h] [DecidableEq h]
    {P J : CMatrix h} (hP : P.PosSemidef) (hJ : J.PosSemidef) :
    0 ≤ globalSectorMass P J := by
  exact QIT.cMatrix_trace_mul_posSemidef_re_nonneg hP hJ

/-- Expanding the four-sector operator inside the real SDP trace objective
gives exactly the scalar objective used in `GlobalSDPScalar.lean`. -/
theorem globalSDPObjective_sectorPerformance
    {h : Type*} [Fintype h]
    (D gamma : ℝ) (PWPlus PWMinus PLPlus PLMinus J : CMatrix h) :
    globalSDPObjective
        (globalSectorPerformanceOperator D gamma
          PWPlus PWMinus PLPlus PLMinus) J =
      lambdaWPlus D gamma * globalSectorMass PWPlus J +
        lambdaWMinus D gamma * globalSectorMass PWMinus J +
        lambdaLPlus D gamma * globalSectorMass PLPlus J +
        lambdaLMinus D gamma * globalSectorMass PLMinus J := by
  simp only [globalSDPObjective, globalSectorPerformanceOperator,
    globalSectorMass, Matrix.add_mul, Matrix.smul_mul, Matrix.trace_add,
    Matrix.trace_smul, Complex.add_re, Complex.smul_re, smul_eq_mul]

/-- The mass in `WPlus` is bounded by the trace of the input-symmetric
projector.  This is the operator form of the capacity step in the paper. -/
theorem globalWPlusMass_le_inputProjectorTrace
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    {J PWPlus : CMatrix (Prod x y)} {Pinput : CMatrix x}
    (hJ : IsGlobalCPTNChoi J)
    (hPWPlus : PWPlus ≤ Matrix.kronecker Pinput (1 : CMatrix y))
    (hPinput : Pinput.PosSemidef) :
    globalSectorMass PWPlus J ≤ Pinput.trace.re := by
  have hfirst :=
    QIT.cMatrix_trace_mul_le_of_le_posSemidef_left hJ.1 hPWPlus
  have hsecond :=
    QIT.cMatrix_trace_mul_le_of_le_posSemidef_left hPinput hJ.2
  calc
    globalSectorMass PWPlus J = ((J * PWPlus).trace).re := by
      rw [globalSectorMass, Matrix.trace_mul_comm]
    _ ≤ ((J * Matrix.kronecker Pinput (1 : CMatrix y)).trace).re := hfirst
    _ = ((Matrix.kronecker Pinput (1 : CMatrix y) * J).trace).re := by
      rw [Matrix.trace_mul_comm]
    _ = ((Pinput * QIT.partialTraceB (a := x) (b := y) J).trace).re := by
      rw [trace_kronecker_one_mul_eq_trace_mul_partialTraceB]
    _ ≤ ((Pinput * (1 : CMatrix x)).trace).re := hsecond
    _ = Pinput.trace.re := by rw [Matrix.mul_one]

/-- Matrix-level global upper bound obtained from the concrete four-sector
spectral decomposition and the CPTN partial-trace constraint. -/
theorem global_four_sector_SDP_upper_bound
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    {D gamma : ℝ}
    {PWPlus PWMinus PLPlus PLMinus : CMatrix (Prod x y)}
    {Pinput : CMatrix x} {J : CMatrix (Prod x y)}
    (hD : 4 ≤ D) (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (hPWPlusPos : PWPlus.PosSemidef)
    (hPWMinusPos : PWMinus.PosSemidef)
    (hPLPlusPos : PLPlus.PosSemidef)
    (hPLMinusPos : PLMinus.PosSemidef)
    (hPinputPos : Pinput.PosSemidef)
    (hPWPlusLe : PWPlus ≤ Matrix.kronecker Pinput (1 : CMatrix y))
    (hPinputTrace : Pinput.trace.re = inputSymmetricDimension D)
    (hJ : IsGlobalCPTNChoi J) :
    globalSDPObjective
        (globalSectorPerformanceOperator D gamma
          PWPlus PWMinus PLPlus PLMinus) J ≤
      globalOptimalGain D gamma := by
  rw [globalSDPObjective_sectorPerformance]
  apply global_four_sector_objective_le hD hgamma0 hgamma1
  · exact globalSectorMass_nonneg hPWPlusPos hJ.1
  · exact globalSectorMass_nonneg hPWMinusPos hJ.1
  · exact globalSectorMass_nonneg hPLPlusPos hJ.1
  · exact globalSectorMass_nonneg hPLMinusPos hJ.1
  · rw [← hPinputTrace]
    exact globalWPlusMass_le_inputProjectorTrace hJ hPWPlusLe hPinputPos

/-- Equality in the matrix upper bound is equivalent to saturation of the
`WPlus` capacity and zero mass in all three negative sectors. -/
theorem global_four_sector_SDP_eq_iff
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    {D gamma : ℝ}
    {PWPlus PWMinus PLPlus PLMinus : CMatrix (Prod x y)}
    {Pinput : CMatrix x} {J : CMatrix (Prod x y)}
    (hD : 4 ≤ D) (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (hPWPlusPos : PWPlus.PosSemidef)
    (hPWMinusPos : PWMinus.PosSemidef)
    (hPLPlusPos : PLPlus.PosSemidef)
    (hPLMinusPos : PLMinus.PosSemidef)
    (hPinputPos : Pinput.PosSemidef)
    (hPWPlusLe : PWPlus ≤ Matrix.kronecker Pinput (1 : CMatrix y))
    (hPinputTrace : Pinput.trace.re = inputSymmetricDimension D)
    (hJ : IsGlobalCPTNChoi J) :
    (globalSDPObjective
          (globalSectorPerformanceOperator D gamma
            PWPlus PWMinus PLPlus PLMinus) J =
        globalOptimalGain D gamma) ↔
      globalSectorMass PWPlus J = inputSymmetricDimension D ∧
        globalSectorMass PWMinus J = 0 ∧
        globalSectorMass PLPlus J = 0 ∧
        globalSectorMass PLMinus J = 0 := by
  rw [globalSDPObjective_sectorPerformance]
  apply global_four_sector_objective_eq_iff hD hgamma0 hgamma1
  · exact globalSectorMass_nonneg hPWPlusPos hJ.1
  · exact globalSectorMass_nonneg hPWMinusPos hJ.1
  · exact globalSectorMass_nonneg hPLPlusPos hJ.1
  · exact globalSectorMass_nonneg hPLMinusPos hJ.1
  · rw [← hPinputTrace]
    exact globalWPlusMass_le_inputProjectorTrace hJ hPWPlusLe hPinputPos

/-- The dual matrix used in the paper: the positive `WPlus` eigenvalue times
the symmetric input projector. -/
def globalSectorDualCandidate
    {x : Type*} [Fintype x]
    (D gamma : ℝ) (Pinput : CMatrix x) : CMatrix x :=
  lambdaWPlus D gamma • Pinput

/-- All three complementary coefficients are negative, so the four-sector
performance operator is bounded above by its positive `WPlus` part. -/
theorem globalSectorPerformanceOperator_le_WPlus
    {h : Type*} [Fintype h] [DecidableEq h]
    {D gamma : ℝ} {PWPlus PWMinus PLPlus PLMinus : CMatrix h}
    (hD : 4 ≤ D) (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (hPWMinusPos : PWMinus.PosSemidef)
    (hPLPlusPos : PLPlus.PosSemidef)
    (hPLMinusPos : PLMinus.PosSemidef) :
    globalSectorPerformanceOperator D gamma
        PWPlus PWMinus PLPlus PLMinus ≤
      lambdaWPlus D gamma • PWPlus := by
  rw [Matrix.le_iff]
  have hminus :
      ((-lambdaWMinus D gamma) • PWMinus).PosSemidef :=
    hPWMinusPos.smul (le_of_lt (neg_pos.mpr
      (lambdaWMinus_neg hD hgamma0 hgamma1)))
  have hlplus :
      ((-lambdaLPlus D gamma) • PLPlus).PosSemidef :=
    hPLPlusPos.smul (le_of_lt (neg_pos.mpr
      (lambdaLPlus_neg hD hgamma0 hgamma1)))
  have hlminus :
      ((-lambdaLMinus D gamma) • PLMinus).PosSemidef :=
    hPLMinusPos.smul (le_of_lt (neg_pos.mpr
      (lambdaLMinus_neg hD hgamma0 hgamma1)))
  have hsum := (hminus.add hlplus).add hlminus
  convert hsum using 1
  ext i j
  simp [globalSectorPerformanceOperator]
  ring

/-- The explicit matrix `lambda_WPlus * Pinput` is dual feasible whenever
the distinguished sector lies inside `Pinput tensor I`. -/
theorem globalSectorDualCandidate_feasible
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    {D gamma : ℝ}
    {PWPlus PWMinus PLPlus PLMinus : CMatrix (Prod x y)}
    {Pinput : CMatrix x}
    (hD : 4 ≤ D) (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (hPWMinusPos : PWMinus.PosSemidef)
    (hPLPlusPos : PLPlus.PosSemidef)
    (hPLMinusPos : PLMinus.PosSemidef)
    (hPinputPos : Pinput.PosSemidef)
    (hPWPlusLe : PWPlus ≤ Matrix.kronecker Pinput (1 : CMatrix y)) :
    IsGlobalCPTNDual
      (globalSectorPerformanceOperator D gamma
        PWPlus PWMinus PLPlus PLMinus)
      (globalSectorDualCandidate D gamma Pinput) := by
  have hlambda : 0 ≤ lambdaWPlus D gamma :=
    le_of_lt (lambdaWPlus_pos hD hgamma0 hgamma1)
  constructor
  · exact hPinputPos.smul hlambda
  · have hfirst := globalSectorPerformanceOperator_le_WPlus
      (PWPlus := PWPlus) hD hgamma0 hgamma1
        hPWMinusPos hPLPlusPos hPLMinusPos
    have hsecond :
        lambdaWPlus D gamma • PWPlus ≤
          lambdaWPlus D gamma •
            Matrix.kronecker Pinput (1 : CMatrix y) := by
      rw [Matrix.le_iff]
      have hdiff := (Matrix.le_iff.mp hPWPlusLe).smul hlambda
      simpa [smul_sub] using hdiff
    calc
      globalSectorPerformanceOperator D gamma
          PWPlus PWMinus PLPlus PLMinus
          ≤ lambdaWPlus D gamma • PWPlus := hfirst
      _ ≤ lambdaWPlus D gamma •
          Matrix.kronecker Pinput (1 : CMatrix y) := hsecond
      _ = Matrix.kronecker (globalSectorDualCandidate D gamma Pinput)
          (1 : CMatrix y) := by
        rw [globalSectorDualCandidate]
        exact (Matrix.smul_kronecker (lambdaWPlus D gamma) Pinput
          (1 : CMatrix y)).symm

/-- The explicit dual certificate has the claimed objective value. -/
theorem globalSectorDualCandidate_trace_eq_optimalGain
    {x : Type*} [Fintype x]
    {D gamma : ℝ} {Pinput : CMatrix x}
    (hD : 4 ≤ D)
    (hPinputTrace : Pinput.trace.re = inputSymmetricDimension D) :
    (globalSectorDualCandidate D gamma Pinput).trace.re =
      globalOptimalGain D gamma := by
  rw [globalSectorDualCandidate, Matrix.trace_smul, Complex.smul_re,
    smul_eq_mul, hPinputTrace]
  exact globalDualValue_eq_optimalGain hD

end

end EntanglementPurification
