import EntanglementPurification.MajorizationConsequences
import EntanglementPurification.SchmidtEffect
import QIT.Information.Entropy.Log2Lemmas
import Mathlib.Analysis.Convex.Jensen
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Tactic

/-!
# Shannon entropy from a collision-probability bound

This file formalizes the Shannon--collision comparison used in
`main.tex`, Corollary `cor:pure_entropy_obstruction`.  For a finite
probability vector `p`, Jensen's inequality for the natural logarithm gives

`-log₂ (∑ i, p i ^ 2) ≤ -∑ i, p i log₂ (p i)`.

The proof applies Jensen only to the strictly positive support of `p`.
Consequently the boundary convention `0 log 0 = 0`, represented by
`QIT.xlog2`, is handled explicitly rather than hidden in an appeal to a
logarithm theorem at zero.
-/

namespace EntanglementPurification

noncomputable section

open scoped BigOperators

/-- Shannon entropy in bits of a finite real vector, using QIT's
`0 log₂ 0 = 0` convention.  Under the probability hypotheses below this is
the paper's Schmidt entropy. -/
def shannonEntropyBits {n : ℕ} (p : Fin n → ℝ) : ℝ :=
  -∑ i, QIT.xlog2 (p i)

/-- Collision (Rényi-2) entropy in bits, denoted `H₂` in `main.tex`. -/
def collisionEntropyBits {n : ℕ} (p : Fin n → ℝ) : ℝ :=
  -QIT.log2 (collisionProbability p)

@[simp]
theorem collisionProbability_eq_sum_sq {n : ℕ} (p : Fin n → ℝ) :
    collisionProbability p = ∑ i, p i ^ 2 := by
  rw [collisionProbability, ← List.ofFn_comp']
  exact (FiniteSchmidtData.sum_univ_eq_sum_ofFn (fun i => p i ^ 2)).symm

/-- A nonnegative finite vector of total mass one has strictly positive
collision probability. -/
theorem collisionProbability_pos_of_probability
    {n : ℕ} {p : Fin n → ℝ}
    (hnonneg : ∀ i, 0 ≤ p i)
    (htotal : (List.ofFn p).sum = 1) :
    0 < collisionProbability p := by
  have htotal' : ∑ i, p i = 1 := by
    exact (FiniteSchmidtData.sum_univ_eq_sum_ofFn p).trans htotal
  have hexists : ∃ i, 0 < p i := by
    by_contra h
    push Not at h
    have hzero : ∀ i, p i = 0 := by
      intro i
      exact le_antisymm (h i) (hnonneg i)
    simp [hzero] at htotal'
  rcases hexists with ⟨i, hi⟩
  rw [collisionProbability_eq_sum_sq]
  exact lt_of_lt_of_le (sq_pos_of_pos hi)
    (Finset.single_le_sum (fun j _ => sq_nonneg (p j)) (Finset.mem_univ i))

/-- The classical Shannon--collision comparison for a finite probability
vector:

`H(p) ≥ H₂(p) = -log₂ (∑ i, p i²)`.

No ordering assumption is needed for this analytic inequality. -/
theorem neg_log2_collisionProbability_le_shannonEntropyBits
    {n : ℕ} {p : Fin n → ℝ}
    (hnonneg : ∀ i, 0 ≤ p i)
    (htotal : (List.ofFn p).sum = 1) :
    -QIT.log2 (collisionProbability p) ≤ shannonEntropyBits p := by
  classical
  let support : Finset (Fin n) := Finset.univ.filter fun i => 0 < p i
  have hzero_of_not_mem {i : Fin n} (hi : i ∉ support) : p i = 0 := by
    have hnotpos : ¬0 < p i := by
      simpa [support] using hi
    exact le_antisymm (le_of_not_gt hnotpos) (hnonneg i)
  have htotal' : ∑ i, p i = 1 := by
    exact (FiniteSchmidtData.sum_univ_eq_sum_ofFn p).trans htotal
  have hsupport_sum : ∑ i ∈ support, p i = 1 := by
    rw [← htotal']
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro i hi_univ hi_not_mem
    exact hzero_of_not_mem hi_not_mem
  have hsupport_pos : ∀ i ∈ support, 0 < p i := by
    intro i hi
    exact (Finset.mem_filter.mp hi).2
  have hjensen :
      (∑ i ∈ support, p i * Real.log (p i)) ≤
        Real.log (∑ i ∈ support, p i * p i) := by
    have hconcave : ConcaveOn ℝ (Set.Ioi (0 : ℝ)) Real.log :=
      strictConcaveOn_log_Ioi.concaveOn
    have h := hconcave.le_map_sum
      (t := support) (w := p) (p := p)
      (by
        intro i hi
        exact (hsupport_pos i hi).le)
      hsupport_sum
      (by
        intro i hi
        exact hsupport_pos i hi)
    simpa [smul_eq_mul] using h
  have hlog_sum_support :
      (∑ i, p i * Real.log (p i)) =
        ∑ i ∈ support, p i * Real.log (p i) := by
    symm
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro i hi_univ hi_not_mem
    simp [hzero_of_not_mem hi_not_mem]
  have hsquare_sum_support :
      (∑ i, p i ^ 2) = ∑ i ∈ support, p i * p i := by
    calc
      (∑ i, p i ^ 2) = ∑ i ∈ support, p i ^ 2 := by
        symm
        apply Finset.sum_subset (Finset.filter_subset _ _)
        intro i _ hi_not_mem
        simp [hzero_of_not_mem hi_not_mem]
      _ = ∑ i ∈ support, p i * p i := by
        apply Finset.sum_congr rfl
        intro i _
        rw [pow_two]
  have hln :
      (∑ i, p i * Real.log (p i)) ≤
        Real.log (collisionProbability p) := by
    rw [hlog_sum_support, collisionProbability_eq_sum_sq,
      hsquare_sum_support]
    exact hjensen
  have hlog_two_pos : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hxlog_mul (x : ℝ) :
      QIT.xlog2 x * Real.log 2 = x * Real.log x := by
    rw [QIT.xlog2_eq_mul_log2]
    unfold QIT.log2
    field_simp [hlog_two_pos.ne']
  have hentropy_mul :
      shannonEntropyBits p * Real.log 2 =
        -(∑ i, p i * Real.log (p i)) := by
    rw [shannonEntropyBits]
    calc
      (-∑ i, QIT.xlog2 (p i)) * Real.log 2 =
          -((∑ i, QIT.xlog2 (p i)) * Real.log 2) := by ring
      _ = -(∑ i, QIT.xlog2 (p i) * Real.log 2) := by
        rw [Finset.sum_mul]
      _ = -(∑ i, p i * Real.log (p i)) := by
        congr 1
        apply Finset.sum_congr rfl
        intro i hi
        exact hxlog_mul (p i)
  have hscaled :
      (-QIT.log2 (collisionProbability p)) * Real.log 2 ≤
        shannonEntropyBits p * Real.log 2 := by
    calc
      (-QIT.log2 (collisionProbability p)) * Real.log 2 =
          -Real.log (collisionProbability p) := by
            unfold QIT.log2
            field_simp [hlog_two_pos.ne']
      _ ≤ -(∑ i, p i * Real.log (p i)) := neg_le_neg hln
      _ = shannonEntropyBits p * Real.log 2 := hentropy_mul.symm
  nlinarith

/-- A collision probability at most `1/2` forces at least one bit of Shannon
entropy. -/
theorem one_le_shannonEntropyBits_of_collisionProbability_le_half
    {n : ℕ} {p : Fin n → ℝ}
    (hnonneg : ∀ i, 0 ≤ p i)
    (htotal : (List.ofFn p).sum = 1)
    (hcollision : collisionProbability p ≤ 1 / 2) :
    1 ≤ shannonEntropyBits p := by
  have hcollision_pos :=
    collisionProbability_pos_of_probability hnonneg htotal
  have hlog_le :
      QIT.log2 (collisionProbability p) ≤ QIT.log2 (1 / 2 : ℝ) :=
    QIT.log2_mono_of_pos hcollision_pos hcollision
  have hlog_half : QIT.log2 (1 / 2 : ℝ) = -1 := by
    rw [QIT.log2_one_div, QIT.log2_two]
  have hcollision_entropy :
      1 ≤ -QIT.log2 (collisionProbability p) := by
    rw [hlog_half] at hlog_le
    linarith
  exact hcollision_entropy.trans
    (neg_log2_collisionProbability_le_shannonEntropyBits hnonneg htotal)

/-- A collision probability at most `1/2` forces collision entropy
`H₂` to be at least one bit. -/
theorem one_le_collisionEntropyBits_of_collisionProbability_le_half
    {n : ℕ} {p : Fin n → ℝ}
    (hnonneg : ∀ i, 0 ≤ p i)
    (htotal : (List.ofFn p).sum = 1)
    (hcollision : collisionProbability p ≤ 1 / 2) :
    1 ≤ collisionEntropyBits p := by
  have hcollision_pos :=
    collisionProbability_pos_of_probability hnonneg htotal
  have hlog_le :
      QIT.log2 (collisionProbability p) ≤ QIT.log2 (1 / 2 : ℝ) :=
    QIT.log2_mono_of_pos hcollision_pos hcollision
  have hlog_half : QIT.log2 (1 / 2 : ℝ) = -1 := by
    rw [QIT.log2_one_div, QIT.log2_two]
  rw [hlog_half] at hlog_le
  rw [collisionEntropyBits]
  linarith

/-- Paper-facing ordered-probability wrapper for the collision-entropy
conclusion. -/
theorem one_le_collisionEntropyBits_of_orderedProbability_of_collisionProbability_le_half
    {n : ℕ} {p : Fin n → ℝ}
    (hp : IsOrderedProbability p)
    (hcollision : collisionProbability p ≤ 1 / 2) :
    1 ≤ collisionEntropyBits p :=
  one_le_collisionEntropyBits_of_collisionProbability_le_half
    hp.2.1 hp.2.2 hcollision

/-- Paper-facing wrapper for a finite ordered Schmidt probability vector. -/
theorem one_le_shannonEntropyBits_of_orderedProbability_of_collisionProbability_le_half
    {n : ℕ} {p : Fin n → ℝ}
    (hp : IsOrderedProbability p)
    (hcollision : collisionProbability p ≤ 1 / 2) :
    1 ≤ shannonEntropyBits p :=
  one_le_shannonEntropyBits_of_collisionProbability_le_half
    hp.2.1 hp.2.2 hcollision

end

end EntanglementPurification
