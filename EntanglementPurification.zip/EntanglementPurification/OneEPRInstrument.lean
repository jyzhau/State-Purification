import EntanglementPurification.OneEPRAlgorithmOptimality
import EntanglementPurification.LocalContractionOutputTrace
import EntanglementPurification.FiniteInstrumentCoarseGraining
import QIT.Protocols.LOCC
import Mathlib.Tactic

/-!
# Complete outcome instrument for Algorithm 1

This module records all four terminal Hadamard outcomes of the one-EPR
protocol.  The equal outcomes are the accepted flag and the unequal outcomes
are the rejected flag.  Unlike the earlier accepted-map calculation, the
four branches are packaged as a genuine `QIT.FiniteInstrument`, so forgetting
the classical outcome is proved trace preserving.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

/-- Each unequal Hadamard outcome (`01` or `10`) induces the antisymmetric
projector divided by `sqrt 2` on the two complete copies. -/
theorem oneEPRHadamard_unequalOutcomeKraus
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] (outcome : Bool) :
    oneEPRHadamardOutcomeKraus (a := a) (b := b) outcome (!outcome) =
      TwoQubit.invSqrtTwo • localInputPairPAsym (x := a × b) := by
  have hcubic :
      TwoQubit.invSqrtTwo * TwoQubit.invSqrtTwo * TwoQubit.invSqrtTwo =
        (1 / 2 : ℂ) * TwoQubit.invSqrtTwo := by
    rw [TwoQubit.invSqrtTwo_mul_self]
  have hcubicNeg :
      TwoQubit.invSqrtTwo * TwoQubit.invSqrtTwo *
          (-TwoQubit.invSqrtTwo) =
        -((1 / 2 : ℂ) * TwoQubit.invSqrtTwo) := by
    rw [TwoQubit.invSqrtTwo_mul_self]
    ring
  have hnegCube :
      -(TwoQubit.invSqrtTwo ^ 3) =
        TwoQubit.invSqrtTwo * (-1 / 2 : ℂ) := by
    calc
      -(TwoQubit.invSqrtTwo ^ 3) =
          -(TwoQubit.invSqrtTwo * TwoQubit.invSqrtTwo *
            TwoQubit.invSqrtTwo) := by ring
      _ = -((1 / 2 : ℂ) * TwoQubit.invSqrtTwo) := by rw [hcubic]
      _ = TwoQubit.invSqrtTwo * (-1 / 2 : ℂ) := by ring
  have hcross :
      TwoQubit.invSqrtTwo * (-TwoQubit.invSqrtTwo) *
          TwoQubit.invSqrtTwo =
        TwoQubit.invSqrtTwo * (-1 / 2 : ℂ) := by
    calc
      TwoQubit.invSqrtTwo * (-TwoQubit.invSqrtTwo) *
          TwoQubit.invSqrtTwo = -(TwoQubit.invSqrtTwo ^ 3) := by ring
      _ = TwoQubit.invSqrtTwo * (-1 / 2 : ℂ) := hnegCube
  cases outcome
  · simp only [Bool.not_false, oneEPRHadamardOutcomeKraus,
      Fintype.sum_bool, standardEPRAmp, hadamardAmp, zero_mul, zero_smul,
      add_zero, locallyControlledCopySwap_false_false,
      locallyControlledCopySwap_true_true, hcubic, hcubicNeg]
    simp only [localInputPairPAsym]
    module
  · simp only [Bool.not_true, oneEPRHadamardOutcomeKraus,
      Fintype.sum_bool, standardEPRAmp, hadamardAmp, zero_mul, zero_smul,
      add_zero, locallyControlledCopySwap_false_false,
      locallyControlledCopySwap_true_true, hcubic, hcross]
    simp only [localInputPairPAsym]
    module

/-- The four Algorithm 1 outcome Kraus operators form a complete family. -/
theorem oneEPRHadamardOutcomeKraus_krausAdjoint_one
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    MatrixMap.krausAdjoint
        (fun outcome : Bool × Bool =>
          oneEPRHadamardOutcomeKraus (a := a) (b := b)
            outcome.1 outcome.2)
        (1 : CMatrix ((a × b) × (a × b))) = 1 := by
  simp only [MatrixMap.krausAdjoint, Fintype.sum_prod_type,
    Fintype.sum_bool]
  have h01 :
      oneEPRHadamardOutcomeKraus (a := a) (b := b) false true =
        TwoQubit.invSqrtTwo • localInputPairPAsym (x := a × b) := by
    simpa using
      (oneEPRHadamard_unequalOutcomeKraus (a := a) (b := b) false)
  have h10 :
      oneEPRHadamardOutcomeKraus (a := a) (b := b) true false =
        TwoQubit.invSqrtTwo • localInputPairPAsym (x := a × b) := by
    simpa using
      (oneEPRHadamard_unequalOutcomeKraus (a := a) (b := b) true)
  rw [oneEPRHadamard_equalOutcomeKraus (a := a) (b := b) false]
  rw [h01, h10]
  rw [oneEPRHadamard_equalOutcomeKraus (a := a) (b := b) true]
  simp_rw [Matrix.conjTranspose_smul]
  rw [globalInputPairPSym_isHermitian (x := a × b),
    localInputPairPAsym_isHermitian (x := a × b)]
  simp only [TwoQubit.star_invSqrtTwo, Matrix.mul_one,
    Matrix.smul_mul, Matrix.mul_smul, smul_smul]
  rw [globalInputPairPSym_idempotent (x := a × b),
    localInputPairPAsym_idempotent (x := a × b)]
  rw [TwoQubit.invSqrtTwo_mul_self]
  rw [← globalInputPairPSym_add_localInputPairPAsym (x := a × b)]
  module

/-- Forgetting the two recorded Hadamard outcomes gives a physical channel on
the two-copy input. -/
def oneEPRAllOutcomeTwoCopyChannel
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    Channel ((a × b) × (a × b)) ((a × b) × (a × b)) where
  map := MatrixMap.ofKraus
    (fun outcome : Bool × Bool =>
      oneEPRHadamardOutcomeKraus (a := a) (b := b)
        outcome.1 outcome.2)
  completelyPositive := MatrixMap.ofKraus_isCompletelyPositive _
  tracePreserving :=
    MatrixMap.ofKraus_tracePreserving_of_krausAdjoint_one _
      oneEPRHadamardOutcomeKraus_krausAdjoint_one
  mapsPositive := MatrixMap.isCompletelyPositive_mapsPositive _
    (MatrixMap.ofKraus_isCompletelyPositive _)

/-- The CP map associated with one separately recorded pair `(c_A,c_B)`. -/
def oneEPRSingleOutcomeTwoCopyMap
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] (outcome : Bool × Bool) :
    MatrixMap ((a × b) × (a × b)) ((a × b) × (a × b)) :=
  MatrixMap.ofKraus (fun (_ : Unit) =>
    oneEPRHadamardOutcomeKraus (a := a) (b := b)
      outcome.1 outcome.2)

/-- The sum of the four separately recorded CP branches is the complete
four-Kraus channel.  The sum here is classical: no outcome amplitudes are
added coherently. -/
theorem oneEPR_sum_singleOutcomeTwoCopyMap_eq_allOutcomeChannel
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    (∑ outcome : Bool × Bool,
        oneEPRSingleOutcomeTwoCopyMap (a := a) (b := b) outcome) =
      (oneEPRAllOutcomeTwoCopyChannel (a := a) (b := b)).map := by
  apply LinearMap.ext
  intro X
  simp [oneEPRSingleOutcomeTwoCopyMap, oneEPRAllOutcomeTwoCopyChannel,
    MatrixMap.ofKraus, Fintype.sum_prod_type]

/-- Every one of the four terminal branches is CP and trace nonincreasing.
Trace nonincrease follows from positivity of all four branches together with
the proved trace preservation of their sum. -/
theorem oneEPRSingleOutcomeTwoCopyMap_traceNonincreasingCP
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] (outcome : Bool × Bool) :
    MatrixMap.TraceNonincreasingCP
      (oneEPRSingleOutcomeTwoCopyMap (a := a) (b := b) outcome) := by
  refine
    { completelyPositive := MatrixMap.ofKraus_isCompletelyPositive _
      traceNonincreasing := ?_ }
  intro X hX
  have hpos : ∀ r : Bool × Bool,
      0 ≤ ((oneEPRSingleOutcomeTwoCopyMap (a := a) (b := b) r X).trace).re := by
    intro r
    exact (MatrixMap.isCompletelyPositive_mapsPositive _
      (MatrixMap.ofKraus_isCompletelyPositive _) X hX).trace_nonneg.1
  have htotal :=
    (oneEPRAllOutcomeTwoCopyChannel (a := a) (b := b)).tracePreserving X
  rw [← oneEPR_sum_singleOutcomeTwoCopyMap_eq_allOutcomeChannel] at htotal
  simp only [LinearMap.sum_apply, Matrix.trace_sum] at htotal
  have htotal_re := congrArg Complex.re htotal
  simp only [Fintype.sum_prod_type, Fintype.sum_bool, Complex.add_re] at htotal_re
  have h00 := hpos (false, false)
  have h01 := hpos (false, true)
  have h10 := hpos (true, false)
  have h11 := hpos (true, true)
  simp only [Fintype.sum_prod_type, Fintype.sum_bool] at htotal
  rcases outcome with ⟨cA, cB⟩
  cases cA <;> cases cB <;> nlinarith [htotal_re]

/-- Lean-QIT instrument whose classical outcome is the complete pair
`(c_A,c_B)` and whose quantum output still contains both noisy copies. -/
def oneEPRFourOutcomeTwoCopyInstrument
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    QIT.FiniteInstrument
      ((a × b) × (a × b)) ((a × b) × (a × b)) (Bool × Bool) where
  branch := oneEPRSingleOutcomeTwoCopyMap
  branchTraceNonincreasingCP :=
    oneEPRSingleOutcomeTwoCopyMap_traceNonincreasingCP
  total := oneEPRAllOutcomeTwoCopyChannel
  sum_branch_eq_total :=
    oneEPR_sum_singleOutcomeTwoCopyMap_eq_allOutcomeChannel

/-- The paper discards the second noisy copy after recording success or
failure.  Postcomposition by the trace-out channel gives the corresponding
complete four-outcome instrument with one-copy quantum output. -/
def oneEPRFourOutcomeInstrument
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    QIT.FiniteInstrument ((a × b) × (a × b)) (a × b) (Bool × Bool) :=
  QIT.FiniteInstrument.postcompChannel
    (oneEPRFourOutcomeTwoCopyInstrument (a := a) (b := b))
    (Channel.traceOutRight (a × b) (a × b))

/-- Classical comparison performed in Algorithm 1: equal local outcomes are
labelled `true` (success), and unequal outcomes are labelled `false`. -/
def oneEPRSuccessFlag (outcome : Bool × Bool) : Bool :=
  decide (outcome.1 = outcome.2)

/-- Complete success/failure instrument before the unused second noisy copy
is discarded. -/
def oneEPRSuccessFailureTwoCopyInstrument
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    QIT.FiniteInstrument
      ((a × b) × (a × b)) ((a × b) × (a × b)) Bool :=
  (oneEPRFourOutcomeTwoCopyInstrument (a := a) (b := b)).coarseGrain
    oneEPRSuccessFlag

/-- Complete success/failure instrument exactly at the paper's one-copy
quantum output interface.  `true` is success and `false` is failure. -/
def oneEPRSuccessFailureInstrument
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    QIT.FiniteInstrument ((a × b) × (a × b)) (a × b) Bool :=
  QIT.FiniteInstrument.postcompChannel
    (oneEPRSuccessFailureTwoCopyInstrument (a := a) (b := b))
    (Channel.traceOutRight (a × b) (a × b))

/-- The `true` branch before discard is precisely the classical sum of the
separately recorded `00` and `11` maps. -/
theorem oneEPRSuccessFailureTwoCopyInstrument_success
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    (oneEPRSuccessFailureTwoCopyInstrument (a := a) (b := b)).branch true =
      oneEPREqualOutcomeTwoCopyMap (a := a) (b := b) := by
  apply LinearMap.ext
  intro X
  simp [oneEPRSuccessFailureTwoCopyInstrument,
    QIT.FiniteInstrument.coarseGrainBranch, oneEPRSuccessFlag,
    oneEPRFourOutcomeTwoCopyInstrument, oneEPRSingleOutcomeTwoCopyMap,
    oneEPREqualOutcomeTwoCopyMap, MatrixMap.ofKraus]
  rw [Finset.sum_filter]
  simp only [Fintype.sum_prod_type, Fintype.sum_bool]
  simp

/-- The rejected two-copy CP map obtained by classically coarse-graining the
separately recorded unequal outcomes `01` and `10`. -/
def oneEPRUnequalOutcomeTwoCopyMap
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    MatrixMap ((a × b) × (a × b)) ((a × b) × (a × b)) :=
  MatrixMap.ofKraus (fun outcome : Bool =>
    oneEPRHadamardOutcomeKraus (a := a) (b := b) outcome (!outcome))

/-- Coarse-graining `01` and `10` gives exactly the antisymmetric-projector
sandwich. -/
theorem oneEPRUnequalOutcomeTwoCopyMap_apply
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b]
    (X : CMatrix ((a × b) × (a × b))) :
    oneEPRUnequalOutcomeTwoCopyMap (a := a) (b := b) X =
      localInputPairPAsym (x := a × b) * X *
        localInputPairPAsym (x := a × b) := by
  simp only [oneEPRUnequalOutcomeTwoCopyMap, MatrixMap.ofKraus,
    LinearMap.coe_mk, AddHom.coe_mk, Fintype.sum_bool,
    oneEPRHadamard_unequalOutcomeKraus,
    Matrix.smul_mul, Matrix.mul_smul, Matrix.conjTranspose_smul,
    TwoQubit.star_invSqrtTwo, smul_smul]
  rw [localInputPairPAsym_isHermitian]
  rw [TwoQubit.invSqrtTwo_mul_self]
  module

/-- The `false` branch before discard is precisely the classical sum of the
separately recorded `01` and `10` maps. -/
theorem oneEPRSuccessFailureTwoCopyInstrument_failure
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    (oneEPRSuccessFailureTwoCopyInstrument (a := a) (b := b)).branch false =
      oneEPRUnequalOutcomeTwoCopyMap (a := a) (b := b) := by
  apply LinearMap.ext
  intro X
  simp [oneEPRSuccessFailureTwoCopyInstrument,
    QIT.FiniteInstrument.coarseGrainBranch, oneEPRSuccessFlag,
    oneEPRFourOutcomeTwoCopyInstrument, oneEPRSingleOutcomeTwoCopyMap,
    oneEPRUnequalOutcomeTwoCopyMap, MatrixMap.ofKraus]
  rw [Finset.sum_filter]
  simp only [Fintype.sum_prod_type, Fintype.sum_bool]
  simp

/-- Explicit rejected circuit map after the second noisy copy is discarded. -/
def oneEPRAlgorithmRejectedCircuitMap
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    MatrixMap ((a × b) × (a × b)) (a × b) :=
  (MatrixMap.partialTraceB (a × b) (a × b)).comp
    (oneEPRUnequalOutcomeTwoCopyMap (a := a) (b := b))

/-- The success branch of the complete Lean-QIT instrument is exactly the
accepted circuit map already connected to the paper's optimizer. -/
theorem oneEPRSuccessFailureInstrument_success
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    (oneEPRSuccessFailureInstrument (a := a) (b := b)).branch true =
      oneEPRAlgorithmAcceptedCircuitMap (a := a) (b := b) := by
  simp only [oneEPRSuccessFailureInstrument,
    QIT.FiniteInstrument.postcompChannel_branch,
    oneEPRSuccessFailureTwoCopyInstrument_success]
  rfl

/-- The failure branch of the complete instrument is the explicit
antisymmetric outcome map followed by the same discard operation. -/
theorem oneEPRSuccessFailureInstrument_failure
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    (oneEPRSuccessFailureInstrument (a := a) (b := b)).branch false =
      oneEPRAlgorithmRejectedCircuitMap (a := a) (b := b) := by
  simp only [oneEPRSuccessFailureInstrument,
    QIT.FiniteInstrument.postcompChannel_branch,
    oneEPRSuccessFailureTwoCopyInstrument_failure]
  rfl

/-- Therefore the success branch of the complete instrument is exactly the
globally optimal one-EPR accepted map. -/
theorem oneEPRSuccessFailureInstrument_success_eq_oneEPRAcceptedMap
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    (oneEPRSuccessFailureInstrument (a := a) (b := b)).branch true =
      oneEPRAcceptedMap (x := a × b) := by
  rw [oneEPRSuccessFailureInstrument_success]
  exact oneEPRAlgorithmAcceptedCircuitMap_eq_oneEPRAcceptedMap

/-- Failure plus success is a trace-preserving channel.  This is the formal
statement that the protocol has no omitted terminal outcome. -/
theorem oneEPRSuccessFailureInstrument_complete
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    (oneEPRSuccessFailureInstrument (a := a) (b := b)).branch false +
        (oneEPRSuccessFailureInstrument (a := a) (b := b)).branch true =
      (oneEPRSuccessFailureInstrument (a := a) (b := b)).total.map := by
  have h :
      (∑ flag : Bool,
          (oneEPRSuccessFailureInstrument (a := a) (b := b)).branch flag) =
        (oneEPRSuccessFailureInstrument (a := a) (b := b)).total.map :=
    (oneEPRSuccessFailureInstrument (a := a) (b := b)).sum_branch_eq_total
  rw [Fintype.sum_bool] at h
  rw [add_comm]
  exact h

/-- Headline complete-instrument certificate for Algorithm 1.

It simultaneously records the explicit rejected and accepted branches, CP
and trace nonincrease of both terminal flags, completeness of those flags,
trace preservation after forgetting the flag, the optimizer Choi identity,
and exact attainment of the paper's Haar-averaged benchmark.
-/
theorem oneEPRAlgorithm_completeInstrument_certificate
    {d : Nat} (hd : 2 ≤ d)
    (nu : PureVector (GlobalPaperIndex d))
    (gamma : Real) :
    let M := oneEPRSuccessFailureInstrument (a := Fin d) (b := Fin d)
    M.branch false =
        oneEPRAlgorithmRejectedCircuitMap (a := Fin d) (b := Fin d) ∧
    M.branch true =
        oneEPRAlgorithmAcceptedCircuitMap (a := Fin d) (b := Fin d) ∧
    MatrixMap.TraceNonincreasingCP (M.branch false) ∧
    MatrixMap.TraceNonincreasingCP (M.branch true) ∧
    M.branch false + M.branch true = M.total.map ∧
    MatrixMap.IsTracePreserving M.total.map ∧
    MatrixMap.choi (M.branch true) =
      globalOptimalChoi (x := GlobalPaperIndex d) ∧
    globalSDPObjective
        (globalPaperHaarPerformanceOperator hd nu gamma)
        (MatrixMap.choi (M.branch true)) =
      globalOptimalGain ((d : Real) ^ 2) gamma := by
  dsimp only
  refine And.intro oneEPRSuccessFailureInstrument_failure ?_
  refine And.intro oneEPRSuccessFailureInstrument_success ?_
  refine And.intro
    ((oneEPRSuccessFailureInstrument
      (a := Fin d) (b := Fin d)).branchTraceNonincreasingCP false) ?_
  refine And.intro
    ((oneEPRSuccessFailureInstrument
      (a := Fin d) (b := Fin d)).branchTraceNonincreasingCP true) ?_
  refine And.intro oneEPRSuccessFailureInstrument_complete ?_
  refine And.intro
    (oneEPRSuccessFailureInstrument
      (a := Fin d) (b := Fin d)).total.tracePreserving ?_
  refine And.intro ?_ ?_
  · rw [oneEPRSuccessFailureInstrument_success]
    exact choi_oneEPRAlgorithmAcceptedCircuitMap_eq_globalOptimalChoi
  · rw [oneEPRSuccessFailureInstrument_success]
    exact oneEPRAlgorithmAcceptedCircuitMap_attains_globalPaperHaar_gain
      hd nu gamma

end

end EntanglementPurification
