import EntanglementPurification.PhysicalResourceInsertion
import EntanglementPurification.OutputTraceSectorDecomposition

/-!
# Mixed local-parity output sectors of the inserted global optimizer

This file proves the two zero-sector premises used by the compressed physical
instrument theorem.  The proof keeps separate the two facts which are often
compressed into one sentence in the paper: the output trace of the explicit
global optimizer is the global two-copy symmetric projector, and after
regrouping the two copies by party that projector has support only in the
`++` and `--` local-parity sectors.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b r : Type*}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

/-- Regroup two copies of the global `A × B` input into Alice's pair and
Bob's pair. -/
def globalInputPairToLocalPairsEquiv :
    ((a × b) × (a × b)) ≃ ((a × a) × (b × b)) where
  toFun p := ((p.1.1, p.2.1), (p.1.2, p.2.2))
  invFun p := ((p.1.1, p.2.1), (p.1.2, p.2.2))
  left_inv _ := rfl
  right_inv _ := rfl

/-- The global two-copy symmetric projector in local Alice/Bob pair order. -/
def localRegroupedGlobalInputPairPSym :
    CMatrix ((a × a) × (b × b)) :=
  (Matrix.reindexAlgEquiv ℂ ℂ
    (globalInputPairToLocalPairsEquiv (a := a) (b := b)))
      (globalInputPairPSym (x := a × b))

/-- The displayed global optimizer has output trace equal to the symmetric
projector on its two input copies. -/
theorem partialTraceB_globalOptimalChoi :
    QIT.partialTraceB (a := (a × b) × (a × b)) (b := a × b)
        (globalOptimalChoi (x := a × b)) =
      globalInputPairPSym (x := a × b) := by
  rw [globalOptimalChoi]
  change
    QIT.partialTraceB
        (((((Fintype.card (a × b) : ℝ) + 1) / 2 : ℝ) : ℂ) •
          globalPWPlus) =
      globalInputPairPSym
  rw [QIT.partialTraceB_smul, partialTraceB_globalPWPlus]
  have hdenom : (Fintype.card (a × b) : ℂ) + 1 ≠ 0 := by
    positivity
  have hscalar :
      (((((Fintype.card (a × b) : ℝ) + 1) / 2 : ℝ) : ℂ) *
          (((2 / ((Fintype.card (a × b) : ℝ) + 1)) : ℝ) : ℂ)) = 1 := by
    push_cast
    field_simp [hdenom]
  rw [smul_smul, hscalar, one_smul]

/-- Trace out the two output registers of an unassisted physical branch. -/
def physicalUnassistedBranchOutputTrace
    (J : CMatrix (JointContractionUnassistedPhysicalIndex a b)) :
    CMatrix ((a × a) × (b × b)) :=
  fun p q =>
    ∑ aOut : a, ∑ bOut : b,
      J ((p.1, aOut), (p.2, bOut))
        ((q.1, aOut), (q.2, bOut))

/-- Output trace commutes with regrouping an unassisted raw Choi matrix into
physical Alice/Bob order. -/
theorem physicalBranchOutputTrace_physicalInsertedChoiMatrix
    (J : CMatrix (PhysicalUnassistedChoiIndex a b)) :
    physicalUnassistedBranchOutputTrace (physicalInsertedChoiMatrix J) =
      (Matrix.reindexAlgEquiv ℂ ℂ
        (globalInputPairToLocalPairsEquiv (a := a) (b := b)))
          (QIT.partialTraceB J) := by
  ext p q
  rcases p with ⟨⟨iA, jA⟩, ⟨iB, jB⟩⟩
  rcases q with ⟨⟨kA, lA⟩, ⟨kB, lB⟩⟩
  simp [physicalUnassistedBranchOutputTrace, physicalInsertedChoiMatrix,
    Matrix.reindexAlgEquiv_apply, Matrix.reindex_apply,
    physicalInsertedChoiEquiv, globalInputPairToLocalPairsEquiv,
    QIT.partialTraceB, Fintype.sum_prod_type]

/-- Physical output trace of the regrouped global optimizer. -/
theorem physicalBranchOutputTrace_physicalInserted_globalOptimalChoi :
    physicalUnassistedBranchOutputTrace
        (physicalInsertedChoiMatrix
          (globalOptimalChoi (x := a × b))) =
      localRegroupedGlobalInputPairPSym (a := a) (b := b) := by
  rw [physicalBranchOutputTrace_physicalInsertedChoiMatrix,
    partialTraceB_globalOptimalChoi]
  rfl

private theorem reindex_globalInputPairSwap_eq_kronecker :
    (Matrix.reindexAlgEquiv ℂ ℂ
      (globalInputPairToLocalPairsEquiv (a := a) (b := b)))
        (globalInputPairSwap (x := a × b)) =
      Matrix.kronecker (globalInputPairSwap (x := a))
        (globalInputPairSwap (x := b)) := by
  ext p q
  rcases p with ⟨⟨iA, jA⟩, ⟨iB, jB⟩⟩
  rcases q with ⟨⟨kA, lA⟩, ⟨kB, lB⟩⟩
  simp only [globalInputPairToLocalPairsEquiv, Equiv.symm, Equiv.coe_fn_mk,
    Matrix.reindexAlgEquiv_apply,
    Matrix.reindex_apply, Matrix.submatrix_apply,
    globalInputPairSwap,
    Matrix.kronecker, Matrix.kroneckerMap_apply, Prod.ext_iff]
  have hSwap :
      ((kA = jA ∧ kB = jB) ∧ lA = iA ∧ lB = iB) ↔
        (kA = jA ∧ lA = iA) ∧ (kB = jB ∧ lB = iB) := by
    aesop
  simp only [hSwap]
  by_cases hA : kA = jA ∧ lA = iA <;>
    by_cases hB : kB = jB ∧ lB = iB <;>
    simp [hA, hB]

private theorem localRegroupedGlobalInputPairPSym_eq_swap_formula :
    localRegroupedGlobalInputPairPSym (a := a) (b := b) =
      (1 / 2 : ℂ) •
        (Matrix.kronecker (1 : CMatrix (a × a)) (1 : CMatrix (b × b)) +
          Matrix.kronecker (globalInputPairSwap (x := a))
            (globalInputPairSwap (x := b))) := by
  unfold localRegroupedGlobalInputPairPSym globalInputPairPSym
  simp only [map_smul, map_add, map_one,
    reindex_globalInputPairSwap_eq_kronecker]
  rw [← Matrix.one_kronecker_one]
  rfl

omit [Fintype a] [Fintype b] [DecidableEq a] [DecidableEq b] in
private theorem half_kronecker_parity_identity
    (IA SA : CMatrix (a × a)) (IB SB : CMatrix (b × b)) :
    (1 / 2 : ℂ) •
        (Matrix.kronecker IA IB + Matrix.kronecker SA SB) =
      Matrix.kronecker
          ((1 / 2 : ℂ) • (IA + SA))
          ((1 / 2 : ℂ) • (IB + SB)) +
        Matrix.kronecker
          ((1 / 2 : ℂ) • (IA - SA))
          ((1 / 2 : ℂ) • (IB - SB)) := by
  ext p q
  simp only [Matrix.smul_apply, Matrix.add_apply, Matrix.sub_apply,
    Matrix.kronecker, Matrix.kroneckerMap_apply]
  ring

/-- Equation `eq:global_input_parity_local_decomposition`: in local pair
order, global input symmetry means equal local parities. -/
theorem localRegroupedGlobalInputPairPSym_eq_PP_add_MM :
    localRegroupedGlobalInputPairPSym (a := a) (b := b) =
      jointInputSectorProjector (a := a) (b := b) sectorPP +
        jointInputSectorProjector (a := a) (b := b) sectorMM := by
  calc
    localRegroupedGlobalInputPairPSym (a := a) (b := b) =
        (1 / 2 : ℂ) •
          (Matrix.kronecker (1 : CMatrix (a × a)) (1 : CMatrix (b × b)) +
            Matrix.kronecker (globalInputPairSwap (x := a))
              (globalInputPairSwap (x := b))) :=
      localRegroupedGlobalInputPairPSym_eq_swap_formula
    _ = jointInputSectorProjector (a := a) (b := b) sectorPP +
          jointInputSectorProjector (a := a) (b := b) sectorMM := by
      simpa only [jointInputSectorProjector, sectorPP, sectorMM,
        localInputPairProjector, globalInputPairPSym,
        localInputPairPAsym] using
        (half_kronecker_parity_identity
          (IA := (1 : CMatrix (a × a)))
          (SA := globalInputPairSwap (x := a))
          (IB := (1 : CMatrix (b × b)))
          (SB := globalInputPairSwap (x := b)))

/-- Sandwich an output-trace matrix with a fixed pure resource vector. -/
def outputTracePureResourceInsert (eta : r → ℂ)
    (T : CMatrix (JointContractionInputResourceIndex a b r)) :
    CMatrix ((a × a) × (b × b)) :=
  fun p q =>
    ∑ u : r, ∑ v : r,
      star (eta u) * T (p, u) (q, v) * eta v

omit [Fintype a] [Fintype b] [DecidableEq a] [DecidableEq b]
    [DecidableEq r] in
@[simp]
theorem outputTracePureResourceInsert_zero (eta : r → ℂ) :
    outputTracePureResourceInsert (a := a) (b := b) eta 0 = 0 := by
  ext p q
  simp [outputTracePureResourceInsert]

omit [Fintype a] [Fintype b] [DecidableEq a] [DecidableEq b]
    [DecidableEq r] in
theorem outputTracePureResourceInsert_add
    (eta : r → ℂ)
    (T U : CMatrix (JointContractionInputResourceIndex a b r)) :
    outputTracePureResourceInsert eta (T + U) =
      outputTracePureResourceInsert eta T +
        outputTracePureResourceInsert eta U := by
  ext p q
  simp only [outputTracePureResourceInsert, Matrix.add_apply]
  simp_rw [mul_add, add_mul, Finset.sum_add_distrib]

omit [Fintype a] [Fintype b] [DecidableEq a] [DecidableEq b]
    [DecidableEq r] in
theorem outputTracePureResourceInsert_finset_sum
    {i : Type*} (s : Finset i)
    (eta : r → ℂ)
    (T : i → CMatrix (JointContractionInputResourceIndex a b r)) :
    outputTracePureResourceInsert eta (∑ j ∈ s, T j) =
      ∑ j ∈ s, outputTracePureResourceInsert eta (T j) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert j s hj ih =>
      simp [hj, outputTracePureResourceInsert_add, ih]

omit [Fintype a] [Fintype b] [DecidableEq a] [DecidableEq b]
    [DecidableEq r] in
theorem outputTracePureResourceInsert_sum
    {i : Type*} [Fintype i]
    (eta : r → ℂ)
    (T : i → CMatrix (JointContractionInputResourceIndex a b r)) :
    outputTracePureResourceInsert eta (∑ j, T j) =
      ∑ j, outputTracePureResourceInsert eta (T j) := by
  simpa using
    (outputTracePureResourceInsert_finset_sum (a := a) (b := b)
      (r := r) (Finset.univ : Finset i) eta T)

omit [Fintype a] [Fintype b] [DecidableEq a] [DecidableEq b]
    [DecidableEq r] in
/-- On one exact sector term, resource insertion replaces its resource block
by the corresponding scalar quadratic form. -/
theorem outputTracePureResourceInsert_kronecker
    (eta : r → ℂ) (P : CMatrix ((a × a) × (b × b)))
    (C : CMatrix r) :
    outputTracePureResourceInsert eta (Matrix.kronecker P C) =
      dotProduct (star eta) (C.mulVec eta) • P := by
  ext p q
  simp [outputTracePureResourceInsert, Matrix.kronecker,
    Matrix.smul_apply, dotProduct, Matrix.mulVec,
    Finset.mul_sum, Finset.sum_mul, mul_comm, mul_left_comm, mul_assoc]

/-- Insert the resource vector into the canonical exact four-sector output
trace expansion. -/
theorem outputTracePureResourceInsert_eq_sum_sectorQuadratic
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (eta : r → ℂ)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K) :
    outputTracePureResourceInsert eta (physicalBranchOutputTrace K) =
      ∑ z : LocalMultiplicitySector,
        dotProduct (star eta)
            ((outputTraceSectorCoefficient
              (physicalBranchOutputTrace K) z).mulVec eta) •
          jointInputSectorProjector (a := a) (b := b) z := by
  let T := physicalBranchOutputTrace K
  have hExpansion : T =
      ∑ z : LocalMultiplicitySector,
        Matrix.kronecker
          (jointInputSectorProjector (a := a) (b := b) z)
          (outputTraceSectorCoefficient T z) := by
    simpa [T] using
      physicalBranchOutputTrace_eq_sum_outputTraceSectorCoefficient
        hcardA hcardB hInvariant
  calc
    outputTracePureResourceInsert eta (physicalBranchOutputTrace K) =
        outputTracePureResourceInsert eta T := by rfl
    _ = outputTracePureResourceInsert eta
        (∑ z : LocalMultiplicitySector,
          Matrix.kronecker
            (jointInputSectorProjector (a := a) (b := b) z)
            (outputTraceSectorCoefficient T z)) :=
      congrArg (outputTracePureResourceInsert eta) hExpansion
    _ = ∑ z : LocalMultiplicitySector,
        outputTracePureResourceInsert eta
          (Matrix.kronecker
            (jointInputSectorProjector (a := a) (b := b) z)
            (outputTraceSectorCoefficient T z)) :=
      outputTracePureResourceInsert_sum eta _
    _ = _ := by
      apply Finset.sum_congr rfl
      intro z _
      rw [outputTracePureResourceInsert_kronecker]

/-- Tracing out the physical outputs commutes with sandwiching the resource. -/
theorem physicalUnassistedBranchOutputTrace_physicalPureResourceInsert
    (eta : r → ℂ)
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    physicalUnassistedBranchOutputTrace
        (physicalPureResourceInsert eta K) =
      outputTracePureResourceInsert eta (physicalBranchOutputTrace K) := by
  ext p q
  rcases p with ⟨iA, iB⟩
  rcases q with ⟨kA, kB⟩
  simp only [physicalUnassistedBranchOutputTrace,
    physicalPureResourceInsert_apply,
    outputTracePureResourceInsert, physicalBranchOutputTrace_apply]
  simp_rw [Finset.mul_sum, Finset.sum_mul]
  let f : (a × b) → (r × r) → ℂ := fun o uv =>
    star (eta uv.1) *
      K (((iA, o.1), (iB, o.2)), uv.1)
        (((kA, o.1), (kB, o.2)), uv.2) * eta uv.2
  change (∑ aOut : a, ∑ bOut : b, ∑ u : r, ∑ v : r,
      f (aOut, bOut) (u, v)) =
    ∑ u : r, ∑ v : r, ∑ aOut : a, ∑ bOut : b,
      f (aOut, bOut) (u, v)
  simpa only [Fintype.sum_prod_type] using
    (Finset.sum_comm :
      (∑ o : a × b, ∑ uv : r × r, f o uv) =
        ∑ uv : r × r, ∑ o : a × b, f o uv)

private theorem sectorScalar_eq_zero_of_sum_eq_PP_add_MM
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (c : LocalMultiplicitySector → ℂ) (z : LocalMultiplicitySector)
    (hzPP : z ≠ sectorPP) (hzMM : z ≠ sectorMM)
    (hEq :
      (∑ w : LocalMultiplicitySector,
          c w • jointInputSectorProjector (a := a) (b := b) w) =
        jointInputSectorProjector (a := a) (b := b) sectorPP +
          jointInputSectorProjector (a := a) (b := b) sectorMM) :
    c z = 0 := by
  classical
  let P := jointInputSectorProjector (a := a) (b := b) z
  have hmul :
      P * (∑ w : LocalMultiplicitySector,
          c w • jointInputSectorProjector (a := a) (b := b) w) =
        c z • P := by
    rw [Matrix.mul_sum]
    simp [P, jointInputSectorProjector_mul]
  have hzeroMatrix : c z • P = 0 := by
    calc
      c z • P = P * (∑ w : LocalMultiplicitySector,
          c w • jointInputSectorProjector (a := a) (b := b) w) := hmul.symm
      _ = P *
          (jointInputSectorProjector (a := a) (b := b) sectorPP +
            jointInputSectorProjector (a := a) (b := b) sectorMM) := by
              rw [hEq]
      _ = 0 := by
        simp only [P, Matrix.mul_add, jointInputSectorProjector_mul,
          hzPP, hzMM, if_false, zero_add]
  have htrace := congrArg Matrix.trace hzeroMatrix
  simp only [Matrix.trace_smul, Matrix.trace_zero] at htrace
  change c z *
      (jointInputSectorProjector (a := a) (b := b) z).trace = 0 at htrace
  rw [jointInputSectorProjector_trace_eq_scale] at htrace
  have hscale :
      ((jointInputSectorTraceScale a b z : ℝ) : ℂ) ≠ 0 := by
    exact_mod_cast (jointInputSectorTraceScale_pos hcardA hcardB z).ne'
  exact (mul_eq_zero.mp htrace).resolve_right hscale

/-- Exact insertion into the global optimizer forces the two mixed local
parity output-sector resource quadratic forms to vanish. -/
theorem outputTrace_mixedSector_quadratics_zero_of_physicalInserted_globalOptimalChoi
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (eta : r → ℂ)
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hInvariant : JointContractionPhysicalInvariant K)
    (hInserted :
      physicalPureResourceInsert eta K =
        physicalInsertedChoiMatrix
          (globalOptimalChoi (x := a × b))) :
    dotProduct (star eta)
        ((outputTraceSectorCoefficient
          (physicalBranchOutputTrace K) sectorPM).mulVec eta) = 0 ∧
      dotProduct (star eta)
        ((outputTraceSectorCoefficient
          (physicalBranchOutputTrace K) sectorMP).mulVec eta) = 0 := by
  let c : LocalMultiplicitySector → ℂ := fun z =>
    dotProduct (star eta)
      ((outputTraceSectorCoefficient
        (physicalBranchOutputTrace K) z).mulVec eta)
  have hInsertedTrace :
      outputTracePureResourceInsert eta (physicalBranchOutputTrace K) =
        localRegroupedGlobalInputPairPSym (a := a) (b := b) := by
    calc
      outputTracePureResourceInsert eta (physicalBranchOutputTrace K) =
          physicalUnassistedBranchOutputTrace
            (physicalPureResourceInsert eta K) :=
        (physicalUnassistedBranchOutputTrace_physicalPureResourceInsert
          eta K).symm
      _ = physicalUnassistedBranchOutputTrace
          (physicalInsertedChoiMatrix
            (globalOptimalChoi (x := a × b))) := by rw [hInserted]
      _ = localRegroupedGlobalInputPairPSym (a := a) (b := b) :=
        physicalBranchOutputTrace_physicalInserted_globalOptimalChoi
  have hEq :
      (∑ z : LocalMultiplicitySector,
          c z • jointInputSectorProjector (a := a) (b := b) z) =
        jointInputSectorProjector (a := a) (b := b) sectorPP +
          jointInputSectorProjector (a := a) (b := b) sectorMM := by
    calc
      (∑ z : LocalMultiplicitySector,
          c z • jointInputSectorProjector (a := a) (b := b) z) =
          outputTracePureResourceInsert eta
            (physicalBranchOutputTrace K) := by
        simpa [c] using
          (outputTracePureResourceInsert_eq_sum_sectorQuadratic
            hcardA hcardB eta hInvariant).symm
      _ = localRegroupedGlobalInputPairPSym (a := a) (b := b) := hInsertedTrace
      _ = _ := localRegroupedGlobalInputPairPSym_eq_PP_add_MM
  constructor
  · simpa [c] using
      sectorScalar_eq_zero_of_sum_eq_PP_add_MM
        hcardA hcardB c sectorPM (by simp [sectorPM, sectorPP])
          (by simp [sectorPM, sectorMM]) hEq
  · simpa [c] using
      sectorScalar_eq_zero_of_sum_eq_PP_add_MM
        hcardA hcardB c sectorMP (by simp [sectorMP, sectorPP])
          (by simp [sectorMP, sectorMM]) hEq

/-- Raw input-first Choi form: exact pure-resource insertion into the global
optimizer implies both canonical mixed-sector output quadratics vanish. -/
theorem outputTrace_mixedSector_quadratics_zero_of_raw_globalOptimalChoi
    {ra rb : Type*}
    [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (eta : ra × rb → ℂ)
    (K : CMatrix
      (PhysicalInstrumentInput a b ra rb × PhysicalInstrumentOutput a b))
    (hInvariant : JointContractionPhysicalInvariant
      (physicalInstrumentChoiMatrix K))
    (hRaw : pureResourceInsert eta K =
      globalOptimalChoi (x := a × b)) :
    dotProduct (star eta)
        ((outputTraceSectorCoefficient
          (physicalBranchOutputTrace
            (physicalInstrumentChoiMatrix K)) sectorPM).mulVec eta) = 0 ∧
      dotProduct (star eta)
        ((outputTraceSectorCoefficient
          (physicalBranchOutputTrace
            (physicalInstrumentChoiMatrix K)) sectorMP).mulVec eta) = 0 := by
  apply
    outputTrace_mixedSector_quadratics_zero_of_physicalInserted_globalOptimalChoi
      hcardA hcardB eta hInvariant
  rw [physicalPureResourceInsert_physicalInstrumentChoiMatrix, hRaw]

end

end EntanglementPurification
