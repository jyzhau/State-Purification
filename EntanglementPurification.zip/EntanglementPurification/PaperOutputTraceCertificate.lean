import EntanglementPurification.OutputTraceSectorDecomposition
import EntanglementPurification.PaperOutputTraceBounds

/-!
# Paper-level output-trace sector certificate

This module packages the output-trace part of the local mixed-Schur argument
into one proposition.  In particular, the sector coefficients below are not
arbitrary compressions: the exact expansion and uniqueness fields identify
them with the unique resource-valued coefficients used in `main.tex`.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b ra rb : Type*}
  [Fintype a] [Fintype b] [Fintype ra] [Fintype rb]
  [DecidableEq a] [DecidableEq b] [DecidableEq ra] [DecidableEq rb]
  [Nonempty a] [Nonempty b]

/-- The paper-facing conclusions for the output trace of one physical branch.

The scale is written in the paper's equal-dimension notation.  The theorem
constructing this certificate below therefore requires `card b = card a`.
-/
structure PaperOutputTraceD2Certificate
    (K : CMatrix (JointContractionPhysicalIndex a b (ra × rb))) : Prop where
  /-- Equation `eq:output_trace_sector_coefficient_definition`. -/
  exact_sector_expansion :
    physicalBranchOutputTrace K =
      ∑ z : LocalMultiplicitySector,
        Matrix.kronecker
          (jointInputSectorProjector (a := a) (b := b) z)
          (outputTraceSectorCoefficient (physicalBranchOutputTrace K) z)
  /-- The resource-valued coefficients in that expansion are unique. -/
  sector_coefficients_unique :
    ∀ C : LocalMultiplicitySector → CMatrix (ra × rb),
      physicalBranchOutputTrace K =
          ∑ z : LocalMultiplicitySector,
            Matrix.kronecker
              (jointInputSectorProjector (a := a) (b := b) z) (C z) →
        C = fun z =>
          outputTraceSectorCoefficient (physicalBranchOutputTrace K) z
  /-- Positivity of every output-trace sector coefficient. -/
  sector_coefficient_posSemidef :
    ∀ z : LocalMultiplicitySector,
      (outputTraceSectorCoefficient
        (physicalBranchOutputTrace K) z).PosSemidef
  /-- The residual also has the exact canonical four-sector expansion. -/
  residual_exact_sector_expansion :
    physicalBranchOutputTrace (jointContractionResidual K) =
      ∑ z : LocalMultiplicitySector,
        Matrix.kronecker
          (jointInputSectorProjector (a := a) (b := b) z)
          (outputTraceSectorCoefficient
            (physicalBranchOutputTrace (jointContractionResidual K)) z)
  /-- Equation `eq:branch_sector_trace_decomposition`, uniformly in `z`. -/
  sector_coefficient_decomposition :
    ∀ z : LocalMultiplicitySector,
      outputTraceSectorCoefficient (physicalBranchOutputTrace K) z =
        localSectorTraceScale (Fintype.card a) z •
            resourceSectorBlock (jointContractionSchurCoefficient K) z z +
          outputTraceSectorCoefficient
            (physicalBranchOutputTrace (jointContractionResidual K)) z
  /-- Equation `eq:residual_output_trace_sector_positive`. -/
  residual_sector_coefficient_posSemidef :
    ∀ z : LocalMultiplicitySector,
      (outputTraceSectorCoefficient
        (physicalBranchOutputTrace (jointContractionResidual K)) z).PosSemidef
  /-- Equation `eq:branch_sector_trace_lower_bounds`, uniformly in `z`. -/
  sector_coefficient_lowerBound :
    ∀ z : LocalMultiplicitySector,
      localSectorTraceScale (Fintype.card a) z •
          resourceSectorBlock (jointContractionSchurCoefficient K) z z ≤
        outputTraceSectorCoefficient (physicalBranchOutputTrace K) z
  /-- Equation `eq:mixed_schur_trace_ppt_order`. -/
  sector_coefficient_partialTransposeB_posSemidef :
    ∀ z : LocalMultiplicitySector,
      (QIT.partialTransposeB
        (outputTraceSectorCoefficient
          (physicalBranchOutputTrace K) z)).PosSemidef

/-- One paper-level entry point for the complete output-trace sector argument.

Its assumptions are exactly the standing hypotheses used by this part of the
paper: local-unitary invariance, branch positivity, physical Bob-PPT, local
dimensions at least two, and equality of Alice's and Bob's local dimensions.
-/
theorem physicalInvariantPPT_outputTrace_D2_certificate_paper
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (hcardEq : Fintype.card b = Fintype.card a)
    {K : CMatrix (JointContractionPhysicalIndex a b (ra × rb))}
    (hInvariant : JointContractionPhysicalInvariant K)
    (hK : K.PosSemidef)
    (hKppt : (physicalBranchPartialTransposeB K).PosSemidef) :
    PaperOutputTraceD2Certificate K := by
  have hExact :=
    physicalBranchOutputTrace_eq_sum_outputTraceSectorCoefficient
      hcardA hcardB hInvariant
  refine
    { exact_sector_expansion := hExact
      sector_coefficients_unique := ?_
      sector_coefficient_posSemidef := ?_
      residual_exact_sector_expansion := ?_
      sector_coefficient_decomposition := ?_
      residual_sector_coefficient_posSemidef := ?_
      sector_coefficient_lowerBound := ?_
      sector_coefficient_partialTransposeB_posSemidef := ?_ }
  · intro C hC
    exact outputInputSectorDecomposition_unique
      hcardA hcardB hC hExact
  · intro z
    exact outputTraceSectorCoefficient_posSemidef hcardA hcardB
      (physicalBranchOutputTrace_posSemidef hK) z
  · exact physicalBranchOutputTrace_eq_sum_outputTraceSectorCoefficient
      hcardA hcardB
      (jointContractionResidual_physicalInvariant hInvariant)
  · intro z
    rw [← jointContractionOutputTraceRealScale_eq_localSectorTraceScale
      hcardA hcardEq z]
    exact physicalInvariant_outputTrace_sectorCoefficient_decomposition
      hcardA hcardB hInvariant hK z
  · intro z
    exact physicalInvariant_outputTrace_residualSectorCoefficient_posSemidef
      hcardA hcardB hK z
  · intro z
    exact physicalInvariant_outputTrace_sectorCoefficient_lowerBound_paper
      hcardA hcardB hcardEq hInvariant hK z
  · intro z
    exact
      physicalPPT_outputTrace_sectorCoefficient_partialTransposeB_posSemidef
        hcardA hcardB hKppt z

end

end EntanglementPurification
