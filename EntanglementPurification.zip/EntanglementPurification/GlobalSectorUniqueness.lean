import EntanglementPurification.GlobalSDPRigidity
import EntanglementPurification.GlobalSectorOptimization
import Mathlib.Tactic

/-!
# Equality rigidity for the global four-sector SDP

This file converts equality in the scalar/SDP bound into support on the
distinguished sector, then gives the generic compression-and-trace argument
that turns such support into the unique scaled range projection.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

/-- Any optimizer of the four-sector SDP is supported entirely on `WPlus`,
and its `WPlus` mass saturates the input-symmetric capacity. -/
theorem global_four_sector_optimizer_support
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    {D gamma : ℝ}
    {PWPlus PWMinus PLPlus PLMinus : CMatrix (Prod x y)}
    {Pinput : CMatrix x} {J : CMatrix (Prod x y)}
    (hD : 4 ≤ D) (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (hPWPlusPos : PWPlus.PosSemidef)
    (hPWMinusPos : PWMinus.PosSemidef)
    (hPLPlusPos : PLPlus.PosSemidef)
    (hPLMinusPos : PLMinus.PosSemidef)
    (hPWPlusId : PWPlus * PWPlus = PWPlus)
    (hPWMinusId : PWMinus * PWMinus = PWMinus)
    (hPLPlusId : PLPlus * PLPlus = PLPlus)
    (hPLMinusId : PLMinus * PLMinus = PLMinus)
    (horth : PairwiseOrthogonalFour PWPlus PWMinus PLPlus PLMinus)
    (hresolve : PWPlus + PWMinus + PLPlus + PLMinus = 1)
    (hPinputPos : Pinput.PosSemidef)
    (hPWPlusLe : PWPlus ≤ Matrix.kronecker Pinput (1 : CMatrix y))
    (hPinputTrace : Pinput.trace.re = inputSymmetricDimension D)
    (hJ : IsGlobalCPTNChoi J)
    (hoptimal :
      globalSDPObjective
          (globalSectorPerformanceOperator D gamma
            PWPlus PWMinus PLPlus PLMinus) J =
        globalOptimalGain D gamma) :
    globalSectorMass PWPlus J = inputSymmetricDimension D ∧
      J = PWPlus * J * PWPlus := by
  have heq := (global_four_sector_SDP_eq_iff
    hD hgamma0 hgamma1 hPWPlusPos hPWMinusPos hPLPlusPos hPLMinusPos
    hPinputPos hPWPlusLe hPinputTrace hJ).mp hoptimal
  refine ⟨heq.1, ?_⟩
  exact psd_eq_distinguished_compression_of_four_projection_zero_masses
    hJ.1 hPWPlusPos.isHermitian hPWMinusPos.isHermitian
    hPLPlusPos.isHermitian hPLMinusPos.isHermitian
    hPWPlusId hPWMinusId hPLPlusId hPLMinusId horth hresolve
    heq.2.1 heq.2.2.1 heq.2.2.2

/-- Generic final step of the uniqueness proof.

If `W` is an isometry, `J` is supported on its range projection, the
compressed matrix `W^H J W` is bounded by `c I`, and its trace saturates that
bound, then `J` is exactly `c` times the range projection. -/
theorem supported_psd_eq_scaled_rangeProjection_of_compression_bound
    {x h : Type*} [Fintype x] [Fintype h]
    [DecidableEq x] [DecidableEq h]
    {D c : ℝ} {W : Matrix h x ℂ} {J : CMatrix h}
    (hcard : (Fintype.card x : ℝ) = D)
    (hWiso : Matrix.conjTranspose W * W = (1 : CMatrix x))
    (hJ : J.PosSemidef)
    (hsupport :
      J = (W * Matrix.conjTranspose W) * J *
        (W * Matrix.conjTranspose W))
    (hcompression :
      Matrix.conjTranspose W * J * W ≤ c • (1 : CMatrix x))
    (hmass :
      (((W * Matrix.conjTranspose W) * J).trace).re = c * D) :
    J = c • (W * Matrix.conjTranspose W) := by
  let A : CMatrix x := Matrix.conjTranspose W * J * W
  have hA : A.PosSemidef := by
    exact hJ.conjTranspose_mul_mul_same W
  have htraceA : A.trace = ((W * Matrix.conjTranspose W) * J).trace := by
    calc
      A.trace = ((Matrix.conjTranspose W * J) * W).trace := by rfl
      _ = (W * (Matrix.conjTranspose W * J)).trace :=
        Matrix.trace_mul_comm (Matrix.conjTranspose W * J) W
      _ = ((W * Matrix.conjTranspose W) * J).trace := by
        rw [Matrix.mul_assoc]
  have hdiff : (c • (1 : CMatrix x) - A).PosSemidef := by
    rwa [← Matrix.le_iff]
  have htraceDiffRe : (c • (1 : CMatrix x) - A).trace.re = 0 := by
    rw [Matrix.trace_sub, Complex.sub_re, Matrix.trace_smul,
      Complex.smul_re, smul_eq_mul, Matrix.trace_one, htraceA, hmass]
    norm_num [hcard]
  have htraceDiff : (c • (1 : CMatrix x) - A).trace = 0 := by
    apply Complex.ext
    · exact htraceDiffRe
    · exact (Matrix.PosSemidef.trace_nonneg hdiff).2.symm
  have hAeq : A = c • (1 : CMatrix x) := by
    have hzero := (Matrix.PosSemidef.trace_eq_zero_iff hdiff).mp htraceDiff
    exact sub_eq_zero.mp hzero |>.symm
  have hrangeId :
      (W * Matrix.conjTranspose W) * (W * Matrix.conjTranspose W) =
        W * Matrix.conjTranspose W := by
    calc
      (W * Matrix.conjTranspose W) * (W * Matrix.conjTranspose W) =
          W * ((Matrix.conjTranspose W * W) * Matrix.conjTranspose W) := by
        rw [Matrix.mul_assoc, ← Matrix.mul_assoc
          (Matrix.conjTranspose W) W (Matrix.conjTranspose W)]
      _ = W * Matrix.conjTranspose W := by rw [hWiso, Matrix.one_mul]
  have hsupport' :
      J = ((W * Matrix.conjTranspose W) * (W * Matrix.conjTranspose W)) * J *
        ((W * Matrix.conjTranspose W) * (W * Matrix.conjTranspose W)) := by
    rw [hrangeId]
    exact hsupport
  calc
    J = ((W * Matrix.conjTranspose W) * (W * Matrix.conjTranspose W)) * J *
        ((W * Matrix.conjTranspose W) * (W * Matrix.conjTranspose W)) := hsupport'
    _ = (W * Matrix.conjTranspose W) * J *
        (W * Matrix.conjTranspose W) := by rw [hrangeId]
    _ = W * A * Matrix.conjTranspose W := by
      simp only [A, Matrix.mul_assoc]
    _ = W * (c • (1 : CMatrix x)) * Matrix.conjTranspose W := by rw [hAeq]
    _ = c • (W * Matrix.conjTranspose W) := by
      simp [Matrix.mul_smul, Matrix.smul_mul]

end

end EntanglementPurification
