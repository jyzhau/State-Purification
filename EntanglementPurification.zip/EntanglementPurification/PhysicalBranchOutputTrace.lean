import EntanglementPurification.PhysicalPPTCompression

/-!
# Physical output trace and Bob partial transpose

The physical branch index stores each local three-leg Choi space in the order
`(X₁ × X₂) × X'`.  Thus the two discarded output registers `A' B'` are not a
single outer product factor in `JointContractionPhysicalIndex`.  This module
first regroups the index into

`(((A₁A₂) × (B₁B₂)) × R) × (A' × B')`

and then applies `QIT.partialTraceB`.  For a bipartite resource `R_A × R_B`,
the remaining input/resource index is also regrouped along the Alice/Bob cut.
The main compatibility theorem says that tracing out `A' B'` after the full
physical Bob partial transpose is exactly the Bob partial transpose of the
output trace.  In particular, physical branchwise PPT implies positivity of
that output-trace partial transpose.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b r : Type*}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

/-- The input/resource index left after tracing out the two physical output
registers `A' B'`. -/
abbrev JointContractionInputResourceIndex (a b r : Type*) :=
  (((a × a) × (b × b)) × r)

/-- Regroup the physical branch index so that the two output registers form
the final product factor to which `QIT.partialTraceB` applies. -/
def jointPhysicalOutputGroupingEquiv :
    JointContractionPhysicalIndex a b r ≃
      (JointContractionInputResourceIndex a b r × (a × b)) where
  toFun p := (((p.1.1.1, p.1.2.1), p.2), (p.1.1.2, p.1.2.2))
  invFun p := (((p.1.1.1, p.2.1), (p.1.1.2, p.2.2)), p.1.2)
  left_inv _ := rfl
  right_inv _ := rfl

/-- The physical output trace `Tr_{A'B'}` of a branch matrix. -/
def physicalBranchOutputTrace
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    CMatrix (JointContractionInputResourceIndex a b r) :=
  QIT.partialTraceB
    ((Matrix.reindexAlgEquiv ℂ ℂ
      (jointPhysicalOutputGroupingEquiv (a := a) (b := b) (r := r))) K)

/-- Entrywise form of the physical output trace. -/
@[simp]
theorem physicalBranchOutputTrace_apply
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (iA kA : a × a) (iB kB : b × b) (u v : r) :
    physicalBranchOutputTrace K ((iA, iB), u) ((kA, kB), v) =
      ∑ aOut : a, ∑ bOut : b,
        K (((iA, aOut), (iB, bOut)), u)
          (((kA, aOut), (kB, bOut)), v) := by
  simp [physicalBranchOutputTrace, QIT.partialTraceB,
    Matrix.reindexAlgEquiv_apply, Matrix.reindex_apply,
    jointPhysicalOutputGroupingEquiv, Fintype.sum_prod_type]

/-- Tracing out `A' B'` preserves positive semidefiniteness. -/
theorem physicalBranchOutputTrace_posSemidef
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hK : K.PosSemidef) :
    (physicalBranchOutputTrace K).PosSemidef := by
  let e := jointPhysicalOutputGroupingEquiv (a := a) (b := b) (r := r)
  have hgrouped :
      ((Matrix.reindexAlgEquiv ℂ ℂ e) K).PosSemidef := by
    change (Matrix.reindex e e K).PosSemidef
    simpa [Matrix.reindex_apply, Matrix.submatrix_apply] using
      hK.submatrix e.symm
  exact QIT.partialTraceB_posSemidef hgrouped

variable {ra rb : Type*}
  [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]

/-- Regroup the input/resource index remaining after the output trace into the
physical Alice/Bob cut
`((A₁A₂) × R_A) × ((B₁B₂) × R_B)`. -/
def jointInputResourceBobGroupingEquiv :
    JointContractionInputResourceIndex a b (ra × rb) ≃
      (((a × a) × ra) × ((b × b) × rb)) where
  toFun p := ((p.1.1, p.2.1), (p.1.2, p.2.2))
  invFun p := ((p.1.1, p.2.1), (p.1.2, p.2.2))
  left_inv _ := rfl
  right_inv _ := rfl

/-- Bob partial transpose on the input/resource matrix remaining after
tracing out `A' B'`.  It transposes `B₁B₂B_r`. -/
def physicalBranchOutputPartialTransposeB
    (T : CMatrix (JointContractionInputResourceIndex a b (ra × rb))) :
    CMatrix (JointContractionInputResourceIndex a b (ra × rb)) :=
  (Matrix.reindexAlgEquiv ℂ ℂ
      (jointInputResourceBobGroupingEquiv
        (a := a) (b := b) (ra := ra) (rb := rb)).symm)
    (QIT.partialTransposeB
      ((Matrix.reindexAlgEquiv ℂ ℂ
        (jointInputResourceBobGroupingEquiv
          (a := a) (b := b) (ra := ra) (rb := rb))) T))

/-- Entrywise form of the Bob partial transpose after the output trace. -/
@[simp]
theorem physicalBranchOutputPartialTransposeB_apply
    (T : CMatrix (JointContractionInputResourceIndex a b (ra × rb)))
    (iA kA : a × a) (iB kB : b × b)
    (u w : ra) (v x : rb) :
    physicalBranchOutputPartialTransposeB T
        ((iA, iB), (u, v)) ((kA, kB), (w, x)) =
      T ((iA, kB), (u, x)) ((kA, iB), (w, v)) := by
  simp [physicalBranchOutputPartialTransposeB,
    Matrix.reindexAlgEquiv_apply, Matrix.reindex_apply,
    jointInputResourceBobGroupingEquiv]

/-- Tracing out `A' B'` commutes with the physical Bob partial transpose.
The transpose on the traced register `B'` disappears because that register is
summed on equal row and column indices. -/
theorem physicalBranchOutputTrace_physicalBranchPartialTransposeB
    (K : CMatrix (JointContractionPhysicalIndex a b (ra × rb))) :
    physicalBranchOutputTrace (physicalBranchPartialTransposeB K) =
      physicalBranchOutputPartialTransposeB (physicalBranchOutputTrace K) := by
  ext p q
  rcases p with ⟨⟨iA, iB⟩, ⟨u, v⟩⟩
  rcases q with ⟨⟨kA, kB⟩, ⟨w, x⟩⟩
  simp only [physicalBranchOutputTrace_apply,
    physicalBranchPartialTransposeB_apply,
    physicalBranchOutputPartialTransposeB_apply]

/-- A physical branch whose full Bob partial transpose is positive has a
positive output trace after partial transpose on the remaining Bob registers
`B₁B₂B_r`. -/
theorem physicalBranchOutputPartialTransposeB_posSemidef_of_physical
    {K : CMatrix (JointContractionPhysicalIndex a b (ra × rb))}
    (hKppt : (physicalBranchPartialTransposeB K).PosSemidef) :
    (physicalBranchOutputPartialTransposeB
      (physicalBranchOutputTrace K)).PosSemidef := by
  rw [← physicalBranchOutputTrace_physicalBranchPartialTransposeB]
  exact physicalBranchOutputTrace_posSemidef hKppt

end

end EntanglementPurification
