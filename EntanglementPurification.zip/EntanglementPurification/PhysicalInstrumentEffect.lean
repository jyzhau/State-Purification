import EntanglementPurification.PhysicalPPTInstrument
import EntanglementPurification.PhysicalOutputInstrumentEffect

/-!
# From an operational physical instrument to its compressed effect

This file removes the remaining matrix-level physicality premises from
`physicalOutputCompressedData`.  Positivity, physical PPT, and output-trace
completeness are supplied by the two branches of a `PhysicalPPTInstrument`.
Only success-branch symmetry and the three paper-specific optimality premises
remain explicit.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b ra rb : Type*}
  [Fintype a] [Fintype b] [Fintype ra] [Fintype rb]
  [DecidableEq a] [DecidableEq b] [DecidableEq ra] [DecidableEq rb]
  [Nonempty a] [Nonempty b]

/-- The canonical compressed data associated with a complete operational
two-outcome physical PPT instrument.

The success and failure matrices are exactly `M.success` and `M.failure`.
Their positivity, PPT properties, and output completeness are derived from
`M`; they are not additional hypotheses. -/
def physicalInstrumentCompressedData
    (d : ℕ) (hd : 2 ≤ d)
    (hcardA : Fintype.card a = d) (hcardB : Fintype.card b = d)
    (M : PhysicalPPTInstrument a b ra rb)
    (hSinvariant : JointContractionPhysicalInvariant M.success)
    (resource : PureVector (ra × rb))
    (hinserted :
      insertPureResourceBlock resource.amp
          (jointContractionSchurCoefficient M.success) =
        rankOneMatrix (localOptimalMultiplicityVector d))
    (hzeroPM :
      dotProduct (star resource.amp)
        ((outputTraceSectorCoefficient
          (physicalBranchOutputTrace M.success) sectorPM).mulVec
            resource.amp) = 0)
    (hzeroMP :
      dotProduct (star resource.amp)
        ((outputTraceSectorCoefficient
          (physicalBranchOutputTrace M.success) sectorMP).mulVec
            resource.amp) = 0) :
    CompressedPPTInstrumentData d ra rb := by
  subst d
  have hcardBge : 2 ≤ Fintype.card b := by
    simpa [hcardB] using hd
  have hSuccessPPT :
      (physicalBranchPartialTransposeB M.success).PosSemidef := by
    simpa [PhysicalPPTInstrument.success] using M.success_ppt
  have hFailurePPT :
      (physicalBranchPartialTransposeB M.failure).PosSemidef := by
    simpa [PhysicalPPTInstrument.failure] using M.failure_ppt
  exact physicalOutputCompressedData
    hd hcardBge hcardB resource hSinvariant
      M.success_posSemidef M.failure_posSemidef hSuccessPPT hFailurePPT
      M.outputTrace_success_add_failure_eq_one hinserted hzeroPM hzeroMP

/-- The auxiliary operator `N` canonically extracted from a complete physical
PPT instrument is an effect.  No positivity, PPT, or completeness property of
the branches is assumed separately. -/
theorem physicalInstrumentCompressedData_auxiliaryEffect_isEffect
    (d : ℕ) (hd : 2 ≤ d)
    (hcardA : Fintype.card a = d) (hcardB : Fintype.card b = d)
    (M : PhysicalPPTInstrument a b ra rb)
    (hSinvariant : JointContractionPhysicalInvariant M.success)
    (resource : PureVector (ra × rb))
    (hinserted :
      insertPureResourceBlock resource.amp
          (jointContractionSchurCoefficient M.success) =
        rankOneMatrix (localOptimalMultiplicityVector d))
    (hzeroPM :
      dotProduct (star resource.amp)
        ((outputTraceSectorCoefficient
          (physicalBranchOutputTrace M.success) sectorPM).mulVec
            resource.amp) = 0)
    (hzeroMP :
      dotProduct (star resource.amp)
        ((outputTraceSectorCoefficient
          (physicalBranchOutputTrace M.success) sectorMP).mulVec
            resource.amp) = 0) :
    IsEffectMatrix
      (physicalInstrumentCompressedData d hd hcardA hcardB M hSinvariant
        resource hinserted hzeroPM hzeroMP).auxiliaryEffect := by
  exact
    (physicalInstrumentCompressedData d hd hcardA hcardB M hSinvariant
      resource hinserted hzeroPM hzeroMP).auxiliaryEffect_isEffect hd

end

end EntanglementPurification
