import EntanglementPurification.PPTBlockOrder
import EntanglementPurification.ResourceProjection
import EntanglementPurification.EffectBounds

/-!
# Auxiliary effect extracted from compressed PPT data

This file formalizes the operator-order part of equations
eq:auxiliary_effect_definition--eq:auxiliary_effect_bounds in main.tex.
The two PPT quadratic tests that provide the final scalar bounds are layered on
top of this construction.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {r : Type*} [Fintype r] [DecidableEq r]

private theorem hermitian_sandwich_mono
    {A B P : CMatrix r} (hP : P.IsHermitian) (hAB : A ≤ B) :
    P * A * P ≤ P * B * P := by
  rw [Matrix.le_iff]
  have hpsd :
      (Matrix.conjTranspose P * (B - A) * P).PosSemidef :=
    (Matrix.le_iff.mp hAB).conjTranspose_mul_mul_same P
  have hdiff :
      P * B * P - P * A * P =
        Matrix.conjTranspose P * (B - A) * P := by
    rw [show Matrix.conjTranspose P = P by
      simpa [Matrix.IsHermitian] using hP]
    rw [Matrix.mul_sub, Matrix.sub_mul]
  rw [hdiff]
  exact hpsd

/-- The paper's Hermitian cross-block sum, compressed to `eta`'s orthogonal
complement and divided by the positive contraction factor. -/
def projectedNormalizedHermitianCross
    (eta : PureVector r) (t : ℝ) (C : CMatrix r) : CMatrix r :=
  (1 / t : ℝ) •
    (pureVectorPerpProjection eta *
      (C + Matrix.conjTranspose C) * pureVectorPerpProjection eta)

/-- Compression by `Pi_eta_perp`, followed by division by a positive scalar,
turns `-2t I ≤ C+Cᴴ ≤ 2t I` into equation
`eq:auxiliary_operator_bounds` for the normalized projected cross term. -/
theorem projectedNormalizedHermitianCross_order
    (eta : PureVector r) (t : ℝ) (ht : 0 < t) (C : CMatrix r)
    (hlo : (-2 * t : ℝ) • (1 : CMatrix r) ≤
      C + Matrix.conjTranspose C)
    (hhi : C + Matrix.conjTranspose C ≤
      (2 * t : ℝ) • (1 : CMatrix r)) :
    (-2 : ℝ) • (1 : CMatrix r) ≤
        projectedNormalizedHermitianCross eta t C ∧
      projectedNormalizedHermitianCross eta t C ≤
        (2 : ℝ) • (1 : CMatrix r) := by
  let P := pureVectorPerpProjection eta
  have hPherm : P.IsHermitian := pureVectorPerpProjection_isHermitian eta
  have hPle : P ≤ (1 : CMatrix r) := pureVectorPerpProjection_le_one eta
  have ht2 : 0 ≤ 2 * t := by positivity
  have hposP : (2 * t : ℝ) • P ≤ (2 * t : ℝ) • (1 : CMatrix r) :=
    cMatrix_real_smul_le_smul ht2 hPle
  have hnegP : (-2 * t : ℝ) • (1 : CMatrix r) ≤
      (-2 * t : ℝ) • P := by
    have h := neg_le_neg hposP
    simpa [neg_smul] using h
  have hloSandwich := hermitian_sandwich_mono hPherm hlo
  have hhiSandwich := hermitian_sandwich_mono hPherm hhi
  have hPid : P * P = P := pureVectorPerpProjection_idempotent eta
  have hloP : (-2 * t : ℝ) • P ≤
      P * (C + Matrix.conjTranspose C) * P := by
    simpa [Matrix.mul_smul, Matrix.smul_mul, hPid] using hloSandwich
  have hhiP : P * (C + Matrix.conjTranspose C) * P ≤
      (2 * t : ℝ) • P := by
    simpa [Matrix.mul_smul, Matrix.smul_mul, hPid] using hhiSandwich
  have hloFull : (-2 * t : ℝ) • (1 : CMatrix r) ≤
      P * (C + Matrix.conjTranspose C) * P := hnegP.trans hloP
  have hhiFull : P * (C + Matrix.conjTranspose C) * P ≤
      (2 * t : ℝ) • (1 : CMatrix r) := hhiP.trans hposP
  have hcancelPos : t⁻¹ * (2 * t) = (2 : ℝ) := by
    field_simp [ne_of_gt ht]
  have hcancelNeg : t⁻¹ * (-2 * t) = (-2 : ℝ) := by
    field_simp [ne_of_gt ht]
  constructor
  · have hscaled := cMatrix_real_smul_le_smul
      (show 0 ≤ (1 / t : ℝ) by positivity) hloFull
    simpa [projectedNormalizedHermitianCross, P, one_div, smul_smul,
      hcancelPos, hcancelNeg] using hscaled
  · have hscaled := cMatrix_real_smul_le_smul
      (show 0 ≤ (1 / t : ℝ) by positivity) hhiFull
    simpa [projectedNormalizedHermitianCross, P, one_div, smul_smul,
      hcancelPos] using hscaled

/-- A real multiple of the identity, kept explicit to avoid confusing real
Loewner scaling with arbitrary complex scalar multiplication. -/
def realScalarIdentity (c : ℝ) : CMatrix r :=
  c • (1 : CMatrix r)

/-- The paper's auxiliary effect, with A denoting the normalized projected
Hermitian cross-block sum. -/
def auxiliaryResourceEffect (Q A : CMatrix r) : CMatrix r :=
  (1 / 6 : ℝ) •
    (Q + (realScalarIdentity (r := r) 2 - A))

/-- The order interval 0 ≤ Q ≤ 2I and -2I ≤ A ≤ 2I is sufficient for the
auxiliary operator to be an effect. -/
theorem auxiliaryResourceEffect_isEffect
    {Q A : CMatrix r}
    (hQ0 : Q.PosSemidef)
    (hQ2 : Q ≤ realScalarIdentity (r := r) 2)
    (hAlo : realScalarIdentity (r := r) (-2) ≤ A)
    (hAhi : A ≤ realScalarIdentity (r := r) 2) :
    IsEffectMatrix (auxiliaryResourceEffect Q A) := by
  constructor
  · have htwoSubA :
        (realScalarIdentity (r := r) 2 - A).PosSemidef :=
      Matrix.le_iff.mp hAhi
    exact Matrix.PosSemidef.smul (hQ0.add htwoSubA)
      (by norm_num : (0 : ℝ) ≤ 1 / 6)
  · rw [Matrix.le_iff]
    have htwoSubQ :
        (realScalarIdentity (r := r) 2 - Q).PosSemidef :=
      Matrix.le_iff.mp hQ2
    have hAplusTwo :
        (A - realScalarIdentity (r := r) (-2)).PosSemidef :=
      Matrix.le_iff.mp hAlo
    have hsum := htwoSubQ.add hAplusTwo
    have hscaled :
        ((1 / 6 : ℝ) •
          ((realScalarIdentity (r := r) 2 - Q) +
            (A - realScalarIdentity (r := r) (-2)))).PosSemidef :=
      Matrix.PosSemidef.smul hsum
        (by norm_num : (0 : ℝ) ≤ 1 / 6)
    convert hscaled using 1
    ext i j
    simp [auxiliaryResourceEffect, realScalarIdentity, Matrix.one_apply]
    split_ifs <;> ring

/-- The auxiliary effect built directly from a positive four-sector success
block and its cross-sector trace budget `Q`. -/
def sectorPPTAuxiliaryResourceEffect
    (eta : PureVector r) (d : ℕ)
    (K : CMatrix (LocalMultiplicitySector × r)) (Q : CMatrix r) : CMatrix r :=
  auxiliaryResourceEffect Q
    (projectedNormalizedHermitianCross eta
      (localContractionAlpha d * localContractionBeta d)
      (resourceSectorBlock K sectorPP sectorMM))

/-- Equations `eq:auxiliary_operator_bounds`--`eq:auxiliary_effect_bounds`.
The cross-block order is derived from positivity of `K` and the two diagonal
trace bounds; together with `0 ≤ Q ≤ 2I`, it makes the displayed `N` an effect. -/
theorem sectorPPTAuxiliaryResourceEffect_isEffect
    (d : ℕ) (hd : 2 ≤ d) (eta : PureVector r)
    {K : CMatrix (LocalMultiplicitySector × r)} (hK : K.PosSemidef)
    (hPPupper : resourceSectorBlock K sectorPP sectorPP ≤
      (localContractionAlpha d) ^ 2 • (1 : CMatrix r))
    (hMMupper : resourceSectorBlock K sectorMM sectorMM ≤
      (localContractionBeta d) ^ 2 • (1 : CMatrix r))
    {Q : CMatrix r} (hQ0 : Q.PosSemidef)
    (hQ2 : Q ≤ realScalarIdentity (r := r) 2) :
    IsEffectMatrix (sectorPPTAuxiliaryResourceEffect eta d K Q) := by
  have halpha : 0 < localContractionAlpha d := by
    unfold localContractionAlpha
    positivity
  have hdR : (1 : ℝ) < (d : ℝ) := by exact_mod_cast hd
  have hbeta : 0 < localContractionBeta d := by
    unfold localContractionBeta
    positivity
  have ht :
      0 < localContractionAlpha d * localContractionBeta d :=
    mul_pos halpha hbeta
  have hcross := crossBlockHermitian_order K hK
    (localContractionAlpha d) (localContractionBeta d)
    halpha hbeta hPPupper hMMupper
  have hcrossLo :
      (-2 * (localContractionAlpha d * localContractionBeta d) : ℝ) •
          (1 : CMatrix r) ≤
        resourceSectorBlock K sectorPP sectorMM +
          Matrix.conjTranspose (resourceSectorBlock K sectorPP sectorMM) := by
    simpa [mul_assoc] using hcross.1
  have hcrossHi :
      resourceSectorBlock K sectorPP sectorMM +
          Matrix.conjTranspose (resourceSectorBlock K sectorPP sectorMM) ≤
        (2 * (localContractionAlpha d * localContractionBeta d) : ℝ) •
          (1 : CMatrix r) := by
    simpa [mul_assoc] using hcross.2
  have hA := projectedNormalizedHermitianCross_order eta
    (localContractionAlpha d * localContractionBeta d) ht
    (resourceSectorBlock K sectorPP sectorMM) hcrossLo hcrossHi
  exact auxiliaryResourceEffect_isEffect hQ0 hQ2 hA.1 hA.2

end

end EntanglementPurification
