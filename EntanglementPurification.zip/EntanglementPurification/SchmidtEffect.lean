import EntanglementPurification.EffectBounds
import EntanglementPurification.FiniteMajorization
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Tactic

/-!
# Schmidt resource projection and its two-vector Gram data

The finite type Fin (m + 2) labels the diagonal Schmidt kets |jj>.  Thus this
is the diagonal subspace of the full bipartite resource space; all off-diagonal
coordinates are zero.  Zero probabilities are allowed, so a smaller
finite-Schmidt-rank vector embeds by appending zero-probability coordinates.
-/

namespace EntanglementPurification

noncomputable section

/-- A finite probability vector with two distinguished leading coordinates.
No ordering hypothesis is needed for the Gram identities. -/
structure FiniteSchmidtData (m : ℕ) where
  probability : Fin (m + 2) → ℝ
  probability_nonneg : ∀ j, 0 ≤ probability j
  probability_sum : ∑ j, probability j = 1

namespace FiniteSchmidtData

variable {m : ℕ}

/-- The complex Hilbert space spanned by the diagonal kets |jj>. -/
abbrev Space (m : ℕ) := EuclideanSpace ℂ (Fin (m + 2))

/-- The leading Schmidt probability. -/
def p0 (data : FiniteSchmidtData m) : ℝ :=
  data.probability 0

/-- The second Schmidt probability. -/
def p1 (data : FiniteSchmidtData m) : ℝ :=
  data.probability 1

/-- The paper's phase convention: the 0-coordinate is positive and every
remaining Schmidt amplitude carries a minus sign. -/
def eta (data : FiniteSchmidtData m) : Space m :=
  WithLp.toLp 2 fun j =>
    if j = 0 then (Real.sqrt (data.probability j) : ℂ)
    else -(Real.sqrt (data.probability j) : ℂ)

/-- The standard diagonal ket |jj>. -/
def ket (j : Fin (m + 2)) : Space m :=
  PiLp.single 2 j 1

/-- The ket |00>. -/
def ket0 : Space m :=
  ket 0

/-- The ket |11>. -/
def ket1 : Space m :=
  ket 1

@[simp]
theorem eta_apply (data : FiniteSchmidtData m) (j : Fin (m + 2)) :
    data.eta j =
      if j = 0 then (Real.sqrt (data.probability j) : ℂ)
      else -(Real.sqrt (data.probability j) : ℂ) := by
  rfl

@[simp]
theorem ket_apply (j k : Fin (m + 2)) :
    ket j k = if k = j then 1 else 0 := by
  simp [ket]

/-- The signed Schmidt resource vector has unit squared norm. -/
theorem eta_normSq (data : FiniteSchmidtData m) :
    ‖data.eta‖ ^ 2 = 1 := by
  rw [EuclideanSpace.norm_sq_eq]
  rw [← data.probability_sum]
  apply Finset.sum_congr rfl
  intro j _
  by_cases hj : j = 0
  · simp [eta, hj, Real.norm_eq_abs, abs_of_nonneg (Real.sqrt_nonneg _)]
    exact Real.sq_sqrt (data.probability_nonneg 0)
  · simp [eta, hj, Real.norm_eq_abs, abs_of_nonneg (Real.sqrt_nonneg _),
      Real.sq_sqrt (data.probability_nonneg j)]

/-- Unit-inner-product form of eta_normSq. -/
theorem inner_eta_eta (data : FiniteSchmidtData m) :
    inner ℂ data.eta data.eta = 1 := by
  rw [inner_self_eq_norm_sq_to_K]
  have h :=
    congrArg (fun t : ℝ => (t : ℂ)) data.eta_normSq
  simpa using h

/-- Overlap of eta with |00>. -/
theorem inner_eta_ket0 (data : FiniteSchmidtData m) :
    inner ℂ data.eta ket0 = (Real.sqrt data.p0 : ℂ) := by
  rw [PiLp.inner_apply]
  simp [ket0, ket, eta, p0]

/-- The minus phase makes the overlap with |11> negative. -/
theorem inner_eta_ket1 (data : FiniteSchmidtData m) :
    inner ℂ data.eta ket1 = -(Real.sqrt data.p1 : ℂ) := by
  rw [PiLp.inner_apply]
  simp [ket1, ket, eta, p1]

/-- The explicit orthogonal-complement projection
Pi = I - |eta><eta|. -/
def etaPerpProjection (data : FiniteSchmidtData m) (u : Space m) : Space m :=
  u - (inner ℂ data.eta u) • data.eta

/-- Pi sends every vector to one orthogonal to eta. -/
theorem inner_eta_etaPerpProjection
    (data : FiniteSchmidtData m) (u : Space m) :
    inner ℂ data.eta (data.etaPerpProjection u) = 0 := by
  rw [etaPerpProjection, inner_sub_right, inner_smul_right,
    data.inner_eta_eta]
  ring

/-- The explicit map Pi is idempotent. -/
theorem etaPerpProjection_idempotent
    (data : FiniteSchmidtData m) (u : Space m) :
    data.etaPerpProjection (data.etaPerpProjection u) =
      data.etaPerpProjection u := by
  change data.etaPerpProjection u -
      (inner ℂ data.eta (data.etaPerpProjection u)) • data.eta =
    data.etaPerpProjection u
  rw [data.inner_eta_etaPerpProjection, zero_smul, sub_zero]

/-- The projected vector v0 = Pi |00>. -/
def v0 (data : FiniteSchmidtData m) : Space m :=
  data.etaPerpProjection ket0

/-- The projected vector v1 = Pi |11>. -/
def v1 (data : FiniteSchmidtData m) : Space m :=
  data.etaPerpProjection ket1

/-- Expansion of v0 in terms of eta and |00>. -/
theorem v0_eq (data : FiniteSchmidtData m) :
    data.v0 = ket0 - (Real.sqrt data.p0 : ℂ) • data.eta := by
  rw [v0, etaPerpProjection, data.inner_eta_ket0]

/-- Expansion of v1; the paper's minus phase turns this into a plus sign. -/
theorem v1_eq (data : FiniteSchmidtData m) :
    data.v1 = ket1 + (Real.sqrt data.p1 : ℂ) • data.eta := by
  rw [v1, etaPerpProjection, data.inner_eta_ket1]
  simp

/-- Gram formula for two vectors after applying Pi. -/
theorem inner_etaPerpProjection
    (data : FiniteSchmidtData m) (u v : Space m) :
    inner ℂ (data.etaPerpProjection u) (data.etaPerpProjection v) =
      inner ℂ u v -
        star (inner ℂ data.eta u) * inner ℂ data.eta v := by
  simp only [etaPerpProjection, inner_sub_left, inner_sub_right,
    inner_smul_left, inner_smul_right, starRingEnd_apply]
  rw [data.inner_eta_eta]
  rw [← inner_conj_symm data.eta u]
  simp

/-- Exact complex Gram entry for v0. -/
theorem inner_v0_v0 (data : FiniteSchmidtData m) :
    inner ℂ data.v0 data.v0 = ((1 - data.p0 : ℝ) : ℂ) := by
  rw [v0, data.inner_etaPerpProjection, data.inner_eta_ket0]
  simp [ket0, ket, p0]
  norm_cast
  exact Real.mul_self_sqrt (data.probability_nonneg 0)

/-- Exact complex Gram entry for v1. -/
theorem inner_v1_v1 (data : FiniteSchmidtData m) :
    inner ℂ data.v1 data.v1 = ((1 - data.p1 : ℝ) : ℂ) := by
  rw [v1, data.inner_etaPerpProjection, data.inner_eta_ket1]
  simp [ket1, ket, p1]
  norm_cast
  exact Real.mul_self_sqrt (data.probability_nonneg 1)

/-- The paper's phase convention makes the off-diagonal Gram entry
positive. -/
theorem inner_v0_v1 (data : FiniteSchmidtData m) :
    inner ℂ data.v0 data.v1 =
      (Real.sqrt (data.p0 * data.p1) : ℂ) := by
  rw [v0, v1, data.inner_etaPerpProjection,
    data.inner_eta_ket0, data.inner_eta_ket1]
  have hp0 : 0 ≤ data.p0 := data.probability_nonneg 0
  rw [Real.sqrt_mul hp0]
  simp [ket0, ket1, ket, PiLp.inner_apply]

/-- Squared norm of v0, equation (abstract_projected_gram_data). -/
theorem v0_normSq (data : FiniteSchmidtData m) :
    ‖data.v0‖ ^ 2 = 1 - data.p0 := by
  calc
    ‖data.v0‖ ^ 2 =
        RCLike.re (inner ℂ data.v0 data.v0) :=
      (inner_self_eq_norm_sq (𝕜 := ℂ) data.v0).symm
    _ = 1 - data.p0 := by rw [data.inner_v0_v0]; simp

/-- Squared norm of v1, equation (abstract_projected_gram_data). -/
theorem v1_normSq (data : FiniteSchmidtData m) :
    ‖data.v1‖ ^ 2 = 1 - data.p1 := by
  calc
    ‖data.v1‖ ^ 2 =
        RCLike.re (inner ℂ data.v1 data.v1) :=
      (inner_self_eq_norm_sq (𝕜 := ℂ) data.v1).symm
    _ = 1 - data.p1 := by rw [data.inner_v1_v1]; simp

/-- Real part of the off-diagonal projected Gram entry. -/
theorem re_inner_v0_v1 (data : FiniteSchmidtData m) :
    RCLike.re (inner ℂ data.v0 data.v1) =
      Real.sqrt (data.p0 * data.p1) := by
  rw [data.inner_v0_v1]
  simp

/-- Gram--Schmidt coefficient of v0 in v1. -/
def residualCoefficient (data : FiniteSchmidtData m) : ℝ :=
  Real.sqrt (data.p0 * data.p1) / (1 - data.p0)

/-- The component of v1 orthogonal to v0. -/
def residual (data : FiniteSchmidtData m) : Space m :=
  data.v1 - (data.residualCoefficient : ℂ) • data.v0

/-- The residual is orthogonal to v0 whenever p0 < 1, so its coefficient
has a nonzero denominator. -/
theorem inner_v0_residual
    (data : FiniteSchmidtData m) (hp0 : data.p0 < 1) :
    inner ℂ data.v0 data.residual = 0 := by
  have hden : 1 - data.p0 ≠ 0 :=
    ne_of_gt (sub_pos.mpr hp0)
  rw [residual, inner_sub_right, inner_smul_right,
    data.inner_v0_v1, data.inner_v0_v0]
  unfold residualCoefficient
  norm_cast
  field_simp [hden]
  ring

/-- The squared norm contributed by the v0 component of v1. -/
theorem residualCoefficient_normSq
    (data : FiniteSchmidtData m) (hp0 : data.p0 < 1) :
    data.residualCoefficient ^ 2 * (1 - data.p0) =
      data.p0 * data.p1 / (1 - data.p0) := by
  have hden : 1 - data.p0 ≠ 0 :=
    ne_of_gt (sub_pos.mpr hp0)
  have hproduct : 0 ≤ data.p0 * data.p1 :=
    mul_nonneg (data.probability_nonneg 0)
      (data.probability_nonneg 1)
  unfold residualCoefficient
  field_simp [hden]
  nlinarith [Real.sq_sqrt hproduct]

/-- First form of the residual norm formula from the paper. -/
theorem residual_normSq
    (data : FiniteSchmidtData m) (hp0 : data.p0 < 1) :
    ‖data.residual‖ ^ 2 =
      1 - data.p1 - data.p0 * data.p1 / (1 - data.p0) := by
  have horth :
      inner ℂ ((data.residualCoefficient : ℂ) • data.v0)
        data.residual = 0 := by
    rw [inner_smul_left, data.inner_v0_residual hp0]
    simp
  have hdecomp :
      (data.residualCoefficient : ℂ) • data.v0 + data.residual =
        data.v1 := by
    simp [residual]
  have hscaled :
      ‖(data.residualCoefficient : ℂ) • data.v0‖ ^ 2 =
        data.p0 * data.p1 / (1 - data.p0) := by
    rw [norm_smul, mul_pow, data.v0_normSq]
    simp only [Complex.norm_real, Real.norm_eq_abs, sq_abs]
    exact data.residualCoefficient_normSq hp0
  have hpyth :=
    norm_add_sq_eq_norm_sq_add_norm_sq_of_inner_eq_zero
      ((data.residualCoefficient : ℂ) • data.v0) data.residual horth
  rw [hdecomp] at hpyth
  have hpythPow :
      ‖data.v1‖ ^ 2 =
        ‖(data.residualCoefficient : ℂ) • data.v0‖ ^ 2 +
          ‖data.residual‖ ^ 2 := by
    simpa only [pow_two] using hpyth
  rw [data.v1_normSq, hscaled] at hpythPow
  linarith

/-- Sum of all zero-padded Schmidt probabilities after p0 and p1. -/
def tailMass (data : FiniteSchmidtData m) : ℝ :=
  ∑ j ∈ (Finset.univ.erase (0 : Fin (m + 2))).erase
    (1 : Fin (m + 2)), data.probability j

/-- The finite tail sum is 1 - p0 - p1. -/
theorem tailMass_eq_one_sub (data : FiniteSchmidtData m) :
    data.tailMass = 1 - data.p0 - data.p1 := by
  have hzero :
      (∑ j ∈ Finset.univ.erase (0 : Fin (m + 2)),
        data.probability j) + data.p0 = 1 := by
    rw [p0, ← data.probability_sum]
    exact Finset.sum_erase_add _ _ (Finset.mem_univ 0)
  have honeMem :
      (1 : Fin (m + 2)) ∈
        Finset.univ.erase (0 : Fin (m + 2)) := by
    simp
  have hone :
      data.tailMass + data.p1 =
        ∑ j ∈ Finset.univ.erase (0 : Fin (m + 2)),
          data.probability j := by
    rw [tailMass, p1]
    exact Finset.sum_erase_add _ _ honeMem
  linarith

/-- Paper form of the residual norm: the tail mass divided by 1 - p0. -/
theorem residual_normSq_eq_tailMass_div
    (data : FiniteSchmidtData m) (hp0 : data.p0 < 1) :
    ‖data.residual‖ ^ 2 =
      data.tailMass / (1 - data.p0) := by
  rw [data.residual_normSq hp0, data.tailMass_eq_one_sub]
  have hden : 1 - data.p0 ≠ 0 :=
    ne_of_gt (sub_pos.mpr hp0)
  field_simp [hden]
  ring

/-- Finset and List.ofFn compute the same finite sum. -/
theorem sum_univ_eq_sum_ofFn
    {n : ℕ} (p : Fin n → ℝ) :
    (∑ j, p j) = (List.ofFn p).sum := by
  induction n with
  | zero =>
      simp
  | succ n ih =>
      rw [Fin.sum_univ_succ, List.ofFn_succ, List.sum_cons]
      exact congrArg (fun x : ℝ => p 0 + x)
        (ih (fun j => p j.succ))

/-- An ordered probability vector in the converse supplies Schmidt data
directly. -/
def ofOrderedProbability
    {k : ℕ} (p : Fin (k + 2) → ℝ) (hp : IsOrderedProbability p) :
    FiniteSchmidtData k where
  probability := p
  probability_nonneg := hp.2.1
  probability_sum :=
    (sum_univ_eq_sum_ofFn p).trans hp.2.2

/-- For the Fin (m+3) shape used by the converse, the explicit Finset tail
agrees with FiniteMajorization.tailFromTwo. -/
theorem tailMass_eq_tailFromTwo
    (data : FiniteSchmidtData (m + 1)) :
    data.tailMass = tailFromTwo data.probability := by
  have hsplit := prefix_two_add_tail data.probability
  have hlistSum :
      (List.ofFn data.probability).sum = 1 :=
    (sum_univ_eq_sum_ofFn data.probability).symm.trans
      data.probability_sum
  rw [orderedPrefixSum_two_three, hlistSum] at hsplit
  rw [data.tailMass_eq_one_sub, p0, p1]
  linarith

/-- Raw coordinates of a diagonal-space vector, for direct use by
EffectBounds. -/
def coordinates (u : Space m) : Fin (m + 2) → ℂ :=
  fun j => u j

@[simp]
theorem coordinates_apply (u : Space m) (j : Fin (m + 2)) :
    coordinates u j = u j := rfl

/-- Wrapping raw coordinates recovers the original Euclidean-space vector. -/
theorem toLp_coordinates (u : Space m) :
    (WithLp.toLp 2 (coordinates u) : Space m) = u := by
  rfl

/-- Raw coordinate vector corresponding to v0. -/
def v0Coordinates (data : FiniteSchmidtData m) : Fin (m + 2) → ℂ :=
  coordinates data.v0

/-- Raw coordinate vector corresponding to v1. -/
def v1Coordinates (data : FiniteSchmidtData m) : Fin (m + 2) → ℂ :=
  coordinates data.v1

/-- Raw coordinate vector corresponding to the orthogonal residual. -/
def residualCoordinates
    (data : FiniteSchmidtData m) : Fin (m + 2) → ℂ :=
  coordinates data.residual

/-- Coordinate inner product agrees with the real part of the Hilbert-space
inner product. -/
theorem cVecInnerRe_coordinates (u v : Space m) :
    cVecInnerRe (coordinates u) (coordinates v) =
      RCLike.re (inner ℂ u v) := by
  unfold cVecInnerRe coordinates
  change
    (star (fun j => u j) ⬝ᵥ (fun j => v j)).re =
      ((fun j => v j) ⬝ᵥ star (fun j => u j)).re
  rw [dotProduct_comm]

/-- Raw-function norm identity for v0. -/
theorem cVecNormSq_v0Coordinates (data : FiniteSchmidtData m) :
    cVecNormSq data.v0Coordinates = 1 - data.p0 := by
  rw [cVecNormSq_eq_norm_toLp_sq]
  change ‖data.v0‖ ^ 2 = 1 - data.p0
  exact data.v0_normSq

/-- Raw-function norm identity for v1. -/
theorem cVecNormSq_v1Coordinates (data : FiniteSchmidtData m) :
    cVecNormSq data.v1Coordinates = 1 - data.p1 := by
  rw [cVecNormSq_eq_norm_toLp_sq]
  change ‖data.v1‖ ^ 2 = 1 - data.p1
  exact data.v1_normSq

/-- Raw-function cross Gram identity. -/
theorem cVecInnerRe_v0Coordinates_v1Coordinates
    (data : FiniteSchmidtData m) :
    cVecInnerRe data.v0Coordinates data.v1Coordinates =
      Real.sqrt (data.p0 * data.p1) := by
  change cVecInnerRe (coordinates data.v0) (coordinates data.v1) =
    Real.sqrt (data.p0 * data.p1)
  rw [cVecInnerRe_coordinates]
  exact data.re_inner_v0_v1

/-- Gram--Schmidt decomposition in the Hilbert-space representation. -/
theorem v1_decomposition (data : FiniteSchmidtData m) :
    data.v1 =
      (data.residualCoefficient : ℂ) • data.v0 + data.residual := by
  simp [residual]

/-- Gram--Schmidt decomposition in the raw-function representation consumed
by SchmidtConverse. -/
theorem v1Coordinates_decomposition (data : FiniteSchmidtData m) :
    data.v1Coordinates =
      (data.residualCoefficient : ℂ) • data.v0Coordinates +
        data.residualCoordinates := by
  ext j
  exact congrArg (fun u : Space m => u j) data.v1_decomposition

/-- The raw decomposition with the coefficient expanded exactly as it appears
in SchmidtConverse. -/
theorem v1Coordinates_decomposition_explicit
    (data : FiniteSchmidtData m) :
    data.v1Coordinates =
      ((Real.sqrt (data.p0 * data.p1) / (1 - data.p0) : ℝ) : ℂ) •
        data.v0Coordinates + data.residualCoordinates := by
  simpa [residualCoefficient] using data.v1Coordinates_decomposition

/-- Raw-function orthogonality of v0 and the residual. -/
theorem cVecInnerRe_v0Coordinates_residualCoordinates
    (data : FiniteSchmidtData m) (hp0 : data.p0 < 1) :
    cVecInnerRe data.v0Coordinates data.residualCoordinates = 0 := by
  change cVecInnerRe (coordinates data.v0) (coordinates data.residual) = 0
  rw [cVecInnerRe_coordinates, data.inner_v0_residual hp0]
  simp

/-- Raw-function residual norm with the explicit Finset tail. -/
theorem cVecNormSq_residualCoordinates
    (data : FiniteSchmidtData m) (hp0 : data.p0 < 1) :
    cVecNormSq data.residualCoordinates =
      data.tailMass / (1 - data.p0) := by
  rw [cVecNormSq_eq_norm_toLp_sq]
  change ‖data.residual‖ ^ 2 =
    data.tailMass / (1 - data.p0)
  exact data.residual_normSq_eq_tailMass_div hp0

/-- Raw-function residual norm in exactly the tailFromTwo form required by
SchmidtConverse. -/
theorem cVecNormSq_residualCoordinates_eq_tailFromTwo
    (data : FiniteSchmidtData (m + 1)) (hp0 : data.p0 < 1) :
    cVecNormSq data.residualCoordinates =
      tailFromTwo data.probability / (1 - data.p0) := by
  rw [data.cVecNormSq_residualCoordinates hp0,
    data.tailMass_eq_tailFromTwo]

/-- A single ready-to-use package of the four raw-function hypotheses needed
by SchmidtConverse. -/
theorem orderedProbability_rawGramData
    {p : Fin (m + 3) → ℝ}
    (hp : IsOrderedProbability p) (hp0 : p 0 < 1) :
    let data : FiniteSchmidtData (m + 1) :=
      ofOrderedProbability p hp
    cVecNormSq data.v0Coordinates = 1 - p 0 ∧
      data.v1Coordinates =
        ((Real.sqrt (p 0 * p 1) / (1 - p 0) : ℝ) : ℂ) •
          data.v0Coordinates + data.residualCoordinates ∧
      cVecInnerRe data.v0Coordinates data.residualCoordinates = 0 ∧
      cVecNormSq data.residualCoordinates =
        tailFromTwo p / (1 - p 0) := by
  let data : FiniteSchmidtData (m + 1) :=
    ofOrderedProbability p hp
  change cVecNormSq data.v0Coordinates = 1 - p 0 ∧
    data.v1Coordinates =
      ((Real.sqrt (p 0 * p 1) / (1 - p 0) : ℝ) : ℂ) •
        data.v0Coordinates + data.residualCoordinates ∧
    cVecInnerRe data.v0Coordinates data.residualCoordinates = 0 ∧
    cVecNormSq data.residualCoordinates =
      tailFromTwo p / (1 - p 0)
  have hp0Data : data.p0 < 1 := by
    simpa [data, p0, ofOrderedProbability] using hp0
  refine ⟨?_, ?_, ?_, ?_⟩
  · simpa [data, p0, ofOrderedProbability] using
      data.cVecNormSq_v0Coordinates
  · simpa [data, p0, p1, ofOrderedProbability] using
      data.v1Coordinates_decomposition_explicit
  · exact data.cVecInnerRe_v0Coordinates_residualCoordinates hp0Data
  · simpa [data, p0, ofOrderedProbability] using
      data.cVecNormSq_residualCoordinates_eq_tailFromTwo hp0Data

end FiniteSchmidtData

end

end EntanglementPurification
