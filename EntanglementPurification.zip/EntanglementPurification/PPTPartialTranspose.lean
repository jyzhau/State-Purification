import EntanglementPurification.PPTSectorBlocks

/-!
# Bob-side partial transpose for compressed sector/resource matrices

The compressed index is initially written as

  (Alice parity, Bob parity) x (Alice resource, Bob resource).

The physical bipartition instead groups Alice's two coordinates and Bob's two
coordinates.  This file records that reindexing explicitly before applying the
QIT partial transpose.  It is intentionally separate from the full resource
transpose used by pure-resource insertion.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {ra rb : Type*}

/-- Regroup multiplicity and resource coordinates according to the physical
Alice/Bob cut. -/
def sectorResourceGroupingEquiv :
    (LocalMultiplicitySector × (ra × rb)) ≃
      ((LocalParity × ra) × (LocalParity × rb)) where
  toFun p := ((p.1.1, p.2.1), (p.1.2, p.2.2))
  invFun p := ((p.1.1, p.2.1), (p.1.2, p.2.2))
  left_inv _ := rfl
  right_inv _ := rfl

variable [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]

/-- Bob-side partial transpose on both the Bob multiplicity coordinate and the
Bob resource coordinate. -/
def sectorResourcePartialTransposeB
    (K : CMatrix (LocalMultiplicitySector × (ra × rb))) :
    CMatrix (LocalMultiplicitySector × (ra × rb)) :=
  (Matrix.reindexAlgEquiv ℂ ℂ
      (sectorResourceGroupingEquiv (ra := ra) (rb := rb)).symm)
    (QIT.partialTransposeB
      ((Matrix.reindexAlgEquiv ℂ ℂ
          (sectorResourceGroupingEquiv (ra := ra) (rb := rb))) K))

/-- Entrywise form of the compressed Bob-side partial transpose. -/
@[simp]
theorem sectorResourcePartialTransposeB_apply
    (K : CMatrix (LocalMultiplicitySector × (ra × rb)))
    (sA sB tA tB : LocalParity) (a c : ra) (b d : rb) :
    sectorResourcePartialTransposeB K
        ((sA, sB), (a, b)) ((tA, tB), (c, d)) =
      K ((sA, tB), (a, d)) ((tA, sB), (c, b)) := by
  simp [sectorResourcePartialTransposeB, Matrix.reindexAlgEquiv_apply,
    Matrix.reindex_apply, sectorResourceGroupingEquiv]

/-- Applying the same Bob-side partial transpose twice restores the matrix. -/
@[simp]
theorem sectorResourcePartialTransposeB_involutive
    (K : CMatrix (LocalMultiplicitySector × (ra × rb))) :
    sectorResourcePartialTransposeB (sectorResourcePartialTransposeB K) = K := by
  ext p q
  rcases p with ⟨⟨sA, sB⟩, ⟨a, b⟩⟩
  rcases q with ⟨⟨tA, tB⟩, ⟨c, d⟩⟩
  simp

/-- At the block level the multiplicity Bob indices are exchanged, while the
corresponding resource block is partially transposed on Bob. -/
theorem resourceSectorBlock_sectorResourcePartialTransposeB
    (K : CMatrix (LocalMultiplicitySector × (ra × rb)))
    (sA sB tA tB : LocalParity) :
    resourceSectorBlock (sectorResourcePartialTransposeB K)
        (sA, tB) (tA, sB) =
      QIT.partialTransposeB
        (resourceSectorBlock K (sA, sB) (tA, tB)) := by
  ext p q
  rcases p with ⟨a, b⟩
  rcases q with ⟨c, d⟩
  simp [resourceSectorBlock]

/-- The Bob-side PPT constraint for an unnormalized branch matrix. -/
def HasBobPPTConstraint
    (K : CMatrix (LocalMultiplicitySector × (ra × rb))) : Prop :=
  (sectorResourcePartialTransposeB K).PosSemidef

/-- Matrix-level branchwise PPT: positivity of the branch itself together with
positivity after Bob-side partial transpose.  Unlike QIT.IsPPT, this predicate
does not assume trace-one normalization. -/
def BranchPPT
    (K : CMatrix (LocalMultiplicitySector × (ra × rb))) : Prop :=
  K.PosSemidef ∧ HasBobPPTConstraint K

end

end EntanglementPurification
