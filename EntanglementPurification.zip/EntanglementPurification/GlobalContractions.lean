import QIT.Core.Map
import Mathlib.Tactic

/-!
# Three-leg contractions in the global CPTN calculation

The input index is x × x, the output index is x, and the complete
input-first Choi index is therefore (x × x) × x.  This file gives explicit
finite-coordinate matrices for the two contractions used in the global SDP
proof and develops their Gram matrices and normalized range projections.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

/-- The physical three-leg index: two input copies followed by the output. -/
abbrev GlobalThreeLeg (x : Type*) := (x × x) × x

/-- Paper contraction Gamma_1, characterized by
Gamma_1 |a> = sum_i |i,a,i>. -/
def globalGamma1
    {x : Type*} [DecidableEq x] :
    Matrix (GlobalThreeLeg x) x ℂ :=
  fun p a =>
    if p.1.1 = p.2 then
      if p.1.2 = a then 1 else 0
    else 0

/-- Paper contraction Gamma_2, characterized by
Gamma_2 |a> = sum_i |a,i,i>. -/
def globalGamma2
    {x : Type*} [DecidableEq x] :
    Matrix (GlobalThreeLeg x) x ℂ :=
  fun p a =>
    if p.1.2 = p.2 then
      if p.1.1 = a then 1 else 0
    else 0

private theorem global_cross_delta_sum
    {x : Type*} [Fintype x] [DecidableEq x] (a b : x) :
    (∑ i : x,
      star (if b = i then if i = a then (1 : ℂ) else 0 else 0)) =
        if a = b then 1 else 0 := by
  by_cases hab : a = b
  · subst b
    rw [if_pos rfl, Fintype.sum_eq_single a]
    · simp
    · intro i hia
      simp [Ne.symm hia]
  · have hba : b ≠ a := Ne.symm hab
    rw [if_neg hab]
    exact Fintype.sum_eq_zero _ fun i => by
      by_cases hbi : b = i
      · subst i
        simp [hba]
      · simp [hbi]

/-- The first contraction has Gram matrix D I. -/
theorem globalGamma1_conjTranspose_mul_self
    {x : Type*} [Fintype x] [DecidableEq x] :
    Matrix.conjTranspose (globalGamma1 (x := x)) * globalGamma1 =
      (Fintype.card x : ℂ) • (1 : CMatrix x) := by
  ext a b
  by_cases h : a = b
  · subst b
    simp [Matrix.mul_apply, globalGamma1, Fintype.sum_prod_type]
  · have hba : b ≠ a := Ne.symm h
    simp [Matrix.mul_apply, globalGamma1, Fintype.sum_prod_type,
      h, hba]

/-- The second contraction has Gram matrix D I. -/
theorem globalGamma2_conjTranspose_mul_self
    {x : Type*} [Fintype x] [DecidableEq x] :
    Matrix.conjTranspose (globalGamma2 (x := x)) * globalGamma2 =
      (Fintype.card x : ℂ) • (1 : CMatrix x) := by
  ext a b
  by_cases h : a = b
  · subst b
    simp [Matrix.mul_apply, globalGamma2, Fintype.sum_prod_type]
  · have hba : b ≠ a := Ne.symm h
    simp [Matrix.mul_apply, globalGamma2, Fintype.sum_prod_type,
      h, hba]

/-- The first cross Gram matrix is the identity. -/
theorem globalGamma1_conjTranspose_mul_globalGamma2
    {x : Type*} [Fintype x] [DecidableEq x] :
    Matrix.conjTranspose (globalGamma1 (x := x)) * globalGamma2 =
      (1 : CMatrix x) := by
  ext a b
  simp [Matrix.mul_apply, globalGamma1, globalGamma2,
    Fintype.sum_prod_type]
  exact global_cross_delta_sum a b

/-- The reverse cross Gram matrix is the identity. -/
theorem globalGamma2_conjTranspose_mul_globalGamma1
    {x : Type*} [Fintype x] [DecidableEq x] :
    Matrix.conjTranspose (globalGamma2 (x := x)) * globalGamma1 =
      (1 : CMatrix x) := by
  ext a b
  simp [Matrix.mul_apply, globalGamma1, globalGamma2,
    Fintype.sum_prod_type]
  exact global_cross_delta_sum a b

/-- Unnormalized even-parity contraction Gamma_1 + Gamma_2. -/
def globalGammaPlus
    {x : Type*} [DecidableEq x] :
    Matrix (GlobalThreeLeg x) x ℂ :=
  globalGamma1 + globalGamma2

/-- Unnormalized odd-parity contraction Gamma_2 - Gamma_1. -/
def globalGammaMinus
    {x : Type*} [DecidableEq x] :
    Matrix (GlobalThreeLeg x) x ℂ :=
  globalGamma2 - globalGamma1

/-- Gram matrix of the unnormalized even-parity contraction. -/
theorem globalGammaPlus_conjTranspose_mul_self
    {x : Type*} [Fintype x] [DecidableEq x] :
    Matrix.conjTranspose (globalGammaPlus (x := x)) * globalGammaPlus =
      (2 * ((Fintype.card x : ℂ) + 1)) • (1 : CMatrix x) := by
  simp only [globalGammaPlus, Matrix.conjTranspose_add, Matrix.add_mul,
    Matrix.mul_add]
  rw [
    globalGamma1_conjTranspose_mul_self,
    globalGamma1_conjTranspose_mul_globalGamma2,
    globalGamma2_conjTranspose_mul_globalGamma1,
    globalGamma2_conjTranspose_mul_self]
  ext a b
  by_cases h : a = b
  · subst b
    simp
    ring
  · simp [h]

/-- Gram matrix of the unnormalized odd-parity contraction. -/
theorem globalGammaMinus_conjTranspose_mul_self
    {x : Type*} [Fintype x] [DecidableEq x] :
    Matrix.conjTranspose (globalGammaMinus (x := x)) * globalGammaMinus =
      (2 * ((Fintype.card x : ℂ) - 1)) • (1 : CMatrix x) := by
  simp only [globalGammaMinus, Matrix.conjTranspose_sub, Matrix.sub_mul,
    Matrix.mul_sub]
  rw [
    globalGamma2_conjTranspose_mul_self,
    globalGamma2_conjTranspose_mul_globalGamma1,
    globalGamma1_conjTranspose_mul_globalGamma2,
    globalGamma1_conjTranspose_mul_self]
  ext a b
  by_cases h : a = b
  · subst b
    simp
    ring
  · simp [h]

/-- The unnormalized even and odd contractions have zero cross Gram
matrix. -/
theorem globalGammaPlus_conjTranspose_mul_globalGammaMinus
    {x : Type*} [Fintype x] [DecidableEq x] :
    Matrix.conjTranspose (globalGammaPlus (x := x)) * globalGammaMinus =
      (0 : CMatrix x) := by
  simp only [globalGammaPlus, globalGammaMinus, Matrix.conjTranspose_add,
    Matrix.add_mul, Matrix.mul_sub]
  rw [
    globalGamma1_conjTranspose_mul_globalGamma2,
    globalGamma1_conjTranspose_mul_self,
    globalGamma2_conjTranspose_mul_self,
    globalGamma2_conjTranspose_mul_globalGamma1]
  ext a b
  by_cases h : a = b
  · subst b
    simp
    ring
  · simp [h]

/-- The reverse unnormalized cross Gram matrix also vanishes. -/
theorem globalGammaMinus_conjTranspose_mul_globalGammaPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    Matrix.conjTranspose (globalGammaMinus (x := x)) * globalGammaPlus =
      (0 : CMatrix x) := by
  simp only [globalGammaPlus, globalGammaMinus, Matrix.conjTranspose_sub,
    Matrix.sub_mul, Matrix.mul_add]
  rw [
    globalGamma2_conjTranspose_mul_globalGamma1,
    globalGamma2_conjTranspose_mul_self,
    globalGamma1_conjTranspose_mul_self,
    globalGamma1_conjTranspose_mul_globalGamma2]
  ext a b
  by_cases h : a = b
  · subst b
    simp
  · simp [h]

private theorem inv_sqrt_sq_mul
    {a : ℝ} (ha : 0 < a) :
    (1 / Real.sqrt a) ^ 2 * a = 1 := by
  have hsqrtPos : 0 < Real.sqrt a := Real.sqrt_pos.2 ha
  have hsqrtNe : Real.sqrt a ≠ 0 := ne_of_gt hsqrtPos
  have hsquare : (Real.sqrt a) ^ 2 = a := Real.sq_sqrt ha.le
  field_simp
  nlinarith

/-- Normalized even-parity intertwiner W_+ from the paper. -/
def globalWPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    Matrix (GlobalThreeLeg x) x ℂ :=
  (1 / Real.sqrt (2 * ((Fintype.card x : ℝ) + 1))) • globalGammaPlus

/-- Normalized odd-parity intertwiner W_- from the paper. -/
def globalWMinus
    {x : Type*} [Fintype x] [DecidableEq x] :
    Matrix (GlobalThreeLeg x) x ℂ :=
  (1 / Real.sqrt (2 * ((Fintype.card x : ℝ) - 1))) • globalGammaMinus

/-- W_+ is an isometry. -/
theorem globalWPlus_conjTranspose_mul_self
    {x : Type*} [Fintype x] [DecidableEq x] :
    Matrix.conjTranspose (globalWPlus (x := x)) * globalWPlus =
      (1 : CMatrix x) := by
  simp only [globalWPlus, Matrix.conjTranspose_smul, star_trivial,
    Matrix.smul_mul, Matrix.mul_smul, smul_smul]
  rw [globalGammaPlus_conjTranspose_mul_self]
  have harg : 0 < 2 * ((Fintype.card x : ℝ) + 1) := by positivity
  have hnormalizer := inv_sqrt_sq_mul harg
  have hnormalizerComplex :=
    congrArg (fun r : ℝ => (r : ℂ)) hnormalizer
  push_cast at hnormalizerComplex
  ext a b
  by_cases h : a = b
  · subst b
    simp only [Matrix.one_apply]
    simpa [pow_two] using hnormalizerComplex
  · simp [h]

/-- W_- is an isometry whenever the one-leg dimension is at least two. -/
theorem globalWMinus_conjTranspose_mul_self
    {x : Type*} [Fintype x] [DecidableEq x]
    (hcard : 2 ≤ Fintype.card x) :
    Matrix.conjTranspose (globalWMinus (x := x)) * globalWMinus =
      (1 : CMatrix x) := by
  simp only [globalWMinus, Matrix.conjTranspose_smul, star_trivial,
    Matrix.smul_mul, Matrix.mul_smul, smul_smul]
  rw [globalGammaMinus_conjTranspose_mul_self]
  have hcardReal : (1 : ℝ) < Fintype.card x := by exact_mod_cast hcard
  have harg : 0 < 2 * ((Fintype.card x : ℝ) - 1) := by positivity
  have hnormalizer := inv_sqrt_sq_mul harg
  have hnormalizerComplex :=
    congrArg (fun r : ℝ => (r : ℂ)) hnormalizer
  push_cast at hnormalizerComplex
  ext a b
  by_cases h : a = b
  · subst b
    simp only [Matrix.one_apply]
    simpa [pow_two] using hnormalizerComplex
  · simp [h]

/-- The normalized even and odd intertwiners have zero cross Gram matrix. -/
theorem globalWPlus_conjTranspose_mul_globalWMinus
    {x : Type*} [Fintype x] [DecidableEq x] :
    Matrix.conjTranspose (globalWPlus (x := x)) * globalWMinus =
      (0 : CMatrix x) := by
  simp only [globalWPlus, globalWMinus, Matrix.conjTranspose_smul,
    star_trivial, Matrix.smul_mul, Matrix.mul_smul, smul_smul]
  rw [globalGammaPlus_conjTranspose_mul_globalGammaMinus]
  simp

/-- The reverse normalized cross Gram matrix also vanishes. -/
theorem globalWMinus_conjTranspose_mul_globalWPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    Matrix.conjTranspose (globalWMinus (x := x)) * globalWPlus =
      (0 : CMatrix x) := by
  simp only [globalWPlus, globalWMinus, Matrix.conjTranspose_smul,
    star_trivial, Matrix.smul_mul, Matrix.mul_smul, smul_smul]
  rw [globalGammaMinus_conjTranspose_mul_globalGammaPlus]
  simp

/-- Orthogonal range projection P_{W_+} = W_+ W_+^H. -/
def globalPWPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    CMatrix (GlobalThreeLeg x) :=
  globalWPlus * Matrix.conjTranspose globalWPlus

/-- Orthogonal range projection P_{W_-} = W_- W_-^H. -/
def globalPWMinus
    {x : Type*} [Fintype x] [DecidableEq x] :
    CMatrix (GlobalThreeLeg x) :=
  globalWMinus * Matrix.conjTranspose globalWMinus

/-- P_{W_+} is Hermitian. -/
theorem globalPWPlus_isHermitian
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalPWPlus (x := x)).IsHermitian := by
  rw [Matrix.IsHermitian, globalPWPlus, Matrix.conjTranspose_mul]
  simp

/-- P_{W_-} is Hermitian. -/
theorem globalPWMinus_isHermitian
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalPWMinus (x := x)).IsHermitian := by
  rw [Matrix.IsHermitian, globalPWMinus, Matrix.conjTranspose_mul]
  simp

/-- P_{W_+} is positive semidefinite. -/
theorem globalPWPlus_posSemidef
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalPWPlus (x := x)).PosSemidef := by
  simpa [globalPWPlus] using
    Matrix.posSemidef_conjTranspose_mul_self
      (Matrix.conjTranspose (globalWPlus (x := x)))

/-- P_{W_-} is positive semidefinite. -/
theorem globalPWMinus_posSemidef
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalPWMinus (x := x)).PosSemidef := by
  simpa [globalPWMinus] using
    Matrix.posSemidef_conjTranspose_mul_self
      (Matrix.conjTranspose (globalWMinus (x := x)))

/-- P_{W_+} is idempotent. -/
theorem globalPWPlus_idempotent
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPWPlus (x := x) * globalPWPlus = globalPWPlus := by
  simp only [globalPWPlus]
  calc
    (globalWPlus * Matrix.conjTranspose globalWPlus) *
          (globalWPlus * Matrix.conjTranspose globalWPlus) =
        globalWPlus *
          (Matrix.conjTranspose globalWPlus * globalWPlus) *
          Matrix.conjTranspose globalWPlus := by
            simp only [Matrix.mul_assoc]
    _ = globalWPlus * Matrix.conjTranspose globalWPlus := by
      rw [globalWPlus_conjTranspose_mul_self]
      simp

/-- P_{W_-} is idempotent when D is at least two. -/
theorem globalPWMinus_idempotent
    {x : Type*} [Fintype x] [DecidableEq x]
    (hcard : 2 ≤ Fintype.card x) :
    globalPWMinus (x := x) * globalPWMinus = globalPWMinus := by
  simp only [globalPWMinus]
  calc
    (globalWMinus * Matrix.conjTranspose globalWMinus) *
          (globalWMinus * Matrix.conjTranspose globalWMinus) =
        globalWMinus *
          (Matrix.conjTranspose globalWMinus * globalWMinus) *
          Matrix.conjTranspose globalWMinus := by
            simp only [Matrix.mul_assoc]
    _ = globalWMinus * Matrix.conjTranspose globalWMinus := by
      rw [globalWMinus_conjTranspose_mul_self hcard]
      simp

/-- The two range projections are orthogonal in the WPlus-WMinus order. -/
theorem globalPWPlus_mul_globalPWMinus
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPWPlus (x := x) * globalPWMinus = 0 := by
  simp only [globalPWPlus, globalPWMinus]
  calc
    (globalWPlus * Matrix.conjTranspose globalWPlus) *
          (globalWMinus * Matrix.conjTranspose globalWMinus) =
        globalWPlus *
          (Matrix.conjTranspose globalWPlus * globalWMinus) *
          Matrix.conjTranspose globalWMinus := by
            simp only [Matrix.mul_assoc]
    _ = (0 : CMatrix (GlobalThreeLeg x)) := by
      rw [globalWPlus_conjTranspose_mul_globalWMinus]
      simp

/-- The two range projections are orthogonal in the reverse order. -/
theorem globalPWMinus_mul_globalPWPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPWMinus (x := x) * globalPWPlus = 0 := by
  simp only [globalPWPlus, globalPWMinus]
  calc
    (globalWMinus * Matrix.conjTranspose globalWMinus) *
          (globalWPlus * Matrix.conjTranspose globalWPlus) =
        globalWMinus *
          (Matrix.conjTranspose globalWMinus * globalWPlus) *
          Matrix.conjTranspose globalWPlus := by
            simp only [Matrix.mul_assoc]
    _ = (0 : CMatrix (GlobalThreeLeg x)) := by
      rw [globalWMinus_conjTranspose_mul_globalWPlus]
      simp

/-- Exchange the two input-copy coordinates and leave the output fixed. -/
def globalSwapIndex
    {x : Type*} (p : GlobalThreeLeg x) : GlobalThreeLeg x :=
  ((p.1.2, p.1.1), p.2)

/-- Matrix of the full input-copy swap on the three-leg Choi space. -/
def globalInputSwap
    {x : Type*} [DecidableEq x] :
    CMatrix (GlobalThreeLeg x) :=
  fun p q => if q = globalSwapIndex p then 1 else 0

@[simp]
theorem globalSwapIndex_involutive
    {x : Type*} (p : GlobalThreeLeg x) :
    globalSwapIndex (globalSwapIndex p) = p := by
  rcases p with ⟨⟨i, j⟩, k⟩
  rfl

/-- Left multiplication by the swap permutes the row index explicitly. -/
theorem globalInputSwap_mul_apply
    {x y : Type*} [Fintype x] [DecidableEq x]
    (M : Matrix (GlobalThreeLeg x) y ℂ)
    (p : GlobalThreeLeg x) (a : y) :
    (globalInputSwap (x := x) * M) p a =
      M (globalSwapIndex p) a := by
  simp [Matrix.mul_apply, globalInputSwap]

/-- The input-copy swap is an involution. -/
theorem globalInputSwap_sq
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalInputSwap (x := x) * globalInputSwap = 1 := by
  ext p q
  rw [globalInputSwap_mul_apply]
  simp only [globalInputSwap, globalSwapIndex_involutive, Matrix.one_apply]
  by_cases h : p = q
  · subst q
    simp
  · simp [h, Ne.symm h]

/-- The input-copy swap matrix is Hermitian. -/
theorem globalInputSwap_isHermitian
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalInputSwap (x := x)).IsHermitian := by
  rw [Matrix.IsHermitian]
  ext p q
  simp only [Matrix.conjTranspose_apply, globalInputSwap]
  by_cases h : q = globalSwapIndex p
  · subst q
    simp
  · have hreverse : p ≠ globalSwapIndex q := by
      intro hp
      apply h
      calc
        q = globalSwapIndex (globalSwapIndex q) := by simp
        _ = globalSwapIndex p := by rw [hp]
    simp [h, hreverse]

/-- The normalized WPlus intertwiner has even input-swap parity. -/
theorem globalInputSwap_mul_globalWPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalInputSwap (x := x) * globalWPlus = globalWPlus := by
  ext p a
  rw [globalInputSwap_mul_apply]
  rcases p with ⟨⟨i, j⟩, k⟩
  simp [globalWPlus, globalGammaPlus, globalGamma1, globalGamma2,
    globalSwapIndex, add_comm]

/-- The normalized WMinus intertwiner has odd input-swap parity. -/
theorem globalInputSwap_mul_globalWMinus
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalInputSwap (x := x) * globalWMinus = -globalWMinus := by
  ext p a
  rw [globalInputSwap_mul_apply]
  rcases p with ⟨⟨i, j⟩, k⟩
  simp [globalWMinus, globalGammaMinus, globalGamma1, globalGamma2,
    globalSwapIndex]
  ring

/-- Projector onto even input-copy parity. -/
def globalPSym
    {x : Type*} [Fintype x] [DecidableEq x] :
    CMatrix (GlobalThreeLeg x) :=
  (1 / 2 : ℂ) • (1 + globalInputSwap)

/-- Projector onto odd input-copy parity. -/
def globalPAsym
    {x : Type*} [Fintype x] [DecidableEq x] :
    CMatrix (GlobalThreeLeg x) :=
  (1 / 2 : ℂ) • (1 - globalInputSwap)

/-- The parity projectors sum to the identity. -/
theorem globalPSym_add_globalPAsym
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPSym (x := x) + globalPAsym = 1 := by
  simp only [globalPSym, globalPAsym]
  module

/-- The even-parity matrix is idempotent. -/
theorem globalPSym_idempotent
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPSym (x := x) * globalPSym = globalPSym := by
  simp only [globalPSym, Matrix.smul_mul, Matrix.mul_smul, smul_smul]
  noncomm_ring [globalInputSwap_sq (x := x)]
  module

/-- The odd-parity matrix is idempotent. -/
theorem globalPAsym_idempotent
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPAsym (x := x) * globalPAsym = globalPAsym := by
  simp only [globalPAsym, Matrix.smul_mul, Matrix.mul_smul, smul_smul]
  noncomm_ring [globalInputSwap_sq (x := x)]
  module

/-- The two parity projectors are orthogonal. -/
theorem globalPSym_mul_globalPAsym
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPSym (x := x) * globalPAsym = 0 := by
  simp only [globalPSym, globalPAsym, Matrix.smul_mul, Matrix.mul_smul,
    smul_smul]
  noncomm_ring [globalInputSwap_sq (x := x)]
  simp

/-- Orthogonality in the reverse order. -/
theorem globalPAsym_mul_globalPSym
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPAsym (x := x) * globalPSym = 0 := by
  simp only [globalPSym, globalPAsym, Matrix.smul_mul, Matrix.mul_smul,
    smul_smul]
  noncomm_ring [globalInputSwap_sq (x := x)]
  simp

/-- The even-parity projector is Hermitian. -/
theorem globalPSym_isHermitian
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalPSym (x := x)).IsHermitian := by
  have hswap := globalInputSwap_isHermitian (x := x)
  rw [Matrix.IsHermitian] at hswap
  rw [Matrix.IsHermitian, globalPSym, Matrix.conjTranspose_smul,
    Matrix.conjTranspose_add]
  rw [hswap]
  norm_num

/-- The odd-parity projector is Hermitian. -/
theorem globalPAsym_isHermitian
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalPAsym (x := x)).IsHermitian := by
  have hswap := globalInputSwap_isHermitian (x := x)
  rw [Matrix.IsHermitian] at hswap
  rw [Matrix.IsHermitian, globalPAsym, Matrix.conjTranspose_smul,
    Matrix.conjTranspose_sub]
  rw [hswap]
  norm_num

/-- The even-parity projector is positive semidefinite. -/
theorem globalPSym_posSemidef
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalPSym (x := x)).PosSemidef := by
  have hpos :=
    Matrix.posSemidef_conjTranspose_mul_self (globalPSym (x := x))
  rw [globalPSym_isHermitian (x := x), globalPSym_idempotent (x := x)] at hpos
  exact hpos

/-- The odd-parity projector is positive semidefinite. -/
theorem globalPAsym_posSemidef
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalPAsym (x := x)).PosSemidef := by
  have hpos :=
    Matrix.posSemidef_conjTranspose_mul_self (globalPAsym (x := x))
  rw [globalPAsym_isHermitian (x := x), globalPAsym_idempotent (x := x)] at hpos
  exact hpos

/-- Swap matrix on the two-copy input space alone. -/
def globalInputPairSwap
    {x : Type*} [DecidableEq x] :
    CMatrix (x × x) :=
  fun p q => if q = (p.2, p.1) then 1 else 0

/-- Symmetric projector on the two-copy input space. -/
def globalInputPairPSym
    {x : Type*} [DecidableEq x] :
    CMatrix (x × x) :=
  (1 / 2 : ℂ) • (1 + globalInputPairSwap)

/-- First diagonal contraction identity after tracing out the output. -/
theorem partialTraceB_globalGamma1_mul_conjTranspose
    {x : Type*} [Fintype x] [DecidableEq x] :
    QIT.partialTraceB (a := x × x) (b := x)
        (globalGamma1 * Matrix.conjTranspose globalGamma1) =
      (1 : CMatrix (x × x)) := by
  ext p q
  rcases p with ⟨a, b⟩
  rcases q with ⟨c, d⟩
  by_cases hac : a = c
  · subst c
    by_cases hbd : b = d
    · subst d
      simp [QIT.partialTraceB, Matrix.mul_apply, globalGamma1]
    · simp [QIT.partialTraceB, Matrix.mul_apply, globalGamma1,
        hbd, Ne.symm hbd]
  · simp [QIT.partialTraceB, Matrix.mul_apply, globalGamma1,
      hac, Ne.symm hac]

/-- Second diagonal contraction identity after tracing out the output. -/
theorem partialTraceB_globalGamma2_mul_conjTranspose
    {x : Type*} [Fintype x] [DecidableEq x] :
    QIT.partialTraceB (a := x × x) (b := x)
        (globalGamma2 * Matrix.conjTranspose globalGamma2) =
      (1 : CMatrix (x × x)) := by
  ext p q
  rcases p with ⟨a, b⟩
  rcases q with ⟨c, d⟩
  by_cases hac : a = c
  · subst c
    by_cases hbd : b = d
    · subst d
      simp [QIT.partialTraceB, Matrix.mul_apply, globalGamma2]
    · simp [QIT.partialTraceB, Matrix.mul_apply, globalGamma2,
        hbd, Ne.symm hbd]
  · simp [QIT.partialTraceB, Matrix.mul_apply, globalGamma2,
      hac, Ne.symm hac]

/-- First cross contraction identity after tracing out the output. -/
theorem partialTraceB_globalGamma1_mul_globalGamma2_conjTranspose
    {x : Type*} [Fintype x] [DecidableEq x] :
    QIT.partialTraceB (a := x × x) (b := x)
        (globalGamma1 * Matrix.conjTranspose globalGamma2) =
      globalInputPairSwap := by
  ext p q
  rcases p with ⟨a, b⟩
  rcases q with ⟨c, d⟩
  by_cases hbc : b = c
  · subst c
    by_cases had : a = d
    · subst d
      simp [QIT.partialTraceB, Matrix.mul_apply, globalGamma1, globalGamma2,
        globalInputPairSwap]
    · simp [QIT.partialTraceB, Matrix.mul_apply, globalGamma1, globalGamma2,
        globalInputPairSwap, Ne.symm had]
  · simp [QIT.partialTraceB, Matrix.mul_apply, globalGamma1, globalGamma2,
      globalInputPairSwap, Ne.symm hbc]

/-- Reverse cross contraction identity after tracing out the output. -/
theorem partialTraceB_globalGamma2_mul_globalGamma1_conjTranspose
    {x : Type*} [Fintype x] [DecidableEq x] :
    QIT.partialTraceB (a := x × x) (b := x)
        (globalGamma2 * Matrix.conjTranspose globalGamma1) =
      globalInputPairSwap := by
  ext p q
  rcases p with ⟨a, b⟩
  rcases q with ⟨c, d⟩
  by_cases hbc : b = c
  · subst c
    by_cases had : a = d
    · subst d
      simp [QIT.partialTraceB, Matrix.mul_apply, globalGamma1, globalGamma2,
        globalInputPairSwap]
    · simp [QIT.partialTraceB, Matrix.mul_apply, globalGamma1, globalGamma2,
        globalInputPairSwap, Ne.symm had]
  · simp [QIT.partialTraceB, Matrix.mul_apply, globalGamma1, globalGamma2,
      globalInputPairSwap, Ne.symm hbc]

/-- The normalized range projector is the unnormalized even contraction
projector scaled by 1 / (2(D+1)). -/
theorem globalPWPlus_eq_scaledGammaPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPWPlus (x := x) =
      (1 / (2 * ((Fintype.card x : ℝ) + 1))) •
        (globalGammaPlus * Matrix.conjTranspose globalGammaPlus) := by
  have harg : 0 < 2 * ((Fintype.card x : ℝ) + 1) := by positivity
  have hsqrtNe : Real.sqrt (2 * ((Fintype.card x : ℝ) + 1)) ≠ 0 :=
    ne_of_gt (Real.sqrt_pos.2 harg)
  have hsquare :
      (Real.sqrt (2 * ((Fintype.card x : ℝ) + 1))) ^ 2 =
        2 * ((Fintype.card x : ℝ) + 1) :=
    Real.sq_sqrt harg.le
  have hcoefficient :
      (1 / Real.sqrt (2 * ((Fintype.card x : ℝ) + 1))) *
          (1 / Real.sqrt (2 * ((Fintype.card x : ℝ) + 1))) =
        1 / (2 * ((Fintype.card x : ℝ) + 1)) := by
    field_simp
    nlinarith
  simp only [globalPWPlus, globalWPlus, Matrix.conjTranspose_smul,
    star_trivial, Matrix.smul_mul, Matrix.mul_smul, smul_smul]
  rw [hcoefficient]

/-- The normalized odd range projector is the unnormalized odd contraction
projector scaled by 1 / (2(D-1)). -/
theorem globalPWMinus_eq_scaledGammaMinus
    {x : Type*} [Fintype x] [DecidableEq x]
    (hcard : 2 ≤ Fintype.card x) :
    globalPWMinus (x := x) =
      (1 / (2 * ((Fintype.card x : ℝ) - 1))) •
        (globalGammaMinus * Matrix.conjTranspose globalGammaMinus) := by
  have hcardReal : (1 : ℝ) < Fintype.card x := by exact_mod_cast hcard
  have harg : 0 < 2 * ((Fintype.card x : ℝ) - 1) := by positivity
  have hsqrtNe : Real.sqrt (2 * ((Fintype.card x : ℝ) - 1)) ≠ 0 :=
    ne_of_gt (Real.sqrt_pos.2 harg)
  have hsquare :
      (Real.sqrt (2 * ((Fintype.card x : ℝ) - 1))) ^ 2 =
        2 * ((Fintype.card x : ℝ) - 1) :=
    Real.sq_sqrt harg.le
  have hcoefficient :
      (1 / Real.sqrt (2 * ((Fintype.card x : ℝ) - 1))) *
          (1 / Real.sqrt (2 * ((Fintype.card x : ℝ) - 1))) =
        1 / (2 * ((Fintype.card x : ℝ) - 1)) := by
    rw [one_div, one_div, ← mul_inv, ← pow_two, hsquare]
  simp only [globalPWMinus, globalWMinus, Matrix.conjTranspose_smul,
    star_trivial, Matrix.smul_mul, Matrix.mul_smul, smul_smul]
  rw [hcoefficient]

/-- Output trace of the unnormalized even contraction projector. -/
theorem partialTraceB_globalGammaPlus_mul_conjTranspose
    {x : Type*} [Fintype x] [DecidableEq x] :
    QIT.partialTraceB (a := x × x) (b := x)
        (globalGammaPlus * Matrix.conjTranspose globalGammaPlus) =
      (2 : ℂ) • (1 + globalInputPairSwap) := by
  simp only [globalGammaPlus, Matrix.conjTranspose_add, Matrix.add_mul,
    Matrix.mul_add, QIT.partialTraceB_add]
  rw [partialTraceB_globalGamma1_mul_conjTranspose,
    partialTraceB_globalGamma1_mul_globalGamma2_conjTranspose,
    partialTraceB_globalGamma2_mul_globalGamma1_conjTranspose,
    partialTraceB_globalGamma2_mul_conjTranspose]
  module

/-- Equation eq:contraction_output_trace_identities combined with the
normalization of WPlus:
Tr_output(P_WPlus) = 2/(D+1) P_sym. -/
theorem partialTraceB_globalPWPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    QIT.partialTraceB (a := x × x) (b := x) (globalPWPlus (x := x)) =
      ((2 / ((Fintype.card x : ℝ) + 1) : ℝ) : ℂ) •
        globalInputPairPSym := by
  rw [globalPWPlus_eq_scaledGammaPlus]
  change
    QIT.partialTraceB (a := x × x) (b := x)
        (((1 / (2 * ((Fintype.card x : ℝ) + 1)) : ℝ) : ℂ) •
          (globalGammaPlus * Matrix.conjTranspose globalGammaPlus)) =
      ((2 / ((Fintype.card x : ℝ) + 1) : ℝ) : ℂ) •
        globalInputPairPSym
  rw [QIT.partialTraceB_smul,
    partialTraceB_globalGammaPlus_mul_conjTranspose]
  simp only [globalInputPairPSym, smul_smul]
  have hdenom : (Fintype.card x : ℝ) + 1 ≠ 0 := by positivity
  have hscalarReal :
      (1 / (2 * ((Fintype.card x : ℝ) + 1))) * 2 =
        (2 / ((Fintype.card x : ℝ) + 1)) * (1 / 2) := by
    field_simp [hdenom]
  have hscalarComplex :
      ((1 / (2 * ((Fintype.card x : ℝ) + 1)) : ℝ) : ℂ) * 2 =
        ((2 / ((Fintype.card x : ℝ) + 1) : ℝ) : ℂ) * (1 / 2) := by
    have hdenomComplex :
        (Fintype.card x : ℂ) + 1 ≠ 0 := by
      intro hzero
      have hre := congrArg Complex.re hzero
      norm_num at hre
      have hpos : 0 < (Fintype.card x : ℝ) + 1 := by positivity
      linarith
    push_cast
    field_simp [hdenomComplex]
  exact congrArg
    (fun z : ℂ => z •
      ((1 : CMatrix (x × x)) + globalInputPairSwap))
    hscalarComplex

/-- The two-input swap is an involution. -/
theorem globalInputPairSwap_mul_apply
    {x y : Type*} [Fintype x] [DecidableEq x]
    (M : Matrix (x × x) y ℂ) (p : x × x) (a : y) :
    (globalInputPairSwap (x := x) * M) p a = M (p.2, p.1) a := by
  simp [Matrix.mul_apply, globalInputPairSwap]

/-- The two-input swap is an involution. -/
theorem globalInputPairSwap_sq
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalInputPairSwap (x := x) * globalInputPairSwap = 1 := by
  ext p q
  rw [globalInputPairSwap_mul_apply]
  rcases p with ⟨a, b⟩
  rcases q with ⟨c, d⟩
  by_cases h : (a, b) = (c, d)
  · cases h
    simp [globalInputPairSwap]
  · have hreverse : (c, d) ≠ (a, b) := Ne.symm h
    simp [globalInputPairSwap, h, hreverse]

/-- The two-input swap is Hermitian. -/
theorem globalInputPairSwap_isHermitian
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalInputPairSwap (x := x)).IsHermitian := by
  rw [Matrix.IsHermitian]
  ext p q
  rcases p with ⟨a, b⟩
  rcases q with ⟨c, d⟩
  simp only [Matrix.conjTranspose_apply, globalInputPairSwap]
  by_cases h : (c, d) = (b, a)
  · simp [h]
    cases h
    simp
  · have hreverse : (a, b) ≠ (d, c) := by
      intro hr
      apply h
      cases hr
      rfl
    simp [h, hreverse]

/-- The two-input symmetric matrix is idempotent. -/
theorem globalInputPairPSym_idempotent
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalInputPairPSym (x := x) * globalInputPairPSym =
      globalInputPairPSym := by
  simp only [globalInputPairPSym, Matrix.smul_mul, Matrix.mul_smul,
    smul_smul]
  noncomm_ring [globalInputPairSwap_sq (x := x)]
  module

/-- The two-input symmetric projector is Hermitian. -/
theorem globalInputPairPSym_isHermitian
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalInputPairPSym (x := x)).IsHermitian := by
  have hswap := globalInputPairSwap_isHermitian (x := x)
  rw [Matrix.IsHermitian] at hswap
  rw [Matrix.IsHermitian, globalInputPairPSym, Matrix.conjTranspose_smul,
    Matrix.conjTranspose_add, hswap]
  norm_num

/-- The two-input symmetric projector is positive semidefinite. -/
theorem globalInputPairPSym_posSemidef
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalInputPairPSym (x := x)).PosSemidef := by
  have hpos :=
    Matrix.posSemidef_conjTranspose_mul_self
      (globalInputPairPSym (x := x))
  rw [globalInputPairPSym_isHermitian (x := x),
    globalInputPairPSym_idempotent (x := x)] at hpos
  exact hpos

/-- Trace of the two-input swap. -/
theorem globalInputPairSwap_trace
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalInputPairSwap (x := x)).trace = Fintype.card x := by
  simp only [Matrix.trace]
  change
    (∑ p : x × x,
      if p = (p.2, p.1) then (1 : ℂ) else 0) = Fintype.card x
  rw [Fintype.sum_prod_type]
  change
    (∑ a : x, ∑ b : x,
      if (a, b) = (b, a) then (1 : ℂ) else 0) = Fintype.card x
  calc
    (∑ a : x, ∑ b : x,
        if (a, b) = (b, a) then (1 : ℂ) else 0) =
        ∑ _a : x, (1 : ℂ) := by
      apply Finset.sum_congr rfl
      intro a _
      rw [Fintype.sum_eq_single a]
      · simp
      · intro b hba
        simp [hba, Ne.symm hba]
    _ = Fintype.card x := by simp

/-- Exact dimension/trace of the two-input symmetric projector. -/
theorem globalInputPairPSym_trace
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalInputPairPSym (x := x)).trace =
      (Fintype.card x : ℂ) * ((Fintype.card x : ℂ) + 1) / 2 := by
  rw [globalInputPairPSym, Matrix.trace_smul, Matrix.trace_add,
    Matrix.trace_one, globalInputPairSwap_trace]
  simp only [Fintype.card_prod]
  push_cast
  ring

/-- The three-leg parity projector is the input symmetric projector tensored
with the output identity. -/
theorem globalPSym_eq_kronecker_inputPairPSym_one
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPSym (x := x) =
      Matrix.kronecker globalInputPairPSym (1 : CMatrix x) := by
  ext p q
  rcases p with ⟨⟨a, b⟩, c⟩
  rcases q with ⟨⟨d, e⟩, f⟩
  by_cases hcf : c = f
  · subst f
    by_cases hin : (a, b) = (d, e)
    · cases hin
      by_cases hab : a = b
      · simp [globalPSym, globalInputSwap, globalSwapIndex,
          globalInputPairPSym, globalInputPairSwap, Matrix.kronecker,
          Matrix.kroneckerMap_apply, hab]
        ring
      · simp [globalPSym, globalInputSwap, globalSwapIndex,
          globalInputPairPSym, globalInputPairSwap, Matrix.kronecker,
          Matrix.kroneckerMap_apply, hab]
    · by_cases hswap : (d, e) = (b, a)
      · by_cases hab : a = b
        · simp [globalPSym, globalInputSwap, globalSwapIndex,
            globalInputPairPSym, globalInputPairSwap, Matrix.kronecker,
            Matrix.kroneckerMap_apply, hswap, hab]
          ring
        · simp [globalPSym, globalInputSwap, globalSwapIndex,
            globalInputPairPSym, globalInputPairSwap, Matrix.kronecker,
            Matrix.kroneckerMap_apply, hswap, hab]
      · simp [globalPSym, globalInputSwap, globalSwapIndex,
          globalInputPairPSym, globalInputPairSwap, Matrix.kronecker,
          Matrix.kroneckerMap_apply, hin, hswap]
  · simp [globalPSym, globalInputSwap, globalSwapIndex,
      globalInputPairPSym, globalInputPairSwap, Matrix.kronecker,
      Matrix.kroneckerMap_apply, Matrix.one_apply, hcf, Ne.symm hcf]

private theorem reverse_absorption_of_isHermitian
    {r : Type*} [Fintype r]
    {P Q : CMatrix r} (hP : P.IsHermitian) (hQ : Q.IsHermitian)
    (hPQ : P * Q = Q) :
    Q * P = Q := by
  rw [Matrix.IsHermitian] at hP hQ
  have h := congrArg Matrix.conjTranspose hPQ
  simpa [Matrix.conjTranspose_mul, hP, hQ] using h

private theorem reverse_zero_of_isHermitian
    {r : Type*} [Fintype r]
    {P Q : CMatrix r} (hP : P.IsHermitian) (hQ : Q.IsHermitian)
    (hPQ : P * Q = 0) :
    Q * P = 0 := by
  rw [Matrix.IsHermitian] at hP hQ
  have h := congrArg Matrix.conjTranspose hPQ
  simpa [Matrix.conjTranspose_mul, hP, hQ] using h

/-- Even parity absorbs WPlus. -/
theorem globalPSym_mul_globalWPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPSym (x := x) * globalWPlus = globalWPlus := by
  simp only [globalPSym, Matrix.smul_mul, Matrix.add_mul, Matrix.one_mul]
  rw [globalInputSwap_mul_globalWPlus]
  module

/-- Odd parity absorbs WMinus. -/
theorem globalPAsym_mul_globalWMinus
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPAsym (x := x) * globalWMinus = globalWMinus := by
  simp only [globalPAsym, Matrix.smul_mul, Matrix.sub_mul, Matrix.one_mul]
  rw [globalInputSwap_mul_globalWMinus]
  module

/-- Even parity annihilates WMinus. -/
theorem globalPSym_mul_globalWMinus
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPSym (x := x) * globalWMinus (x := x) =
      (0 : Matrix (GlobalThreeLeg x) x ℂ) := by
  simp only [globalPSym, Matrix.smul_mul, Matrix.add_mul, Matrix.one_mul]
  rw [globalInputSwap_mul_globalWMinus]
  module

/-- Odd parity annihilates WPlus. -/
theorem globalPAsym_mul_globalWPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPAsym (x := x) * globalWPlus (x := x) =
      (0 : Matrix (GlobalThreeLeg x) x ℂ) := by
  simp only [globalPAsym, Matrix.smul_mul, Matrix.sub_mul, Matrix.one_mul]
  rw [globalInputSwap_mul_globalWPlus]
  module

/-- P_WPlus is a subprojection of the even-parity projector. -/
theorem globalPSym_mul_globalPWPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPSym (x := x) * globalPWPlus = globalPWPlus := by
  simp only [globalPWPlus]
  calc
    globalPSym * (globalWPlus * Matrix.conjTranspose globalWPlus) =
        (globalPSym * globalWPlus) * Matrix.conjTranspose globalWPlus :=
      (Matrix.mul_assoc _ _ _).symm
    _ = globalWPlus * Matrix.conjTranspose globalWPlus := by
      rw [globalPSym_mul_globalWPlus (x := x)]

/-- Reverse absorption for P_WPlus. -/
theorem globalPWPlus_mul_globalPSym
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPWPlus (x := x) * globalPSym = globalPWPlus := by
  exact reverse_absorption_of_isHermitian
    (P := globalPSym (x := x)) (Q := globalPWPlus (x := x))
    (globalPSym_isHermitian (x := x)) (globalPWPlus_isHermitian (x := x))
    (globalPSym_mul_globalPWPlus (x := x))

/-- P_WMinus is a subprojection of the odd-parity projector. -/
theorem globalPAsym_mul_globalPWMinus
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPAsym (x := x) * globalPWMinus = globalPWMinus := by
  simp only [globalPWMinus]
  calc
    globalPAsym * (globalWMinus * Matrix.conjTranspose globalWMinus) =
        (globalPAsym * globalWMinus) * Matrix.conjTranspose globalWMinus :=
      (Matrix.mul_assoc _ _ _).symm
    _ = globalWMinus * Matrix.conjTranspose globalWMinus := by
      rw [globalPAsym_mul_globalWMinus (x := x)]

/-- Reverse absorption for P_WMinus. -/
theorem globalPWMinus_mul_globalPAsym
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPWMinus (x := x) * globalPAsym = globalPWMinus := by
  exact reverse_absorption_of_isHermitian
    (P := globalPAsym (x := x)) (Q := globalPWMinus (x := x))
    (globalPAsym_isHermitian (x := x)) (globalPWMinus_isHermitian (x := x))
    (globalPAsym_mul_globalPWMinus (x := x))

/-- Even parity annihilates P_WMinus. -/
theorem globalPSym_mul_globalPWMinus
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPSym (x := x) * globalPWMinus = 0 := by
  simp only [globalPWMinus]
  calc
    globalPSym * (globalWMinus * Matrix.conjTranspose globalWMinus) =
        (globalPSym * globalWMinus) * Matrix.conjTranspose globalWMinus :=
      (Matrix.mul_assoc _ _ _).symm
    _ = 0 := by rw [globalPSym_mul_globalWMinus (x := x)]; simp

/-- Reverse parity annihilation for P_WMinus. -/
theorem globalPWMinus_mul_globalPSym
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPWMinus (x := x) * globalPSym = 0 := by
  exact reverse_zero_of_isHermitian
    (P := globalPSym (x := x)) (Q := globalPWMinus (x := x))
    (globalPSym_isHermitian (x := x)) (globalPWMinus_isHermitian (x := x))
    (globalPSym_mul_globalPWMinus (x := x))

/-- Odd parity annihilates P_WPlus. -/
theorem globalPAsym_mul_globalPWPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPAsym (x := x) * globalPWPlus = 0 := by
  simp only [globalPWPlus]
  calc
    globalPAsym * (globalWPlus * Matrix.conjTranspose globalWPlus) =
        (globalPAsym * globalWPlus) * Matrix.conjTranspose globalWPlus :=
      (Matrix.mul_assoc _ _ _).symm
    _ = 0 := by rw [globalPAsym_mul_globalWPlus (x := x)]; simp

/-- Reverse parity annihilation for P_WPlus. -/
theorem globalPWPlus_mul_globalPAsym
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPWPlus (x := x) * globalPAsym = 0 := by
  exact reverse_zero_of_isHermitian
    (P := globalPAsym (x := x)) (Q := globalPWPlus (x := x))
    (globalPAsym_isHermitian (x := x)) (globalPWPlus_isHermitian (x := x))
    (globalPAsym_mul_globalPWPlus (x := x))

/-- Residual even-parity sector projector. -/
def globalPLPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    CMatrix (GlobalThreeLeg x) :=
  globalPSym - globalPWPlus

/-- Residual odd-parity sector projector. -/
def globalPLMinus
    {x : Type*} [Fintype x] [DecidableEq x] :
    CMatrix (GlobalThreeLeg x) :=
  globalPAsym - globalPWMinus

/-- The residual even sector is Hermitian. -/
theorem globalPLPlus_isHermitian
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalPLPlus (x := x)).IsHermitian :=
  (globalPSym_isHermitian (x := x)).sub (globalPWPlus_isHermitian (x := x))

/-- The residual odd sector is Hermitian. -/
theorem globalPLMinus_isHermitian
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalPLMinus (x := x)).IsHermitian :=
  (globalPAsym_isHermitian (x := x)).sub (globalPWMinus_isHermitian (x := x))

/-- The residual even sector is idempotent. -/
theorem globalPLPlus_idempotent
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPLPlus (x := x) * globalPLPlus = globalPLPlus := by
  simp only [globalPLPlus, Matrix.sub_mul, Matrix.mul_sub]
  rw [globalPSym_idempotent, globalPSym_mul_globalPWPlus,
    globalPWPlus_mul_globalPSym, globalPWPlus_idempotent]
  abel

/-- The residual odd sector is idempotent. -/
theorem globalPLMinus_idempotent
    {x : Type*} [Fintype x] [DecidableEq x]
    (hcard : 2 ≤ Fintype.card x) :
    globalPLMinus (x := x) * globalPLMinus = globalPLMinus := by
  simp only [globalPLMinus, Matrix.sub_mul, Matrix.mul_sub]
  rw [globalPAsym_idempotent, globalPAsym_mul_globalPWMinus,
    globalPWMinus_mul_globalPAsym, globalPWMinus_idempotent hcard]
  abel

/-- The residual even sector is positive semidefinite. -/
theorem globalPLPlus_posSemidef
    {x : Type*} [Fintype x] [DecidableEq x] :
    (globalPLPlus (x := x)).PosSemidef := by
  have hpos :=
    Matrix.posSemidef_conjTranspose_mul_self (globalPLPlus (x := x))
  rw [globalPLPlus_isHermitian (x := x),
    globalPLPlus_idempotent (x := x)] at hpos
  exact hpos

/-- The residual odd sector is positive semidefinite. -/
theorem globalPLMinus_posSemidef
    {x : Type*} [Fintype x] [DecidableEq x]
    (hcard : 2 ≤ Fintype.card x) :
    (globalPLMinus (x := x)).PosSemidef := by
  have hpos :=
    Matrix.posSemidef_conjTranspose_mul_self (globalPLMinus (x := x))
  rw [globalPLMinus_isHermitian (x := x),
    globalPLMinus_idempotent hcard] at hpos
  exact hpos

/-- WPlus and its residual even sector are orthogonal. -/
theorem globalPWPlus_mul_globalPLPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPWPlus (x := x) * globalPLPlus = 0 := by
  rw [globalPLPlus, Matrix.mul_sub, globalPWPlus_mul_globalPSym,
    globalPWPlus_idempotent, sub_self]

/-- WMinus and its residual odd sector are orthogonal. -/
theorem globalPWMinus_mul_globalPLMinus
    {x : Type*} [Fintype x] [DecidableEq x]
    (hcard : 2 ≤ Fintype.card x) :
    globalPWMinus (x := x) * globalPLMinus = 0 := by
  rw [globalPLMinus, Matrix.mul_sub, globalPWMinus_mul_globalPAsym,
    globalPWMinus_idempotent hcard, sub_self]

/-- WPlus is orthogonal to the residual odd-parity sector. -/
theorem globalPWPlus_mul_globalPLMinus
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPWPlus (x := x) * globalPLMinus = 0 := by
  rw [globalPLMinus, Matrix.mul_sub, globalPWPlus_mul_globalPAsym,
    globalPWPlus_mul_globalPWMinus]
  simp

/-- WMinus is orthogonal to the residual even-parity sector. -/
theorem globalPWMinus_mul_globalPLPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPWMinus (x := x) * globalPLPlus = 0 := by
  rw [globalPLPlus, Matrix.mul_sub, globalPWMinus_mul_globalPSym,
    globalPWMinus_mul_globalPWPlus]
  simp

/-- The two residual parity sectors are orthogonal. -/
theorem globalPLPlus_mul_globalPLMinus
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPLPlus (x := x) * globalPLMinus = 0 := by
  simp only [globalPLPlus, globalPLMinus, Matrix.sub_mul, Matrix.mul_sub]
  rw [globalPSym_mul_globalPAsym, globalPSym_mul_globalPWMinus,
    globalPWPlus_mul_globalPAsym, globalPWPlus_mul_globalPWMinus]
  simp

/-- The four concrete sector projectors resolve the identity. -/
theorem global_four_projectors_sum
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalPWPlus (x := x) + globalPWMinus + globalPLPlus + globalPLMinus =
      1 := by
  rw [globalPLPlus, globalPLMinus, ← globalPSym_add_globalPAsym]
  abel

end

end EntanglementPurification
