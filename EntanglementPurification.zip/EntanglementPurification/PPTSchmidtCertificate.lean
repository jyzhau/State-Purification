import EntanglementPurification.PPTResourceCertificate
import EntanglementPurification.SchmidtConverse

/-!
# From the compressed PPT certificate to Schmidt majorization

This module identifies the paper's signed Schmidt coordinates with the
diagonal subspace of the bipartite resource, compresses the auxiliary resource
effect to that subspace, and feeds the PPT-derived diagonal/cross inequalities
into the Appendix-B Schmidt converse.

The final theorems start from `CompressedPPTInstrumentData`.  They do not yet
construct that record from an uncompressed physical Choi instrument; that
upstream construction is deliberately kept as a separate interface.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {n : ℕ}

/-- The diagonal inclusion |j> ↦ |j,j>. -/
def schmidtDiagonalEmbedding :
    Matrix (Fin n × Fin n) (Fin n) ℂ :=
  fun ij k => if ij = (k, k) then 1 else 0

@[simp]
theorem schmidtDiagonalEmbedding_apply (i j k : Fin n) :
    schmidtDiagonalEmbedding (i, j) k =
      if (i, j) = (k, k) then 1 else 0 := rfl

theorem schmidtDiagonalEmbedding_conjTranspose_mul_self :
    Matrix.conjTranspose (schmidtDiagonalEmbedding (n := n)) *
        schmidtDiagonalEmbedding =
      (1 : CMatrix (Fin n)) := by
  ext i j
  simp [schmidtDiagonalEmbedding, Matrix.mul_apply,
    Matrix.conjTranspose_apply, Matrix.one_apply, eq_comm]

@[simp]
theorem schmidtDiagonalEmbedding_mulVec_apply
    (u : Fin n → ℂ) (i j : Fin n) :
    schmidtDiagonalEmbedding.mulVec u (i, j) =
      if i = j then u i else 0 := by
  by_cases hij : i = j
  · subst j
    simp [schmidtDiagonalEmbedding, Matrix.mulVec, dotProduct]
  · rw [if_neg hij]
    simp only [schmidtDiagonalEmbedding, Matrix.mulVec, dotProduct]
    apply Finset.sum_eq_zero
    intro x hx
    have hpair : (i, j) ≠ (x, x) := by
      intro h
      exact hij ((congrArg Prod.fst h).trans (congrArg Prod.snd h).symm)
    simp [hpair]

theorem schmidtDiagonalEmbedding_mulVec_basis (j : Fin n) :
    schmidtDiagonalEmbedding.mulVec (coordinateBasisVector j) =
      coordinateBasisVector (j, j) := by
  funext ij
  rcases ij with ⟨i, k⟩
  by_cases hik : i = k
  · subst k
    simp [coordinateBasisVector, Pi.single_apply, Prod.ext_iff]
  · have hpair : (i, k) ≠ (j, j) := by
      intro h
      exact hik ((congrArg Prod.fst h).trans (congrArg Prod.snd h).symm)
    simp [coordinateBasisVector, hik, hpair]

/-- Compression of an ambient bipartite operator to the diagonal Schmidt
subspace. -/
def schmidtDiagonalCompression
    (N : CMatrix (Fin n × Fin n)) : CMatrix (Fin n) :=
  Matrix.conjTranspose schmidtDiagonalEmbedding * N *
    schmidtDiagonalEmbedding

@[simp]
theorem schmidtDiagonalCompression_apply
    (N : CMatrix (Fin n × Fin n)) (i j : Fin n) :
    schmidtDiagonalCompression N i j = N (i, i) (j, j) := by
  simp [schmidtDiagonalCompression, schmidtDiagonalEmbedding,
    Matrix.mul_apply, Matrix.conjTranspose_apply]

theorem schmidtDiagonalCompression_isEffect
    {N : CMatrix (Fin n × Fin n)} (hN : IsEffectMatrix N) :
    IsEffectMatrix (schmidtDiagonalCompression N) := by
  constructor
  · exact hN.1.conjTranspose_mul_mul_same schmidtDiagonalEmbedding
  · rw [Matrix.le_iff]
    have hgap : ((1 : CMatrix (Fin n × Fin n)) - N).PosSemidef :=
      Matrix.le_iff.mp hN.2
    have hsandwich :=
      hgap.conjTranspose_mul_mul_same (schmidtDiagonalEmbedding (n := n))
    have hE := schmidtDiagonalEmbedding_conjTranspose_mul_self (n := n)
    have heq :
        (1 : CMatrix (Fin n)) - schmidtDiagonalCompression N =
          Matrix.conjTranspose schmidtDiagonalEmbedding *
            ((1 : CMatrix (Fin n × Fin n)) - N) *
              schmidtDiagonalEmbedding := by
      rw [schmidtDiagonalCompression]
      calc
        (1 : CMatrix (Fin n)) -
              Matrix.conjTranspose schmidtDiagonalEmbedding * N *
                schmidtDiagonalEmbedding =
            Matrix.conjTranspose schmidtDiagonalEmbedding *
                schmidtDiagonalEmbedding -
              Matrix.conjTranspose schmidtDiagonalEmbedding * N *
                schmidtDiagonalEmbedding := by rw [hE]
        _ = Matrix.conjTranspose schmidtDiagonalEmbedding *
              ((1 : CMatrix (Fin n × Fin n)) - N) *
                schmidtDiagonalEmbedding := by
          rw [Matrix.mul_sub, Matrix.sub_mul, Matrix.mul_one]
    rw [heq]
    exact hsandwich

theorem quadraticRe_schmidtDiagonalCompression
    (N : CMatrix (Fin n × Fin n)) (u : Fin n → ℂ) :
    quadraticRe (schmidtDiagonalCompression N) u =
      quadraticRe N (schmidtDiagonalEmbedding.mulVec u) := by
  unfold quadraticRe schmidtDiagonalCompression
  rw [← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec]
  simp only [Matrix.star_mulVec, Matrix.dotProduct_mulVec]

theorem effectCrossRe_schmidtDiagonalCompression
    (N : CMatrix (Fin n × Fin n)) (u v : Fin n → ℂ) :
    effectCrossRe (schmidtDiagonalCompression N) u v =
      effectCrossRe N (schmidtDiagonalEmbedding.mulVec u)
        (schmidtDiagonalEmbedding.mulVec v) := by
  unfold effectCrossRe cVecInnerRe schmidtDiagonalCompression
  rw [← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec]
  simp only [Matrix.star_mulVec, Matrix.dotProduct_mulVec]

/-- The paper's signed Schmidt amplitudes, embedded in the full bipartite
resource basis. -/
def ambientSignedSchmidtAmp
    {m : ℕ} (p : Fin (m + 3) → ℝ) :
    (Fin (m + 3) × Fin (m + 3)) → ℂ :=
  fun ij =>
    if ij.1 = ij.2 then
      if ij.1 = 0 then (Real.sqrt (p ij.1) : ℂ)
      else -(Real.sqrt (p ij.1) : ℂ)
    else 0

@[simp]
theorem ambientSignedSchmidtAmp_diag
    {m : ℕ} (p : Fin (m + 3) → ℝ) (j : Fin (m + 3)) :
    ambientSignedSchmidtAmp p (j, j) =
      if j = 0 then (Real.sqrt (p j) : ℂ)
      else -(Real.sqrt (p j) : ℂ) := by
  simp [ambientSignedSchmidtAmp]

@[simp]
theorem ambientSignedSchmidtAmp_offdiag
    {m : ℕ} (p : Fin (m + 3) → ℝ) (i j : Fin (m + 3))
    (hij : i ≠ j) :
    ambientSignedSchmidtAmp p (i, j) = 0 := by
  simp [ambientSignedSchmidtAmp, hij]

def ambientSignedSchmidtResource
    {m : ℕ} (p : Fin (m + 3) → ℝ)
    (hp : IsOrderedProbability p) :
    PureVector (Fin (m + 3) × Fin (m + 3)) where
  amp := ambientSignedSchmidtAmp p
  trace_rankOne_eq_one := by
    rw [Matrix.trace]
    simp only [Matrix.diag, rankOneMatrix_apply]
    rw [Fintype.sum_prod_type]
    have hsum : (∑ i, p i) = 1 :=
      (FiniteSchmidtData.sum_univ_eq_sum_ofFn p).trans hp.2.2
    have hsumC : ((∑ i, p i : ℝ) : ℂ) = 1 := by
      exact_mod_cast hsum
    rw [← hsumC]
    push_cast
    apply Finset.sum_congr rfl
    intro i hi
    rw [Finset.sum_eq_single i]
    · by_cases hi0 : i = 0
      · simp [ambientSignedSchmidtAmp, hi0]
        norm_cast
        simpa [pow_two] using Real.sq_sqrt (hp.2.1 0)
      · simp [ambientSignedSchmidtAmp, hi0]
        norm_cast
        simpa [pow_two] using Real.sq_sqrt (hp.2.1 i)
    · intro j hj hji
      have hij : i ≠ j := Ne.symm hji
      simp [ambientSignedSchmidtAmp, hij]
    · intro hnot
      exact False.elim (hnot (Finset.mem_univ i))

/-- The diagonal inclusion sends the signed Schmidt-coordinate vector to the
full bipartite resource amplitude, with exactly the paper's phase convention. -/
theorem schmidtDiagonalEmbedding_mulVec_signedEta
    {m : ℕ} (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p) :
    schmidtDiagonalEmbedding.mulVec
        (schmidtDataOfOrderedProbability p hp).eta =
      (ambientSignedSchmidtResource p hp).amp := by
  funext ij
  rcases ij with ⟨i, j⟩
  rw [schmidtDiagonalEmbedding_mulVec_apply]
  by_cases hij : i = j
  · subst j
    simp [ambientSignedSchmidtResource, ambientSignedSchmidtAmp,
      schmidtDataOfOrderedProbability, FiniteSchmidtData.ofOrderedProbability,
      FiniteSchmidtData.eta_apply]
  · simp [ambientSignedSchmidtResource, ambientSignedSchmidtAmp, hij]

/-- Orthogonal-complement projection on the signed Schmidt coordinates. -/
def signedSchmidtDiagonalPerpProjection
    {m : ℕ} (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p) :
    CMatrix (Fin (m + 3)) :=
  1 - rankOneMatrix (schmidtDataOfOrderedProbability p hp).eta

/-- The full bipartite resource projector intertwines the diagonal inclusion
with the coordinate-space projector. -/
theorem ambientPerpProjection_mul_schmidtDiagonalEmbedding
    {m : ℕ} (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p) :
    pureVectorPerpProjection (ambientSignedSchmidtResource p hp) *
        schmidtDiagonalEmbedding =
      schmidtDiagonalEmbedding * signedSchmidtDiagonalPerpProjection p hp := by
  have hAmp := schmidtDiagonalEmbedding_mulVec_signedEta p hp
  have hRank :
      rankOneMatrix (ambientSignedSchmidtResource p hp).amp =
        schmidtDiagonalEmbedding *
            rankOneMatrix (schmidtDataOfOrderedProbability p hp).eta *
          Matrix.conjTranspose schmidtDiagonalEmbedding := by
    rw [← hAmp]
    exact
      rankOneMatrix_mulVec_eq_mul_rankOneMatrix_mul_conjTranspose
        schmidtDiagonalEmbedding
          (schmidtDataOfOrderedProbability p hp).eta
  have hE :=
    schmidtDiagonalEmbedding_conjTranspose_mul_self (n := m + 3)
  rw [pureVectorPerpProjection, signedSchmidtDiagonalPerpProjection, hRank]
  rw [Matrix.sub_mul, Matrix.one_mul, Matrix.mul_sub, Matrix.mul_one]
  congr 1
  calc
    (schmidtDiagonalEmbedding *
          rankOneMatrix (schmidtDataOfOrderedProbability p hp).eta *
        Matrix.conjTranspose schmidtDiagonalEmbedding) *
        schmidtDiagonalEmbedding =
      schmidtDiagonalEmbedding *
          rankOneMatrix (schmidtDataOfOrderedProbability p hp).eta *
        (Matrix.conjTranspose schmidtDiagonalEmbedding *
          schmidtDiagonalEmbedding) := by
            simp only [Matrix.mul_assoc]
    _ = schmidtDiagonalEmbedding *
        rankOneMatrix (schmidtDataOfOrderedProbability p hp).eta := by
      rw [hE, Matrix.mul_one]

/-- Matrix multiplication by the coordinate projector is the raw-coordinate
form of `FiniteSchmidtData.etaPerpProjection`. -/
theorem signedSchmidtDiagonalPerpProjection_mulVec
    {m : ℕ} (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (u : Fin (m + 3) → ℂ) :
    (signedSchmidtDiagonalPerpProjection p hp).mulVec u =
      FiniteSchmidtData.coordinates
        ((schmidtDataOfOrderedProbability p hp).etaPerpProjection
          (WithLp.toLp 2 u)) := by
  rw [signedSchmidtDiagonalPerpProjection, Matrix.sub_mulVec,
    Matrix.one_mulVec, rankOneMatrix_mulVec_eq_dotProduct_smul]
  funext i
  simp [FiniteSchmidtData.coordinates,
    FiniteSchmidtData.etaPerpProjection, PiLp.inner_apply,
    RCLike.inner_apply, dotProduct, mul_comm]

@[simp]
theorem signedSchmidtDiagonalPerpProjection_mulVec_basis_zero
    {m : ℕ} (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p) :
    (signedSchmidtDiagonalPerpProjection p hp).mulVec
        (coordinateBasisVector (0 : Fin (m + 3))) =
      (schmidtDataOfOrderedProbability p hp).v0Coordinates := by
  rw [signedSchmidtDiagonalPerpProjection_mulVec]
  rfl

@[simp]
theorem signedSchmidtDiagonalPerpProjection_mulVec_basis_one
    {m : ℕ} (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p) :
    (signedSchmidtDiagonalPerpProjection p hp).mulVec
        (coordinateBasisVector (1 : Fin (m + 3))) =
      (schmidtDataOfOrderedProbability p hp).v1Coordinates := by
  rw [signedSchmidtDiagonalPerpProjection_mulVec]
  rfl

/-- The embedded Schmidt vector `v₀` is the full resource projection of
the physical diagonal basis ket `|0,0⟩`. -/
theorem schmidtDiagonalEmbedding_mulVec_v0Coordinates
    {m : ℕ} (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p) :
    schmidtDiagonalEmbedding.mulVec
        (schmidtDataOfOrderedProbability p hp).v0Coordinates =
      (pureVectorPerpProjection (ambientSignedSchmidtResource p hp)).mulVec
        (coordinateBasisVector
          ((0 : Fin (m + 3)), (0 : Fin (m + 3)))) := by
  have hmat := ambientPerpProjection_mul_schmidtDiagonalEmbedding p hp
  have hvec := congrArg
    (fun M => M.mulVec (coordinateBasisVector (0 : Fin (m + 3)))) hmat
  simp only [← Matrix.mulVec_mulVec] at hvec
  rw [schmidtDiagonalEmbedding_mulVec_basis,
    signedSchmidtDiagonalPerpProjection_mulVec_basis_zero] at hvec
  exact hvec.symm

/-- The analogous identity for `v₁` and `|1,1⟩`. -/
theorem schmidtDiagonalEmbedding_mulVec_v1Coordinates
    {m : ℕ} (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p) :
    schmidtDiagonalEmbedding.mulVec
        (schmidtDataOfOrderedProbability p hp).v1Coordinates =
      (pureVectorPerpProjection (ambientSignedSchmidtResource p hp)).mulVec
        (coordinateBasisVector
          ((1 : Fin (m + 3)), (1 : Fin (m + 3)))) := by
  have hmat := ambientPerpProjection_mul_schmidtDiagonalEmbedding p hp
  have hvec := congrArg
    (fun M => M.mulVec (coordinateBasisVector (1 : Fin (m + 3)))) hmat
  simp only [← Matrix.mulVec_mulVec] at hvec
  rw [schmidtDiagonalEmbedding_mulVec_basis,
    signedSchmidtDiagonalPerpProjection_mulVec_basis_one] at hvec
  exact hvec.symm

/-- Evaluating a quadratic form on a projected vector is the same as
evaluating the doubly compressed matrix on the original vector. -/
theorem quadraticRe_pureVectorPerpProjection_mulVec
    {r : Type*} [Fintype r] [DecidableEq r]
    (eta : PureVector r) (N : CMatrix r) (u : r → ℂ) :
    quadraticRe N ((pureVectorPerpProjection eta).mulVec u) =
      quadraticRe
        (pureVectorPerpProjection eta * N * pureVectorPerpProjection eta) u := by
  unfold quadraticRe
  rw [← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec]
  simp only [Matrix.star_mulVec, Matrix.dotProduct_mulVec,
    pureVectorPerpProjection_conjTranspose]

/-- Cross-form version of the preceding compression identity. -/
theorem effectCrossRe_pureVectorPerpProjection_mulVec
    {r : Type*} [Fintype r] [DecidableEq r]
    (eta : PureVector r) (N : CMatrix r) (u v : r → ℂ) :
    effectCrossRe N ((pureVectorPerpProjection eta).mulVec u)
        ((pureVectorPerpProjection eta).mulVec v) =
      effectCrossRe
        (pureVectorPerpProjection eta * N * pureVectorPerpProjection eta)
          u v := by
  unfold effectCrossRe cVecInnerRe
  rw [← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec]
  simp only [Matrix.star_mulVec, Matrix.dotProduct_mulVec,
    pureVectorPerpProjection_conjTranspose]

@[simp]
theorem quadraticRe_coordinateBasisVector
    {r : Type*} [Fintype r] [DecidableEq r]
    (M : CMatrix r) (i : r) :
    quadraticRe M (coordinateBasisVector i) = (M i i).re := by
  simp [quadraticRe]

@[simp]
theorem effectCrossRe_coordinateBasisVector
    {r : Type*} [Fintype r] [DecidableEq r]
    (M : CMatrix r) (i j : r) :
    effectCrossRe M (coordinateBasisVector i) (coordinateBasisVector j) =
      (M i j).re := by
  simp [effectCrossRe, cVecInnerRe]

namespace CompressedPPTInstrumentData

/-- The compressed PPT instrument supplies exactly the two projected Schmidt
effect inequalities consumed by Appendix B; neither inequality is a field of
`CompressedPPTInstrumentData`. -/
theorem projectedSchmidtEffect_certificate
    {d m : ℕ} (data :
      CompressedPPTInstrumentData d (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hresource : data.resource = ambientSignedSchmidtResource p hp) :
    let N := schmidtDiagonalCompression data.auxiliaryEffect
    IsEffectMatrix N ∧
      (1 / 3 : ℝ) ≤ quadraticRe N
        (schmidtDataOfOrderedProbability p hp).v0Coordinates ∧
      effectCrossRe N
          (schmidtDataOfOrderedProbability p hp).v0Coordinates
          (schmidtDataOfOrderedProbability p hp).v1Coordinates ≤ 1 / 3 := by
  let N := schmidtDiagonalCompression data.auxiliaryEffect
  have hdiagAmbient :=
    data.auxiliaryEffect_projected_diagonal_lower_bound hd
      ((0 : Fin (m + 3)), (0 : Fin (m + 3)))
  have hcrossAmbient :=
    data.auxiliaryEffect_projected_cross_upper_bound hd
      (0 : Fin (m + 3)) (1 : Fin (m + 3))
      (0 : Fin (m + 3)) (1 : Fin (m + 3)) Fin.zero_ne_one'
  rw [hresource] at hdiagAmbient hcrossAmbient
  have hdiag :
      (1 / 3 : ℝ) ≤ quadraticRe N
        (schmidtDataOfOrderedProbability p hp).v0Coordinates := by
    dsimp [N]
    rw [quadraticRe_schmidtDiagonalCompression,
      schmidtDiagonalEmbedding_mulVec_v0Coordinates,
      quadraticRe_pureVectorPerpProjection_mulVec,
      quadraticRe_coordinateBasisVector]
    exact hdiagAmbient
  have hcross :
      effectCrossRe N
          (schmidtDataOfOrderedProbability p hp).v0Coordinates
          (schmidtDataOfOrderedProbability p hp).v1Coordinates ≤ 1 / 3 := by
    dsimp [N]
    rw [effectCrossRe_schmidtDiagonalCompression,
      schmidtDiagonalEmbedding_mulVec_v0Coordinates,
      schmidtDiagonalEmbedding_mulVec_v1Coordinates,
      effectCrossRe_pureVectorPerpProjection_mulVec,
      effectCrossRe_coordinateBasisVector]
    exact hcrossAmbient
  exact ⟨schmidtDiagonalCompression_isEffect
      (data.auxiliaryEffect_isEffect hd), hdiag, hcross⟩

/-- End-to-end compressed-instrument version of the Appendix-B majorization
converse.  The PPT assumptions are contained in `data`; the only identification
hypothesis says that its resource is the paper's signed Schmidt resource. -/
theorem implies_schmidt_majorization
    {d m : ℕ} (data :
      CompressedPPTInstrumentData d (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hresource : data.resource = ambientSignedSchmidtResource p hp) :
    p 0 ≤ 2 / 3 ∧
      (p 0 ≤ 1 / 2 →
        PrefixMajorizedBy p (twoPointComparison (m + 1))) ∧
      (1 / 2 < p 0 →
        zStar (p 0) ≤ tailFromTwo p ∧
        2 * (p 0 - 1 / 2) ^ 2 < tailFromTwo p ∧
        PrefixMajorizedBy p
          (threePointComparison m (p 0) (zStar (p 0)))) := by
  have hcert := data.projectedSchmidtEffect_certificate hd p hp hresource
  exact projectedSchmidtEffectConstraints_imply_majorization hp
    hcert.1 hcert.2.1 hcert.2.2

/-- In particular, the resource collision probability is at most one half,
the quantitative endpoint used in the entanglement-cost converse. -/
theorem implies_collisionProbability_le_half
    {d m : ℕ} (data :
      CompressedPPTInstrumentData d (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hresource : data.resource = ambientSignedSchmidtResource p hp) :
    collisionProbability p ≤ 1 / 2 := by
  have hcert := data.projectedSchmidtEffect_certificate hd p hp hresource
  exact projectedSchmidtEffectConstraints_imply_collisionProbability_le_half hp
    hcert.1 hcert.2.1 hcert.2.2

end CompressedPPTInstrumentData

end

end EntanglementPurification
