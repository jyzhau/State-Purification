import EntanglementPurification.PPTResourceEffect
import EntanglementPurification.PPTPartialTranspose

/-!
# Compressed branchwise-PPT success/failure data

This module records the exact finite-matrix output of the local mixed-Schur
reduction used in `main.tex`.  Its fields are branch positivity/PPT, the four
output-trace sector coefficients, their success/failure complement identity,
and the residual-sector trace decomposition.  The lemmas below derive the
smaller collection of inequalities consumed by the two PPT test vectors.

The structure is an intermediate interface, not a replacement for the
physical local-twirl theorem: a later wrapper constructs it from physical Choi
branches.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

/-- Reciprocal contraction coefficient in each of the four local parity
sectors, as in `eq:branch_sector_trace_decomposition`. -/
def localSectorTraceScale (d : ℕ) : LocalMultiplicitySector → ℝ
  | (.plus, .plus) => 1 / (localContractionAlpha d) ^ 2
  | (.plus, .minus) =>
      1 / (localContractionAlpha d * localContractionBeta d)
  | (.minus, .plus) =>
      1 / (localContractionAlpha d * localContractionBeta d)
  | (.minus, .minus) => 1 / (localContractionBeta d) ^ 2

/-- The locally compressed data of a success/failure instrument around a pure
resource.  Every field corresponds to an equation or positivity statement in
`main.tex`, rather than to one of the final desired effect inequalities. -/
structure CompressedPPTInstrumentData
    (d : ℕ) (ra rb : Type*)
    [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb] where
  resource : PureVector (ra × rb)
  success : CMatrix (LocalMultiplicitySector × (ra × rb))
  outputSuccess : LocalMultiplicitySector → CMatrix (ra × rb)
  outputFailure : LocalMultiplicitySector → CMatrix (ra × rb)
  residualSuccess : LocalMultiplicitySector → CMatrix (ra × rb)
  success_branchPPT : BranchPPT success
  outputSuccess_pos : ∀ z, (outputSuccess z).PosSemidef
  outputFailure_pos : ∀ z, (outputFailure z).PosSemidef
  outputFailure_ppt : ∀ z, (QIT.partialTransposeB (outputFailure z)).PosSemidef
  output_complement : ∀ z, outputSuccess z + outputFailure z = 1
  success_trace_decomposition : ∀ z,
    outputSuccess z =
      localSectorTraceScale d z • resourceSectorBlock success z z +
        residualSuccess z
  residualSuccess_pos : ∀ z, (residualSuccess z).PosSemidef
  inserted_optimal :
    insertPureResourceBlock resource.amp success =
      rankOneMatrix (localOptimalMultiplicityVector d)
  zero_output_PM :
    dotProduct (star resource.amp)
      ((outputSuccess sectorPM).mulVec resource.amp) = 0
  zero_output_MP :
    dotProduct (star resource.amp)
      ((outputSuccess sectorMP).mulVec resource.amp) = 0

namespace CompressedPPTInstrumentData

variable {d : ℕ} {ra rb : Type*}
  [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]

/-- `Q` in `eq:cross_sector_budget_definition`. -/
def crossSectorBudget
    (data : CompressedPPTInstrumentData d ra rb) : CMatrix (ra × rb) :=
  data.outputSuccess sectorPM + data.outputSuccess sectorMP

/-- Sum of the two contraction-sector diagonal blocks entering the PPT tests. -/
def mixedContractionDiagonal
    (data : CompressedPPTInstrumentData d ra rb) : CMatrix (ra × rb) :=
  resourceSectorBlock data.success sectorPM sectorPM +
    resourceSectorBlock data.success sectorMP sectorMP

/-- Positive residual contribution to the cross-sector success budget. -/
def mixedResidualBudget
    (data : CompressedPPTInstrumentData d ra rb) : CMatrix (ra × rb) :=
  data.residualSuccess sectorPM + data.residualSuccess sectorMP

/-- Sum of the two failure output-trace sectors used in the Bell test. -/
def mixedFailureBudget
    (data : CompressedPPTInstrumentData d ra rb) : CMatrix (ra × rb) :=
  data.outputFailure sectorPM + data.outputFailure sectorMP

theorem outputSuccess_le_one
    (data : CompressedPPTInstrumentData d ra rb)
    (z : LocalMultiplicitySector) :
    data.outputSuccess z ≤ (1 : CMatrix (ra × rb)) := by
  rw [Matrix.le_iff]
  have hcomp :
      (1 : CMatrix (ra × rb)) - data.outputSuccess z =
        data.outputFailure z := by
    rw [← data.output_complement z]
    abel
  rw [hcomp]
  exact data.outputFailure_pos z

private theorem diagonal_block_upper_of_trace_decomposition
    {r : Type*} [Fintype r] [DecidableEq r]
    (c : ℝ) (hc : 0 < c) (A T R : CMatrix r)
    (hdecomp : T = (1 / c ^ 2 : ℝ) • A + R)
    (hR : R.PosSemidef) (hT : T ≤ (1 : CMatrix r)) :
    A ≤ c ^ 2 • (1 : CMatrix r) := by
  have hsmall : (1 / c ^ 2 : ℝ) • A ≤ T := by
    rw [Matrix.le_iff, hdecomp]
    (convert hR using 1; module)
  have hsmallOne := hsmall.trans hT
  have hscaled := cMatrix_real_smul_le_smul (sq_nonneg c) hsmallOne
  have hcancel : c ^ 2 * (1 / c ^ 2) = (1 : ℝ) := by
    field_simp [ne_of_gt hc]
  have hcancelInv : c ^ 2 * (c ^ 2)⁻¹ = (1 : ℝ) := by
    field_simp [ne_of_gt hc]
  simpa [one_div, smul_smul, hcancel, hcancelInv] using hscaled

theorem success_PP_upper
    (data : CompressedPPTInstrumentData d ra rb) :
    resourceSectorBlock data.success sectorPP sectorPP ≤
      (localContractionAlpha d) ^ 2 • (1 : CMatrix (ra × rb)) := by
  have halpha : 0 < localContractionAlpha d := by
    unfold localContractionAlpha
    positivity
  apply diagonal_block_upper_of_trace_decomposition
    (localContractionAlpha d) halpha
    (resourceSectorBlock data.success sectorPP sectorPP)
    (data.outputSuccess sectorPP) (data.residualSuccess sectorPP)
  · simpa [localSectorTraceScale, sectorPP] using
      data.success_trace_decomposition sectorPP
  · exact data.residualSuccess_pos sectorPP
  · exact data.outputSuccess_le_one sectorPP

theorem success_MM_upper
    (data : CompressedPPTInstrumentData d ra rb) (hd : 2 ≤ d) :
    resourceSectorBlock data.success sectorMM sectorMM ≤
      (localContractionBeta d) ^ 2 • (1 : CMatrix (ra × rb)) := by
  have hdR : (1 : ℝ) < (d : ℝ) := by exact_mod_cast hd
  have hbeta : 0 < localContractionBeta d := by
    unfold localContractionBeta
    positivity
  apply diagonal_block_upper_of_trace_decomposition
    (localContractionBeta d) hbeta
    (resourceSectorBlock data.success sectorMM sectorMM)
    (data.outputSuccess sectorMM) (data.residualSuccess sectorMM)
  · simpa [localSectorTraceScale, sectorMM] using
      data.success_trace_decomposition sectorMM
  · exact data.residualSuccess_pos sectorMM
  · exact data.outputSuccess_le_one sectorMM

theorem crossSectorBudget_posSemidef
    (data : CompressedPPTInstrumentData d ra rb) :
    data.crossSectorBudget.PosSemidef :=
  (data.outputSuccess_pos sectorPM).add (data.outputSuccess_pos sectorMP)

theorem crossSectorBudget_le_two
    (data : CompressedPPTInstrumentData d ra rb) :
    data.crossSectorBudget ≤ (2 : ℝ) • (1 : CMatrix (ra × rb)) := by
  have h := add_le_add (data.outputSuccess_le_one sectorPM)
    (data.outputSuccess_le_one sectorMP)
  simpa [crossSectorBudget, two_smul ℝ] using h

theorem crossSectorBudget_mulVec_resource_eq_zero
    (data : CompressedPPTInstrumentData d ra rb) :
    data.crossSectorBudget.mulVec data.resource.amp = 0 := by
  have hPM :=
    ((data.outputSuccess_pos sectorPM).dotProduct_mulVec_zero_iff
      data.resource.amp).mp data.zero_output_PM
  have hMP :=
    ((data.outputSuccess_pos sectorMP).dotProduct_mulVec_zero_iff
      data.resource.amp).mp data.zero_output_MP
  simp [crossSectorBudget, Matrix.add_mulVec, hPM, hMP]

theorem crossSectorBudget_eq_perp_compression
    (data : CompressedPPTInstrumentData d ra rb) :
    data.crossSectorBudget =
      pureVectorPerpProjection data.resource * data.crossSectorBudget *
        pureVectorPerpProjection data.resource := by
  have hQ := data.crossSectorBudget_mulVec_resource_eq_zero
  have hQstar :
      (Matrix.conjTranspose data.crossSectorBudget).mulVec data.resource.amp = 0 := by
    rw [data.crossSectorBudget_posSemidef.isHermitian.eq]
    exact hQ
  have hQ' :
      data.crossSectorBudget.mulVec data.resource.amp =
        (0 : ℂ) • data.resource.amp := by simpa using hQ
  have hQstar' :
      (Matrix.conjTranspose data.crossSectorBudget).mulVec data.resource.amp =
        (0 : ℂ) • data.resource.amp := by simpa using hQstar
  simpa using matrix_eq_eigen_rankOne_add_perp_compression
    data.resource data.crossSectorBudget 0 hQ' hQstar'

theorem mixedResidualBudget_posSemidef
    (data : CompressedPPTInstrumentData d ra rb) :
    data.mixedResidualBudget.PosSemidef :=
  (data.residualSuccess_pos sectorPM).add
    (data.residualSuccess_pos sectorMP)

/-- Equation `eq:cross_sector_budget_decomposition`, including its exact
positive residual rather than only the resulting order inequality. -/
theorem crossSectorBudget_decomposition
    (data : CompressedPPTInstrumentData d ra rb) :
    data.crossSectorBudget =
      (1 / (localContractionAlpha d * localContractionBeta d) : ℝ) •
          data.mixedContractionDiagonal + data.mixedResidualBudget := by
  rw [crossSectorBudget, mixedContractionDiagonal, mixedResidualBudget,
    data.success_trace_decomposition sectorPM,
    data.success_trace_decomposition sectorMP]
  simp only [localSectorTraceScale, sectorPM, sectorMP]
  module

theorem crossSectorBudget_sub_scaled_diagonal_posSemidef
    (data : CompressedPPTInstrumentData d ra rb) :
    (data.crossSectorBudget -
      (1 / (localContractionAlpha d * localContractionBeta d) : ℝ) •
        data.mixedContractionDiagonal).PosSemidef := by
  rw [data.crossSectorBudget_decomposition]
  simpa using data.mixedResidualBudget_posSemidef

theorem mixedContractionDiagonal_posSemidef
    (data : CompressedPPTInstrumentData d ra rb) :
    data.mixedContractionDiagonal.PosSemidef :=
  (resourceSectorBlock_diag_posSemidef data.success_branchPPT.1 sectorPM).add
    (resourceSectorBlock_diag_posSemidef data.success_branchPPT.1 sectorMP)

theorem mixedContractionDiagonal_mulVec_resource_eq_zero
    (data : CompressedPPTInstrumentData d ra rb) (hd : 2 ≤ d) :
    data.mixedContractionDiagonal.mulVec data.resource.amp = 0 := by
  rcases inserted_optimal_forces_diagonal_block_actions d data.resource.amp
      (EntanglementPurification.PureVector.isNormalizedResourceVector
        data.resource)
      data.success_branchPPT.1 data.inserted_optimal data.success_PP_upper
      (data.success_MM_upper hd) with ⟨hPM, hMP, _, _⟩
  simp [mixedContractionDiagonal, Matrix.add_mulVec, hPM, hMP]

theorem mixedContractionDiagonal_eq_perp_compression
    (data : CompressedPPTInstrumentData d ra rb) (hd : 2 ≤ d) :
    data.mixedContractionDiagonal =
      pureVectorPerpProjection data.resource *
        data.mixedContractionDiagonal *
        pureVectorPerpProjection data.resource := by
  have hD := data.mixedContractionDiagonal_mulVec_resource_eq_zero hd
  have hDstar :
      (Matrix.conjTranspose data.mixedContractionDiagonal).mulVec
          data.resource.amp = 0 := by
    rw [data.mixedContractionDiagonal_posSemidef.isHermitian.eq]
    exact hD
  have hD' : data.mixedContractionDiagonal.mulVec data.resource.amp =
      (0 : ℂ) • data.resource.amp := by simpa using hD
  have hDstar' :
      (Matrix.conjTranspose data.mixedContractionDiagonal).mulVec
          data.resource.amp = (0 : ℂ) • data.resource.amp := by
    simpa using hDstar
  simpa using matrix_eq_eigen_rankOne_add_perp_compression data.resource
    data.mixedContractionDiagonal 0 hD' hDstar'

/-- Sum form of `eq:forced_offdiagonal_block_decompositions`. -/
theorem crossBlockHermitian_decomposition
    (data : CompressedPPTInstrumentData d ra rb) (hd : 2 ≤ d) :
    resourceSectorBlock data.success sectorPP sectorMM +
        Matrix.conjTranspose
          (resourceSectorBlock data.success sectorPP sectorMM) =
      (((2 * (localContractionAlpha d * localContractionBeta d) : ℝ) : ℂ) •
          rankOneMatrix data.resource.amp) +
        pureVectorPerpProjection data.resource *
          (resourceSectorBlock data.success sectorPP sectorMM +
            Matrix.conjTranspose
              (resourceSectorBlock data.success sectorPP sectorMM)) *
          pureVectorPerpProjection data.resource := by
  have hAdj :
      Matrix.conjTranspose
          (resourceSectorBlock data.success sectorPP sectorMM) =
        resourceSectorBlock data.success sectorMM sectorPP :=
    resourceSectorBlock_conjTranspose data.success_branchPPT.1.isHermitian
      sectorPP sectorMM
  rcases inserted_optimal_forces_off_diagonal_block_decompositions
      d hd data.resource data.success_branchPPT.1 data.inserted_optimal
      data.success_PP_upper (data.success_MM_upper hd) with ⟨hC, hCstar⟩
  rw [hAdj]
  calc
    resourceSectorBlock data.success sectorPP sectorMM +
          resourceSectorBlock data.success sectorMM sectorPP =
        ((((localContractionAlpha d * localContractionBeta d : ℝ) : ℂ) •
            rankOneMatrix data.resource.amp) +
          pureVectorPerpProjection data.resource *
            resourceSectorBlock data.success sectorPP sectorMM *
            pureVectorPerpProjection data.resource) +
        ((((localContractionAlpha d * localContractionBeta d : ℝ) : ℂ) •
            rankOneMatrix data.resource.amp) +
          pureVectorPerpProjection data.resource *
            resourceSectorBlock data.success sectorMM sectorPP *
            pureVectorPerpProjection data.resource) :=
      congrArg₂ (· + ·) hC hCstar
    _ =
        (((2 * (localContractionAlpha d * localContractionBeta d) : ℝ) : ℂ) •
            rankOneMatrix data.resource.amp) +
          pureVectorPerpProjection data.resource *
            (resourceSectorBlock data.success sectorPP sectorMM +
              resourceSectorBlock data.success sectorMM sectorPP) *
            pureVectorPerpProjection data.resource := by
      rw [Matrix.mul_add, Matrix.add_mul]
      push_cast
      module

theorem mixedFailureBudget_eq_two_sub_crossSectorBudget
    (data : CompressedPPTInstrumentData d ra rb) :
    data.mixedFailureBudget =
      (2 : ℝ) • (1 : CMatrix (ra × rb)) - data.crossSectorBudget := by
  rw [mixedFailureBudget, crossSectorBudget]
  have hPM : data.outputFailure sectorPM =
      (1 : CMatrix (ra × rb)) - data.outputSuccess sectorPM := by
    rw [← data.output_complement sectorPM]
    abel
  have hMP : data.outputFailure sectorMP =
      (1 : CMatrix (ra × rb)) - data.outputSuccess sectorMP := by
    rw [← data.output_complement sectorMP]
    abel
  rw [hPM, hMP]
  module

theorem partialTransposeB_mixedFailureBudget_posSemidef
    (data : CompressedPPTInstrumentData d ra rb) :
    (QIT.partialTransposeB data.mixedFailureBudget).PosSemidef := by
  have h := (data.outputFailure_ppt sectorPM).add
    (data.outputFailure_ppt sectorMP)
  simpa [mixedFailureBudget, QIT.partialTransposeB] using h

/-- The auxiliary resource effect attached to the compressed instrument. -/
def auxiliaryEffect
    (data : CompressedPPTInstrumentData d ra rb) : CMatrix (ra × rb) :=
  sectorPPTAuxiliaryResourceEffect data.resource d data.success
    data.crossSectorBudget

/-- The compressed success/failure identities derive every operator-order
hypothesis needed to make the paper's auxiliary operator an effect. -/
theorem auxiliaryEffect_isEffect
    (data : CompressedPPTInstrumentData d ra rb) (hd : 2 ≤ d) :
    IsEffectMatrix data.auxiliaryEffect := by
  exact sectorPPTAuxiliaryResourceEffect_isEffect d hd data.resource
    data.success_branchPPT.1 data.success_PP_upper (data.success_MM_upper hd)
    data.crossSectorBudget_posSemidef data.crossSectorBudget_le_two

end CompressedPPTInstrumentData

end

end EntanglementPurification
