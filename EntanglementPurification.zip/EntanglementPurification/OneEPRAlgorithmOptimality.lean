import EntanglementPurification.OneEPRProjectorBridge
import Mathlib.Tactic

/-!
# Algorithm 1: algebraic sufficiency certificate

This file packages the verified finite-coordinate calculation for Algorithm 1.
The accepted branch first coarse-grains the two equal control outcomes and then
discards the second noisy copy.  The resulting matrix map is proved equal to
`oneEPRAcceptedMap`, so its complete positivity, trace nonincrease, optimal
Choi matrix, and Haar-averaged gain follow from the existing global theorem.

The statement is intentionally at the concrete circuit/map level.  It does
not claim that Lean-QIT currently supplies a general entanglement-assisted
finite-round LOCC syntax in which the whole protocol has been constructed.
-/

namespace EntanglementPurification

open QIT

noncomputable section

/-- The resource amplitude used by the circuit is not an ad hoc vector: it
is exactly QIT's canonical maximally entangled vector on two Boolean qubits. -/
theorem standardEPRAmp_eq_qitMaximallyEntangled_amp :
    standardEPRAmp =
      (PureVector.maximallyEntangled (Equiv.refl Bool)).amp := by
  funext p
  rcases p with ⟨i, j⟩
  cases i <;> cases j <;>
    norm_num [standardEPRAmp, PureVector.maximallyEntangled_amp,
      PureVector.maximallyEntangled, TwoQubit.invSqrtTwo]

/-- Matrix form of the local Hadamard amplitudes used in the circuit. -/
def oneEPRHadamardMatrix : CMatrix Bool :=
  fun output input => hadamardAmp output input

/-- The circuit's explicit Hadamard matrix is unitary. -/
theorem oneEPRHadamardMatrix_mul_conjTranspose :
    oneEPRHadamardMatrix * Matrix.conjTranspose oneEPRHadamardMatrix = 1 := by
  ext i j
  cases i <;> cases j <;>
    norm_num [oneEPRHadamardMatrix, hadamardAmp, Matrix.mul_apply,
      TwoQubit.invSqrtTwo_mul_starRingEnd_invSqrtTwo,
      TwoQubit.invSqrtTwo_mul_self]

/-- The accepted Algorithm 1 circuit map: retain the two equal Hadamard
outcomes and then discard the second bipartite copy. -/
def oneEPRAlgorithmAcceptedCircuitMap
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    MatrixMap (Prod (Prod a b) (Prod a b)) (Prod a b) :=
  (MatrixMap.partialTraceB (Prod a b) (Prod a b)).comp
    (oneEPREqualOutcomeTwoCopyMap (a := a) (b := b))

/-- The concrete accepted circuit is exactly the previously certified
one-EPR optimal map. -/
theorem oneEPRAlgorithmAcceptedCircuitMap_eq_oneEPRAcceptedMap
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    oneEPRAlgorithmAcceptedCircuitMap (a := a) (b := b) =
      oneEPRAcceptedMap (x := Prod a b) := by
  apply LinearMap.ext
  intro X
  exact oneEPREqualOutcome_then_discard_eq_oneEPRAcceptedMap X

/-- The accepted Algorithm 1 circuit is a completely positive,
trace-nonincreasing map. -/
theorem oneEPRAlgorithmAcceptedCircuitMap_traceNonincreasingCP
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    MatrixMap.TraceNonincreasingCP
      (oneEPRAlgorithmAcceptedCircuitMap (a := a) (b := b)) := by
  rw [oneEPRAlgorithmAcceptedCircuitMap_eq_oneEPRAcceptedMap]
  exact oneEPRAcceptedMap_traceNonincreasingCP

/-- The circuit's accepted Choi matrix is exactly the unique global
optimizer used by the paper. -/
theorem choi_oneEPRAlgorithmAcceptedCircuitMap_eq_globalOptimalChoi
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    MatrixMap.choi (oneEPRAlgorithmAcceptedCircuitMap (a := a) (b := b)) =
      globalOptimalChoi (x := Prod a b) := by
  rw [oneEPRAlgorithmAcceptedCircuitMap_eq_oneEPRAcceptedMap]
  exact choi_oneEPRAcceptedMap_eq_globalOptimalChoi

/-- In paper dimension `D = d^2`, the concrete accepted circuit reaches the
globally optimal Haar-averaged fidelity gain. -/
theorem oneEPRAlgorithmAcceptedCircuitMap_attains_globalPaperHaar_gain
    {d : Nat} (hd : 2 <= d)
    (nu : PureVector (GlobalPaperIndex d))
    (gamma : Real) :
    globalSDPObjective
        (globalPaperHaarPerformanceOperator hd nu gamma)
        (MatrixMap.choi
          (oneEPRAlgorithmAcceptedCircuitMap (a := Fin d) (b := Fin d))) =
      globalOptimalGain ((d : Real) ^ 2) gamma := by
  rw [oneEPRAlgorithmAcceptedCircuitMap_eq_oneEPRAcceptedMap]
  exact oneEPRAcceptedMap_attains_globalPaperHaar_gain hd nu gamma

/-- Headline sufficiency certificate for Algorithm 1.  It records in one
statement the circuit-to-map bridge, physical admissibility of the accepted
branch, the optimal Choi identity, and exact attainment of the paper gain.

No general-purpose LOCC witness is asserted here; the local gate calculation
is the one proved in `OneEPRProjectorBridge`. -/
theorem oneEPRAlgorithm_sufficiency_certificate
    {d : Nat} (hd : 2 <= d)
    (nu : PureVector (GlobalPaperIndex d))
    (gamma : Real) :
    (oneEPRAlgorithmAcceptedCircuitMap (a := Fin d) (b := Fin d) =
        oneEPRAcceptedMap (x := GlobalPaperIndex d)) /\
    MatrixMap.TraceNonincreasingCP
      (oneEPRAlgorithmAcceptedCircuitMap (a := Fin d) (b := Fin d)) /\
    MatrixMap.choi
        (oneEPRAlgorithmAcceptedCircuitMap (a := Fin d) (b := Fin d)) =
      globalOptimalChoi (x := GlobalPaperIndex d) /\
    globalSDPObjective
        (globalPaperHaarPerformanceOperator hd nu gamma)
        (MatrixMap.choi
          (oneEPRAlgorithmAcceptedCircuitMap (a := Fin d) (b := Fin d))) =
      globalOptimalGain ((d : Real) ^ 2) gamma := by
  exact And.intro
    oneEPRAlgorithmAcceptedCircuitMap_eq_oneEPRAcceptedMap
    (And.intro
      oneEPRAlgorithmAcceptedCircuitMap_traceNonincreasingCP
      (And.intro
        choi_oneEPRAlgorithmAcceptedCircuitMap_eq_globalOptimalChoi
        (oneEPRAlgorithmAcceptedCircuitMap_attains_globalPaperHaar_gain
          hd nu gamma)))

end

end EntanglementPurification
