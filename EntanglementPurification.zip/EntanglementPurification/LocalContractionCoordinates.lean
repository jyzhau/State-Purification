import EntanglementPurification.LocalMixedSchur
import EntanglementPurification.PPTSectorBlocks

/-!
# Local contraction-sector coordinates

This file formalizes the one-side matrix identities in lines 2133--2190 of
`main.tex`.  The two normalized contraction maps `W₊` and `W₋` are assembled
as the two multiplicity blocks of a single coordinate isometry `G_X`.

No new mixed Schur--Weyl decomposition is assumed here: all orthogonality,
covariance, and input-swap facts are reused from `LocalMixedSchur`.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {x : Type*} [Fintype x] [DecidableEq x]

/-- Select the normalized local contraction map belonging to a parity label. -/
def localWByParity (s : LocalParity) :
    Matrix (LocalMixedSchurSpace x) x ℂ :=
  match s with
  | .plus => localWPlus
  | .minus => localWMinus

/-- The paper's local contraction coordinate isometry `G_X`.  Its `+` block
is `W₊`, and its `-` block is `W₋`. -/
def localContractionCoordinates :
    Matrix (LocalMixedSchurSpace x) (LocalParity × x) ℂ :=
  fun p q => localWByParity q.1 p q.2

@[simp]
theorem localContractionCoordinates_apply_plus
    (p : LocalMixedSchurSpace x) (a : x) :
    localContractionCoordinates p (.plus, a) = localWPlus p a :=
  rfl

@[simp]
theorem localContractionCoordinates_apply_minus
    (p : LocalMixedSchurSpace x) (a : x) :
    localContractionCoordinates p (.minus, a) = localWMinus p a :=
  rfl

/-- The coordinate matrix unit `|s><t|` on the two-dimensional local
multiplicity space. -/
def localParityMatrixUnit (s t : LocalParity) : CMatrix LocalParity :=
  fun u v => if u = s ∧ v = t then 1 else 0

/-- The coordinate operator `|s><t| ⊗ I_x` on the local contraction
component. -/
def localContractionCoordinateMatrixUnit (s t : LocalParity) :
    CMatrix (LocalParity × x) :=
  Matrix.kronecker (localParityMatrixUnit s t) (1 : CMatrix x)

/-- Embedding a coordinate matrix unit by `G_X` gives the corresponding
physical contraction block `W_s W_t†`.  This is the one-side building block
for `eq:resource_contraction_element_correspondence` in `main.tex`. -/
theorem localContractionEmbedding_coordinateMatrixUnit (s t : LocalParity) :
    localContractionCoordinates (x := x) *
          localContractionCoordinateMatrixUnit (x := x) s t *
          Matrix.conjTranspose localContractionCoordinates =
      localWByParity s * Matrix.conjTranspose (localWByParity t) := by
  ext p q
  cases s <;> cases t <;>
    simp [localContractionCoordinateMatrixUnit, localParityMatrixUnit,
      localContractionCoordinates, localWByParity, Matrix.kronecker,
      Matrix.mul_apply, Fintype.sum_prod_type, sum_localParity,
      Matrix.one_apply, Matrix.conjTranspose_apply]

/-- The representation on contraction coordinates is
`I_{LocalParity} ⊗ bar U`. -/
def localContractionCoordinateRepresentation
    (U : Matrix.unitaryGroup x ℂ) : CMatrix (LocalParity × x) :=
  Matrix.kronecker (1 : CMatrix LocalParity) (localEntrywiseConjugate U)

/-- The multiplicity sign operator `|+><+| - |-><-|`. -/
def localParitySign : CMatrix LocalParity
  | .plus, .plus => 1
  | .minus, .minus => -1
  | _, _ => 0

/-- The input swap in contraction coordinates:
`(|+><+| - |-><-|) ⊗ I`. -/
def localContractionInputSwapCoordinates : CMatrix (LocalParity × x) :=
  Matrix.kronecker localParitySign (1 : CMatrix x)

/-- Equation `G_X† G_X = I`. -/
theorem localContractionCoordinates_conjTranspose_mul_self
    (hcard : 2 ≤ Fintype.card x) :
    Matrix.conjTranspose (localContractionCoordinates (x := x)) *
        localContractionCoordinates =
      (1 : CMatrix (LocalParity × x)) := by
  ext p q
  rcases p with ⟨s, a⟩
  rcases q with ⟨t, b⟩
  cases s <;> cases t
  · change
      ((Matrix.conjTranspose (localWPlus (x := x)) *
        localWPlus (x := x)) : CMatrix x) a b =
        (1 : CMatrix (LocalParity × x)) (.plus, a) (.plus, b)
    rw [globalWPlus_conjTranspose_mul_self]
    simp [Matrix.one_apply]
  · change
      ((Matrix.conjTranspose (localWPlus (x := x)) *
        localWMinus (x := x)) : CMatrix x) a b =
        (1 : CMatrix (LocalParity × x)) (.plus, a) (.minus, b)
    rw [globalWPlus_conjTranspose_mul_globalWMinus]
    simp
  · change
      ((Matrix.conjTranspose (localWMinus (x := x)) *
        localWPlus (x := x)) : CMatrix x) a b =
        (1 : CMatrix (LocalParity × x)) (.minus, a) (.plus, b)
    rw [globalWMinus_conjTranspose_mul_globalWPlus]
    simp
  · change
      ((Matrix.conjTranspose (localWMinus (x := x)) *
        localWMinus (x := x)) : CMatrix x) a b =
        (1 : CMatrix (LocalParity × x)) (.minus, a) (.minus, b)
    rw [globalWMinus_conjTranspose_mul_self hcard]
    simp [Matrix.one_apply]

/-- First identity in `eq:local_contraction_representation_coordinates`:
`π_X(U) G_X = G_X (I_M ⊗ bar U)`. -/
theorem localContractionCoordinates_intertwines
    (U : Matrix.unitaryGroup x ℂ) :
    localMixedSchurRepresentation U *
        localContractionCoordinates (x := x) =
      localContractionCoordinates *
        localContractionCoordinateRepresentation U := by
  ext p q
  rcases q with ⟨s, a⟩
  cases s
  · have h := congrFun
      (congrFun (localWPlus_intertwines (x := x) U) p) a
    simpa [localContractionCoordinates,
      localContractionCoordinateRepresentation, localWByParity,
      Matrix.mul_apply, Matrix.kronecker, Fintype.sum_prod_type,
      sum_localParity, Matrix.one_apply] using h
  · have h := congrFun
      (congrFun (localWMinus_intertwines (x := x) U) p) a
    simpa [localContractionCoordinates,
      localContractionCoordinateRepresentation, localWByParity,
      Matrix.mul_apply, Matrix.kronecker, Fintype.sum_prod_type,
      sum_localParity, Matrix.one_apply] using h

private theorem localInputSwap_mul_localContractionCoordinates :
    localInputSwap (x := x) * localContractionCoordinates =
      localContractionCoordinates *
        localContractionInputSwapCoordinates := by
  ext p q
  rcases q with ⟨s, a⟩
  cases s
  · have h := congrFun
      (congrFun (globalInputSwap_mul_globalWPlus (x := x)) p) a
    simpa [localContractionCoordinates,
      localContractionInputSwapCoordinates, localParitySign, localWByParity,
      Matrix.mul_apply, Matrix.kronecker, Fintype.sum_prod_type,
      sum_localParity, Matrix.one_apply] using h
  · have h := congrFun
      (congrFun (globalInputSwap_mul_globalWMinus (x := x)) p) a
    simpa [localContractionCoordinates,
      localContractionInputSwapCoordinates, localParitySign, localWByParity,
      Matrix.mul_apply, Matrix.kronecker, Fintype.sum_prod_type,
      sum_localParity, Matrix.one_apply] using h

/-- Second identity in `eq:local_contraction_representation_coordinates`:
compressing the physical input swap by `G_X` gives the parity-sign operator
tensored with the identity on the conjugate-fundamental coordinate. -/
theorem localContractionCoordinates_inputSwap_compression
    (hcard : 2 ≤ Fintype.card x) :
    Matrix.conjTranspose (localContractionCoordinates (x := x)) *
        localInputSwap * localContractionCoordinates =
      localContractionInputSwapCoordinates := by
  calc
    Matrix.conjTranspose (localContractionCoordinates (x := x)) *
          localInputSwap * localContractionCoordinates =
        Matrix.conjTranspose localContractionCoordinates *
          (localInputSwap * localContractionCoordinates) := by
            rw [Matrix.mul_assoc]
    _ = Matrix.conjTranspose localContractionCoordinates *
          (localContractionCoordinates *
            localContractionInputSwapCoordinates) := by
          rw [localInputSwap_mul_localContractionCoordinates]
    _ = (Matrix.conjTranspose localContractionCoordinates *
          localContractionCoordinates) *
            localContractionInputSwapCoordinates := by
          rw [Matrix.mul_assoc]
    _ = localContractionInputSwapCoordinates := by
          rw [localContractionCoordinates_conjTranspose_mul_self hcard,
            Matrix.one_mul]

end

end EntanglementPurification
