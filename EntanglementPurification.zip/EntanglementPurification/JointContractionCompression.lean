import EntanglementPurification.LocalContractionCoordinates

/-!
# Resource-extended joint contraction compression

This file gives the finite-matrix skeleton of lines 2313--2457 of `main.tex`.
It combines the local contraction coordinate isometries for Alice and Bob,
extends them by the identity on the assisting resource, and explicitly reorders
the tensor indices into the paper's convention

`((multiplicity_A, multiplicity_B), resource), (coordinate_A, coordinate_B)`.

Only isometry, congruence, projection, and representation-intertwining facts
are proved here.  No Schur-lemma coefficient decomposition is assumed.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b r : Type*}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

/-- Physical order `H_A ⊗ H_B ⊗ R`. -/
abbrev JointContractionPhysicalIndex (a b r : Type*) :=
  (LocalMixedSchurSpace a × LocalMixedSchurSpace b) × r

/-- The direct Kronecker-product order before regrouping tensor factors. -/
abbrev JointContractionCanonicalIndex (a b r : Type*) :=
  (((LocalParity × a) × (LocalParity × b)) × r)

/-- The paper's order `M_AB ⊗ R ⊗ A ⊗ B`. -/
abbrev JointContractionCoordinateIndex (a b r : Type*) :=
  ((LocalMultiplicitySector × r) × (a × b))

/-- Regroup the direct Kronecker-product coordinates into the paper's order. -/
def jointContractionCoordinateEquiv :
    JointContractionCanonicalIndex a b r ≃
      JointContractionCoordinateIndex a b r where
  toFun q := (((q.1.1.1, q.1.2.1), q.2), (q.1.1.2, q.1.2.2))
  invFun q := (((q.1.1.1, q.2.1), (q.1.1.2, q.2.2)), q.1.2)
  left_inv q := by
    rcases q with ⟨⟨⟨sA, i⟩, ⟨sB, j⟩⟩, z⟩
    rfl
  right_inv q := by
    rcases q with ⟨⟨⟨sA, sB⟩, z⟩, ⟨i, j⟩⟩
    rfl

/-- The unreordered tensor product `(G_A ⊗ G_B) ⊗ I_R`. -/
def jointContractionCanonicalIsometry :
    Matrix (JointContractionPhysicalIndex a b r)
      (JointContractionCanonicalIndex a b r) ℂ :=
  Matrix.kronecker
    (Matrix.kronecker
      (localContractionCoordinates (x := a))
      (localContractionCoordinates (x := b)))
    (1 : CMatrix r)

/-- The resource-extended joint contraction isometry `𝒢`, with columns in the
paper's coordinate order. -/
def jointContractionIsometry :
    Matrix (JointContractionPhysicalIndex a b r)
      (JointContractionCoordinateIndex a b r) ℂ :=
  Matrix.reindex (Equiv.refl (JointContractionPhysicalIndex a b r))
    (jointContractionCoordinateEquiv (a := a) (b := b) (r := r))
    jointContractionCanonicalIsometry

omit [Fintype r] in
/-- Entrywise form of `𝒢`, making the tensor-factor regrouping explicit. -/
@[simp]
theorem jointContractionIsometry_apply
    (uA : LocalMixedSchurSpace a) (uB : LocalMixedSchurSpace b)
    (z z' : r) (sA sB : LocalParity) (i : a) (j : b) :
    jointContractionIsometry ((uA, uB), z') (((sA, sB), z), (i, j)) =
      localContractionCoordinates uA (sA, i) *
        localContractionCoordinates uB (sB, j) *
          (if z' = z then 1 else 0) := by
  simp [jointContractionIsometry, jointContractionCanonicalIsometry,
    jointContractionCoordinateEquiv, Matrix.reindex_apply,
    Matrix.kronecker, Matrix.one_apply]

private theorem jointContractionCanonicalIsometry_conjTranspose_mul_self
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b) :
    Matrix.conjTranspose
        (jointContractionCanonicalIsometry (a := a) (b := b) (r := r)) *
      jointContractionCanonicalIsometry =
        (1 : CMatrix (JointContractionCanonicalIndex a b r)) := by
  unfold jointContractionCanonicalIsometry
  unfold Matrix.kronecker
  rw [Matrix.conjTranspose_kronecker]
  rw [← Matrix.mul_kronecker_mul]
  rw [Matrix.conjTranspose_kronecker]
  rw [← Matrix.mul_kronecker_mul]
  rw [localContractionCoordinates_conjTranspose_mul_self hcardA,
    localContractionCoordinates_conjTranspose_mul_self hcardB]
  simp

/-- The joint resource-extended map is an isometry: `𝒢†𝒢 = I`. -/
theorem jointContractionIsometry_conjTranspose_mul_self
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b) :
    Matrix.conjTranspose
        (jointContractionIsometry (a := a) (b := b) (r := r)) *
      jointContractionIsometry =
        (1 : CMatrix (JointContractionCoordinateIndex a b r)) := by
  let e := jointContractionCoordinateEquiv (a := a) (b := b) (r := r)
  let G := jointContractionCanonicalIsometry (a := a) (b := b) (r := r)
  change Matrix.conjTranspose
      (Matrix.reindex (Equiv.refl (JointContractionPhysicalIndex a b r)) e G) *
        Matrix.reindex (Equiv.refl (JointContractionPhysicalIndex a b r)) e G = 1
  rw [Matrix.conjTranspose_reindex]
  calc
    Matrix.reindex e (Equiv.refl (JointContractionPhysicalIndex a b r))
          (Matrix.conjTranspose G) *
        Matrix.reindex (Equiv.refl (JointContractionPhysicalIndex a b r)) e G =
      Matrix.reindex e e (Matrix.conjTranspose G * G) := by
        simpa using Matrix.reindexLinearEquiv_mul (R := ℂ) (A := ℂ)
          e (Equiv.refl (JointContractionPhysicalIndex a b r)) e
          (Matrix.conjTranspose G) G
    _ = Matrix.reindex e e
        (1 : CMatrix (JointContractionCanonicalIndex a b r)) := by
      rw [jointContractionCanonicalIsometry_conjTranspose_mul_self
        hcardA hcardB]
    _ = 1 := by
      exact Matrix.reindexLinearEquiv_one (R := ℂ) (A := ℂ) e

/-- Pull an operator on the physical space back to contraction coordinates. -/
def jointContractionPullback
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    CMatrix (JointContractionCoordinateIndex a b r) :=
  Matrix.conjTranspose jointContractionIsometry * K *
    jointContractionIsometry

/-- Embed a contraction-coordinate operator back into the physical space. -/
def jointContractionEmbedding
    (Q : CMatrix (JointContractionCoordinateIndex a b r)) :
    CMatrix (JointContractionPhysicalIndex a b r) :=
  jointContractionIsometry * Q *
    Matrix.conjTranspose jointContractionIsometry

/-- The physical projection onto the range of `𝒢`. -/
def jointContractionRangeProjection :
    CMatrix (JointContractionPhysicalIndex a b r) :=
  jointContractionIsometry * Matrix.conjTranspose jointContractionIsometry

/-- Pullback by `𝒢` preserves positive semidefiniteness. -/
theorem jointContractionPullback_posSemidef
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hK : K.PosSemidef) :
    (jointContractionPullback K).PosSemidef := by
  exact hK.conjTranspose_mul_mul_same jointContractionIsometry

/-- Reverse conjugation by `𝒢` preserves positive semidefiniteness. -/
theorem jointContractionEmbedding_posSemidef
    {Q : CMatrix (JointContractionCoordinateIndex a b r)}
    (hQ : Q.PosSemidef) :
    (jointContractionEmbedding Q).PosSemidef := by
  have h := hQ.conjTranspose_mul_mul_same
    (Matrix.conjTranspose
      (jointContractionIsometry (a := a) (b := b) (r := r)))
  simpa [jointContractionEmbedding] using h

/-- `𝒢𝒢†` is Hermitian. -/
theorem jointContractionRangeProjection_isHermitian :
    (jointContractionRangeProjection (a := a) (b := b) (r := r)).IsHermitian := by
  rw [Matrix.IsHermitian]
  simp [jointContractionRangeProjection, Matrix.conjTranspose_mul]

/-- `𝒢𝒢†` is positive semidefinite. -/
theorem jointContractionRangeProjection_posSemidef :
    (jointContractionRangeProjection (a := a) (b := b) (r := r)).PosSemidef := by
  simpa [jointContractionRangeProjection] using
    Matrix.posSemidef_conjTranspose_mul_self
      (Matrix.conjTranspose
        (jointContractionIsometry (a := a) (b := b) (r := r)))

/-- `𝒢𝒢†` is idempotent, hence is the orthogonal range projection. -/
theorem jointContractionRangeProjection_idempotent
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b) :
    jointContractionRangeProjection (a := a) (b := b) (r := r) *
        jointContractionRangeProjection =
      jointContractionRangeProjection := by
  unfold jointContractionRangeProjection
  let G := jointContractionIsometry (a := a) (b := b) (r := r)
  have hG : Matrix.conjTranspose G * G = 1 :=
    jointContractionIsometry_conjTranspose_mul_self hcardA hcardB
  change (G * Matrix.conjTranspose G) * (G * Matrix.conjTranspose G) =
    G * Matrix.conjTranspose G
  calc
    (G * Matrix.conjTranspose G) * (G * Matrix.conjTranspose G) =
        G * (Matrix.conjTranspose G * G) * Matrix.conjTranspose G := by
      simp only [Matrix.mul_assoc]
    _ = G * Matrix.conjTranspose G := by rw [hG, Matrix.mul_one]

/-- Pulling an embedded coordinate operator back recovers it exactly. -/
theorem jointContractionPullback_embedding
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (Q : CMatrix (JointContractionCoordinateIndex a b r)) :
    jointContractionPullback (jointContractionEmbedding Q) = Q := by
  unfold jointContractionPullback jointContractionEmbedding
  let G := jointContractionIsometry (a := a) (b := b) (r := r)
  have hG : Matrix.conjTranspose G * G = 1 :=
    jointContractionIsometry_conjTranspose_mul_self hcardA hcardB
  change Matrix.conjTranspose G * (G * Q * Matrix.conjTranspose G) * G = Q
  calc
    Matrix.conjTranspose G * (G * Q * Matrix.conjTranspose G) * G =
        (Matrix.conjTranspose G * G) * Q *
          (Matrix.conjTranspose G * G) := by
      simp only [Matrix.mul_assoc]
    _ = Q := by rw [hG, Matrix.one_mul, Matrix.mul_one]

/-- Embedding a pullback is compression by the physical range projection. -/
theorem jointContractionEmbedding_pullback
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    jointContractionEmbedding (jointContractionPullback K) =
      jointContractionRangeProjection * K * jointContractionRangeProjection := by
  unfold jointContractionEmbedding jointContractionPullback
    jointContractionRangeProjection
  simp only [Matrix.mul_assoc]

private def jointResourceContractionCanonicalElement
    (sA tA sB tB : LocalParity) (Y : CMatrix r) :
    CMatrix (JointContractionCanonicalIndex a b r) :=
  Matrix.kronecker
    (Matrix.kronecker
      (localContractionCoordinateMatrixUnit (x := a) sA tA)
      (localContractionCoordinateMatrixUnit (x := b) sB tB))
    Y

/-- The coordinate-space operator
`((|s_A><t_A| ⊗ |s_B><t_B|) ⊗ Y_R) ⊗ I_{A B}` in the paper's reordered
contraction coordinates. -/
def jointResourceContractionCoordinateElement
    (sA tA sB tB : LocalParity) (Y : CMatrix r) :
    CMatrix (JointContractionCoordinateIndex a b r) :=
  let e := jointContractionCoordinateEquiv (a := a) (b := b) (r := r)
  Matrix.reindex e e
    (jointResourceContractionCanonicalElement
      (a := a) (b := b) sA tA sB tB Y)

/-- Entrywise form of a resource-valued matrix unit in the paper's reordered
contraction coordinates. -/
@[simp]
theorem jointResourceContractionCoordinateElement_apply
    (sA tA sB tB : LocalParity) (Y : CMatrix r)
    (uA vA uB vB : LocalParity) (i k : r)
    (p q : a) (w x : b) :
    jointResourceContractionCoordinateElement
        (a := a) (b := b) sA tA sB tB Y
        (((uA, uB), i), (p, w))
        (((vA, vB), k), (q, x)) =
      (if uA = sA ∧ vA = tA then 1 else 0) *
      (if uB = sB ∧ vB = tB then 1 else 0) *
      Y i k * (if (p, w) = (q, x) then 1 else 0) := by
  simp [jointResourceContractionCoordinateElement,
    jointContractionCoordinateEquiv,
    jointResourceContractionCanonicalElement,
    localContractionCoordinateMatrixUnit, localParityMatrixUnit,
    Matrix.reindex_apply, Matrix.kronecker, Matrix.one_apply]
  by_cases hpq : p = q <;> by_cases hwx : w = x <;>
    simp [hpq, hwx]

/-- The physical contraction-block operator
`W_{s_A} W_{t_A}† ⊗ W_{s_B} W_{t_B}† ⊗ Y_R`. -/
def jointResourceContractionPhysicalElement
    (sA tA sB tB : LocalParity) (Y : CMatrix r) :
    CMatrix (JointContractionPhysicalIndex a b r) :=
  Matrix.kronecker
    (Matrix.kronecker
      (localWByParity (x := a) sA *
        Matrix.conjTranspose (localWByParity (x := a) tA))
      (localWByParity (x := b) sB *
        Matrix.conjTranspose (localWByParity (x := b) tB)))
    Y

private theorem jointContractionCanonicalEmbedding_resourceElement
    (sA tA sB tB : LocalParity) (Y : CMatrix r) :
    jointContractionCanonicalIsometry (a := a) (b := b) (r := r) *
          jointResourceContractionCanonicalElement
            (a := a) (b := b) sA tA sB tB Y *
          Matrix.conjTranspose jointContractionCanonicalIsometry =
      jointResourceContractionPhysicalElement
        (a := a) (b := b) sA tA sB tB Y := by
  unfold jointContractionCanonicalIsometry
    jointResourceContractionCanonicalElement
    jointResourceContractionPhysicalElement
  unfold Matrix.kronecker
  rw [Matrix.conjTranspose_kronecker]
  rw [Matrix.conjTranspose_kronecker]
  rw [← Matrix.mul_kronecker_mul]
  rw [← Matrix.mul_kronecker_mul]
  rw [← Matrix.mul_kronecker_mul]
  rw [← Matrix.mul_kronecker_mul]
  rw [localContractionEmbedding_coordinateMatrixUnit,
    localContractionEmbedding_coordinateMatrixUnit]
  simp

/-- Second identity in `eq:resource_contraction_element_correspondence`:
embedding a multiplicity/resource matrix element gives its physical
contraction block. -/
theorem jointContractionEmbedding_resourceElement
    (sA tA sB tB : LocalParity) (Y : CMatrix r) :
    jointContractionEmbedding
        (jointResourceContractionCoordinateElement
          (a := a) (b := b) sA tA sB tB Y) =
      jointResourceContractionPhysicalElement
        (a := a) (b := b) sA tA sB tB Y := by
  let e := jointContractionCoordinateEquiv (a := a) (b := b) (r := r)
  let G := jointContractionCanonicalIsometry (a := a) (b := b) (r := r)
  let Q := jointResourceContractionCanonicalElement
    (a := a) (b := b) sA tA sB tB Y
  change Matrix.reindex
        (Equiv.refl (JointContractionPhysicalIndex a b r)) e G *
      Matrix.reindex e e Q *
      Matrix.conjTranspose
        (Matrix.reindex
          (Equiv.refl (JointContractionPhysicalIndex a b r)) e G) = _
  rw [Matrix.conjTranspose_reindex]
  have hGQ :
      Matrix.reindex
          (Equiv.refl (JointContractionPhysicalIndex a b r)) e G *
        Matrix.reindex e e Q =
      Matrix.reindex
          (Equiv.refl (JointContractionPhysicalIndex a b r)) e (G * Q) := by
    exact Matrix.reindexLinearEquiv_mul (R := ℂ) (A := ℂ)
      (Equiv.refl (JointContractionPhysicalIndex a b r)) e e G Q
  have hGQG :
      Matrix.reindex
          (Equiv.refl (JointContractionPhysicalIndex a b r)) e (G * Q) *
        Matrix.reindex e
          (Equiv.refl (JointContractionPhysicalIndex a b r))
          (Matrix.conjTranspose G) =
      Matrix.reindex
          (Equiv.refl (JointContractionPhysicalIndex a b r))
          (Equiv.refl (JointContractionPhysicalIndex a b r))
          (G * Q * Matrix.conjTranspose G) := by
    exact Matrix.reindexLinearEquiv_mul (R := ℂ) (A := ℂ)
      (Equiv.refl (JointContractionPhysicalIndex a b r)) e
      (Equiv.refl (JointContractionPhysicalIndex a b r))
      (G * Q) (Matrix.conjTranspose G)
  calc
    Matrix.reindex
          (Equiv.refl (JointContractionPhysicalIndex a b r)) e G *
        Matrix.reindex e e Q *
        Matrix.reindex e
          (Equiv.refl (JointContractionPhysicalIndex a b r))
          (Matrix.conjTranspose G) =
      Matrix.reindex
          (Equiv.refl (JointContractionPhysicalIndex a b r)) e (G * Q) *
        Matrix.reindex e
          (Equiv.refl (JointContractionPhysicalIndex a b r))
          (Matrix.conjTranspose G) := by
        rw [hGQ]
    _ = Matrix.reindex
          (Equiv.refl (JointContractionPhysicalIndex a b r))
          (Equiv.refl (JointContractionPhysicalIndex a b r))
          (G * Q * Matrix.conjTranspose G) := by
        exact hGQG
    _ = G * Q * Matrix.conjTranspose G := by rfl
    _ = _ := jointContractionCanonicalEmbedding_resourceElement
      (a := a) (b := b) sA tA sB tB Y

/-- First identity in `eq:resource_contraction_element_correspondence`:
pulling a physical contraction block back recovers its unique
multiplicity/resource coordinate element. -/
theorem jointContractionPullback_resourceElement
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (sA tA sB tB : LocalParity) (Y : CMatrix r) :
    jointContractionPullback
        (jointResourceContractionPhysicalElement
          (a := a) (b := b) sA tA sB tB Y) =
      jointResourceContractionCoordinateElement
        (a := a) (b := b) sA tA sB tB Y := by
  rw [← jointContractionEmbedding_resourceElement]
  exact jointContractionPullback_embedding hcardA hcardB _

/-- Physical action `(π_A(U) ⊗ π_B(V)) ⊗ I_R`. -/
def jointContractionPhysicalRepresentation
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    CMatrix (JointContractionPhysicalIndex a b r) :=
  Matrix.kronecker
    (Matrix.kronecker
      (localMixedSchurRepresentation U)
      (localMixedSchurRepresentation V))
    (1 : CMatrix r)

private def jointContractionCanonicalRepresentation
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    CMatrix (JointContractionCanonicalIndex a b r) :=
  Matrix.kronecker
    (Matrix.kronecker
      (localContractionCoordinateRepresentation U)
      (localContractionCoordinateRepresentation V))
    (1 : CMatrix r)

/-- Coordinate action, reindexed into `M_AB ⊗ R ⊗ A ⊗ B` order. -/
def jointContractionCoordinateRepresentation
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    CMatrix (JointContractionCoordinateIndex a b r) :=
  let e := jointContractionCoordinateEquiv (a := a) (b := b) (r := r)
  Matrix.reindex e e (jointContractionCanonicalRepresentation U V)

/-- In the paper's reordered coordinates, the joint action is exactly
`I_{M_AB ⊗ R} ⊗ (bar U ⊗ bar V)`. -/
theorem jointContractionCoordinateRepresentation_eq
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    jointContractionCoordinateRepresentation (r := r) U V =
      Matrix.kronecker
        (1 : CMatrix (LocalMultiplicitySector × r))
        (Matrix.kronecker
          (localEntrywiseConjugate U)
          (localEntrywiseConjugate V)) := by
  ext q q'
  rcases q with ⟨⟨⟨sA, sB⟩, z⟩, ⟨i, j⟩⟩
  rcases q' with ⟨⟨⟨tA, tB⟩, z'⟩, ⟨k, l⟩⟩
  simp [jointContractionCoordinateRepresentation,
    jointContractionCanonicalRepresentation,
    localContractionCoordinateRepresentation,
    jointContractionCoordinateEquiv, Matrix.reindex_apply,
    Matrix.kronecker, Matrix.one_apply]
  by_cases hA : sA = tA <;>
    by_cases hB : sB = tB <;>
      by_cases hz : z = z' <;> simp [hA, hB, hz]

private theorem jointContractionCanonical_intertwines
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    jointContractionPhysicalRepresentation (r := r) U V *
        jointContractionCanonicalIsometry =
      jointContractionCanonicalIsometry *
        jointContractionCanonicalRepresentation (r := r) U V := by
  unfold jointContractionPhysicalRepresentation
    jointContractionCanonicalIsometry
    jointContractionCanonicalRepresentation
  unfold Matrix.kronecker
  rw [← Matrix.mul_kronecker_mul]
  rw [← Matrix.mul_kronecker_mul]
  rw [← Matrix.mul_kronecker_mul]
  rw [← Matrix.mul_kronecker_mul]
  rw [localContractionCoordinates_intertwines U,
    localContractionCoordinates_intertwines V]

/-- Equation `eq:joint_contraction_intertwining`. -/
theorem jointContractionIsometry_intertwines
    (U : Matrix.unitaryGroup a ℂ) (V : Matrix.unitaryGroup b ℂ) :
    jointContractionPhysicalRepresentation (r := r) U V *
        jointContractionIsometry =
      jointContractionIsometry *
        jointContractionCoordinateRepresentation (r := r) U V := by
  let e := jointContractionCoordinateEquiv (a := a) (b := b) (r := r)
  let P := jointContractionPhysicalRepresentation (r := r) U V
  let G := jointContractionCanonicalIsometry (a := a) (b := b) (r := r)
  let C := jointContractionCanonicalRepresentation (r := r) U V
  change P * Matrix.reindex
      (Equiv.refl (JointContractionPhysicalIndex a b r)) e G =
    Matrix.reindex (Equiv.refl (JointContractionPhysicalIndex a b r)) e G *
      Matrix.reindex e e C
  calc
    P * Matrix.reindex
        (Equiv.refl (JointContractionPhysicalIndex a b r)) e G =
      Matrix.reindex (Equiv.refl (JointContractionPhysicalIndex a b r)) e
        (P * G) := by
          simpa using Matrix.reindexLinearEquiv_mul (R := ℂ) (A := ℂ)
            (Equiv.refl (JointContractionPhysicalIndex a b r))
            (Equiv.refl (JointContractionPhysicalIndex a b r)) e P G
    _ = Matrix.reindex (Equiv.refl (JointContractionPhysicalIndex a b r)) e
        (G * C) := by
          rw [jointContractionCanonical_intertwines (r := r) U V]
    _ = Matrix.reindex (Equiv.refl (JointContractionPhysicalIndex a b r)) e G *
        Matrix.reindex e e C := by
          symm
          exact Matrix.reindexLinearEquiv_mul (R := ℂ) (A := ℂ)
            (Equiv.refl (JointContractionPhysicalIndex a b r)) e e G C

end

end EntanglementPurification
