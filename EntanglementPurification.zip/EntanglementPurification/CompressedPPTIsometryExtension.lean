import EntanglementPurification.CompressedPPTIsometryPullback
import QIT.Core.Map
import Mathlib.Tactic

/-!
# Extending compressed PPT data along local isometries

This is the zero-padding counterpart of
`CompressedPPTInstrumentData.pullbackLocalIsometries`.  A compressed
instrument on a resource register is embedded into a larger product register.
On the orthogonal complement of the embedded product subspace the success
branch is zero and the failure branch is the identity.  Thus completeness is
preserved without adding any artificial successful action.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

universe uA uB vA vB

variable {sA : Type uA} {sB : Type uB} {rA : Type vA} {rB : Type vB}
variable [Fintype sA] [DecidableEq sA] [Fintype sB] [DecidableEq sB]
variable [Fintype rA] [DecidableEq rA] [Fintype rB] [DecidableEq rB]

/-- Embed a resource operator into the range of a product local isometry. -/
def localResourcePushforward
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (X : CMatrix (sA × sB)) : CMatrix (rA × rB) :=
  (localResourceIsometry VA VB).matrix * X *
    Matrix.conjTranspose (localResourceIsometry VA VB).matrix

/-- Embed a four-sector resource operator, leaving the sector label fixed. -/
def localSectorResourcePushforward
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (K : CMatrix (LocalMultiplicitySector × (sA × sB))) :
    CMatrix (LocalMultiplicitySector × (rA × rB)) :=
  (localSectorResourceIsometry VA VB).matrix * K *
    Matrix.conjTranspose (localSectorResourceIsometry VA VB).matrix

/-- Projection onto the embedded product resource subspace. -/
def localResourceRangeProjection
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB) :
    CMatrix (rA × rB) :=
  (localResourceIsometry VA VB).matrix *
    Matrix.conjTranspose (localResourceIsometry VA VB).matrix

/-- The unused part of the enlarged product resource register. -/
def localResourceRangeComplement
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB) :
    CMatrix (rA × rB) :=
  1 - localResourceRangeProjection VA VB

theorem localResourcePushforward_posSemidef
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    {X : CMatrix (sA × sB)} (hX : X.PosSemidef) :
    (localResourcePushforward VA VB X).PosSemidef := by
  exact hX.mul_mul_conjTranspose_same (localResourceIsometry VA VB).matrix

theorem localSectorResourcePushforward_posSemidef
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    {K : CMatrix (LocalMultiplicitySector × (sA × sB))}
    (hK : K.PosSemidef) :
    (localSectorResourcePushforward VA VB K).PosSemidef := by
  exact hK.mul_mul_conjTranspose_same
    (localSectorResourceIsometry VA VB).matrix

@[simp]
theorem localResourcePushforward_one
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB) :
    localResourcePushforward VA VB (1 : CMatrix (sA × sB)) =
      localResourceRangeProjection VA VB := by
  simp [localResourcePushforward, localResourceRangeProjection]

theorem localResourcePushforward_add
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (X Y : CMatrix (sA × sB)) :
    localResourcePushforward VA VB (X + Y) =
      localResourcePushforward VA VB X + localResourcePushforward VA VB Y := by
  simp [localResourcePushforward, Matrix.mul_add, Matrix.add_mul]

theorem localResourcePushforward_smul
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (c : ℝ) (X : CMatrix (sA × sB)) :
    localResourcePushforward VA VB (c • X) =
      c • localResourcePushforward VA VB X := by
  simp [localResourcePushforward, Matrix.mul_smul, Matrix.smul_mul]

theorem localResourceRangeProjection_posSemidef
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB) :
    (localResourceRangeProjection VA VB).PosSemidef := by
  simpa [localResourceRangeProjection] using
    Matrix.posSemidef_conjTranspose_mul_self
      (Matrix.conjTranspose (localResourceIsometry VA VB).matrix)

theorem localResourceRangeProjection_idempotent
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB) :
    localResourceRangeProjection VA VB *
        localResourceRangeProjection VA VB =
      localResourceRangeProjection VA VB := by
  simp only [localResourceRangeProjection, Matrix.mul_assoc]
  rw [← Matrix.mul_assoc
    (Matrix.conjTranspose (localResourceIsometry VA VB).matrix)]
  rw [(localResourceIsometry VA VB).isometry]
  simp

theorem localResourceRangeComplement_posSemidef
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB) :
    ((1 : CMatrix (rA × rB)) -
      localResourceRangeProjection VA VB).PosSemidef := by
  exact MatrixMap.posSemidef_one_sub_of_posSemidef_idempotent
    (localResourceRangeProjection VA VB)
    (localResourceRangeProjection_posSemidef VA VB)
    (localResourceRangeProjection_idempotent VA VB)

theorem localResourceRangeComplement_posSemidef'
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB) :
    (localResourceRangeComplement VA VB).PosSemidef := by
  exact localResourceRangeComplement_posSemidef VA VB

/-- Resource-sector blocks commute with local-isometry extension. -/
theorem resourceSectorBlock_localSectorResourcePushforward
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (K : CMatrix (LocalMultiplicitySector × (sA × sB)))
    (z w : LocalMultiplicitySector) :
    resourceSectorBlock (localSectorResourcePushforward VA VB K) z w =
      localResourcePushforward VA VB (resourceSectorBlock K z w) := by
  ext i j
  rcases i with ⟨iA, iB⟩
  rcases j with ⟨jA, jB⟩
  simp [localSectorResourcePushforward, localSectorResourceIsometry,
    localResourcePushforward, localResourceIsometry, ReferenceIsometry.prod,
    ReferenceIsometry.ofEquiv, resourceSectorBlock, Matrix.mul_apply,
    Matrix.conjTranspose_apply, Matrix.kronecker,
    Matrix.kroneckerMap_apply, Fintype.sum_prod_type, apply_ite]

/-- Bob partial transpose is covariant under extension by a product local
isometry; the Bob isometry is entrywise conjugated. -/
theorem partialTransposeB_localResourcePushforward
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (X : CMatrix (sA × sB)) :
    QIT.partialTransposeB (localResourcePushforward VA VB X) =
      localResourcePushforward VA (conjugateReferenceIsometry VB)
        (QIT.partialTransposeB X) := by
  rw [localResourcePushforward, localResourcePushforward]
  change QIT.partialTransposeB
      (Matrix.kronecker VA.matrix VB.matrix * X *
        Matrix.conjTranspose (Matrix.kronecker VA.matrix VB.matrix)) = _
  rw [show (Matrix.kronecker VA.matrix VB.matrix).conjTranspose =
      Matrix.kronecker VA.matrix.conjTranspose VB.matrix.conjTranspose from
    Matrix.conjTranspose_kronecker VA.matrix VB.matrix]
  rw [partialTransposeB_kronecker_sandwich_rectangular]
  change
    Matrix.kronecker VA.matrix VB.matrix.conjTranspose.transpose *
          QIT.partialTransposeB X *
        Matrix.kronecker VA.matrix.conjTranspose VB.matrix.transpose =
      Matrix.kronecker VA.matrix (VB.matrix.map star) *
          QIT.partialTransposeB X *
        Matrix.conjTranspose
          (Matrix.kronecker VA.matrix (VB.matrix.map star))
  rw [show (Matrix.kronecker VA.matrix (VB.matrix.map star)).conjTranspose =
      Matrix.kronecker VA.matrix.conjTranspose
        (VB.matrix.map star).conjTranspose from
    Matrix.conjTranspose_kronecker VA.matrix (VB.matrix.map star)]
  have hleft :
      VB.matrix.conjTranspose.transpose = VB.matrix.map star :=
    Matrix.transpose_conjTranspose VB.matrix
  have hright :
      (VB.matrix.map star).conjTranspose = VB.matrix.transpose := by
    ext i j
    simp [Matrix.conjTranspose_apply]
  rw [hleft, hright]

theorem partialTransposeB_localResourcePushforward_posSemidef
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    {X : CMatrix (sA × sB)}
    (hX : (QIT.partialTransposeB X).PosSemidef) :
    (QIT.partialTransposeB
      (localResourcePushforward VA VB X)).PosSemidef := by
  rw [partialTransposeB_localResourcePushforward]
  exact localResourcePushforward_posSemidef VA
    (conjugateReferenceIsometry VB) hX

/-- The range-complement failure operator is Bob-PPT. -/
theorem partialTransposeB_localResourceRangeComplement_posSemidef
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB) :
    (QIT.partialTransposeB
      ((1 : CMatrix (rA × rB)) -
        localResourceRangeProjection VA VB)).PosSemidef := by
  classical
  have hcov := partialTransposeB_localResourcePushforward VA VB
    (1 : CMatrix (sA × sB))
  have honeSource :
      QIT.partialTransposeB (1 : CMatrix (sA × sB)) = 1 := by
    ext ⟨iA, iB⟩ ⟨jA, jB⟩
    simp only [QIT.partialTransposeB_apply, Matrix.one_apply, Prod.mk.injEq]
    have hiff : (iA = jA ∧ jB = iB) ↔ (iA = jA ∧ iB = jB) := by
      constructor
      · rintro ⟨hA, hB⟩
        exact ⟨hA, hB.symm⟩
      · rintro ⟨hA, hB⟩
        exact ⟨hA, hB.symm⟩
    by_cases h : iA = jA ∧ jB = iB
    · rw [if_pos h, if_pos (hiff.mp h)]
    · rw [if_neg h, if_neg (fun h' => h (hiff.mpr h'))]
  rw [honeSource, localResourcePushforward_one,
    localResourcePushforward_one] at hcov
  have hone :
      QIT.partialTransposeB (1 : CMatrix (rA × rB)) = 1 := by
    ext ⟨iA, iB⟩ ⟨jA, jB⟩
    simp only [QIT.partialTransposeB_apply, Matrix.one_apply, Prod.mk.injEq]
    have hiff : (iA = jA ∧ jB = iB) ↔ (iA = jA ∧ iB = jB) := by
      constructor
      · rintro ⟨hA, hB⟩
        exact ⟨hA, hB.symm⟩
      · rintro ⟨hA, hB⟩
        exact ⟨hA, hB.symm⟩
    by_cases h : iA = jA ∧ jB = iB
    · rw [if_pos h, if_pos (hiff.mp h)]
    · rw [if_neg h, if_neg (fun h' => h (hiff.mpr h'))]
  have hsub :
      QIT.partialTransposeB
          ((1 : CMatrix (rA × rB)) -
            localResourceRangeProjection VA VB) =
        1 - localResourceRangeProjection VA
          (conjugateReferenceIsometry VB) := by
    rw [show QIT.partialTransposeB
        ((1 : CMatrix (rA × rB)) -
          localResourceRangeProjection VA VB) =
        QIT.partialTransposeB (1 : CMatrix (rA × rB)) -
          QIT.partialTransposeB (localResourceRangeProjection VA VB) by
      ext ⟨iA, iB⟩ ⟨jA, jB⟩
      rfl]
    rw [hone, hcov]
  rw [hsub]
  exact localResourceRangeComplement_posSemidef VA
    (conjugateReferenceIsometry VB)

theorem partialTransposeB_localResourceRangeComplement_posSemidef'
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB) :
    (QIT.partialTransposeB
      (localResourceRangeComplement VA VB)).PosSemidef := by
  exact partialTransposeB_localResourceRangeComplement_posSemidef VA VB

/-- Sector/resource Bob partial transpose is covariant under extension. -/
theorem sectorResourcePartialTransposeB_localSectorResourcePushforward
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (K : CMatrix (LocalMultiplicitySector × (sA × sB))) :
    sectorResourcePartialTransposeB
        (localSectorResourcePushforward VA VB K) =
      localSectorResourcePushforward VA (conjugateReferenceIsometry VB)
        (sectorResourcePartialTransposeB K) := by
  ext p q
  rcases p with ⟨⟨s₁, s₂⟩, ⟨a, b⟩⟩
  rcases q with ⟨⟨t₁, t₂⟩, ⟨c, e⟩⟩
  have hblock :
      resourceSectorBlock
          (sectorResourcePartialTransposeB
            (localSectorResourcePushforward VA VB K))
          (s₁, s₂) (t₁, t₂) =
        resourceSectorBlock
          (localSectorResourcePushforward VA (conjugateReferenceIsometry VB)
            (sectorResourcePartialTransposeB K))
          (s₁, s₂) (t₁, t₂) := by
    calc
      _ = QIT.partialTransposeB
          (resourceSectorBlock (localSectorResourcePushforward VA VB K)
            (s₁, t₂) (t₁, s₂)) :=
        resourceSectorBlock_sectorResourcePartialTransposeB
          (localSectorResourcePushforward VA VB K) s₁ t₂ t₁ s₂
      _ = QIT.partialTransposeB
          (localResourcePushforward VA VB
            (resourceSectorBlock K (s₁, t₂) (t₁, s₂))) := by
        rw [resourceSectorBlock_localSectorResourcePushforward]
      _ = localResourcePushforward VA (conjugateReferenceIsometry VB)
          (QIT.partialTransposeB
            (resourceSectorBlock K (s₁, t₂) (t₁, s₂))) := by
        rw [partialTransposeB_localResourcePushforward]
      _ = localResourcePushforward VA (conjugateReferenceIsometry VB)
          (resourceSectorBlock (sectorResourcePartialTransposeB K)
            (s₁, s₂) (t₁, t₂)) := by
        rw [resourceSectorBlock_sectorResourcePartialTransposeB
          K s₁ t₂ t₁ s₂]
      _ = _ := by
        rw [resourceSectorBlock_localSectorResourcePushforward]
  exact congr_fun (congr_fun hblock (a, b)) (c, e)

theorem sectorResourcePartialTransposeB_localSectorResourcePushforward_posSemidef
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    {K : CMatrix (LocalMultiplicitySector × (sA × sB))}
    (hK : (sectorResourcePartialTransposeB K).PosSemidef) :
    (sectorResourcePartialTransposeB
      (localSectorResourcePushforward VA VB K)).PosSemidef := by
  rw [sectorResourcePartialTransposeB_localSectorResourcePushforward]
  exact localSectorResourcePushforward_posSemidef VA
    (conjugateReferenceIsometry VB) hK

/-- Compressing an extended resource operator recovers the source operator. -/
@[simp]
theorem localResourcePullback_pushforward
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (X : CMatrix (sA × sB)) :
    localResourcePullback VA VB (localResourcePushforward VA VB X) = X := by
  simp only [localResourcePullback, localResourcePushforward,
    Matrix.mul_assoc]
  rw [← Matrix.mul_assoc
    (Matrix.conjTranspose (localResourceIsometry VA VB).matrix)]
  rw [(localResourceIsometry VA VB).isometry]
  simp

/-- Compressing an extended sector operator recovers the source operator. -/
@[simp]
theorem localSectorResourcePullback_pushforward
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (K : CMatrix (LocalMultiplicitySector × (sA × sB))) :
    localSectorResourcePullback VA VB
        (localSectorResourcePushforward VA VB K) = K := by
  simp only [localSectorResourcePullback, localSectorResourcePushforward,
    Matrix.mul_assoc]
  rw [← Matrix.mul_assoc
    (Matrix.conjTranspose (localSectorResourceIsometry VA VB).matrix)]
  rw [(localSectorResourceIsometry VA VB).isometry]
  simp

/-- Pure-resource insertion is unchanged by simultaneous extension of the
resource vector and the sector operator. -/
theorem insertPureResourceBlock_localSectorResourcePushforward
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (eta : sA × sB → ℂ)
    (K : CMatrix (LocalMultiplicitySector × (sA × sB))) :
    insertPureResourceBlock
        ((localResourceIsometry VA VB).matrix.mulVec eta)
        (localSectorResourcePushforward VA VB K) =
      insertPureResourceBlock eta K := by
  have h := insertPureResourceBlock_localSectorResourcePullback VA VB eta
    (localSectorResourcePushforward VA VB K)
  rw [localSectorResourcePullback_pushforward] at h
  exact h.symm

/-- The quadratic form on an extended vector/operator equals its value on the
source register. -/
theorem localResourcePushforward_quadratic
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB)
    (eta : sA × sB → ℂ) (X : CMatrix (sA × sB)) :
    dotProduct
        (star ((localResourceIsometry VA VB).matrix.mulVec eta))
        ((localResourcePushforward VA VB X).mulVec
          ((localResourceIsometry VA VB).matrix.mulVec eta)) =
      dotProduct (star eta) (X.mulVec eta) := by
  have h := localResourcePullback_quadratic VA VB eta
    (localResourcePushforward VA VB X)
  rw [localResourcePullback_pushforward] at h
  exact h.symm

/-- Extend a complete compressed PPT certificate to a larger pair of local
resource registers.  All added coordinates are deterministically assigned to
failure: success and residual operators are zero there, while the failure
operator receives the product-range complement. -/
def CompressedPPTInstrumentData.pushforwardLocalIsometries
    {d : ℕ}
    (data : CompressedPPTInstrumentData d sA sB)
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB) :
    CompressedPPTInstrumentData d rA rB := by
  let expandedResource : PureVector (rA × rB) :=
    VA.applyPureVector (VB.applyPureVectorRight data.resource)
  exact
    { resource := expandedResource
      success := localSectorResourcePushforward VA VB data.success
      outputSuccess := fun z =>
        localResourcePushforward VA VB (data.outputSuccess z)
      outputFailure := fun z =>
        localResourcePushforward VA VB (data.outputFailure z) +
          localResourceRangeComplement VA VB
      residualSuccess := fun z =>
        localResourcePushforward VA VB (data.residualSuccess z)
      success_branchPPT := by
        exact ⟨
          localSectorResourcePushforward_posSemidef VA VB
            data.success_branchPPT.1,
          sectorResourcePartialTransposeB_localSectorResourcePushforward_posSemidef
            VA VB data.success_branchPPT.2⟩
      outputSuccess_pos := by
        intro z
        exact localResourcePushforward_posSemidef VA VB
          (data.outputSuccess_pos z)
      outputFailure_pos := by
        intro z
        exact
          (localResourcePushforward_posSemidef VA VB
            (data.outputFailure_pos z)).add
              (localResourceRangeComplement_posSemidef' VA VB)
      outputFailure_ppt := by
        intro z
        have hadd :
            QIT.partialTransposeB
                (localResourcePushforward VA VB (data.outputFailure z) +
                  localResourceRangeComplement VA VB) =
              QIT.partialTransposeB
                  (localResourcePushforward VA VB (data.outputFailure z)) +
                QIT.partialTransposeB
                  (localResourceRangeComplement VA VB) := by
          ext i j
          rfl
        rw [hadd]
        exact
          (partialTransposeB_localResourcePushforward_posSemidef VA VB
            (data.outputFailure_ppt z)).add
              (partialTransposeB_localResourceRangeComplement_posSemidef'
                VA VB)
      output_complement := by
        intro z
        calc
          localResourcePushforward VA VB (data.outputSuccess z) +
                (localResourcePushforward VA VB (data.outputFailure z) +
                  localResourceRangeComplement VA VB) =
              localResourcePushforward VA VB
                  (data.outputSuccess z + data.outputFailure z) +
                localResourceRangeComplement VA VB := by
            rw [localResourcePushforward_add]
            abel
          _ = localResourcePushforward VA VB 1 +
                localResourceRangeComplement VA VB := by
            rw [data.output_complement z]
          _ = 1 := by
            simp [localResourcePushforward_one,
              localResourceRangeComplement]
      success_trace_decomposition := by
        intro z
        rw [resourceSectorBlock_localSectorResourcePushforward]
        calc
          localResourcePushforward VA VB (data.outputSuccess z) =
              localResourcePushforward VA VB
                (localSectorTraceScale d z •
                    resourceSectorBlock data.success z z +
                  data.residualSuccess z) := by
            rw [data.success_trace_decomposition z]
          _ = localResourcePushforward VA VB
                (localSectorTraceScale d z •
                  resourceSectorBlock data.success z z) +
              localResourcePushforward VA VB (data.residualSuccess z) :=
            localResourcePushforward_add VA VB _ _
          _ = localSectorTraceScale d z •
                localResourcePushforward VA VB
                  (resourceSectorBlock data.success z z) +
              localResourcePushforward VA VB (data.residualSuccess z) := by
            rw [localResourcePushforward_smul]
      residualSuccess_pos := by
        intro z
        exact localResourcePushforward_posSemidef VA VB
          (data.residualSuccess_pos z)
      inserted_optimal := by
        rw [← localResourceIsometry_mulVec_amp VA VB data.resource]
        rw [insertPureResourceBlock_localSectorResourcePushforward]
        exact data.inserted_optimal
      zero_output_PM := by
        rw [← localResourceIsometry_mulVec_amp VA VB data.resource]
        rw [localResourcePushforward_quadratic]
        exact data.zero_output_PM
      zero_output_MP := by
        rw [← localResourceIsometry_mulVec_amp VA VB data.resource]
        rw [localResourcePushforward_quadratic]
        exact data.zero_output_MP }

@[simp]
theorem CompressedPPTInstrumentData.pushforwardLocalIsometries_resource
    {d : ℕ}
    (data : CompressedPPTInstrumentData d sA sB)
    (VA : ReferenceIsometry sA rA) (VB : ReferenceIsometry sB rB) :
    (data.pushforwardLocalIsometries VA VB).resource =
      VA.applyPureVector (VB.applyPureVectorRight data.resource) := by
  rfl

end

end EntanglementPurification
