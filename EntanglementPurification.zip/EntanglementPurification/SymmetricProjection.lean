import QIT.Symmetry.SymmetricSubspace

/-!
# Algebraic core of the symmetric projection

The full-copy swap is an involution.  The accepted one-EPR branch uses the
normalized sum of the identity and that involution.  This file records the
noncommutative polynomial identity underlying idempotence of the symmetric
projector; later files can instantiate it with Lean-QIT operators.
-/

namespace EntanglementPurification

open QIT

/-- If `swap² = 1`, then `(1 + swap)² = 2(1 + swap)`.  Over `ℂ`, division
by four gives idempotence of `(1 + swap) / 2`. -/
theorem involution_symmetrizer_numerator_sq
    {A : Type*} [Ring A] (swap : A) (hswap : swap * swap = 1) :
    (1 + swap) * (1 + swap) = (2 : A) * (1 + swap) := by
  noncomm_ring [hswap]

/-- Lean-QIT's two-copy symmetric projection is idempotent.  This is the
operator-level endpoint needed at `main.tex:612-631`. -/
theorem qit_two_copy_symmetricProjection_idempotent
    {a : Type*} [Fintype a] [DecidableEq a] :
    symmetricProjectionMatrix (a := a) 2 * symmetricProjectionMatrix (a := a) 2 =
      symmetricProjectionMatrix (a := a) 2 :=
  symmetricProjectionMatrix_idempotent (a := a) 2

/-- Lean-QIT already identifies the two-copy symmetric projection with one
half times identity plus the full-copy swap. -/
theorem qit_two_copy_symmetricProjection_eq_half_one_add_swap
    {a : Type*} [Fintype a] [DecidableEq a] :
    symmetricProjectionMatrix (a := a) 2 =
      ((2 : ℂ)⁻¹) • (1 + tensorPowerSwapMatrix_two (a := a)) :=
  symmetricProjectionMatrix_two_eq_half_one_add_swap (a := a)

end EntanglementPurification
