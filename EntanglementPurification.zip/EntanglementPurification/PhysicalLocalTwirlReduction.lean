import EntanglementPurification.PhysicalLocalTwirlObjective
import EntanglementPurification.PhysicalLocalTwirlPPT
import EntanglementPurification.PhysicalLocalTwirlCompleteness

/-!
# Arbitrary feasible-pair local-twirl reduction

This module packages the matrix-level content of the paper's local-twirl
reduction.  The input is an arbitrary pair of physical branch matrices with
positivity, physical Bob-PPT positivity, and output-trace completeness.  The
genuine Alice/Bob Haar twirl produces a pair with the same feasibility
properties, local mixed-representation invariance, and unchanged
fixed-resource equation-986 complex trace objectives.

The resource parameter `omega` is an arbitrary complex matrix: normalization,
positivity, and Hermiticity are not needed for the trace identity.  This is a
stronger linear statement than specializing `omega` to a resource state.

This module does not prove that every matrix-level feasible pair belongs to
LOCC, nor does it construct a `FiniteInstrument` from such a pair.  Those are
separate operational inclusion and realization questions.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

universe uA uB uRA uRB

variable {a : Type uA} {b : Type uB} {ra : Type uRA} {rb : Type uRB}
  [Fintype a] [Fintype b] [Fintype ra] [Fintype rb]
  [DecidableEq a] [DecidableEq b] [DecidableEq ra] [DecidableEq rb]
  [Nonempty a] [Nonempty b] [Nonempty ra] [Nonempty rb]

/-- The exact matrix-level feasibility premises for an arbitrary physical
success/failure pair. -/
structure LocalTwirlPairPremise
    (S F : CMatrix (JointContractionPhysicalIndex a b (ra × rb))) : Prop where
  success_posSemidef : S.PosSemidef
  failure_posSemidef : F.PosSemidef
  success_ppt : (physicalBranchPartialTransposeB S).PosSemidef
  failure_ppt : (physicalBranchPartialTransposeB F).PosSemidef
  outputTrace_complete :
    physicalBranchOutputTrace S + physicalBranchOutputTrace F = 1

/-- The complete result of genuinely Haar-twirling an arbitrary feasible
physical success/failure pair.  The equation-986 fields are literal complex
trace equalities; in particular, they do not require a separate feasibility
hypothesis for converting the trace into a real SDP objective. -/
structure LocalTwirlReductionCertificate
    (nu : PureVector (a × b)) (gamma : ℝ) (omega : CMatrix (ra × rb))
    (S F : CMatrix (JointContractionPhysicalIndex a b (ra × rb))) : Prop where
  success_posSemidef : (physicalLocalTwirl S).PosSemidef
  failure_posSemidef : (physicalLocalTwirl F).PosSemidef
  success_ppt :
    (physicalBranchPartialTransposeB (physicalLocalTwirl S)).PosSemidef
  failure_ppt :
    (physicalBranchPartialTransposeB (physicalLocalTwirl F)).PosSemidef
  outputTrace_complete :
    physicalBranchOutputTrace (physicalLocalTwirl S) +
      physicalBranchOutputTrace (physicalLocalTwirl F) = 1
  success_invariant :
    JointContractionPhysicalInvariant (physicalLocalTwirl S)
  failure_invariant :
    JointContractionPhysicalInvariant (physicalLocalTwirl F)
  success_objective_preserved :
    (physicalEq986FixedResourcePairing nu gamma omega *
        physicalLocalTwirl S).trace =
      (physicalEq986FixedResourcePairing nu gamma omega * S).trace
  failure_objective_preserved :
    (physicalEq986FixedResourcePairing nu gamma omega *
        physicalLocalTwirl F).trace =
      (physicalEq986FixedResourcePairing nu gamma omega * F).trace

/-- Headline arbitrary-pair form of the paper's local-twirl reduction.

Every conclusion is derived from the actual Haar twirl and the five fields of
`h`; no invariance or objective-preservation statement is included among the
premises. -/
theorem localTwirlReduction
    (nu : PureVector (a × b)) (gamma : ℝ) (omega : CMatrix (ra × rb))
    {S F : CMatrix (JointContractionPhysicalIndex a b (ra × rb))}
    (h : LocalTwirlPairPremise S F) :
    LocalTwirlReductionCertificate nu gamma omega S F where
  success_posSemidef :=
    physicalLocalTwirl_posSemidef h.success_posSemidef
  failure_posSemidef :=
    physicalLocalTwirl_posSemidef h.failure_posSemidef
  success_ppt :=
    physicalLocalTwirl_preserves_physicalBobPPT h.success_ppt
  failure_ppt :=
    physicalLocalTwirl_preserves_physicalBobPPT h.failure_ppt
  outputTrace_complete :=
    physicalBranchOutputTrace_physicalLocalTwirl_add_eq_one
      h.outputTrace_complete
  success_invariant :=
    physicalLocalTwirl_jointContractionPhysicalInvariant S
  failure_invariant :=
    physicalLocalTwirl_jointContractionPhysicalInvariant F
  success_objective_preserved :=
    trace_physicalEq986FixedResourcePairing_physicalLocalTwirl_eq
      nu gamma omega S
  failure_objective_preserved :=
    trace_physicalEq986FixedResourcePairing_physicalLocalTwirl_eq
      nu gamma omega F

end

end EntanglementPurification
