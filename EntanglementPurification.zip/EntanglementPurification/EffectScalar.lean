import EntanglementPurification.ScalarBounds

/-!
# Scalar consequence of the effect bounds

This file formalizes the real-variable part of the proof of
`eq:sharp_tail_scalar_constraint` in `main.tex`.  The operator layer only has
to provide the two cross-term inequalities; the main theorem below then
deduces the sharp lower bound on the Schmidt tail.
-/

namespace EntanglementPurification

noncomputable section

/-- On the physical interval, `zStar` is the square appearing in the
factorization `eq:explicit_tail_factorization`. -/
theorem zStar_eq_sqrt_difference_sq
    {x : ℝ} (hxLower : (1 / 2 : ℝ) ≤ x) (hxUpper : x ≤ 2 / 3) :
    zStar x =
      ((Real.sqrt x - Real.sqrt (2 - 3 * x)) / 2) ^ 2 := by
  have hxNonneg : 0 ≤ x := by
    linarith
  have hsecondNonneg : 0 ≤ 2 - 3 * x := by
    linarith
  have hsqrtX : (Real.sqrt x) ^ 2 = x :=
    Real.sq_sqrt hxNonneg
  have hsqrtSecond : (Real.sqrt (2 - 3 * x)) ^ 2 = 2 - 3 * x :=
    Real.sq_sqrt hsecondNonneg
  have hsqrtProduct :
      Real.sqrt (x * (2 - 3 * x)) =
        Real.sqrt x * Real.sqrt (2 - 3 * x) :=
    Real.sqrt_mul hxNonneg _
  rw [zStar, hsqrtProduct]
  nlinarith

/-- The sharp scalar constraint from `eq:sharp_tail_scalar_constraint`
implies the optimal tail bound.  Here `x` is `p₀`, `t` is
`∑_{j ≥ 2} p_j`, and `1 - x - t` is `p₁`.

This is the principal pure-real theorem intended to be called by the matrix
effect layer. -/
theorem tail_ge_zStar_of_sharp_scalar_constraint
    {x t : ℝ}
    (hxLower : (1 / 2 : ℝ) ≤ x) (hxUpper : x ≤ 2 / 3)
    (ht : 0 ≤ t) (hpOne : 0 ≤ 1 - x - t)
    (hsharp :
      Real.sqrt (x * (1 - x - t)) ≤
        1 - x + Real.sqrt ((2 - 3 * x) * t)) :
    zStar x ≤ t := by
  have hxNonneg : 0 ≤ x := by
    linarith
  have hsecondNonneg : 0 ≤ 2 - 3 * x := by
    linarith
  have honeSubPos : 0 < 1 - x := by
    linarith
  have hleftRadicand : 0 ≤ x * (1 - x - t) :=
    mul_nonneg hxNonneg hpOne
  have hcrossRadicand : 0 ≤ (2 - 3 * x) * t :=
    mul_nonneg hsecondNonneg ht
  have hleftSq :
      (Real.sqrt (x * (1 - x - t))) ^ 2 = x * (1 - x - t) :=
    Real.sq_sqrt hleftRadicand
  have hcrossSq :
      (Real.sqrt ((2 - 3 * x) * t)) ^ 2 = (2 - 3 * x) * t :=
    Real.sq_sqrt hcrossRadicand
  have hleftNonneg : 0 ≤ Real.sqrt (x * (1 - x - t)) :=
    Real.sqrt_nonneg _
  have hrightNonneg :
      0 ≤ 1 - x + Real.sqrt ((2 - 3 * x) * t) := by
    have := Real.sqrt_nonneg ((2 - 3 * x) * t)
    linarith
  have hsquared :
      (Real.sqrt (x * (1 - x - t))) ^ 2 ≤
        (1 - x + Real.sqrt ((2 - 3 * x) * t)) ^ 2 :=
    (sq_le_sq₀ hleftNonneg hrightNonneg).2 hsharp
  have hfactorBase :
      0 ≤ t + Real.sqrt ((2 - 3 * x) * t) - (x - 1 / 2) := by
    have hproduct :
        0 ≤ 2 * (1 - x) *
          (t + Real.sqrt ((2 - 3 * x) * t) - (x - 1 / 2)) := by
      nlinarith
    exact nonneg_of_mul_nonneg_right hproduct (by positivity)

  have hsqrtT : (Real.sqrt t) ^ 2 = t :=
    Real.sq_sqrt ht
  have hsqrtX : (Real.sqrt x) ^ 2 = x :=
    Real.sq_sqrt hxNonneg
  have hsqrtSecond : (Real.sqrt (2 - 3 * x)) ^ 2 = 2 - 3 * x :=
    Real.sq_sqrt hsecondNonneg
  have hsqrtCross :
      Real.sqrt ((2 - 3 * x) * t) =
        Real.sqrt (2 - 3 * x) * Real.sqrt t :=
    Real.sqrt_mul hsecondNonneg _
  have hfactorization :
      (Real.sqrt t -
          (Real.sqrt x - Real.sqrt (2 - 3 * x)) / 2) *
        (Real.sqrt t +
          (Real.sqrt x + Real.sqrt (2 - 3 * x)) / 2) =
        t + Real.sqrt ((2 - 3 * x) * t) - (x - 1 / 2) := by
    rw [hsqrtCross]
    nlinarith
  have hproductNonneg :
      0 ≤
        (Real.sqrt t -
            (Real.sqrt x - Real.sqrt (2 - 3 * x)) / 2) *
          (Real.sqrt t +
            (Real.sqrt x + Real.sqrt (2 - 3 * x)) / 2) := by
    rw [hfactorization]
    exact hfactorBase
  have hsqrtXPos : 0 < Real.sqrt x :=
    Real.sqrt_pos.2 (by linarith)
  have hsecondFactorPos :
      0 < Real.sqrt t +
        (Real.sqrt x + Real.sqrt (2 - 3 * x)) / 2 := by
    have htSqrtNonneg := Real.sqrt_nonneg t
    have hsecondSqrtNonneg := Real.sqrt_nonneg (2 - 3 * x)
    linarith
  have hfirstFactorNonneg :
      0 ≤ Real.sqrt t -
        (Real.sqrt x - Real.sqrt (2 - 3 * x)) / 2 :=
    nonneg_of_mul_nonneg_left hproductNonneg hsecondFactorPos
  have hsqrtOrder :
      Real.sqrt (2 - 3 * x) ≤ Real.sqrt x :=
    Real.sqrt_le_sqrt (by linarith)
  have hdifferenceNonneg :
      0 ≤ (Real.sqrt x - Real.sqrt (2 - 3 * x)) / 2 := by
    linarith
  have hsquareLe :
      ((Real.sqrt x - Real.sqrt (2 - 3 * x)) / 2) ^ 2 ≤
        (Real.sqrt t) ^ 2 :=
    (sq_le_sq₀ hdifferenceNonneg (Real.sqrt_nonneg t)).2 (by linarith)
  rw [zStar_eq_sqrt_difference_sq hxLower hxUpper]
  nlinarith

/-- A cross-term upper bound and its lower bound evaluated at
`μ = 1 / (3(1-x))` imply the sharp tail estimate.  This statement is a
convenient interface when the operator proof has already performed the
one-variable endpoint minimization. -/
theorem tail_ge_zStar_of_endpoint_cross_bounds
    {x t cross : ℝ}
    (hxLower : (1 / 2 : ℝ) ≤ x) (hxUpper : x ≤ 2 / 3)
    (ht : 0 ≤ t) (hpOne : 0 ≤ 1 - x - t)
    (hcrossUpper : cross ≤ 1 / 3)
    (hcrossLower :
      Real.sqrt (x * (1 - x - t)) / (3 * (1 - x)) -
          Real.sqrt ((2 - 3 * x) * t) / (3 * (1 - x)) ≤ cross) :
    zStar x ≤ t := by
  apply tail_ge_zStar_of_sharp_scalar_constraint hxLower hxUpper ht hpOne
  have hdenominatorPos : 0 < 3 * (1 - x) := by
    nlinarith
  have hquotient :
      (Real.sqrt (x * (1 - x - t)) -
          Real.sqrt ((2 - 3 * x) * t)) / (3 * (1 - x)) ≤ 1 / 3 := by
    rw [sub_div]
    exact hcrossLower.trans hcrossUpper
  have hcleared := (div_le_iff₀ hdenominatorPos).1 hquotient
  nlinarith

/-- Full scalar interface to the effect argument in `main.tex`.

The interval for the normalized effect mean is exactly
`1 / (3(1-x)) ≤ μ ≤ 1`.  The lower cross inequality is
`eq:explicit_two_vector_effect_bound`; monotonicity on this interval and the
cross upper bound produce `eq:sharp_tail_scalar_constraint`, hence the sharp
tail bound. -/
theorem tail_ge_zStar_of_mu_cross_bounds
    {x t μ cross : ℝ}
    (hxLower : (1 / 2 : ℝ) ≤ x) (hxUpper : x ≤ 2 / 3)
    (ht : 0 ≤ t) (hpOne : 0 ≤ 1 - x - t)
    (hmuLower : 1 / (3 * (1 - x)) ≤ μ) (hmuUpper : μ ≤ 1)
    (hcrossUpper : cross ≤ 1 / 3)
    (hcrossLower :
      μ * Real.sqrt (x * (1 - x - t)) -
          Real.sqrt (μ * (1 - μ) * t) ≤ cross) :
    zStar x ≤ t := by
  let m : ℝ := 1 / (3 * (1 - x))
  let d : ℝ := 3 * (1 - x)
  have hdPos : 0 < d := by
    dsimp [d]
    nlinarith
  have hmEq : m = 1 / d := by
    rfl
  have hmLower : (2 / 3 : ℝ) ≤ m := by
    dsimp [m]
    rw [le_div_iff₀ (show 0 < 3 * (1 - x) by nlinarith)]
    nlinarith
  have hmNonneg : 0 ≤ m := by
    linarith
  have hmUpper : m ≤ 1 := by
    rw [hmEq]
    apply (div_le_iff₀ hdPos).2
    dsimp [d]
    nlinarith
  have hmuNonneg : 0 ≤ μ := by
    exact hmNonneg.trans hmuLower
  have honeSubMuNonneg : 0 ≤ 1 - μ := by
    linarith
  have honeSubMNonneg : 0 ≤ 1 - m := by
    linarith
  have hvarianceOrder : μ * (1 - μ) ≤ m * (1 - m) := by
    have hfirst : 0 ≤ μ - m := by
      exact sub_nonneg.2 hmuLower
    have hsecond : 1 - μ - m ≤ 0 := by
      nlinarith
    have hproduct : (μ - m) * (1 - μ - m) ≤ 0 :=
      mul_nonpos_of_nonneg_of_nonpos hfirst hsecond
    nlinarith
  have hvarianceTailOrder :
      μ * (1 - μ) * t ≤ m * (1 - m) * t :=
    mul_le_mul_of_nonneg_right hvarianceOrder ht
  have hsqrtVarianceOrder :
      Real.sqrt (μ * (1 - μ) * t) ≤
        Real.sqrt (m * (1 - m) * t) :=
    Real.sqrt_le_sqrt hvarianceTailOrder
  have hlinearOrder :
      m * Real.sqrt (x * (1 - x - t)) ≤
        μ * Real.sqrt (x * (1 - x - t)) :=
    mul_le_mul_of_nonneg_right hmuLower (Real.sqrt_nonneg _)
  have hendpointToMu :
      m * Real.sqrt (x * (1 - x - t)) -
          Real.sqrt (m * (1 - m) * t) ≤
        μ * Real.sqrt (x * (1 - x - t)) -
          Real.sqrt (μ * (1 - μ) * t) :=
    sub_le_sub hlinearOrder hsqrtVarianceOrder

  have hsecondNonneg : 0 ≤ 2 - 3 * x := by
    linarith
  have htailRadicand : 0 ≤ (2 - 3 * x) * t :=
    mul_nonneg hsecondNonneg ht
  have hvarianceIdentity :
      m * (1 - m) * t = ((2 - 3 * x) * t) / d ^ 2 := by
    rw [hmEq]
    field_simp [ne_of_gt hdPos]
    dsimp [d]
    ring
  have hsqrtVarianceIdentity :
      Real.sqrt (m * (1 - m) * t) =
        Real.sqrt ((2 - 3 * x) * t) / d := by
    rw [hvarianceIdentity, Real.sqrt_div htailRadicand, Real.sqrt_sq hdPos.le]
  have hendpointCrossLower :
      Real.sqrt (x * (1 - x - t)) / (3 * (1 - x)) -
          Real.sqrt ((2 - 3 * x) * t) / (3 * (1 - x)) ≤ cross := by
    calc
      Real.sqrt (x * (1 - x - t)) / (3 * (1 - x)) -
            Real.sqrt ((2 - 3 * x) * t) / (3 * (1 - x)) =
          m * Real.sqrt (x * (1 - x - t)) -
            Real.sqrt (m * (1 - m) * t) := by
              rw [hsqrtVarianceIdentity]
              dsimp [m, d]
              ring
      _ ≤ μ * Real.sqrt (x * (1 - x - t)) -
            Real.sqrt (μ * (1 - μ) * t) := hendpointToMu
      _ ≤ cross := hcrossLower
  exact tail_ge_zStar_of_endpoint_cross_bounds
    hxLower hxUpper ht hpOne hcrossUpper hendpointCrossLower

end

end EntanglementPurification
