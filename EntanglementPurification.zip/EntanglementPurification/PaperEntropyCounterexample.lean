import EntanglementPurification.PhysicalOperationalEntropyConverse
import EntanglementPurification.ExactEntropyCounterexample

/-!
# The paper's entropy counterexample as an operational nonattainment result

This file uses the exact spectrum printed in `main.tex`, namely
`(3/5, 39/100, 1/100)`.  It proves, without decimal approximations, that its
Shannon entropy is larger than one bit while its collision probability is
larger than one half.  The latter contradicts the physical-PPT necessity
theorem, yielding the paper's operational nonattainment conclusion.
-/

namespace EntanglementPurification

open QIT

noncomputable section

/-- The three-point Schmidt spectrum used in
`cor:entropy_not_sufficient` of `main.tex`. -/
def paperEntropyCounterexampleSpectrum : Fin 3 → ℝ :=
  ![(3 / 5 : ℝ), (39 / 100 : ℝ), (1 / 100 : ℝ)]

/-- The paper's spectrum is a nonincreasing probability vector. -/
theorem paperEntropyCounterexampleSpectrum_isOrderedProbability :
    IsOrderedProbability paperEntropyCounterexampleSpectrum := by
  refine ⟨?_, ?_, ?_⟩
  · rw [← List.sortedGE_ofFn_iff, List.sortedGE_iff_pairwise]
    norm_num [paperEntropyCounterexampleSpectrum]
  · intro i
    fin_cases i <;> norm_num [paperEntropyCounterexampleSpectrum]
  · norm_num [paperEntropyCounterexampleSpectrum]

/-- Exact collision probability of the paper's spectrum. -/
theorem paperEntropyCounterexampleSpectrum_collisionProbability :
    collisionProbability paperEntropyCounterexampleSpectrum = 2561 / 5000 := by
  norm_num [collisionProbability, paperEntropyCounterexampleSpectrum]

/-- Consequently the paper's spectrum violates the PPT-required purity
bound. -/
theorem paperEntropyCounterexampleSpectrum_collisionProbability_gt_half :
    (1 / 2 : ℝ) < collisionProbability paperEntropyCounterexampleSpectrum := by
  rw [paperEntropyCounterexampleSpectrum_collisionProbability]
  norm_num

/-- A purely integer certificate for the logarithmic inequality used below.
Taking logarithms of this inequality proves the entropy estimate. -/
theorem paperEntropyCounterexample_integer_certificate :
    (2 : ℝ) ^ 100 <
      ((5 : ℝ) / 3) ^ 60 * ((100 : ℝ) / 39) ^ 39 * 100 := by
  norm_num

/-- The spectrum printed in the paper has Shannon entropy strictly larger
than one bit.  This is exact: no decimal approximation is used. -/
theorem paperEntropyCounterexampleSpectrum_shannonEntropy_gt_one :
    (1 : ℝ) < shannonEntropyBits paperEntropyCounterexampleSpectrum := by
  have hlog := Real.log_lt_log (by positivity)
    paperEntropyCounterexample_integer_certificate
  rw [Real.log_pow, Real.log_mul (by positivity) (by positivity),
    Real.log_mul (by positivity) (by positivity), Real.log_pow,
    Real.log_pow, Real.log_div (by norm_num) (by norm_num),
    Real.log_div (by norm_num) (by norm_num)] at hlog
  have hlogTwoPos : 0 < Real.log 2 := Real.log_pos (by norm_num)
  rw [shannonEntropyBits]
  simp_rw [QIT.xlog2_eq_mul_log2]
  unfold QIT.log2
  simp only [Fin.sum_univ_succ, paperEntropyCounterexampleSpectrum,
    Matrix.cons_val_zero, Matrix.cons_val_succ, Matrix.cons_val_fin_one,
    Finset.univ_eq_empty, Finset.sum_empty, add_zero]
  change
    1 < -((3 / 5 : ℝ) * (Real.log (3 / 5) / Real.log 2) +
      ((39 / 100 : ℝ) * (Real.log (39 / 100) / Real.log 2) +
        (1 / 100 : ℝ) * (Real.log (1 / 100) / Real.log 2)))
  rw [Real.log_div (by norm_num) (by norm_num),
    Real.log_div (by norm_num) (by norm_num),
    Real.log_div (by norm_num) (by norm_num), Real.log_one]
  have hlogTwoNe : Real.log 2 ≠ 0 := ne_of_gt hlogTwoPos
  rw [show
    -((3 / 5 : ℝ) * ((Real.log 3 - Real.log 5) / Real.log 2) +
      ((39 / 100 : ℝ) * ((Real.log 39 - Real.log 100) / Real.log 2) +
        (1 / 100 : ℝ) * ((0 - Real.log 100) / Real.log 2))) =
      (60 * (Real.log 5 - Real.log 3) +
        39 * (Real.log 100 - Real.log 39) + Real.log 100) /
          (100 * Real.log 2) by
    field_simp [hlogTwoNe]
    ring]
  rw [lt_div_iff₀ (mul_pos (by norm_num) hlogTwoPos)]
  norm_num at hlog ⊢
  exact hlog

/-- The actual Lean-QIT entanglement entropy of the signed Schmidt resource
with the paper's spectrum is strictly larger than one ebit. -/
theorem paperEntropyCounterexampleResource_entanglementEntropy_gt_one :
    (1 : ℝ) <
      (ambientSignedSchmidtResource paperEntropyCounterexampleSpectrum
        paperEntropyCounterexampleSpectrum_isOrderedProbability).entanglementEntropy := by
  rw [ambientSignedSchmidtResource_entanglementEntropy]
  simpa [shannonEntropyBits] using
    paperEntropyCounterexampleSpectrum_shannonEntropy_gt_one

/-- Operational form of `cor:entropy_not_sufficient`: for every admissible
benchmark dimension and noise parameter, no physical PPT instrument assisted
by the paper's resource can attain the global optimum. -/
theorem paperEntropyCounterexampleResource_cannot_attain_globalOptimalGain
    {d : ℕ}
    (M : PhysicalPPTInstrument (Fin d) (Fin d) (Fin 3) (Fin 3))
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) :
    physicalPaperOperationalAverageAcceptedGain M hd nu gamma
        hgamma0.le hgamma1.le
        (ambientSignedSchmidtResource paperEntropyCounterexampleSpectrum
          paperEntropyCounterexampleSpectrum_isOrderedProbability) ≠
      globalOptimalGain ((d : ℝ) ^ 2) gamma := by
  intro hattains
  have hnecessary :
      collisionProbability paperEntropyCounterexampleSpectrum ≤ 1 / 2 := by
    exact
      physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_collisionProbability_le_half
        M hd nu hgamma0 hgamma1 paperEntropyCounterexampleSpectrum
          paperEntropyCounterexampleSpectrum_isOrderedProbability hattains
  exact (not_lt_of_ge hnecessary)
    paperEntropyCounterexampleSpectrum_collisionProbability_gt_half

end

end EntanglementPurification
