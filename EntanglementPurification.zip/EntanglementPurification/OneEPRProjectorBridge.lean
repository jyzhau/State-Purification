import EntanglementPurification.OneEPRAcceptedMap
import QIT.Nonlocality.TwoQubit
import QIT.Channels.Diamond
import Mathlib.Tactic

/-!
# Algebraic bridge from the one-EPR equal-outcome branch to the accepted map

This file formalizes the two matrix identities used between the circuit
description of Algorithm 1 and the Choi calculation in `main.tex`:

1. after the EPR controls, local Hadamards, and either equal computational
   outcome, the induced operator on the two copies is
   `1 / sqrt 2` times the complete-copy symmetric projector;
2. coarse-graining the two equal outcomes and then tracing out the second
   copy gives exactly `oneEPRAcceptedMap`.

The local controlled swaps are represented below by their finite-coordinate
permutation matrices.  This is an algebraic gate calculation, not yet a
formal definition of a general LOCC protocol or of classical communication.
-/

namespace EntanglementPurification

open QIT

noncomputable section

/-- Amplitude of the standard EPR pair `( |00> + |11> ) / sqrt 2`. -/
def standardEPRAmp : Bool × Bool → ℂ
  | (false, false) => TwoQubit.invSqrtTwo
  | (true, true) => TwoQubit.invSqrtTwo
  | _ => 0

/-- Computational-basis matrix element `⟨out|H|input⟩` of a Hadamard gate. -/
def hadamardAmp : Bool → Bool → ℂ
  | false, _ => TwoQubit.invSqrtTwo
  | true, false => TwoQubit.invSqrtTwo
  | true, true => -TwoQubit.invSqrtTwo

/-- Coordinate permutation produced by Alice's swap when `controlA = true`
and Bob's swap when `controlB = true`.  The index order is
`(A₁B₁, A₂B₂)`. -/
def locallyControlledCopySwapIndex
    {a b : Type*} (controlA controlB : Bool)
    (p : (a × b) × (a × b)) : (a × b) × (a × b) :=
  ( (cond controlA p.2.1 p.1.1, cond controlB p.2.2 p.1.2),
    (cond controlA p.1.1 p.2.1, cond controlB p.1.2 p.2.2) )

/-- Permutation matrix of the two local controlled swaps, conditioned on a
fixed pair of resource-control values. -/
def locallyControlledCopySwap
    {a b : Type*} [DecidableEq a] [DecidableEq b]
    (controlA controlB : Bool) :
    CMatrix ((a × b) × (a × b)) :=
  fun row col =>
    if col = locallyControlledCopySwapIndex controlA controlB row then 1 else 0

/-- With both controls zero, neither local copy is swapped. -/
theorem locallyControlledCopySwap_false_false
    {a b : Type*} [DecidableEq a] [DecidableEq b] :
    locallyControlledCopySwap (a := a) (b := b) false false = 1 := by
  ext row col
  rcases row with ⟨⟨a₁, b₁⟩, ⟨a₂, b₂⟩⟩
  rcases col with ⟨⟨a₁', b₁'⟩, ⟨a₂', b₂'⟩⟩
  simp only [locallyControlledCopySwap, locallyControlledCopySwapIndex,
    cond_false, Matrix.one_apply, Prod.mk.injEq]
  congr 1
  apply propext
  constructor
  · rintro ⟨⟨ha, hb⟩, hc, hd⟩
    exact ⟨⟨ha.symm, hb.symm⟩, hc.symm, hd.symm⟩
  · rintro ⟨⟨ha, hb⟩, hc, hd⟩
    exact ⟨⟨ha.symm, hb.symm⟩, hc.symm, hd.symm⟩

/-- With both controls one, the two local swaps equal the swap of the two
complete bipartite copies. -/
theorem locallyControlledCopySwap_true_true
    {a b : Type*} [DecidableEq a] [DecidableEq b] :
    locallyControlledCopySwap (a := a) (b := b) true true =
      globalInputPairSwap (x := a × b) := by
  ext row col
  rcases row with ⟨⟨a₁, b₁⟩, ⟨a₂, b₂⟩⟩
  rcases col with ⟨⟨a₁', b₁'⟩, ⟨a₂', b₂'⟩⟩
  simp [locallyControlledCopySwap, locallyControlledCopySwapIndex,
    globalInputPairSwap]

/-- The system operator induced by one specified pair of Hadamard measurement
outcomes.  The sum is the coherent contraction of the EPR resource indices;
the resource is not retained in the output. -/
def oneEPRHadamardOutcomeKraus
    {a b : Type*} [DecidableEq a] [DecidableEq b]
    (outcomeA outcomeB : Bool) :
    CMatrix ((a × b) × (a × b)) :=
  ∑ controlA : Bool, ∑ controlB : Bool,
    (standardEPRAmp (controlA, controlB) *
        hadamardAmp outcomeA controlA * hadamardAmp outcomeB controlB) •
      locallyControlledCopySwap controlA controlB

/-- Each accepted outcome (`00` or `11`) induces `P_sym / sqrt 2` on the two
complete copies.  This is the finite-coordinate form of the calculation at
`main.tex:560-604`. -/
theorem oneEPRHadamard_equalOutcomeKraus
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] (outcome : Bool) :
    oneEPRHadamardOutcomeKraus (a := a) (b := b) outcome outcome =
      TwoQubit.invSqrtTwo • globalInputPairPSym (x := a × b) := by
  have hcubic :
      TwoQubit.invSqrtTwo * TwoQubit.invSqrtTwo * TwoQubit.invSqrtTwo =
        (1 / 2 : ℂ) * TwoQubit.invSqrtTwo := by
    rw [TwoQubit.invSqrtTwo_mul_self]
  have hcubicSigns :
      TwoQubit.invSqrtTwo * (-TwoQubit.invSqrtTwo) *
          (-TwoQubit.invSqrtTwo) =
        (1 / 2 : ℂ) * TwoQubit.invSqrtTwo := by
    calc
      TwoQubit.invSqrtTwo * (-TwoQubit.invSqrtTwo) *
            (-TwoQubit.invSqrtTwo) =
          TwoQubit.invSqrtTwo * TwoQubit.invSqrtTwo *
            TwoQubit.invSqrtTwo := by ring
      _ = (1 / 2 : ℂ) * TwoQubit.invSqrtTwo := hcubic
  cases outcome
  · simp only [oneEPRHadamardOutcomeKraus, Fintype.sum_bool,
      standardEPRAmp, hadamardAmp, zero_mul, zero_smul, add_zero,
      locallyControlledCopySwap_false_false,
      locallyControlledCopySwap_true_true, hcubic]
    simp only [globalInputPairPSym]
    module
  · simp only [oneEPRHadamardOutcomeKraus, Fintype.sum_bool,
      standardEPRAmp, hadamardAmp, zero_mul, zero_smul, add_zero,
      locallyControlledCopySwap_false_false,
      locallyControlledCopySwap_true_true, hcubic, hcubicSigns]
    simp only [globalInputPairPSym]
    module

/-- The accepted two-copy map obtained by classically coarse-graining the
separately recorded equal outcomes `00` and `11`. -/
def oneEPREqualOutcomeTwoCopyMap
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    MatrixMap (((a × b) × (a × b))) (((a × b) × (a × b))) :=
  MatrixMap.ofKraus
    (fun outcome : Bool =>
      oneEPRHadamardOutcomeKraus (a := a) (b := b) outcome outcome)

/-- Coarse-graining `00` and `11` removes the factor `1 / sqrt 2`: the
unnormalized accepted two-copy state is exactly `P_sym X P_sym`. -/
theorem oneEPREqualOutcomeTwoCopyMap_apply
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b]
    (X : CMatrix (((a × b) × (a × b)))) :
    oneEPREqualOutcomeTwoCopyMap (a := a) (b := b) X =
      globalInputPairPSym (x := a × b) * X *
        globalInputPairPSym (x := a × b) := by
  simp only [oneEPREqualOutcomeTwoCopyMap, MatrixMap.ofKraus,
    LinearMap.coe_mk, AddHom.coe_mk, Fintype.sum_bool,
    oneEPRHadamard_equalOutcomeKraus, Matrix.smul_mul,
    Matrix.mul_smul, Matrix.conjTranspose_smul,
    TwoQubit.star_invSqrtTwo, smul_smul]
  rw [globalInputPairPSym_isHermitian]
  rw [TwoQubit.invSqrtTwo_mul_self]
  module

/-- Kraus operator obtained by projecting onto the complete-copy symmetric
subspace and contracting the second copy with basis vector `i`. -/
def symmetricProjectorDiscardKraus
    {x : Type*} [DecidableEq x] (i : x) :
    Matrix x (x × x) ℂ :=
  fun out input => globalInputPairPSym (out, i) input

/-- The projector-and-discard Kraus family is exactly the family used in
`oneEPRAcceptedMap`. -/
theorem symmetricProjectorDiscardKraus_eq_oneEPRAcceptedKraus
    {x : Type*} [DecidableEq x] (i : x) :
    symmetricProjectorDiscardKraus (x := x) i =
      oneEPRAcceptedKraus (x := x) i := by
  ext out input
  rcases input with ⟨a, b⟩
  simp only [symmetricProjectorDiscardKraus, globalInputPairPSym,
    Matrix.smul_apply, smul_eq_mul, Matrix.add_apply, Matrix.one_apply,
    globalInputPairSwap, oneEPRAcceptedKraus, globalGammaPlus,
    globalGamma1, globalGamma2]
  simp only [Prod.mk.injEq, eq_comm, ← ite_and, and_comm]

/-- Map obtained by symmetric projection and discarding the second copy. -/
def symmetricProjectorDiscardMap
    {x : Type*} [Fintype x] [DecidableEq x] :
    MatrixMap (x × x) x :=
  MatrixMap.ofKraus (symmetricProjectorDiscardKraus (x := x))

/-- The Kraus definition above acts as the paper's explicit
`Tr₂[P_sym X P_sym]`. -/
theorem symmetricProjectorDiscardMap_apply
    {x : Type*} [Fintype x] [DecidableEq x]
    (X : CMatrix (x × x)) :
    symmetricProjectorDiscardMap (x := x) X =
      QIT.partialTraceB
        (globalInputPairPSym (x := x) * X * globalInputPairPSym) := by
  ext out out'
  simp only [symmetricProjectorDiscardMap, MatrixMap.ofKraus,
    LinearMap.coe_mk, AddHom.coe_mk, Matrix.sum_apply,
    symmetricProjectorDiscardKraus, Matrix.mul_apply,
    Matrix.conjTranspose_apply, QIT.partialTraceB]
  have hHerm := globalInputPairPSym_isHermitian (x := x)
  rw [Matrix.IsHermitian] at hHerm
  have hstar : ∀ (p q : x × x),
      star (globalInputPairPSym (x := x) p q) =
        globalInputPairPSym q p := by
    intro p q
    have h := congrArg (fun M : CMatrix (x × x) => M q p) hHerm
    change star (globalInputPairPSym (x := x) p q) =
      globalInputPairPSym q p at h
    exact h
  simp_rw [hstar]

/-- The projector/partial-trace description of the accepted Algorithm 1
branch is definitionally the same matrix map as `oneEPRAcceptedMap`. -/
theorem symmetricProjectorDiscardMap_eq_oneEPRAcceptedMap
    {x : Type*} [Fintype x] [DecidableEq x] :
    symmetricProjectorDiscardMap (x := x) =
      oneEPRAcceptedMap (x := x) := by
  have hK : symmetricProjectorDiscardKraus (x := x) =
      oneEPRAcceptedKraus (x := x) := by
    funext i
    exact symmetricProjectorDiscardKraus_eq_oneEPRAcceptedKraus i
  simp only [symmetricProjectorDiscardMap, oneEPRAcceptedMap, hK]

/-- End-to-end algebraic bridge for Algorithm 1 after the local gate
coordinates have been fixed: accept equal outcomes, discard the second copy,
and obtain the existing globally optimal accepted map. -/
theorem oneEPREqualOutcome_then_discard_eq_oneEPRAcceptedMap
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b]
    (X : CMatrix (((a × b) × (a × b)))) :
    QIT.partialTraceB
        (oneEPREqualOutcomeTwoCopyMap (a := a) (b := b) X) =
      oneEPRAcceptedMap (x := a × b) X := by
  rw [oneEPREqualOutcomeTwoCopyMap_apply]
  rw [← symmetricProjectorDiscardMap_apply]
  rw [symmetricProjectorDiscardMap_eq_oneEPRAcceptedMap]

/-- Actual matrix-map composition represented by the fixed gate algebra:
first coarse-grain the two equal resource-qubit outcomes, then trace out the
second noisy copy.  The name `concrete` refers to this fixed finite-coordinate
construction; no general LOCC syntax is asserted here. -/
def oneEPRConcreteAcceptedMap
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    MatrixMap (((a × b) × (a × b))) (a × b) :=
  (MatrixMap.partialTraceB (a × b) (a × b)).comp
    (oneEPREqualOutcomeTwoCopyMap (a := a) (b := b))

/-- Map-level Algorithm 1 bridge: the explicit EPR/control/Hadamard/equal-
outcome/trace construction is exactly the already verified globally optimal
accepted map. -/
theorem oneEPRConcreteAcceptedMap_eq_oneEPRAcceptedMap
    {a b : Type*} [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    oneEPRConcreteAcceptedMap (a := a) (b := b) =
      oneEPRAcceptedMap (x := a × b) := by
  apply LinearMap.ext
  intro X
  change QIT.partialTraceB
      (oneEPREqualOutcomeTwoCopyMap (a := a) (b := b) X) =
    oneEPRAcceptedMap (x := a × b) X
  exact oneEPREqualOutcome_then_discard_eq_oneEPRAcceptedMap X

end

end EntanglementPurification
