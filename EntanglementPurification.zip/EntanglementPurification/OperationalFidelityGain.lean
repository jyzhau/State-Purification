import EntanglementPurification.GlobalChoiObjective
import QIT.States.Subnormalized
import QIT.States.Geometry.PureTargetFidelity
import Mathlib.Tactic

/-!
# Operational accepted fidelity gain

This file formalizes the operational score used before equation 986 of
`main.tex`.  An accepted branch is trace-nonincreasing, so its output is a
positive, possibly subnormalized matrix.  The paper uses the homogeneous
squared fidelity

`F(rho, tau) = ||sqrt(rho) sqrt(tau)||_1^2`,

without the extra failure-mass term occurring in generalized fidelity for two
subnormalized states.  Against a pure target this quantity is the ordinary
trace overlap.  Consequently the success-weighted gain is a linear matrix
pairing, and Lean-QIT's input-first Choi identity turns it into the SDP
objective used later in the development.
-/

namespace EntanglementPurification

open QIT Matrix
open scoped ComplexOrder MatrixOrder

noncomputable section

universe u v

variable {a : Type u} [Fintype a] [DecidableEq a]

/-- Homogeneous squared fidelity for positive subnormalized matrices.  Unlike
`SubnormalizedState.generalizedFidelity`, this definition has no orthogonal
failure-register contribution. -/
def homogeneousSquaredFidelity
    (rho sigma : SubnormalizedState a) : ℝ :=
  traceNorm (psdSqrt rho.matrix * psdSqrt sigma.matrix) ^ 2

@[simp]
theorem homogeneousSquaredFidelity_eq
    (rho sigma : SubnormalizedState a) :
    homogeneousSquaredFidelity rho sigma =
      traceNorm (psdSqrt rho.matrix * psdSqrt sigma.matrix) ^ 2 :=
  rfl

/-- Homogeneous squared fidelity is symmetric. -/
theorem homogeneousSquaredFidelity_comm
    (rho sigma : SubnormalizedState a) :
    homogeneousSquaredFidelity rho sigma =
      homogeneousSquaredFidelity sigma rho := by
  unfold homogeneousSquaredFidelity
  rw [← traceNorm_conjTranspose
    (psdSqrt rho.matrix * psdSqrt sigma.matrix)]
  rw [Matrix.conjTranspose_mul, psdSqrt_isHermitian,
    psdSqrt_isHermitian]

private theorem pureState_mul_matrix_mul_pureState
    (A : CMatrix a) (target : PureVector a) :
    target.state.matrix * A * target.state.matrix =
      ((A * target.state.matrix).trace) • target.state.matrix := by
  let c : ℂ := (star target.amp ᵥ* A) ⬝ᵥ target.amp
  have hc : c = (A * target.state.matrix).trace := by
    dsimp [c]
    simp only [Matrix.vecMul, dotProduct, rankOneMatrix, Matrix.trace,
      Matrix.diag, Matrix.mul_apply, Matrix.vecMulVec_apply]
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro x _
    rw [Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro y _
    ac_rfl
  rw [← hc]
  simp only [PureVector.state_matrix, rankOneMatrix]
  rw [Matrix.vecMulVec_mul, Matrix.vecMulVec_mul_vecMulVec,
    Matrix.vecMulVec_smul]
  change c • vecMulVec target.amp (fun i => star (target.amp i)) =
    c • vecMulVec target.amp (fun i => star (target.amp i))
  rfl

private theorem psdSqrt_pureState_matrix (target : PureVector a) :
    psdSqrt target.state.matrix = target.state.matrix := by
  calc
    psdSqrt target.state.matrix =
        psdSqrt (target.state.matrix * target.state.matrix) := by
      rw [target.state_matrix_mul_self]
    _ = target.state.matrix := by
      simpa [psdSqrt] using
        (CFC.sqrt_unique (b := target.state.matrix) rfl
          target.state.pos.nonneg)

/-- Homogeneous squared fidelity of an arbitrary subnormalized state against a
pure target is its trace overlap. -/
theorem homogeneousSquaredFidelity_pure_right_eq_trace
    (rho : SubnormalizedState a) (target : PureVector a) :
    homogeneousSquaredFidelity rho target.state.toSubnormalized =
      ((rho.matrix * target.state.matrix).trace).re := by
  let P : CMatrix a := target.state.matrix
  let M : CMatrix a := psdSqrt rho.matrix * P
  let t : ℝ := ((rho.matrix * P).trace).re
  have hMstar : Matrix.conjTranspose M = P * psdSqrt rho.matrix := by
    simp [M, P, Matrix.conjTranspose_mul,
      (psdSqrt_isHermitian rho.matrix).eq]
  have hgramC :
      Matrix.conjTranspose M * M = ((rho.matrix * P).trace) • P := by
    rw [hMstar]
    change P * psdSqrt rho.matrix * (psdSqrt rho.matrix * P) =
      ((rho.matrix * P).trace) • P
    rw [show P * psdSqrt rho.matrix * (psdSqrt rho.matrix * P) =
      P * (psdSqrt rho.matrix * psdSqrt rho.matrix) * P by
        noncomm_ring,
      psdSqrt_mul_self_of_posSemidef rho.pos]
    simpa [P] using pureState_mul_matrix_mul_pureState rho.matrix target
  have hgramPos : (Matrix.conjTranspose M * M).PosSemidef :=
    Matrix.posSemidef_conjTranspose_mul_self M
  have hc : (rho.matrix * P).trace = (t : ℂ) := by
    apply Complex.ext
    · rfl
    · have him : (Matrix.conjTranspose M * M).trace.im = 0 :=
        (Matrix.PosSemidef.trace_nonneg hgramPos).2.symm
      rw [hgramC, Matrix.trace_smul, target.state.trace_eq_one] at him
      simpa [t] using him
  have hgram : Matrix.conjTranspose M * M = (t : ℂ) • P := by
    rw [hgramC, hc]
  have ht0 : 0 ≤ t := by
    have htrace := (Matrix.PosSemidef.trace_nonneg hgramPos).1
    change 0 ≤ (Matrix.conjTranspose M * M).trace.re at htrace
    rw [hgram, Matrix.trace_smul, target.state.trace_eq_one] at htrace
    simpa [t] using htrace
  have hsqrt :
      psdSqrt (Matrix.conjTranspose M * M) =
        (Real.sqrt t : ℂ) • P := by
    rw [hgram]
    apply CFC.sqrt_unique
    · change ((Real.sqrt t : ℂ) • P) * ((Real.sqrt t : ℂ) • P) =
        (t : ℂ) • P
      simp only [Matrix.smul_mul, Matrix.mul_smul]
      have hP : P * P = P := by
        simpa [P] using target.state_matrix_mul_self
      rw [hP]
      have hcoeff :
          (Real.sqrt t : ℂ) * (Real.sqrt t : ℂ) = (t : ℂ) := by
        norm_cast
        simpa [pow_two] using Real.sq_sqrt ht0
      ext i j
      change (Real.sqrt t : ℂ) * ((Real.sqrt t : ℂ) * P i j) =
        (t : ℂ) * P i j
      rw [← mul_assoc, hcoeff]
    · apply Matrix.nonneg_iff_posSemidef.mpr
      simpa using target.state.pos.smul (Real.sqrt_nonneg t)
  rw [homogeneousSquaredFidelity, State.toSubnormalized_matrix,
    psdSqrt_pureState_matrix]
  change traceNorm M ^ 2 = t
  rw [traceNorm, hsqrt, Matrix.trace_smul, target.state.trace_eq_one]
  simp [Real.sq_sqrt ht0]

/-- Pure-target form in the argument order used by the paper. -/
theorem homogeneousSquaredFidelity_pure_left_eq_trace
    (target : PureVector a) (rho : SubnormalizedState a) :
    homogeneousSquaredFidelity target.state.toSubnormalized rho =
      ((target.state.matrix * rho.matrix).trace).re := by
  rw [homogeneousSquaredFidelity_comm,
    homogeneousSquaredFidelity_pure_right_eq_trace,
    Matrix.trace_mul_comm]

variable {input output : Type v}
  [Fintype input] [DecidableEq input]
  [Fintype output] [DecidableEq output]

/-- Unnormalized output of an accepted trace-nonincreasing CP branch on a
normalized input state. -/
def acceptedOutput
    (rho : State input) (Phi : MatrixMap input output)
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) :
    SubnormalizedState output :=
  rho.toSubnormalized.applyTraceNonincreasingCP Phi hPhi

@[simp]
theorem acceptedOutput_matrix
    (rho : State input) (Phi : MatrixMap input output)
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) :
    (acceptedOutput rho Phi hPhi).matrix = Phi rho.matrix :=
  rfl

/-- Success probability of an accepted branch. -/
def acceptedProbability
    (rho : State input) (Phi : MatrixMap input output)
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) : ℝ :=
  (acceptedOutput rho Phi hPhi).matrix.trace.re

theorem acceptedProbability_nonneg
    (rho : State input) (Phi : MatrixMap input output)
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) :
    0 ≤ acceptedProbability rho Phi hPhi :=
  (acceptedOutput rho Phi hPhi).trace_nonneg

theorem acceptedProbability_le_one
    (rho : State input) (Phi : MatrixMap input output)
    (hPhi : MatrixMap.TraceNonincreasingCP Phi) :
    acceptedProbability rho Phi hPhi ≤ 1 :=
  (acceptedOutput rho Phi hPhi).trace_le_one

/-- Success-weighted fidelity gain against a pure target.  `baseline` is the
single-copy target fidelity subtracted on every successful run. -/
def acceptedPureTargetGain
    (rho : State input) (Phi : MatrixMap input output)
    (hPhi : MatrixMap.TraceNonincreasingCP Phi)
    (target : PureVector output) (baseline : ℝ) : ℝ :=
  homogeneousSquaredFidelity target.state.toSubnormalized
      (acceptedOutput rho Phi hPhi) -
    acceptedProbability rho Phi hPhi * baseline

/-- The operational pure-target gain is the trace pairing with
`|target><target| - baseline I`. -/
theorem acceptedPureTargetGain_eq_trace
    (rho : State input) (Phi : MatrixMap input output)
    (hPhi : MatrixMap.TraceNonincreasingCP Phi)
    (target : PureVector output) (baseline : ℝ) :
    acceptedPureTargetGain rho Phi hPhi target baseline =
      (((target.state.matrix - baseline • (1 : CMatrix output)) *
        Phi rho.matrix).trace).re := by
  rw [acceptedPureTargetGain,
    homogeneousSquaredFidelity_pure_left_eq_trace]
  simp [acceptedProbability, Matrix.sub_mul, Complex.mul_re]
  ring

/-- Input-first Choi form of the operational pure-target gain. -/
theorem acceptedPureTargetGain_eq_globalSDPObjective_choi
    (rho : State input) (Phi : MatrixMap input output)
    (hPhi : MatrixMap.TraceNonincreasingCP Phi)
    (target : PureVector output) (baseline : ℝ) :
    acceptedPureTargetGain rho Phi hPhi target baseline =
      globalSDPObjective
        (Matrix.kronecker rho.matrix.transpose
          (target.state.matrix - baseline • (1 : CMatrix output)))
        (MatrixMap.choi Phi) := by
  rw [acceptedPureTargetGain_eq_trace]
  exact trace_mul_map_re_eq_globalSDPObjective_choi
    Phi rho.matrix
      (target.state.matrix - baseline • (1 : CMatrix output))

end

end EntanglementPurification
