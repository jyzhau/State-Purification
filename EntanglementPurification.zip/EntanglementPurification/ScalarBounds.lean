import QIT.Entanglement.Majorization
import Mathlib.Data.Real.Sqrt
import Mathlib.Tactic

/-!
# Scalar bounds from the Schmidt-spectrum converse

This file starts formalizing the scalar core of Appendix
"Effect Constraints and Schmidt-Spectrum Bounds" in `main.tex`.
-/

namespace EntanglementPurification

noncomputable section

/-- The three-point boundary spectrum's smallest weight, equation
`eq:boundary_spectrum_definition` in `main.tex`. -/
def zStar (x : ℝ) : ℝ :=
  (1 - x - Real.sqrt (x * (2 - 3 * x))) / 2

/-- On the interval 1/2 ≤ x ≤ 2/3, the radicand in zStar is
nonnegative. -/
theorem zStar_radicand_nonneg_on_interval
    {x : ℝ} (hxLower : (1 / 2 : ℝ) ≤ x) (hxUpper : x ≤ 2 / 3) :
    0 ≤ x * (2 - 3 * x) := by
  have hxNonneg : 0 ≤ x := by
    linarith
  have hsecondNonneg : 0 ≤ 2 - 3 * x := by
    linarith
  exact mul_nonneg hxNonneg hsecondNonneg

/-- Equation `eq:zstar_boundary` in `main.tex`. -/
theorem zStar_mul_complement
    {x : ℝ} (hx : 0 ≤ x * (2 - 3 * x)) :
    zStar x * (1 - x - zStar x) = (x - 1 / 2) ^ 2 := by
  have hsqrt : (Real.sqrt (x * (2 - 3 * x))) ^ 2 = x * (2 - 3 * x) :=
    Real.sq_sqrt hx
  simp only [zStar]
  nlinarith

/-- The boundary comparison spectrum has collision probability exactly `1/2`,
equation `eq:boundary_purity_half` in `main.tex`. -/
theorem boundary_purity_half
    {x : ℝ} (hx : 0 ≤ x * (2 - 3 * x)) :
    x ^ 2 + (1 - x - zStar x) ^ 2 + zStar x ^ 2 = 1 / 2 := by
  have hprod := zStar_mul_complement hx
  nlinarith

/-- The smallest component of the boundary comparison spectrum is
nonnegative throughout 1/2 ≤ x ≤ 2/3. -/
theorem zStar_nonneg_on_interval
    {x : ℝ} (_hxLower : (1 / 2 : ℝ) ≤ x) (hxUpper : x ≤ 2 / 3) :
    0 ≤ zStar x := by
  have hsqrtLe :
      Real.sqrt (x * (2 - 3 * x)) ≤ 1 - x := by
    rw [Real.sqrt_le_iff]
    constructor
    · linarith
    · nlinarith [sq_nonneg (2 * x - 1)]
  rw [zStar]
  linarith

/-- Every component of the boundary comparison spectrum
(x, 1 - x - zStar x, zStar x) is nonnegative on the interval. -/
theorem boundary_spectrum_nonnegative_on_interval
    {x : ℝ} (hxLower : (1 / 2 : ℝ) ≤ x) (hxUpper : x ≤ 2 / 3) :
    0 ≤ x ∧ 0 ≤ 1 - x - zStar x ∧ 0 ≤ zStar x := by
  have hxNonneg : 0 ≤ x := by
    linarith
  have hzNonneg := zStar_nonneg_on_interval hxLower hxUpper
  have hsqrtNonneg : 0 ≤ Real.sqrt (x * (2 - 3 * x)) :=
    Real.sqrt_nonneg _
  have hzLeMiddle : zStar x ≤ 1 - x - zStar x := by
    rw [zStar]
    linarith
  exact ⟨hxNonneg, le_trans hzNonneg hzLeMiddle, hzNonneg⟩

/-- The boundary comparison spectrum is nonincreasing:
x ≥ 1 - x - zStar x ≥ zStar x. -/
theorem boundary_spectrum_nonincreasing_on_interval
    {x : ℝ} (hxLower : (1 / 2 : ℝ) ≤ x) (_hxUpper : x ≤ 2 / 3) :
    1 - x - zStar x ≤ x ∧ zStar x ≤ 1 - x - zStar x := by
  have hsqrtLe :
      Real.sqrt (x * (2 - 3 * x)) ≤ 3 * x - 1 := by
    rw [Real.sqrt_le_iff]
    constructor
    · linarith
    · have hfirst : 0 ≤ 2 * x - 1 := by
        linarith
      have hsecond : 0 ≤ 6 * x - 1 := by
        linarith
      nlinarith [mul_nonneg hfirst hsecond]
  have hsqrtNonneg : 0 ≤ Real.sqrt (x * (2 - 3 * x)) :=
    Real.sqrt_nonneg _
  constructor
  · rw [zStar]
    linarith
  · rw [zStar]
    linarith

/-- The three entries of the boundary comparison spectrum sum to one. -/
theorem boundary_spectrum_sum_eq_one_on_interval
    {x : ℝ} (_hxLower : (1 / 2 : ℝ) ≤ x) (_hxUpper : x ≤ 2 / 3) :
    x + (1 - x - zStar x) + zStar x = 1 := by
  ring

/-- On 1/2 ≤ x ≤ 2/3, the boundary comparison triple is a nonnegative,
nonincreasing probability vector. -/
theorem boundary_spectrum_is_probability_on_interval
    {x : ℝ} (hxLower : (1 / 2 : ℝ) ≤ x) (hxUpper : x ≤ 2 / 3) :
    (0 ≤ x ∧ 0 ≤ 1 - x - zStar x ∧ 0 ≤ zStar x) ∧
      (1 - x - zStar x ≤ x ∧ zStar x ≤ 1 - x - zStar x) ∧
      x + (1 - x - zStar x) + zStar x = 1 := by
  exact ⟨boundary_spectrum_nonnegative_on_interval hxLower hxUpper,
    boundary_spectrum_nonincreasing_on_interval hxLower hxUpper,
    boundary_spectrum_sum_eq_one_on_interval hxLower hxUpper⟩

/-- Interval-specialized form of zStar_mul_complement. -/
theorem zStar_mul_complement_on_interval
    {x : ℝ} (hxLower : (1 / 2 : ℝ) ≤ x) (hxUpper : x ≤ 2 / 3) :
    zStar x * (1 - x - zStar x) = (x - 1 / 2) ^ 2 := by
  exact zStar_mul_complement
    (zStar_radicand_nonneg_on_interval hxLower hxUpper)

/-- Interval-specialized form of the exact purity identity. -/
theorem boundary_purity_half_on_interval
    {x : ℝ} (hxLower : (1 / 2 : ℝ) ≤ x) (hxUpper : x ≤ 2 / 3) :
    x ^ 2 + (1 - x - zStar x) ^ 2 + zStar x ^ 2 = 1 / 2 := by
  exact boundary_purity_half
    (zStar_radicand_nonneg_on_interval hxLower hxUpper)

/-- Away from the left endpoint, zStar strictly dominates twice the
squared displacement from 1/2. -/
theorem zStar_gt_twice_square_on_interval
    {x : ℝ} (hxLower : (1 / 2 : ℝ) ≤ x) (hxUpper : x ≤ 2 / 3)
    (hxStrict : (1 / 2 : ℝ) < x) :
    2 * (x - 1 / 2) ^ 2 < zStar x := by
  have hnonnegative :=
    boundary_spectrum_nonnegative_on_interval hxLower hxUpper
  have hzNonneg : 0 ≤ zStar x := hnonnegative.2.2
  have hproduct :=
    zStar_mul_complement_on_interval hxLower hxUpper
  have hsquarePos : 0 < (x - 1 / 2) ^ 2 :=
    sq_pos_of_pos (sub_pos.mpr hxStrict)
  have hproductPos :
      0 < zStar x * (1 - x - zStar x) := by
    rw [hproduct]
    exact hsquarePos
  have hzNe : zStar x ≠ 0 := by
    intro hzZero
    rw [hzZero, zero_mul] at hproductPos
    exact (lt_irrefl 0) hproductPos
  have hzPos : 0 < zStar x :=
    lt_of_le_of_ne hzNonneg (Ne.symm hzNe)
  have hmiddleLtHalf : 1 - x - zStar x < 1 / 2 := by
    linarith
  have hpositiveDifference :
      0 < zStar x * (1 - 2 * (1 - x - zStar x)) :=
    mul_pos hzPos (by linarith)
  calc
    2 * (x - 1 / 2) ^ 2 =
        2 * (zStar x * (1 - x - zStar x)) := by rw [hproduct]
    _ < zStar x := by
      nlinarith

/-- The rational spectrum used by Corollary `entropy_not_sufficient` is a
nonincreasing probability vector. -/
theorem counterexample_spectrum_is_probability :
    (0 : ℝ) ≤ 1 / 100 ∧
      (1 / 100 : ℝ) ≤ 39 / 100 ∧
      (39 / 100 : ℝ) ≤ 3 / 5 ∧
      (3 / 5 : ℝ) + 39 / 100 + 1 / 100 = 1 := by
  norm_num

/-- Exact collision probability calculation in Corollary
`entropy_not_sufficient`. -/
theorem counterexample_collision_probability :
    (3 / 5 : ℝ) ^ 2 + (39 / 100 : ℝ) ^ 2 + (1 / 100 : ℝ) ^ 2 =
      2561 / 5000 := by
  norm_num

/-- The counterexample violates the necessary collision-probability bound. -/
theorem counterexample_violates_half_bound :
    (1 / 2 : ℝ) <
      (3 / 5 : ℝ) ^ 2 + (39 / 100 : ℝ) ^ 2 + (1 / 100 : ℝ) ^ 2 := by
  rw [counterexample_collision_probability]
  norm_num

end

end EntanglementPurification
