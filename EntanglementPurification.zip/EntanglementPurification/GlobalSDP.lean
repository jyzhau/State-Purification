import QIT.Core.Map
import QIT.Util.SDP.HermitianPSDTraceDuality
import Mathlib.Tactic

/-!
# Global CPTN semidefinite program

This file gives the matrix-level primal/dual formulation used in main.tex,
equation eq:gd_global_cptn_sdp. It is independent of the later four-sector
calculation of the concrete performance operator.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

/-- Choi-matrix feasibility for a completely positive trace-nonincreasing
map in the paper's input-first convention. -/
def IsGlobalCPTNChoi
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    (J : CMatrix (Prod x y)) : Prop :=
  J.PosSemidef ∧ QIT.partialTraceB (a := x) (b := y) J ≤ 1

/-- Real SDP objective Re Tr(MJ). It is real without the explicit real part
whenever M and J are Hermitian. -/
def globalSDPObjective
    {h : Type*} [Fintype h] (M J : CMatrix h) : ℝ :=
  ((M * J).trace).re

/-- For a Hermitian performance operator, the trace pairing with every
feasible Choi matrix is genuinely real, not merely real after applying
`Complex.re`. -/
theorem globalSDPObjective_trace_im_eq_zero
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    {M J : CMatrix (Prod x y)}
    (hM : M.IsHermitian) (hJ : IsGlobalCPTNChoi J) :
    ((M * J).trace).im = 0 :=
  QIT.trace_mul_isHermitian_im_eq_zero hM hJ.1.isHermitian

/-- Complex-valued form of the preceding real-valuedness statement: on the
feasible set, the paper's literal `Tr(MJ)` equals the complex coercion of the
real SDP objective. -/
theorem trace_mul_eq_coe_globalSDPObjective
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    {M J : CMatrix (Prod x y)}
    (hM : M.IsHermitian) (hJ : IsGlobalCPTNChoi J) :
    (M * J).trace = (globalSDPObjective M J : ℂ) := by
  apply Complex.ext
  · simp [globalSDPObjective]
  · simpa using globalSDPObjective_trace_im_eq_zero hM hJ

/-- Dual feasibility for the global CPTN Choi SDP. -/
def IsGlobalCPTNDual
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    (M : CMatrix (Prod x y)) (Y : CMatrix x) : Prop :=
  Y.PosSemidef ∧
    M ≤ Matrix.kronecker Y (1 : CMatrix y)

/-- Trace pairing against Y tensor I equals the pairing of Y with the
output partial trace. -/
theorem trace_kronecker_one_mul_eq_trace_mul_partialTraceB
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    (Y : CMatrix x) (J : CMatrix (Prod x y)) :
    (Matrix.kronecker Y (1 : CMatrix y) * J).trace =
      (Y * QIT.partialTraceB (a := x) (b := y) J).trace := by
  simp only [Matrix.trace, Matrix.mul_apply, Matrix.diag,
    Matrix.kronecker, Matrix.kroneckerMap_apply, Matrix.one_apply,
    QIT.partialTraceB, Fintype.sum_prod_type]
  simp only [mul_ite, ite_mul, mul_one, mul_zero, zero_mul,
    Finset.sum_ite_eq, Finset.mem_univ, if_true, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  rw [Finset.sum_comm]

/-- Weak duality for the exact SDP in eq:gd_global_cptn_sdp. -/
theorem globalCPTN_weak_duality
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    {M J : CMatrix (Prod x y)} {Y : CMatrix x}
    (hJ : IsGlobalCPTNChoi J)
    (hY : IsGlobalCPTNDual M Y) :
    globalSDPObjective M J ≤ Y.trace.re := by
  have hfirst :
      globalSDPObjective M J ≤
        ((Matrix.kronecker Y (1 : CMatrix y) * J).trace).re := by
    calc
      globalSDPObjective M J = ((J * M).trace).re := by
        rw [globalSDPObjective, Matrix.trace_mul_comm]
      _ ≤ ((J * Matrix.kronecker Y (1 : CMatrix y)).trace).re :=
        QIT.cMatrix_trace_mul_le_of_le_posSemidef_left hJ.1 hY.2
      _ = ((Matrix.kronecker Y (1 : CMatrix y) * J).trace).re := by
        rw [Matrix.trace_mul_comm]
  rw [trace_kronecker_one_mul_eq_trace_mul_partialTraceB] at hfirst
  have hsecond :
      ((Y * QIT.partialTraceB (a := x) (b := y) J).trace).re ≤
        ((Y * (1 : CMatrix x)).trace).re :=
    QIT.cMatrix_trace_mul_le_of_le_posSemidef_left hY.1 hJ.2
  simpa using hfirst.trans hsecond

/-- A primal feasible point and a dual feasible point with matching values
certify the global optimum. -/
theorem globalCPTN_optimal_of_matching_primal_dual
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    {M Jstar : CMatrix (Prod x y)} {Y : CMatrix x}
    (hJstar : IsGlobalCPTNChoi Jstar)
    (hY : IsGlobalCPTNDual M Y)
    (hmatch : globalSDPObjective M Jstar = Y.trace.re) :
    IsGlobalCPTNChoi Jstar ∧
      ∀ J, IsGlobalCPTNChoi J →
        globalSDPObjective M J ≤ globalSDPObjective M Jstar := by
  refine ⟨hJstar, ?_⟩
  intro J hJ
  rw [hmatch]
  exact globalCPTN_weak_duality hJ hY

/-- The Choi matrix represented by a primal feasible point is completely
positive in Lean-QIT's native MatrixMap API. -/
theorem globalCPTN_ofChoiMatrix_completelyPositive
    {x y : Type*} [Fintype x] [Fintype y]
    [DecidableEq x] [DecidableEq y]
    {J : CMatrix (Prod x y)} (hJ : IsGlobalCPTNChoi J) :
    MatrixMap.IsCompletelyPositive (MatrixMap.ofChoiMatrix J) :=
  MatrixMap.ofChoiMatrix_isCompletelyPositive hJ.1

end

end EntanglementPurification
