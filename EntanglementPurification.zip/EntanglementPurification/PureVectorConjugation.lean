import EntanglementPurification.PureResourceOperationalMap
import QIT.Information.Entropy.PureEntanglement
import Mathlib.Tactic

/-!
# Coordinatewise conjugation of bipartite pure vectors

The input-first Choi convention used by the operational resource-insertion
map introduces coordinatewise complex conjugation of a pure resource.  This
file records that this coordinate convention does not alter the resource's
Schmidt spectrum or entanglement entropy.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

universe u v

variable {a : Type u} {b : Type v}
  [Fintype a] [DecidableEq a]
  [Fintype b] [DecidableEq b]

/-- Coordinatewise conjugation transposes the first reduced density matrix. -/
theorem conjugatePureVector_marginalA_matrix
    (resource : PureVector (Prod a b)) :
    (conjugatePureVector resource).state.marginalA.matrix =
      resource.state.marginalA.matrix.transpose := by
  ext i j
  simp [conjugatePureVector, State.marginalA, QIT.partialTraceB,
    PureVector.state_matrix, rankOneMatrix_apply, Matrix.transpose_apply,
    mul_comm]

/-- Coordinatewise complex conjugation preserves the Schmidt spectrum and
hence the entanglement entropy of every finite-dimensional bipartite pure
vector. -/
theorem conjugatePureVector_entanglementEntropy
    (resource : PureVector (Prod a b)) :
    (conjugatePureVector resource).entanglementEntropy =
      resource.entanglementEntropy := by
  rw [PureVector.entanglementEntropy_eq_marginalA,
    PureVector.entanglementEntropy_eq_marginalA,
    State.vonNeumann_eq_neg_sum_eigenvalueMultiset,
    State.vonNeumann_eq_neg_sum_eigenvalueMultiset]
  congr 1
  have hleft :=
    (conjugatePureVector resource).state.marginalA.pos.isHermitian.roots_charpoly_eq_eigenvalues
  have hright :=
    resource.state.marginalA.pos.isHermitian.roots_charpoly_eq_eigenvalues
  have hchar :
      (conjugatePureVector resource).state.marginalA.matrix.charpoly =
        resource.state.marginalA.matrix.charpoly := by
    rw [conjugatePureVector_marginalA_matrix,
      Matrix.charpoly_transpose]
  have hrootsComplex :=
    hleft.symm.trans ((congrArg Polynomial.roots hchar).trans hright)
  have hsum := congrArg
    (fun s : Multiset ℂ =>
      (s.map (fun z : ℂ => QIT.xlog2 z.re)).sum)
    hrootsComplex
  simpa [eigenvalueMultiset, Multiset.map_map, Function.comp_def] using hsum

end

end EntanglementPurification
