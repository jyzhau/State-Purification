import EntanglementPurification.PhysicalOperationalEq986
import EntanglementPurification.FiniteKaramata
import EntanglementPurification.SchmidtEntropyBridge

/-!
# Operational forms of the Appendix spectral consequences

This module feeds the majorization theorem produced by an exactly attaining
physical PPT instrument into the finite Karamata results.  Its statements are
the operational versions of equations eq:all_atom_amplitude_budget,
eq:schmidt_entropy_comparison, and the large-head quantitative refinement.
-/

namespace EntanglementPurification

open QIT

noncomputable section

/-- Equation eq:all_atom_amplitude_budget: exact operational attainment
forces the sum of every non-leading Schmidt amplitude to dominate the leading
amplitude. -/
theorem physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_allAtomAmplitudeBudget
    {d m : ℕ}
    (M : PhysicalPPTInstrument
      (Fin d) (Fin d) (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le (ambientSignedSchmidtResource p hp) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) :
    Real.sqrt (p 0) ≤
      ∑ i ∈ Finset.univ.erase (0 : Fin (m + 3)), Real.sqrt (p i) := by
  have hmain :=
    physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_schmidt_majorization
      M hd nu hgamma0 hgamma1 p hp hattains
  have hbudget :
      Real.sqrt (p 0) ≤
        (∑ i, Real.sqrt (p i)) - Real.sqrt (p 0) :=
    allAtomAmplitudeBudget_of_two_or_three_point_branch
      hp hmain.1 hmain.2.1 (fun hlarge => (hmain.2.2 hlarge).2.2)
  have hsplit :
      (∑ i, Real.sqrt (p i)) - Real.sqrt (p 0) =
        ∑ i ∈ Finset.univ.erase (0 : Fin (m + 3)),
          Real.sqrt (p i) := by
    have hsum :=
      Finset.sum_erase_add (s := Finset.univ)
        (f := fun i : Fin (m + 3) => Real.sqrt (p i))
        (Finset.mem_univ (0 : Fin (m + 3)))
    linarith
  rw [hsplit] at hbudget
  exact hbudget

/-- Equation eq:schmidt_entropy_comparison: the entropy of every exactly
attaining ordered Schmidt spectrum is at least the entropy of the paper's
piecewise boundary spectrum. -/
theorem physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_shannonEntropyComparison
    {d m : ℕ}
    (M : PhysicalPPTInstrument
      (Fin d) (Fin d) (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le (ambientSignedSchmidtResource p hp) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) :
    shannonEntropyBits (paperComparisonSpectrum m (p 0)) ≤
      shannonEntropyBits p := by
  have hmain :=
    physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_schmidt_majorization
      M hd nu hgamma0 hgamma1 p hp hattains
  exact shannonEntropyBits_paperComparisonSpectrum_le_of_branches
    hp hmain.1 hmain.2.1 (fun hlarge => (hmain.2.2 hlarge).2.2)

/-- The complete entropy comparison, including the strict-Karamata equality
condition from the paper. -/
theorem physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_shannonEntropyComparisonAndRigidity
    {d m : ℕ}
    (M : PhysicalPPTInstrument
      (Fin d) (Fin d) (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le (ambientSignedSchmidtResource p hp) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) :
    shannonEntropyBits (paperComparisonSpectrum m (p 0)) ≤
        shannonEntropyBits p ∧
      (shannonEntropyBits p =
          shannonEntropyBits (paperComparisonSpectrum m (p 0)) →
        p = paperComparisonSpectrum m (p 0)) := by
  have hmain :=
    physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_schmidt_majorization
      M hd nu hgamma0 hgamma1 p hp hattains
  exact shannonEntropyBits_comparison_and_rigidity_of_branches
    hp hmain.1 hmain.2.1 (fun hlarge => (hmain.2.2 hlarge).2.2)

/-- The preceding comparison stated for the actual Lean-QIT pure-state
entanglement entropy, rather than only for its Schmidt probability formula. -/
theorem physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_entanglementEntropyComparison
    {d m : ℕ}
    (M : PhysicalPPTInstrument
      (Fin d) (Fin d) (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le (ambientSignedSchmidtResource p hp) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) :
    shannonEntropyBits (paperComparisonSpectrum m (p 0)) ≤
      (ambientSignedSchmidtResource p hp).entanglementEntropy := by
  rw [ambientSignedSchmidtResource_entanglementEntropy]
  simpa [shannonEntropyBits] using
    physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_shannonEntropyComparison
      M hd nu hgamma0 hgamma1 p hp hattains

/-- Actual-entanglement version of the comparison and its equality rigidity. -/
theorem physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_entanglementEntropyComparisonAndRigidity
    {d m : ℕ}
    (M : PhysicalPPTInstrument
      (Fin d) (Fin d) (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le (ambientSignedSchmidtResource p hp) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma) :
    shannonEntropyBits (paperComparisonSpectrum m (p 0)) ≤
        (ambientSignedSchmidtResource p hp).entanglementEntropy ∧
      ((ambientSignedSchmidtResource p hp).entanglementEntropy =
          shannonEntropyBits (paperComparisonSpectrum m (p 0)) →
        p = paperComparisonSpectrum m (p 0)) := by
  have hcore :=
    physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_shannonEntropyComparisonAndRigidity
      M hd nu hgamma0 hgamma1 p hp hattains
  rw [ambientSignedSchmidtResource_entanglementEntropy]
  simpa [shannonEntropyBits] using hcore

/-- The full quantitative refinement on the branch p₀ > 1/2: the sharp
tail bound, its strict quadratic corollary, and
H(p) ≥ H(σ⋆(p₀)) > 1 all follow from operational exact attainment. -/
theorem physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_largeHeadQuantitativeRefinement
    {d m : ℕ}
    (M : PhysicalPPTInstrument
      (Fin d) (Fin d) (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le (ambientSignedSchmidtResource p hp) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma)
    (hhead : (1 / 2 : ℝ) < p 0) :
    zStar (p 0) ≤ tailFromTwo p ∧
      2 * (p 0 - 1 / 2) ^ 2 < tailFromTwo p ∧
      1 < shannonEntropyBits (paperComparisonSpectrum m (p 0)) ∧
      shannonEntropyBits (paperComparisonSpectrum m (p 0)) ≤
        shannonEntropyBits p := by
  have hmain :=
    physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_schmidt_majorization
      M hd nu hgamma0 hgamma1 p hp hattains
  have hbranch := hmain.2.2 hhead
  have hentropy :=
    quantitative_shannonEntropyBits_of_large_branch
      hp hhead hmain.1 hbranch.2.2
  exact ⟨hbranch.1, hbranch.2.1, hentropy.1, hentropy.2⟩

/-- Actual-entanglement version of the large-head quantitative entropy
refinement. -/
theorem physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_largeHeadEntanglementRefinement
    {d m : ℕ}
    (M : PhysicalPPTInstrument
      (Fin d) (Fin d) (Fin (m + 3)) (Fin (m + 3)))
    (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (p : Fin (m + 3) → ℝ) (hp : IsOrderedProbability p)
    (hattains :
      physicalPaperOperationalAverageAcceptedGain M hd nu gamma
          hgamma0.le hgamma1.le (ambientSignedSchmidtResource p hp) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma)
    (hhead : (1 / 2 : ℝ) < p 0) :
    1 < shannonEntropyBits (paperComparisonSpectrum m (p 0)) ∧
      shannonEntropyBits (paperComparisonSpectrum m (p 0)) ≤
        (ambientSignedSchmidtResource p hp).entanglementEntropy := by
  have hquant :=
    physicalPaperOperationalAverageAcceptedGain_eq_globalOptimalGain_implies_largeHeadQuantitativeRefinement
      M hd nu hgamma0 hgamma1 p hp hattains hhead
  refine ⟨hquant.2.2.1, ?_⟩
  rw [ambientSignedSchmidtResource_entanglementEntropy]
  simpa [shannonEntropyBits] using hquant.2.2.2

end

end EntanglementPurification
