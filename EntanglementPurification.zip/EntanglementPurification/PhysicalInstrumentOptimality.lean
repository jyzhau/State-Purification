import EntanglementPurification.PhysicalPPTInstrument

/-!
# Exact global optimality for an operational physical instrument

This small bridge applies the already proved exposed-global-optimizer theorem
to the success branch of one complete `PhysicalPPTInstrument`.  The required
positive trace-preserving success/failure Choi pair is derived from the
instrument and is not repeated as a premise.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {d : ℕ} {ra rb : Type*}
  [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]

/-- Exact attainment fixes the pure-resource-inserted operational success
Choi matrix to the unique global optimizer. -/
theorem PhysicalPPTInstrument.insertedSuccess_eq_globalOptimalChoi
    (M : PhysicalPPTInstrument (Fin d) (Fin d) ra rb)
    (hd : 2 ≤ d)
    (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (resource : PureVector (ra × rb))
    (hattains :
      globalSDPObjective
          (globalPaperEq986PerformanceOperator hd nu gamma)
          (pureResourceInsert resource.amp
            (MatrixMap.choi (M.instrument.branch true))) =
        globalOptimalGain ((d : ℕ) ^ 2) gamma) :
    pureResourceInsert resource.amp
        (MatrixMap.choi (M.instrument.branch true)) =
      globalOptimalChoi (x := GlobalPaperIndex d) := by
  exact
    globalPaperEq986_optimality_fixes_pureResourceInsertedSuccess
      hd nu hgamma0 hgamma1 resource.amp
      (PureVector.isNormalizedResourceVector resource)
      M.rawChoi_isChoiSuccessFailurePair hattains

end

end EntanglementPurification
