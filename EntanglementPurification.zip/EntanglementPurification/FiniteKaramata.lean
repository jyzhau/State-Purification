import EntanglementPurification.ShannonCollisionBound
import EntanglementPurification.ShannonCollisionEquality
import Mathlib.Analysis.Convex.Deriv
import Mathlib.Analysis.SpecialFunctions.Log.NegMulLog
import Mathlib.Tactic

/-!
# Finite Karamata consequences for ordered spectra

This file supplies the two concave power/entropy consequences used in the
appendix.  The square-root statement is proved directly by Abel summation,
without assuming a majorization-to-doubly-stochastic bridge.
-/

namespace EntanglementPurification

noncomputable section

open scoped BigOperators

/-- Abel summation with nonnegative prefix differences.  If the total
difference vanishes and every successive weight increment has nonnegative
product with the corresponding prefix, the weighted difference is nonpositive. -/
theorem sum_range_mul_nonpos_of_prefix_total_zero
    (n : ℕ) (w d : ℕ → ℝ)
    (htotal : (∑ i ∈ Finset.range n, d i) = 0)
    (hstep : ∀ i, i + 1 < n →
      0 ≤ (w (i + 1) - w i) * (∑ j ∈ Finset.range (i + 1), d j)) :
    (∑ i ∈ Finset.range n, w i * d i) ≤ 0 := by
  have hterm :
      0 ≤ ∑ i ∈ Finset.range (n - 1),
        (w (i + 1) - w i) * (∑ j ∈ Finset.range (i + 1), d j) := by
    apply Finset.sum_nonneg
    intro i hi
    exact hstep i (by
      have := Finset.mem_range.mp hi
      omega)
  have hparts := Finset.sum_range_by_parts w d n
  simp only [smul_eq_mul] at hparts
  rw [htotal, mul_zero, zero_sub] at hparts
  rw [hparts]
  exact neg_nonpos.mpr hterm

/-- Rationalized square-root divided difference.  The value at `(0,0)` is
irrelevant because the corresponding coordinate difference is zero. -/
def sqrtDividedDifference (a b : ℝ) : ℝ :=
  1 / (Real.sqrt a + Real.sqrt b)

theorem sqrtDividedDifference_mul_sub
    {a b : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) :
    sqrtDividedDifference a b * (a - b) = Real.sqrt a - Real.sqrt b := by
  have hsa := Real.sq_sqrt ha
  have hsb := Real.sq_sqrt hb
  by_cases hden : Real.sqrt a + Real.sqrt b = 0
  · have hsa0 : Real.sqrt a = 0 := by
      have haSqrt := Real.sqrt_nonneg a
      have hbSqrt := Real.sqrt_nonneg b
      linarith
    have hsb0 : Real.sqrt b = 0 := by
      have haSqrt := Real.sqrt_nonneg a
      have hbSqrt := Real.sqrt_nonneg b
      linarith
    have ha0 : a = 0 := (Real.sqrt_eq_zero ha).mp hsa0
    have hb0 : b = 0 := (Real.sqrt_eq_zero hb).mp hsb0
    simp [sqrtDividedDifference, ha0, hb0]
  · unfold sqrtDividedDifference
    field_simp
    nlinarith

/-- Finite Karamata inequality for `sqrt`, in the ordered-prefix convention
of `PrefixMajorizedBy`: if `p ≺ q`, then `∑ √q ≤ ∑ √p`. -/
theorem sum_sqrt_le_of_prefixMajorizedBy
    {n : ℕ} {p q : Fin n → ℝ}
    (hp : IsOrderedProbability p) (hq : IsOrderedProbability q)
    (hpq : PrefixMajorizedBy p q) :
    (∑ i, Real.sqrt (q i)) ≤ ∑ i, Real.sqrt (p i) := by
  let pn : ℕ → ℝ := finNatEntry p
  let qn : ℕ → ℝ := finNatEntry q
  let d : ℕ → ℝ := fun i => qn i - pn i
  let w : ℕ → ℝ := fun i => sqrtDividedDifference (qn i) (pn i)
  have hpn_nonneg : ∀ i, 0 ≤ pn i := by
    intro i
    by_cases hi : i < n
    · simp [pn, finNatEntry, hi, hp.2.1]
    · simp [pn, finNatEntry, hi]
  have hqn_nonneg : ∀ i, 0 ≤ qn i := by
    intro i
    by_cases hi : i < n
    · simp [qn, finNatEntry, hi, hq.2.1]
    · simp [qn, finNatEntry, hi]
  have hprefix : ∀ k, k ≤ n →
      0 ≤ ∑ i ∈ Finset.range k, d i := by
    intro k hk
    rw [Finset.sum_sub_distrib]
    change 0 ≤
      (∑ i ∈ Finset.range k, qn i) -
        ∑ i ∈ Finset.range k, pn i
    rw [sum_range_finNatEntry_eq_orderedPrefixSum q hk,
      sum_range_finNatEntry_eq_orderedPrefixSum p hk]
    exact sub_nonneg.mpr (hpq.1 k)
  have htotal : (∑ i ∈ Finset.range n, d i) = 0 := by
    rw [Finset.sum_sub_distrib]
    change (∑ i ∈ Finset.range n, qn i) -
        ∑ i ∈ Finset.range n, pn i = 0
    rw [sum_range_finNatEntry_eq_orderedPrefixSum q le_rfl,
      sum_range_finNatEntry_eq_orderedPrefixSum p le_rfl]
    have hpFull : orderedPrefixSum p n = (List.ofFn p).sum := by
      unfold orderedPrefixSum
      rw [List.take_of_length_le (by simp)]
    have hqFull : orderedPrefixSum q n = (List.ofFn q).sum := by
      unfold orderedPrefixSum
      rw [List.take_of_length_le (by simp)]
    rw [hpFull, hqFull, hpq.2, sub_self]
  have hstep : ∀ i, i + 1 < n →
      0 ≤ (w (i + 1) - w i) *
        (∑ j ∈ Finset.range (i + 1), d j) := by
    intro i hi
    have hi0 : i < n := by omega
    have hpstep : pn (i + 1) ≤ pn i := by
      have hfin : (⟨i, hi0⟩ : Fin n) ≤ ⟨i + 1, hi⟩ := by simp
      simpa [pn, finNatEntry, hi, hi0] using hp.1 hfin
    have hqstep : qn (i + 1) ≤ qn i := by
      have hfin : (⟨i, hi0⟩ : Fin n) ≤ ⟨i + 1, hi⟩ := by simp
      simpa [qn, finNatEntry, hi, hi0] using hq.1 hfin
    have hdenOrder :
        Real.sqrt (qn (i + 1)) + Real.sqrt (pn (i + 1)) ≤
          Real.sqrt (qn i) + Real.sqrt (pn i) :=
      add_le_add (Real.sqrt_le_sqrt hqstep) (Real.sqrt_le_sqrt hpstep)
    have hpartial := hprefix (i + 1) (by omega)
    by_cases hnext :
        Real.sqrt (qn (i + 1)) + Real.sqrt (pn (i + 1)) = 0
    · have hqSqrt0 : Real.sqrt (qn (i + 1)) = 0 := by
        have hqSqrt := Real.sqrt_nonneg (qn (i + 1))
        have hpSqrt := Real.sqrt_nonneg (pn (i + 1))
        linarith
      have hpSqrt0 : Real.sqrt (pn (i + 1)) = 0 := by
        have hqSqrt := Real.sqrt_nonneg (qn (i + 1))
        have hpSqrt := Real.sqrt_nonneg (pn (i + 1))
        linarith
      have hqnext0 : qn (i + 1) = 0 :=
        (Real.sqrt_eq_zero (hqn_nonneg (i + 1))).mp hqSqrt0
      have hpnext0 : pn (i + 1) = 0 :=
        (Real.sqrt_eq_zero (hpn_nonneg (i + 1))).mp hpSqrt0
      have hpartialZero : (∑ j ∈ Finset.range (i + 1), d j) = 0 := by
        calc
          (∑ j ∈ Finset.range (i + 1), d j) =
              ∑ j ∈ Finset.range n, d j := by
            apply Finset.sum_subset (Finset.range_mono (by omega))
            intro j hjn hjnot
            have hjLower : i + 1 ≤ j := by
              simp only [Finset.mem_range] at hjn hjnot
              omega
            have hj : j < n := Finset.mem_range.mp hjn
            have hfin : (⟨i + 1, hi⟩ : Fin n) ≤ ⟨j, hj⟩ := by
              exact hjLower
            have hpj0 : pn j = 0 := by
              have hpjle : pn j ≤ pn (i + 1) := by
                simpa [pn, finNatEntry, hi, hj] using hp.1 hfin
              exact le_antisymm (hpjle.trans_eq hpnext0) (hpn_nonneg j)
            have hqj0 : qn j = 0 := by
              have hqjle : qn j ≤ qn (i + 1) := by
                simpa [qn, finNatEntry, hi, hj] using hq.1 hfin
              exact le_antisymm (hqjle.trans_eq hqnext0) (hqn_nonneg j)
            simp [d, hpj0, hqj0]
          _ = 0 := htotal
      rw [hpartialZero, mul_zero]
    · have hnextPos :
          0 < Real.sqrt (qn (i + 1)) + Real.sqrt (pn (i + 1)) := by
        exact lt_of_le_of_ne
          (add_nonneg (Real.sqrt_nonneg _) (Real.sqrt_nonneg _))
          (Ne.symm hnext)
      have hwOrder : w i ≤ w (i + 1) := by
        exact one_div_le_one_div_of_le hnextPos hdenOrder
      exact mul_nonneg (sub_nonneg.mpr hwOrder) hpartial
  have hweighted :
      (∑ i ∈ Finset.range n, w i * d i) ≤ 0 :=
    sum_range_mul_nonpos_of_prefix_total_zero n w d htotal hstep
  have hdiff :
      (∑ i ∈ Finset.range n, w i * d i) =
        (∑ i : Fin n, Real.sqrt (q i)) -
          ∑ i : Fin n, Real.sqrt (p i) := by
    calc
      (∑ i ∈ Finset.range n, w i * d i) =
          ∑ i : Fin n, w i.val * d i.val := by
        exact (Fin.sum_univ_eq_sum_range (fun i : ℕ => w i * d i) n).symm
      _ = ∑ i : Fin n, (Real.sqrt (q i) - Real.sqrt (p i)) := by
        apply Finset.sum_congr rfl
        intro i hi
        simp only [w, d]
        rw [sqrtDividedDifference_mul_sub
          (hqn_nonneg i.val) (hpn_nonneg i.val)]
        simp [qn, pn, finNatEntry, i.isLt]
      _ = (∑ i : Fin n, Real.sqrt (q i)) -
          ∑ i : Fin n, Real.sqrt (p i) := by
        rw [Finset.sum_sub_distrib]
  rw [hdiff] at hweighted
  exact sub_nonpos.mp hweighted

/-- The two non-head square-root amplitudes of the boundary spectrum add to
the square-root amplitude of its head.  This is the scalar identity used in
equation `eq:all_atom_amplitude_budget`. -/
theorem sqrt_boundary_tail_eq_sqrt_head
    {x : ℝ} (hxLower : (1 / 2 : ℝ) ≤ x) (hxUpper : x ≤ 2 / 3) :
    Real.sqrt (1 - x - zStar x) + Real.sqrt (zStar x) =
      Real.sqrt x := by
  have hcert := boundary_spectrum_nonnegative_on_interval hxLower hxUpper
  have hx : 0 ≤ x := hcert.1
  have hy : 0 ≤ 1 - x - zStar x := hcert.2.1
  have hz : 0 ≤ zStar x := hcert.2.2
  have hprod := zStar_mul_complement_on_interval hxLower hxUpper
  have hcross :
      Real.sqrt (1 - x - zStar x) * Real.sqrt (zStar x) =
        x - 1 / 2 := by
    have hsqrtProd :
        Real.sqrt ((1 - x - zStar x) * zStar x) =
          Real.sqrt (1 - x - zStar x) * Real.sqrt (zStar x) :=
      Real.sqrt_mul hy _
    have hprod' :
        (1 - x - zStar x) * zStar x = (x - 1 / 2) ^ 2 := by
      nlinarith [hprod]
    rw [← hsqrtProd, hprod', Real.sqrt_sq_eq_abs,
      abs_of_nonneg (sub_nonneg.mpr hxLower)]
  have hySq := Real.sq_sqrt hy
  have hzSq := Real.sq_sqrt hz
  have hxSq := Real.sq_sqrt hx
  have hleftNonneg :
      0 ≤ Real.sqrt (1 - x - zStar x) + Real.sqrt (zStar x) :=
    add_nonneg (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)
  have hrightNonneg : 0 ≤ Real.sqrt x := Real.sqrt_nonneg _
  nlinarith

/-- Small-head branch of the paper's all-atom amplitude budget.  Written as
`total - head ≥ head`, this is exactly `∑_{j≥1} √p_j ≥ √p₀`. -/
theorem allAtomAmplitudeBudget_of_prefixMajorizedBy_twoPoint
    {m : ℕ} {p : Fin (m + 2) → ℝ}
    (hp : IsOrderedProbability p)
    (hhead : p 0 ≤ 1 / 2)
    (hpref : PrefixMajorizedBy p (twoPointComparison m)) :
    Real.sqrt (p 0) ≤ (∑ i, Real.sqrt (p i)) - Real.sqrt (p 0) := by
  have hkaramata := sum_sqrt_le_of_prefixMajorizedBy hp
    (twoPointComparison_isOrderedProbability m) hpref
  have hheadSqrt : Real.sqrt (p 0) ≤ Real.sqrt (1 / 2 : ℝ) :=
    Real.sqrt_le_sqrt hhead
  have hcomparison :
      (∑ i, Real.sqrt (twoPointComparison m i)) =
        2 * Real.sqrt (1 / 2 : ℝ) := by
    simp [twoPointComparison, Fin.sum_univ_succ]
    ring
  rw [hcomparison] at hkaramata
  linarith

/-- Large-head boundary branch of the paper's all-atom amplitude budget. -/
theorem allAtomAmplitudeBudget_of_prefixMajorizedBy_threePoint
    {m : ℕ} {p : Fin (m + 3) → ℝ} {x : ℝ}
    (hp : IsOrderedProbability p)
    (hhead : p 0 = x)
    (hxLower : (1 / 2 : ℝ) ≤ x) (hxUpper : x ≤ 2 / 3)
    (hpref : PrefixMajorizedBy p
      (threePointComparison m x (zStar x))) :
    Real.sqrt (p 0) ≤ (∑ i, Real.sqrt (p i)) - Real.sqrt (p 0) := by
  have hkaramata := sum_sqrt_le_of_prefixMajorizedBy hp
    (threePointComparison_isOrderedProbability_on_interval
      m hxLower hxUpper) hpref
  have hboundary := sqrt_boundary_tail_eq_sqrt_head hxLower hxUpper
  have hcomparison :
      (∑ i, Real.sqrt (threePointComparison m x (zStar x) i)) =
        2 * Real.sqrt x := by
    simp [threePointComparison, Fin.sum_univ_succ]
    linarith
  rw [hcomparison] at hkaramata
  rw [hhead]
  linarith

/-- Single paper-facing amplitude-budget endpoint on the common padded
ambient space used by the two comparison branches. -/
theorem allAtomAmplitudeBudget_of_two_or_three_point_branch
    {m : ℕ} {p : Fin (m + 3) → ℝ}
    (hp : IsOrderedProbability p)
    (hheadUpper : p 0 ≤ 2 / 3)
    (hsmall : p 0 ≤ 1 / 2 →
      PrefixMajorizedBy p (twoPointComparison (m + 1)))
    (hlarge : 1 / 2 < p 0 →
      PrefixMajorizedBy p
        (threePointComparison m (p 0) (zStar (p 0)))) :
    Real.sqrt (p 0) ≤ (∑ i, Real.sqrt (p i)) - Real.sqrt (p 0) := by
  by_cases hp0 : p 0 ≤ 1 / 2
  · have htwo := hsmall hp0
    exact allAtomAmplitudeBudget_of_prefixMajorizedBy_twoPoint
      hp hp0 htwo
  · have hp0' : 1 / 2 < p 0 := lt_of_not_ge hp0
    exact allAtomAmplitudeBudget_of_prefixMajorizedBy_threePoint
      hp rfl (le_of_lt hp0') hheadUpper (hlarge hp0')

/-- Divided difference of the concave function `-x log x`, completed at a
positive diagonal point by its derivative.  The artificial value at `(0,0)`
will only occur after every remaining coordinate has vanished. -/
def negMulLogDividedDifference (a b : ℝ) : ℝ :=
  if a = b then -Real.log a - 1
  else slope Real.negMulLog b a

@[simp]
theorem negMulLogDividedDifference_comm (a b : ℝ) :
    negMulLogDividedDifference a b = negMulLogDividedDifference b a := by
  by_cases hab : a = b
  · subst b
    simp [negMulLogDividedDifference]
  · simp [negMulLogDividedDifference, hab, Ne.symm hab, slope_comm]

theorem negMulLogDividedDifference_mul_sub (a b : ℝ) :
    negMulLogDividedDifference a b * (a - b) =
      Real.negMulLog a - Real.negMulLog b := by
  by_cases hab : a = b
  · subst b
    simp [negMulLogDividedDifference]
  · simp only [negMulLogDividedDifference, hab, if_false, slope_def_field]
    field_simp

/-- For the concave function `-x log x`, its completed divided difference is
antitone in either positive-support endpoint. -/
theorem negMulLogDividedDifference_anti_left
    {a b c : ℝ}
    (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c)
    (hca : c ≤ a) (hcbPos : 0 < c + b) :
    negMulLogDividedDifference a b ≤
      negMulLogDividedDifference c b := by
  by_cases hcaEq : c = a
  · subst c
    rfl
  have hcaLt : c < a := lt_of_le_of_ne hca hcaEq
  by_cases hab : a = b
  · have hcb : c < b := by simpa [hab] using hcaLt
    have hbPos : 0 < b := by nlinarith
    have hcbNe : c ≠ b := ne_of_lt hcb
    have hderiv := Real.hasDerivAt_negMulLog hbPos.ne'
    have hslope := Real.concaveOn_negMulLog.le_slope_of_hasDerivAt
      hc hb hcb hderiv
    simpa [negMulLogDividedDifference, hab, hcbNe, slope_comm] using hslope
  · by_cases hcb : c = b
    · have hba : b < a := by simpa [hcb] using hcaLt
      have hbPos : 0 < b := by nlinarith [hcbPos]
      have hderiv := Real.hasDerivAt_negMulLog hbPos.ne'
      have hslope := Real.concaveOn_negMulLog.slope_le_of_hasDerivAt
        hb ha hba hderiv
      simpa only [negMulLogDividedDifference, hab, hcb, if_false,
        slope_def_field] using hslope
    · have hslope := Real.concaveOn_negMulLog.slope_anti hb
        ⟨hc, by simpa using hcb⟩
        ⟨ha, by simpa using hab⟩ hca
      simpa [negMulLogDividedDifference, hab, hcb, slope_comm] using hslope

theorem negMulLogDividedDifference_anti
    {a b c d : ℝ}
    (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hd : 0 ≤ d)
    (hca : c ≤ a) (hdb : d ≤ b) (hnext : 0 < c + d) :
    negMulLogDividedDifference a b ≤
      negMulLogDividedDifference c d := by
  have hmiddle : 0 < c + b :=
    lt_of_lt_of_le hnext (add_le_add le_rfl hdb)
  calc
    negMulLogDividedDifference a b ≤
        negMulLogDividedDifference c b :=
      negMulLogDividedDifference_anti_left
        ha hb hc hca hmiddle
    _ = negMulLogDividedDifference b c :=
      negMulLogDividedDifference_comm c b
    _ ≤ negMulLogDividedDifference d c :=
      negMulLogDividedDifference_anti_left
        hb hc hd hdb (by simpa [add_comm] using hnext)
    _ = negMulLogDividedDifference c d :=
      negMulLogDividedDifference_comm d c

theorem negMulLogDividedDifference_strict_anti_left
    {a b c : ℝ}
    (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c)
    (hca : c < a) (hcbPos : 0 < c + b) :
    negMulLogDividedDifference a b <
      negMulLogDividedDifference c b := by
  by_cases hab : a = b
  · have hcb : c < b := by simpa [hab] using hca
    have hbPos : 0 < b := by nlinarith
    have hcbNe : c ≠ b := ne_of_lt hcb
    have hderiv := Real.hasDerivAt_negMulLog hbPos.ne'
    have hslope := Real.strictConcaveOn_negMulLog.lt_slope_of_hasDerivAt
      hc hb hcb hderiv
    simpa [negMulLogDividedDifference, hab, hcbNe, slope_comm] using hslope
  · by_cases hcb : c = b
    · have hba : b < a := by simpa [hcb] using hca
      have hbPos : 0 < b := by nlinarith [hcbPos]
      have hderiv := Real.hasDerivAt_negMulLog hbPos.ne'
      have hslope := Real.strictConcaveOn_negMulLog.slope_lt_of_hasDerivAt
        hb ha hba hderiv
      simpa [negMulLogDividedDifference, hab, hcb, slope_comm] using hslope
    · have hslope := Real.strictConcaveOn_negMulLog.secant_strict_mono
        hb hc ha (by simpa using hcb) (by simpa using hab) hca
      simp only [negMulLogDividedDifference, hab, hcb, if_false,
        slope_def_field]
      exact hslope

theorem negMulLogDividedDifference_strict_anti
    {a b c d : ℝ}
    (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hd : 0 ≤ d)
    (hca : c ≤ a) (hdb : d ≤ b) (hnext : 0 < c + d)
    (hstrict : c < a ∨ d < b) :
    negMulLogDividedDifference a b <
      negMulLogDividedDifference c d := by
  rcases hstrict with hca' | hdb'
  · have hmiddle : 0 < c + b :=
      lt_of_lt_of_le hnext (add_le_add le_rfl hdb)
    exact (negMulLogDividedDifference_strict_anti_left
      ha hb hc hca' hmiddle).trans_le
        (by
          rw [negMulLogDividedDifference_comm c b,
            negMulLogDividedDifference_comm c d]
          exact negMulLogDividedDifference_anti_left
            hb hc hd hdb (by simpa [add_comm] using hnext))
  · rw [negMulLogDividedDifference_comm a b,
      negMulLogDividedDifference_comm c d]
    exact (negMulLogDividedDifference_strict_anti_left
      hb ha hd hdb' (by
        have hle : c + d ≤ a + d := by
          simpa [add_comm] using add_le_add_right hca d
        have hpos : 0 < a + d := hnext.trans_le hle
        simpa [add_comm] using hpos)).trans_le
        (by
          rw [negMulLogDividedDifference_comm d a,
            negMulLogDividedDifference_comm d c]
          exact negMulLogDividedDifference_anti_left
            ha hd hc hca hnext)

/-- Finite Karamata inequality for the natural-log Shannon summand. -/
theorem sum_negMulLog_le_of_prefixMajorizedBy
    {n : ℕ} {p q : Fin n → ℝ}
    (hp : IsOrderedProbability p) (hq : IsOrderedProbability q)
    (hpq : PrefixMajorizedBy p q) :
    (∑ i, Real.negMulLog (q i)) ≤
      ∑ i, Real.negMulLog (p i) := by
  let pn : ℕ → ℝ := finNatEntry p
  let qn : ℕ → ℝ := finNatEntry q
  let d : ℕ → ℝ := fun i => qn i - pn i
  let w : ℕ → ℝ := fun i => negMulLogDividedDifference (qn i) (pn i)
  have hpn_nonneg : ∀ i, 0 ≤ pn i := by
    intro i
    by_cases hi : i < n
    · simp [pn, finNatEntry, hi, hp.2.1]
    · simp [pn, finNatEntry, hi]
  have hqn_nonneg : ∀ i, 0 ≤ qn i := by
    intro i
    by_cases hi : i < n
    · simp [qn, finNatEntry, hi, hq.2.1]
    · simp [qn, finNatEntry, hi]
  have hprefix : ∀ k, k ≤ n →
      0 ≤ ∑ i ∈ Finset.range k, d i := by
    intro k hk
    rw [Finset.sum_sub_distrib]
    change 0 ≤
      (∑ i ∈ Finset.range k, qn i) -
        ∑ i ∈ Finset.range k, pn i
    rw [sum_range_finNatEntry_eq_orderedPrefixSum q hk,
      sum_range_finNatEntry_eq_orderedPrefixSum p hk]
    exact sub_nonneg.mpr (hpq.1 k)
  have htotal : (∑ i ∈ Finset.range n, d i) = 0 := by
    rw [Finset.sum_sub_distrib]
    change (∑ i ∈ Finset.range n, qn i) -
        ∑ i ∈ Finset.range n, pn i = 0
    rw [sum_range_finNatEntry_eq_orderedPrefixSum q le_rfl,
      sum_range_finNatEntry_eq_orderedPrefixSum p le_rfl]
    have hpFull : orderedPrefixSum p n = (List.ofFn p).sum := by
      unfold orderedPrefixSum
      rw [List.take_of_length_le (by simp)]
    have hqFull : orderedPrefixSum q n = (List.ofFn q).sum := by
      unfold orderedPrefixSum
      rw [List.take_of_length_le (by simp)]
    rw [hpFull, hqFull, hpq.2, sub_self]
  have hstep : ∀ i, i + 1 < n →
      0 ≤ (w (i + 1) - w i) *
        (∑ j ∈ Finset.range (i + 1), d j) := by
    intro i hi
    have hi0 : i < n := by omega
    have hpstep : pn (i + 1) ≤ pn i := by
      have hfin : (⟨i, hi0⟩ : Fin n) ≤ ⟨i + 1, hi⟩ := by simp
      simpa [pn, finNatEntry, hi, hi0] using hp.1 hfin
    have hqstep : qn (i + 1) ≤ qn i := by
      have hfin : (⟨i, hi0⟩ : Fin n) ≤ ⟨i + 1, hi⟩ := by simp
      simpa [qn, finNatEntry, hi, hi0] using hq.1 hfin
    have hpartial := hprefix (i + 1) (by omega)
    by_cases hnext : qn (i + 1) + pn (i + 1) = 0
    · have hqnext0 : qn (i + 1) = 0 := by
        have := hqn_nonneg (i + 1)
        have := hpn_nonneg (i + 1)
        linarith
      have hpnext0 : pn (i + 1) = 0 := by
        have := hqn_nonneg (i + 1)
        have := hpn_nonneg (i + 1)
        linarith
      have hpartialZero : (∑ j ∈ Finset.range (i + 1), d j) = 0 := by
        calc
          (∑ j ∈ Finset.range (i + 1), d j) =
              ∑ j ∈ Finset.range n, d j := by
            apply Finset.sum_subset (Finset.range_mono (by omega))
            intro j hjn hjnot
            have hjLower : i + 1 ≤ j := by
              simp only [Finset.mem_range] at hjn hjnot
              omega
            have hj : j < n := Finset.mem_range.mp hjn
            have hfin : (⟨i + 1, hi⟩ : Fin n) ≤ ⟨j, hj⟩ := hjLower
            have hpj0 : pn j = 0 := by
              have hpjle : pn j ≤ pn (i + 1) := by
                simpa [pn, finNatEntry, hi, hj] using hp.1 hfin
              exact le_antisymm (hpjle.trans_eq hpnext0) (hpn_nonneg j)
            have hqj0 : qn j = 0 := by
              have hqjle : qn j ≤ qn (i + 1) := by
                simpa [qn, finNatEntry, hi, hj] using hq.1 hfin
              exact le_antisymm (hqjle.trans_eq hqnext0) (hqn_nonneg j)
            simp [d, hpj0, hqj0]
          _ = 0 := htotal
      rw [hpartialZero, mul_zero]
    · have hnextPos : 0 < qn (i + 1) + pn (i + 1) :=
        lt_of_le_of_ne
          (add_nonneg (hqn_nonneg _) (hpn_nonneg _)) (Ne.symm hnext)
      have hwOrder : w i ≤ w (i + 1) := by
        exact negMulLogDividedDifference_anti
          (hqn_nonneg i) (hpn_nonneg i)
          (hqn_nonneg (i + 1)) (hpn_nonneg (i + 1))
          hqstep hpstep hnextPos
      exact mul_nonneg (sub_nonneg.mpr hwOrder) hpartial
  have hweighted :
      (∑ i ∈ Finset.range n, w i * d i) ≤ 0 :=
    sum_range_mul_nonpos_of_prefix_total_zero n w d htotal hstep
  have hdiff :
      (∑ i ∈ Finset.range n, w i * d i) =
        (∑ i : Fin n, Real.negMulLog (q i)) -
          ∑ i : Fin n, Real.negMulLog (p i) := by
    calc
      (∑ i ∈ Finset.range n, w i * d i) =
          ∑ i : Fin n, w i.val * d i.val := by
        exact (Fin.sum_univ_eq_sum_range (fun i : ℕ => w i * d i) n).symm
      _ = ∑ i : Fin n,
          (Real.negMulLog (q i) - Real.negMulLog (p i)) := by
        apply Finset.sum_congr rfl
        intro i hi
        simp only [w, d]
        rw [negMulLogDividedDifference_mul_sub]
        simp [qn, pn, finNatEntry, i.isLt]
      _ = (∑ i : Fin n, Real.negMulLog (q i)) -
          ∑ i : Fin n, Real.negMulLog (p i) := by
        rw [Finset.sum_sub_distrib]
  rw [hdiff] at hweighted
  exact sub_nonpos.mp hweighted

/-- Strict finite Karamata from one certified strict Abel step.  The
certificate is deliberately stated in the same zero-extended natural-index
coordinates used by the proof, so paper-specific spectra can exhibit the
decisive prefix without any sorting bridge. -/
theorem sum_negMulLog_lt_of_prefixMajorizedBy_of_strictStep
    {n : ℕ} {p q : Fin n → ℝ}
    (hp : IsOrderedProbability p) (hq : IsOrderedProbability q)
    (hpq : PrefixMajorizedBy p q)
    (hstrict : ∃ i : ℕ,
      i + 1 < n ∧
      0 < ∑ j ∈ Finset.range (i + 1),
        (finNatEntry q j - finNatEntry p j) ∧
      0 < finNatEntry q (i + 1) + finNatEntry p (i + 1) ∧
      (finNatEntry q (i + 1) < finNatEntry q i ∨
        finNatEntry p (i + 1) < finNatEntry p i)) :
    (∑ i, Real.negMulLog (q i)) <
      ∑ i, Real.negMulLog (p i) := by
  let pn : ℕ → ℝ := finNatEntry p
  let qn : ℕ → ℝ := finNatEntry q
  let d : ℕ → ℝ := fun i => qn i - pn i
  let w : ℕ → ℝ := fun i => negMulLogDividedDifference (qn i) (pn i)
  have hpn_nonneg : ∀ i, 0 ≤ pn i := by
    intro i
    by_cases hi : i < n
    · simp [pn, finNatEntry, hi, hp.2.1]
    · simp [pn, finNatEntry, hi]
  have hqn_nonneg : ∀ i, 0 ≤ qn i := by
    intro i
    by_cases hi : i < n
    · simp [qn, finNatEntry, hi, hq.2.1]
    · simp [qn, finNatEntry, hi]
  have hprefix : ∀ k, k ≤ n →
      0 ≤ ∑ i ∈ Finset.range k, d i := by
    intro k hk
    rw [Finset.sum_sub_distrib]
    change 0 ≤
      (∑ i ∈ Finset.range k, qn i) -
        ∑ i ∈ Finset.range k, pn i
    rw [sum_range_finNatEntry_eq_orderedPrefixSum q hk,
      sum_range_finNatEntry_eq_orderedPrefixSum p hk]
    exact sub_nonneg.mpr (hpq.1 k)
  have htotal : (∑ i ∈ Finset.range n, d i) = 0 := by
    rw [Finset.sum_sub_distrib]
    change (∑ i ∈ Finset.range n, qn i) -
        ∑ i ∈ Finset.range n, pn i = 0
    rw [sum_range_finNatEntry_eq_orderedPrefixSum q le_rfl,
      sum_range_finNatEntry_eq_orderedPrefixSum p le_rfl]
    have hpFull : orderedPrefixSum p n = (List.ofFn p).sum := by
      unfold orderedPrefixSum
      rw [List.take_of_length_le (by simp)]
    have hqFull : orderedPrefixSum q n = (List.ofFn q).sum := by
      unfold orderedPrefixSum
      rw [List.take_of_length_le (by simp)]
    rw [hpFull, hqFull, hpq.2, sub_self]
  have hstep : ∀ i, i + 1 < n →
      0 ≤ (w (i + 1) - w i) *
        (∑ j ∈ Finset.range (i + 1), d j) := by
    intro i hi
    have hi0 : i < n := by omega
    have hpstep : pn (i + 1) ≤ pn i := by
      have hfin : (⟨i, hi0⟩ : Fin n) ≤ ⟨i + 1, hi⟩ := by simp
      simpa [pn, finNatEntry, hi, hi0] using hp.1 hfin
    have hqstep : qn (i + 1) ≤ qn i := by
      have hfin : (⟨i, hi0⟩ : Fin n) ≤ ⟨i + 1, hi⟩ := by simp
      simpa [qn, finNatEntry, hi, hi0] using hq.1 hfin
    have hpartial := hprefix (i + 1) (by omega)
    by_cases hnext : qn (i + 1) + pn (i + 1) = 0
    · have hqnext0 : qn (i + 1) = 0 := by
        have := hqn_nonneg (i + 1)
        have := hpn_nonneg (i + 1)
        linarith
      have hpnext0 : pn (i + 1) = 0 := by
        have := hqn_nonneg (i + 1)
        have := hpn_nonneg (i + 1)
        linarith
      have hpartialZero : (∑ j ∈ Finset.range (i + 1), d j) = 0 := by
        calc
          (∑ j ∈ Finset.range (i + 1), d j) =
              ∑ j ∈ Finset.range n, d j := by
            apply Finset.sum_subset (Finset.range_mono (by omega))
            intro j hjn hjnot
            have hjLower : i + 1 ≤ j := by
              simp only [Finset.mem_range] at hjn hjnot
              omega
            have hj : j < n := Finset.mem_range.mp hjn
            have hfin : (⟨i + 1, hi⟩ : Fin n) ≤ ⟨j, hj⟩ := hjLower
            have hpj0 : pn j = 0 := by
              have hpjle : pn j ≤ pn (i + 1) := by
                simpa [pn, finNatEntry, hi, hj] using hp.1 hfin
              exact le_antisymm (hpjle.trans_eq hpnext0) (hpn_nonneg j)
            have hqj0 : qn j = 0 := by
              have hqjle : qn j ≤ qn (i + 1) := by
                simpa [qn, finNatEntry, hi, hj] using hq.1 hfin
              exact le_antisymm (hqjle.trans_eq hqnext0) (hqn_nonneg j)
            simp [d, hpj0, hqj0]
          _ = 0 := htotal
      rw [hpartialZero, mul_zero]
    · have hnextPos : 0 < qn (i + 1) + pn (i + 1) :=
        lt_of_le_of_ne
          (add_nonneg (hqn_nonneg _) (hpn_nonneg _)) (Ne.symm hnext)
      have hwOrder : w i ≤ w (i + 1) := by
        exact negMulLogDividedDifference_anti
          (hqn_nonneg i) (hpn_nonneg i)
          (hqn_nonneg (i + 1)) (hpn_nonneg (i + 1))
          hqstep hpstep hnextPos
      exact mul_nonneg (sub_nonneg.mpr hwOrder) hpartial
  rcases hstrict with ⟨i, hi, hpartialPos, hnextPos, hcoordinate⟩
  have hi0 : i < n := by omega
  have hpstep : pn (i + 1) ≤ pn i := by
    have hfin : (⟨i, hi0⟩ : Fin n) ≤ ⟨i + 1, hi⟩ := by simp
    simpa [pn, finNatEntry, hi, hi0] using hp.1 hfin
  have hqstep : qn (i + 1) ≤ qn i := by
    have hfin : (⟨i, hi0⟩ : Fin n) ≤ ⟨i + 1, hi⟩ := by simp
    simpa [qn, finNatEntry, hi, hi0] using hq.1 hfin
  have hwStrict : w i < w (i + 1) := by
    exact negMulLogDividedDifference_strict_anti
      (hqn_nonneg i) (hpn_nonneg i)
      (hqn_nonneg (i + 1)) (hpn_nonneg (i + 1))
      hqstep hpstep (by simpa [qn, pn] using hnextPos)
      (by simpa [qn, pn] using hcoordinate)
  have hstrictTerm :
      0 < (w (i + 1) - w i) *
        (∑ j ∈ Finset.range (i + 1), d j) :=
    mul_pos (sub_pos.mpr hwStrict) (by simpa [d, qn, pn] using hpartialPos)
  have htermPos :
      0 < ∑ k ∈ Finset.range (n - 1),
        (w (k + 1) - w k) *
          (∑ j ∈ Finset.range (k + 1), d j) := by
    have hiMem : i ∈ Finset.range (n - 1) := by
      simp only [Finset.mem_range]
      omega
    have hle := Finset.single_le_sum
      (fun k hk => hstep k (by
        have := Finset.mem_range.mp hk
        omega)) hiMem
    exact hstrictTerm.trans_le hle
  have hparts := Finset.sum_range_by_parts w d n
  simp only [smul_eq_mul] at hparts
  rw [htotal, mul_zero, zero_sub] at hparts
  have hweighted : (∑ i ∈ Finset.range n, w i * d i) < 0 := by
    rw [hparts]
    exact neg_lt_zero.mpr htermPos
  have hdiff :
      (∑ i ∈ Finset.range n, w i * d i) =
        (∑ i : Fin n, Real.negMulLog (q i)) -
          ∑ i : Fin n, Real.negMulLog (p i) := by
    calc
      (∑ i ∈ Finset.range n, w i * d i) =
          ∑ i : Fin n, w i.val * d i.val := by
        exact (Fin.sum_univ_eq_sum_range (fun i : ℕ => w i * d i) n).symm
      _ = ∑ i : Fin n,
          (Real.negMulLog (q i) - Real.negMulLog (p i)) := by
        apply Finset.sum_congr rfl
        intro j hj
        simp only [w, d]
        rw [negMulLogDividedDifference_mul_sub]
        simp [qn, pn, finNatEntry, j.isLt]
      _ = (∑ i : Fin n, Real.negMulLog (q i)) -
          ∑ i : Fin n, Real.negMulLog (p i) := by
        rw [Finset.sum_sub_distrib]
  rw [hdiff] at hweighted
  exact sub_neg.mp hweighted

/-- Strict Schur concavity of the natural-log Shannon summand for unequal
ordered vectors.  The proof chooses the first coordinate where `q-p` is
negative; its preceding prefix is strictly positive, and strict concavity
makes exactly that Abel term positive. -/
theorem sum_negMulLog_lt_of_prefixMajorizedBy_of_ne
    {n : ℕ} {p q : Fin n → ℝ}
    (hp : IsOrderedProbability p) (hq : IsOrderedProbability q)
    (hpq : PrefixMajorizedBy p q) (hpne : p ≠ q) :
    (∑ i, Real.negMulLog (q i)) <
      ∑ i, Real.negMulLog (p i) := by
  have hexDiff : ∃ i : Fin n, p i ≠ q i := Function.ne_iff.mp hpne
  have hexNeg : ∃ i : Fin n, q i < p i := by
    by_contra hnone
    push Not at hnone
    have hnonneg : ∀ i : Fin n, 0 ≤ q i - p i := by
      intro i
      exact sub_nonneg.mpr (hnone i)
    rcases hexDiff with ⟨i, hi⟩
    have hpos : 0 < q i - p i := by
      exact sub_pos.mpr (lt_of_le_of_ne (hnone i) hi)
    have hsumPos : 0 < ∑ j : Fin n, (q j - p j) := by
      exact Finset.sum_pos' (fun j _ => hnonneg j)
        ⟨i, Finset.mem_univ i, hpos⟩
    have hsumZero : (∑ j : Fin n, (q j - p j)) = 0 := by
      rw [Finset.sum_sub_distrib]
      have hpsum : (∑ j : Fin n, p j) = (List.ofFn p).sum :=
        FiniteSchmidtData.sum_univ_eq_sum_ofFn p
      have hqsum : (∑ j : Fin n, q j) = (List.ofFn q).sum :=
        FiniteSchmidtData.sum_univ_eq_sum_ofFn q
      rw [hqsum, hpsum, hpq.2, sub_self]
    rw [hsumZero] at hsumPos
    exact (lt_irrefl 0) hsumPos
  have hexNat : ∃ t : ℕ, ∃ ht : t < n,
      q ⟨t, ht⟩ < p ⟨t, ht⟩ := by
    rcases hexNeg with ⟨i, hi⟩
    exact ⟨i.val, i.isLt, hi⟩
  let t : ℕ := Nat.find hexNat
  obtain ⟨ht, htNeg⟩ := Nat.find_spec hexNat
  change t < n at ht
  change q ⟨t, ht⟩ < p ⟨t, ht⟩ at htNeg
  have htPos : 0 < t := by
    by_contra htNot
    have htZero : t = 0 := Nat.eq_zero_of_not_pos htNot
    have hnPos : 0 < n := htZero ▸ ht
    have hprefixOne := hpq.1 1
    have hpqZero : p ⟨0, by omega⟩ ≤ q ⟨0, by omega⟩ := by
      have hpRange := sum_range_finNatEntry_eq_orderedPrefixSum
        p (by omega : 1 ≤ n)
      have hqRange := sum_range_finNatEntry_eq_orderedPrefixSum
        q (by omega : 1 ≤ n)
      rw [← hpRange, ← hqRange] at hprefixOne
      simpa [finNatEntry, hnPos] using hprefixOne
    have hfinZero : (⟨t, ht⟩ : Fin n) = ⟨0, hnPos⟩ := by
      apply Fin.ext
      exact htZero
    have htNegZero : q ⟨0, hnPos⟩ < p ⟨0, hnPos⟩ := by
      simpa only [hfinZero] using htNeg
    exact (not_lt_of_ge hpqZero) htNegZero
  let i : ℕ := t - 1
  have hiSucc : i + 1 = t := by
    dsimp [i]
    omega
  have hiLtT : i < t := by
    dsimp [i]
    omega
  have hiN : i < n := hiLtT.trans ht
  have hprevNot : ¬q ⟨i, hiN⟩ < p ⟨i, hiN⟩ := by
    intro hbad
    exact (Nat.find_min hexNat hiLtT) ⟨hiN, hbad⟩
  have hprevOrder : p ⟨i, hiN⟩ ≤ q ⟨i, hiN⟩ :=
    le_of_not_gt hprevNot
  have hqStep : q ⟨t, ht⟩ ≤ q ⟨i, hiN⟩ := by
    exact hq.1 (by simp [hiLtT.le])
  have hpStep : p ⟨t, ht⟩ ≤ p ⟨i, hiN⟩ := by
    exact hp.1 (by simp [hiLtT.le])
  have hcoordinateStrict :
      q ⟨t, ht⟩ < q ⟨i, hiN⟩ ∨
        p ⟨t, ht⟩ < p ⟨i, hiN⟩ := by
    by_cases hqStrict : q ⟨t, ht⟩ < q ⟨i, hiN⟩
    · exact Or.inl hqStrict
    · right
      have hqEq : q ⟨t, ht⟩ = q ⟨i, hiN⟩ :=
        le_antisymm hqStep (le_of_not_gt hqStrict)
      by_contra hpNot
      have hpEq : p ⟨t, ht⟩ = p ⟨i, hiN⟩ :=
        le_antisymm hpStep (le_of_not_gt hpNot)
      rw [hqEq, hpEq] at htNeg
      exact (not_lt_of_ge hprevOrder) htNeg
  have hprefixNonneg :
      0 ≤ ∑ j ∈ Finset.range t,
        (finNatEntry q j - finNatEntry p j) := by
    rw [Finset.sum_sub_distrib,
      sum_range_finNatEntry_eq_orderedPrefixSum q ht.le,
      sum_range_finNatEntry_eq_orderedPrefixSum p ht.le]
    exact sub_nonneg.mpr (hpq.1 t)
  have hnextPrefixNonneg :
      0 ≤ ∑ j ∈ Finset.range (t + 1),
        (finNatEntry q j - finNatEntry p j) := by
    rw [Finset.sum_sub_distrib,
      sum_range_finNatEntry_eq_orderedPrefixSum q (by omega),
      sum_range_finNatEntry_eq_orderedPrefixSum p (by omega)]
    exact sub_nonneg.mpr (hpq.1 (t + 1))
  have hprefixSplit :
      (∑ j ∈ Finset.range (t + 1),
        (finNatEntry q j - finNatEntry p j)) =
        (∑ j ∈ Finset.range t,
          (finNatEntry q j - finNatEntry p j)) +
          (q ⟨t, ht⟩ - p ⟨t, ht⟩) := by
    rw [Finset.sum_range_succ]
    simp only [finNatEntry, dif_pos ht]
  have hprefixPos :
      0 < ∑ j ∈ Finset.range t,
        (finNatEntry q j - finNatEntry p j) := by
    rw [hprefixSplit] at hnextPrefixNonneg
    nlinarith
  have htSupport :
      0 < finNatEntry q t + finNatEntry p t := by
    have hpPos : 0 < p ⟨t, ht⟩ :=
      lt_of_le_of_lt (hq.2.1 ⟨t, ht⟩) htNeg
    simp only [finNatEntry, dif_pos ht]
    exact add_pos_of_nonneg_of_pos (hq.2.1 ⟨t, ht⟩) hpPos
  apply sum_negMulLog_lt_of_prefixMajorizedBy_of_strictStep hp hq hpq
  refine ⟨i, ?_, ?_, ?_, ?_⟩
  · omega
  · simpa [hiSucc] using hprefixPos
  · simpa [hiSucc] using htSupport
  · rw [hiSucc]
    simp only [finNatEntry, dif_pos ht, dif_pos hiN]
    exact hcoordinateStrict

theorem shannonEntropyBits_mul_log_two {n : ℕ} (p : Fin n → ℝ) :
    shannonEntropyBits p * Real.log 2 =
      ∑ i, Real.negMulLog (p i) := by
  have hlogTwo : Real.log 2 ≠ 0 := ne_of_gt (Real.log_pos (by norm_num))
  have hxlog (x : ℝ) :
      QIT.xlog2 x * Real.log 2 = x * Real.log x := by
    rw [QIT.xlog2_eq_mul_log2]
    unfold QIT.log2
    field_simp [hlogTwo]
  rw [shannonEntropyBits]
  calc
    (-∑ i, QIT.xlog2 (p i)) * Real.log 2 =
        -((∑ i, QIT.xlog2 (p i)) * Real.log 2) := by ring
    _ = -(∑ i, QIT.xlog2 (p i) * Real.log 2) := by
      rw [Finset.sum_mul]
    _ = ∑ i, Real.negMulLog (p i) := by
      rw [← Finset.sum_neg_distrib]
      apply Finset.sum_congr rfl
      intro i hi
      rw [hxlog]
      simp [Real.negMulLog]

/-- Finite Karamata inequality for Shannon entropy in bits. -/
theorem shannonEntropyBits_le_of_prefixMajorizedBy
    {n : ℕ} {p q : Fin n → ℝ}
    (hp : IsOrderedProbability p) (hq : IsOrderedProbability q)
    (hpq : PrefixMajorizedBy p q) :
    shannonEntropyBits q ≤ shannonEntropyBits p := by
  have hnat := sum_negMulLog_le_of_prefixMajorizedBy hp hq hpq
  have hscaled :
      shannonEntropyBits q * Real.log 2 ≤
        shannonEntropyBits p * Real.log 2 := by
    rw [shannonEntropyBits_mul_log_two,
      shannonEntropyBits_mul_log_two]
    exact hnat
  exact (mul_le_mul_iff_of_pos_right (Real.log_pos (by norm_num))).mp hscaled

/-- Strict finite Karamata inequality for Shannon entropy in bits: two
distinct ordered probability vectors related by prefix majorization have
strictly ordered entropies. -/
theorem shannonEntropyBits_lt_of_prefixMajorizedBy_of_ne
    {n : ℕ} {p q : Fin n → ℝ}
    (hp : IsOrderedProbability p) (hq : IsOrderedProbability q)
    (hpq : PrefixMajorizedBy p q) (hne : p ≠ q) :
    shannonEntropyBits q < shannonEntropyBits p := by
  have hnat := sum_negMulLog_lt_of_prefixMajorizedBy_of_ne hp hq hpq hne
  have hscaled :
      shannonEntropyBits q * Real.log 2 <
        shannonEntropyBits p * Real.log 2 := by
    rw [shannonEntropyBits_mul_log_two,
      shannonEntropyBits_mul_log_two]
    exact hnat
  exact (mul_lt_mul_iff_of_pos_right (Real.log_pos (by norm_num))).mp hscaled

/-- Equality rigidity for finite Shannon Karamata: under the same ordered
prefix-majorization hypotheses, equality of entropies is equivalent to
coordinatewise equality of the spectra. -/
theorem shannonEntropyBits_eq_iff_of_prefixMajorizedBy
    {n : ℕ} {p q : Fin n → ℝ}
    (hp : IsOrderedProbability p) (hq : IsOrderedProbability q)
    (hpq : PrefixMajorizedBy p q) :
    shannonEntropyBits p = shannonEntropyBits q ↔ p = q := by
  constructor
  · intro heq
    by_contra hne
    have hlt :=
      shannonEntropyBits_lt_of_prefixMajorizedBy_of_ne hp hq hpq hne
    linarith
  · intro hpqEq
    rw [hpqEq]

/-- The paper's piecewise comparison spectrum `σ⋆(x)`, zero-padded to the
common `Fin (m+3)` ambient space. -/
def paperComparisonSpectrum (m : ℕ) (x : ℝ) : Fin (m + 3) → ℝ :=
  if x ≤ 1 / 2 then twoPointComparison (m + 1)
  else threePointComparison m x (zStar x)

@[simp]
theorem paperComparisonSpectrum_of_le_half
    (m : ℕ) {x : ℝ} (hx : x ≤ 1 / 2) :
    paperComparisonSpectrum m x = twoPointComparison (m + 1) := by
  rw [paperComparisonSpectrum, if_pos hx]

@[simp]
theorem paperComparisonSpectrum_of_half_lt
    (m : ℕ) {x : ℝ} (hx : 1 / 2 < x) :
    paperComparisonSpectrum m x =
      threePointComparison m x (zStar x) := by
  rw [paperComparisonSpectrum, if_neg (not_le.mpr hx)]

theorem paperComparisonSpectrum_isOrderedProbability
    (m : ℕ) {x : ℝ} (hxUpper : x ≤ 2 / 3) :
    IsOrderedProbability (paperComparisonSpectrum m x) := by
  by_cases hx : x ≤ 1 / 2
  · rw [paperComparisonSpectrum_of_le_half m hx]
    exact twoPointComparison_isOrderedProbability (m + 1)
  · have hx' : 1 / 2 < x := lt_of_not_ge hx
    rw [paperComparisonSpectrum_of_half_lt m hx']
    exact threePointComparison_isOrderedProbability_on_interval
      m (le_of_lt hx') hxUpper

/-- The two conditional majorization branches output by `SchmidtConverse`
assemble into the paper's single piecewise comparison relation. -/
theorem prefixMajorizedBy_paperComparisonSpectrum_of_branches
    {m : ℕ} {p : Fin (m + 3) → ℝ}
    (hsmall : p 0 ≤ 1 / 2 →
      PrefixMajorizedBy p (twoPointComparison (m + 1)))
    (hlarge : 1 / 2 < p 0 →
      PrefixMajorizedBy p
        (threePointComparison m (p 0) (zStar (p 0)))) :
    PrefixMajorizedBy p (paperComparisonSpectrum m (p 0)) := by
  by_cases hp0 : p 0 ≤ 1 / 2
  · simpa [paperComparisonSpectrum_of_le_half m hp0] using hsmall hp0
  · have hp0' : 1 / 2 < p 0 := lt_of_not_ge hp0
    simpa [paperComparisonSpectrum_of_half_lt m hp0'] using hlarge hp0'

/-- Equation `eq:schmidt_entropy_comparison`: every ordered spectrum allowed
by the converse has Shannon entropy at least that of `σ⋆(p₀)`. -/
theorem shannonEntropyBits_paperComparisonSpectrum_le_of_branches
    {m : ℕ} {p : Fin (m + 3) → ℝ}
    (hp : IsOrderedProbability p)
    (hheadUpper : p 0 ≤ 2 / 3)
    (hsmall : p 0 ≤ 1 / 2 →
      PrefixMajorizedBy p (twoPointComparison (m + 1)))
    (hlarge : 1 / 2 < p 0 →
      PrefixMajorizedBy p
        (threePointComparison m (p 0) (zStar (p 0)))) :
    shannonEntropyBits (paperComparisonSpectrum m (p 0)) ≤
      shannonEntropyBits p := by
  exact shannonEntropyBits_le_of_prefixMajorizedBy hp
    (paperComparisonSpectrum_isOrderedProbability m hheadUpper)
    (prefixMajorizedBy_paperComparisonSpectrum_of_branches hsmall hlarge)

/-- Equality clause in `eq:schmidt_entropy_comparison`: equality with the
piecewise comparison spectrum forces the entire ordered Schmidt spectrum to
be exactly that comparison spectrum. -/
theorem eq_paperComparisonSpectrum_of_shannonEntropyBits_eq_of_branches
    {m : ℕ} {p : Fin (m + 3) → ℝ}
    (hp : IsOrderedProbability p)
    (hheadUpper : p 0 ≤ 2 / 3)
    (hsmall : p 0 ≤ 1 / 2 →
      PrefixMajorizedBy p (twoPointComparison (m + 1)))
    (hlarge : 1 / 2 < p 0 →
      PrefixMajorizedBy p
        (threePointComparison m (p 0) (zStar (p 0))))
    (hentropy :
      shannonEntropyBits p =
        shannonEntropyBits (paperComparisonSpectrum m (p 0))) :
    p = paperComparisonSpectrum m (p 0) := by
  exact (shannonEntropyBits_eq_iff_of_prefixMajorizedBy hp
    (paperComparisonSpectrum_isOrderedProbability m hheadUpper)
    (prefixMajorizedBy_paperComparisonSpectrum_of_branches hsmall hlarge)).mp
      hentropy

/-- Paper-facing combined statement: the comparison spectrum minimizes
Shannon entropy, and equality is possible only for that exact spectrum. -/
theorem shannonEntropyBits_comparison_and_rigidity_of_branches
    {m : ℕ} {p : Fin (m + 3) → ℝ}
    (hp : IsOrderedProbability p)
    (hheadUpper : p 0 ≤ 2 / 3)
    (hsmall : p 0 ≤ 1 / 2 →
      PrefixMajorizedBy p (twoPointComparison (m + 1)))
    (hlarge : 1 / 2 < p 0 →
      PrefixMajorizedBy p
        (threePointComparison m (p 0) (zStar (p 0)))) :
    shannonEntropyBits (paperComparisonSpectrum m (p 0)) ≤
        shannonEntropyBits p ∧
      (shannonEntropyBits p =
          shannonEntropyBits (paperComparisonSpectrum m (p 0)) →
        p = paperComparisonSpectrum m (p 0)) := by
  constructor
  · exact shannonEntropyBits_paperComparisonSpectrum_le_of_branches
      hp hheadUpper hsmall hlarge
  · exact eq_paperComparisonSpectrum_of_shannonEntropyBits_eq_of_branches
      hp hheadUpper hsmall hlarge

/-- In the large-head branch the boundary comparison spectrum itself has
strictly more than one bit. -/
theorem one_lt_shannonEntropyBits_paperComparisonSpectrum_of_half_lt
    (m : ℕ) {x : ℝ} (hxLower : (1 / 2 : ℝ) < x)
    (hxUpper : x ≤ 2 / 3) :
    1 < shannonEntropyBits (paperComparisonSpectrum m x) := by
  rw [paperComparisonSpectrum_of_half_lt m hxLower]
  let q := threePointComparison m x (zStar x)
  have hq : IsOrderedProbability q :=
    threePointComparison_isOrderedProbability_on_interval
      m (le_of_lt hxLower) hxUpper
  have hcollision : collisionProbability q ≤ 1 / 2 := by
    rw [collisionProbability_threePointComparison_on_interval
      m (le_of_lt hxLower) hxUpper]
  have hone : 1 ≤ shannonEntropyBits q :=
    one_le_shannonEntropyBits_of_orderedProbability_of_collisionProbability_le_half
      hq hcollision
  apply lt_of_le_of_ne hone
  intro heq
  have hqeq : q = twoPointComparison (m + 1) :=
    orderedProbability_eq_twoPoint_of_collision_le_half_of_shannon_eq_one
      hq hcollision heq.symm
  have hhead := congrFun hqeq (0 : Fin (m + 3))
  simp [q, threePointComparison, twoPointComparison] at hhead
  linarith

/-- Quantitative large-head endpoint from the appendix:
`H(p) ≥ H(σ⋆(p₀)) > 1`. -/
theorem quantitative_shannonEntropyBits_of_large_branch
    {m : ℕ} {p : Fin (m + 3) → ℝ}
    (hp : IsOrderedProbability p)
    (hheadLower : (1 / 2 : ℝ) < p 0)
    (hheadUpper : p 0 ≤ 2 / 3)
    (hpref : PrefixMajorizedBy p
      (threePointComparison m (p 0) (zStar (p 0)))) :
    1 < shannonEntropyBits (paperComparisonSpectrum m (p 0)) ∧
      shannonEntropyBits (paperComparisonSpectrum m (p 0)) ≤
        shannonEntropyBits p := by
  constructor
  · exact one_lt_shannonEntropyBits_paperComparisonSpectrum_of_half_lt
      m hheadLower hheadUpper
  · rw [paperComparisonSpectrum_of_half_lt m hheadLower]
    exact shannonEntropyBits_le_of_prefixMajorizedBy hp
      (threePointComparison_isOrderedProbability_on_interval
        m (le_of_lt hheadLower) hheadUpper) hpref

end

end EntanglementPurification
