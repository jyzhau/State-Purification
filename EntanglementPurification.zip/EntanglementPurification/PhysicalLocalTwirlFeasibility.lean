import EntanglementPurification.PhysicalPPTInstrument
import EntanglementPurification.PhysicalLocalTwirlPPT
import EntanglementPurification.PhysicalLocalTwirlCompleteness
import EntanglementPurification.PhysicalResourceInsertion

/-!
# Full feasibility of twirling a physical PPT instrument

Starting from an operational `QIT.FiniteInstrument` packaged as a
`PhysicalPPTInstrument`, this module applies the genuine local Haar twirl to
the two regrouped physical Choi matrices.  Positivity comes from complete
positivity of the original branches, Bob-PPT positivity from the supplied
physical PPT premises, and output completeness from trace preservation of the
total channel.  Local mixed-representation invariance is produced by the Haar
average itself.

None of the four resulting feasibility properties is added as an assumption.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

universe uA uB uRA uRB

variable {a : Type uA} {b : Type uB} {ra : Type uRA} {rb : Type uRB}
  [Fintype a] [Fintype b] [Fintype ra] [Fintype rb]
  [DecidableEq a] [DecidableEq b] [DecidableEq ra] [DecidableEq rb]

namespace PhysicalPPTInstrument

/-- The physical Choi matrix of an operational outcome after the genuine
independent Alice/Bob Haar twirl. -/
def twirledBranch [Nonempty a] [Nonempty b] [Nonempty ra] [Nonempty rb]
    (M : PhysicalPPTInstrument a b ra rb) (outcome : Bool) :
    CMatrix (JointContractionPhysicalIndex a b (ra × rb)) :=
  physicalLocalTwirl
    (physicalInstrumentChoiMatrix
      (MatrixMap.choi (M.instrument.branch outcome)))

/-- Twirled physical success Choi matrix. -/
def twirledSuccess [Nonempty a] [Nonempty b] [Nonempty ra] [Nonempty rb]
    (M : PhysicalPPTInstrument a b ra rb) :
    CMatrix (JointContractionPhysicalIndex a b (ra × rb)) :=
  M.twirledBranch true

/-- Twirled physical failure Choi matrix. -/
def twirledFailure [Nonempty a] [Nonempty b] [Nonempty ra] [Nonempty rb]
    (M : PhysicalPPTInstrument a b ra rb) :
    CMatrix (JointContractionPhysicalIndex a b (ra × rb)) :=
  M.twirledBranch false

/-- Every twirled branch remains positive semidefinite. -/
theorem twirledBranch_posSemidef
    [Nonempty a] [Nonempty b] [Nonempty ra] [Nonempty rb]
    (M : PhysicalPPTInstrument a b ra rb) (outcome : Bool) :
    (M.twirledBranch outcome).PosSemidef := by
  exact physicalLocalTwirl_posSemidef (M.branch_posSemidef outcome)

/-- Every twirled branch remains positive after physical Bob partial
transpose. -/
theorem twirledBranch_ppt
    [Nonempty a] [Nonempty b] [Nonempty ra] [Nonempty rb]
    (M : PhysicalPPTInstrument a b ra rb) (outcome : Bool) :
    (physicalBranchPartialTransposeB
      (M.twirledBranch outcome)).PosSemidef := by
  exact physicalLocalTwirl_preserves_physicalBobPPT (M.branch_ppt outcome)

/-- Every twirled branch is invariant under the independent physical local
mixed representations. -/
theorem twirledBranch_invariant
    [Nonempty a] [Nonempty b] [Nonempty ra] [Nonempty rb]
    (M : PhysicalPPTInstrument a b ra rb) (outcome : Bool) :
    JointContractionPhysicalInvariant (M.twirledBranch outcome) := by
  exact physicalLocalTwirl_jointContractionPhysicalInvariant _

/-- The two twirled branches retain the trace-preserving output-completeness
equation inherited from the original `FiniteInstrument`. -/
theorem outputTrace_twirledSuccess_add_twirledFailure_eq_one
    [Nonempty a] [Nonempty b] [Nonempty ra] [Nonempty rb]
    (M : PhysicalPPTInstrument a b ra rb) :
    physicalBranchOutputTrace M.twirledSuccess +
        physicalBranchOutputTrace M.twirledFailure = 1 := by
  apply physicalBranchOutputTrace_physicalLocalTwirl_add_eq_one
  simpa [success, failure] using M.outputTrace_success_add_failure_eq_one

/-- All feasibility conclusions for the genuine local twirl of a complete
two-outcome physical PPT instrument.  This is a proposition-valued certificate
whose constructor is proved below from the operational instrument data. -/
structure LocalTwirlFeasibilityCertificate
    [Nonempty a] [Nonempty b] [Nonempty ra] [Nonempty rb]
    (M : PhysicalPPTInstrument a b ra rb) : Prop where
  success_posSemidef : M.twirledSuccess.PosSemidef
  failure_posSemidef : M.twirledFailure.PosSemidef
  success_ppt :
    (physicalBranchPartialTransposeB M.twirledSuccess).PosSemidef
  failure_ppt :
    (physicalBranchPartialTransposeB M.twirledFailure).PosSemidef
  outputTrace_complete :
    physicalBranchOutputTrace M.twirledSuccess +
      physicalBranchOutputTrace M.twirledFailure = 1
  success_invariant :
    JointContractionPhysicalInvariant M.twirledSuccess
  failure_invariant :
    JointContractionPhysicalInvariant M.twirledFailure

/-- Headline theorem: applying the actual local Haar twirl to the physical
Choi branches of `M.instrument` produces a complete, positive, Bob-PPT, and
locally invariant two-branch pair. -/
theorem localTwirl_feasibilityCertificate
    [Nonempty a] [Nonempty b] [Nonempty ra] [Nonempty rb]
    (M : PhysicalPPTInstrument a b ra rb) :
    M.LocalTwirlFeasibilityCertificate where
  success_posSemidef := M.twirledBranch_posSemidef true
  failure_posSemidef := M.twirledBranch_posSemidef false
  success_ppt := M.twirledBranch_ppt true
  failure_ppt := M.twirledBranch_ppt false
  outputTrace_complete := M.outputTrace_twirledSuccess_add_twirledFailure_eq_one
  success_invariant := M.twirledBranch_invariant true
  failure_invariant := M.twirledBranch_invariant false

end PhysicalPPTInstrument

end

end EntanglementPurification
