import EntanglementPurification.GlobalHaarPerformance
import EntanglementPurification.GlobalOperationalSDP
import Mathlib.Tactic

/-!
# Haar-facing optimum and uniqueness theorem

This file rewrites the completed concrete SDP theorem back to the performance
operator defined from the genuine second and third unitary-Haar orbit moments.
It is the paper-facing endpoint for `lem:general_d_global_optimum`.

The operator here is the moment-expanded expression in equations 1369--1392.
`GlobalEq986Integral.lean` proves that the original noisy-channel integral in
equation 986 is exactly this operator, and `GlobalEq986Optimality.lean` exposes
the resulting equation-986-facing optimum and uniqueness endpoints.
-/

namespace EntanglementPurification

open QIT

noncomputable section

/-- The scalar name used internally is literally the displayed formula in
`lem:general_d_global_optimum`. -/
theorem globalOptimalGain_eq_displayed_formula (D gamma : ℝ) :
    globalOptimalGain D gamma =
      (1 / 2 : ℝ) * (1 - gamma + gamma / D) * gamma * (1 - gamma) *
        (1 - 1 / D) := by
  rfl

/-- The internal candidate name is literally `(D+1) P_{W₊}/2`. -/
theorem globalOptimalChoi_eq_displayed_formula
    {x : Type*} [Fintype x] [DecidableEq x] :
    globalOptimalChoi (x := x) =
      (((Fintype.card x : ℝ) + 1) / 2) • globalPWPlus := by
  rfl

/-- Complete Haar-facing finite-matrix SDP theorem for an arbitrary finite
one-leg type of dimension at least four. -/
theorem globalHaar_optimal_and_unique
    {x : Type*} [Fintype x] [DecidableEq x] [Nonempty x]
    (nu : PureVector x) {gamma : ℝ}
    (hcard : 4 ≤ (Fintype.card x : ℝ))
    (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) :
    IsGlobalCPTNChoi (globalOptimalChoi (x := x)) ∧
      globalSDPObjective (globalHaarPerformanceOperator nu gamma)
          globalOptimalChoi =
        globalOptimalGain (Fintype.card x : ℝ) gamma ∧
      (∀ J : CMatrix (GlobalThreeLeg x), IsGlobalCPTNChoi J →
        globalSDPObjective (globalHaarPerformanceOperator nu gamma) J ≤
          globalOptimalGain (Fintype.card x : ℝ) gamma) ∧
      (∀ J : CMatrix (GlobalThreeLeg x), IsGlobalCPTNChoi J →
        (globalSDPObjective (globalHaarPerformanceOperator nu gamma) J =
            globalOptimalGain (Fintype.card x : ℝ) gamma ↔
          J = globalOptimalChoi (x := x))) := by
  rw [globalHaarPerformanceOperator_eq_globalConcreteRawPerformanceOperator]
  exact globalConcreteRaw_optimal_and_unique
    hcard hgamma0 hgamma1

/-- Map-level form of the preceding Haar-facing result.  Equality identifies
the CPTN map itself, using injectivity of the input-first Choi representation. -/
theorem globalHaar_map_optimal_and_unique
    {x : Type*} [Fintype x] [DecidableEq x] [Nonempty x]
    (nu : PureVector x) {gamma : ℝ}
    (hcard : 4 ≤ (Fintype.card x : ℝ))
    (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) :
    MatrixMap.TraceNonincreasingCP
        (MatrixMap.ofChoiMatrix (globalOptimalChoi (x := x))) ∧
      globalSDPObjective (globalHaarPerformanceOperator nu gamma)
          (MatrixMap.choi
            (MatrixMap.ofChoiMatrix (globalOptimalChoi (x := x)))) =
        globalOptimalGain (Fintype.card x : ℝ) gamma ∧
      (∀ Phi : MatrixMap (x × x) x,
        MatrixMap.TraceNonincreasingCP Phi →
          globalSDPObjective (globalHaarPerformanceOperator nu gamma)
              (MatrixMap.choi Phi) ≤
            globalOptimalGain (Fintype.card x : ℝ) gamma) ∧
      (∀ Phi : MatrixMap (x × x) x,
        MatrixMap.TraceNonincreasingCP Phi →
          (globalSDPObjective (globalHaarPerformanceOperator nu gamma)
                (MatrixMap.choi Phi) =
              globalOptimalGain (Fintype.card x : ℝ) gamma ↔
            Phi = MatrixMap.ofChoiMatrix
              (globalOptimalChoi (x := x)))) := by
  rw [globalHaarPerformanceOperator_eq_globalConcreteRawPerformanceOperator]
  exact globalRaw_map_optimal_and_unique
    hcard hgamma0 hgamma1

/-- The paper assumption `d ≥ 2` supplies a concrete inhabitant of the
one-leg label type `Fin d × Fin d`. -/
@[reducible] def globalPaperIndexNonempty
    {d : ℕ} (hd : 2 ≤ d) : Nonempty (GlobalPaperIndex d) := by
  have hdpos : 0 < d := by omega
  exact ⟨(⟨0, hdpos⟩, ⟨0, hdpos⟩)⟩

/-- Haar performance operator with the paper's one-leg index and with the
nonemptiness witness derived from `d ≥ 2`. -/
def globalPaperHaarPerformanceOperator
    {d : ℕ} (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    (gamma : ℝ) : CMatrix (GlobalThreeLeg (GlobalPaperIndex d)) := by
  letI : Nonempty (GlobalPaperIndex d) := globalPaperIndexNonempty hd
  exact globalHaarPerformanceOperator nu gamma

/-- The paper-indexed Haar operator is the concrete raw operator used by the
finite SDP calculation. -/
theorem globalPaperHaarPerformanceOperator_eq_raw
    {d : ℕ} (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    (gamma : ℝ) :
    globalPaperHaarPerformanceOperator hd nu gamma =
      globalConcreteRawPerformanceOperator
        (x := GlobalPaperIndex d) gamma := by
  letI : Nonempty (GlobalPaperIndex d) := globalPaperIndexNonempty hd
  exact globalHaarPerformanceOperator_eq_globalConcreteRawPerformanceOperator
    nu gamma

/-- The paper-indexed Haar performance operator is Hermitian for every
`d ≥ 2`. -/
theorem globalPaperHaarPerformanceOperator_isHermitian
    {d : ℕ} (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    (gamma : ℝ) :
    (globalPaperHaarPerformanceOperator hd nu gamma).IsHermitian := by
  rw [globalPaperHaarPerformanceOperator_eq_raw]
  exact globalConcreteRawPerformanceOperator_isHermitian
    (four_le_card_globalPaperIndex hd)

/-- For every feasible paper Choi matrix, the literal Haar trace objective is
real. -/
theorem globalPaperHaar_trace_im_eq_zero
    {d : ℕ} (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    (gamma : ℝ) {J : CMatrix (GlobalThreeLeg (GlobalPaperIndex d))}
    (hJ : IsGlobalCPTNChoi J) :
    ((globalPaperHaarPerformanceOperator hd nu gamma * J).trace).im = 0 :=
  globalSDPObjective_trace_im_eq_zero
    (globalPaperHaarPerformanceOperator_isHermitian hd nu gamma) hJ

/-- On the feasible set, the paper's complex expression `Tr(MJ)` is exactly
the complex coercion of Lean's real-valued `globalSDPObjective M J`. -/
theorem globalPaperHaar_trace_eq_coe_globalSDPObjective
    {d : ℕ} (hd : 2 ≤ d) (nu : PureVector (GlobalPaperIndex d))
    (gamma : ℝ) {J : CMatrix (GlobalThreeLeg (GlobalPaperIndex d))}
    (hJ : IsGlobalCPTNChoi J) :
    (globalPaperHaarPerformanceOperator hd nu gamma * J).trace =
      (globalSDPObjective
        (globalPaperHaarPerformanceOperator hd nu gamma) J : ℂ) :=
  trace_mul_eq_coe_globalSDPObjective
    (globalPaperHaarPerformanceOperator_isHermitian hd nu gamma) hJ

/-- Paper-facing endpoint with `x = Fin d × Fin d`, hence `D=d²`.  It states
feasibility, attainment of the displayed value, the universal upper bound,
and matrix equality as the exact equality condition. -/
theorem globalPaperHaar_optimal_and_unique
    {d : ℕ} (hd : 2 ≤ d)
    (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) :
    IsGlobalCPTNChoi
        (globalOptimalChoi (x := GlobalPaperIndex d)) ∧
      globalSDPObjective
          (globalPaperHaarPerformanceOperator hd nu gamma)
          globalOptimalChoi =
        globalOptimalGain ((d : ℝ) ^ 2) gamma ∧
      (∀ J : CMatrix (GlobalThreeLeg (GlobalPaperIndex d)),
        IsGlobalCPTNChoi J →
          globalSDPObjective
              (globalPaperHaarPerformanceOperator hd nu gamma) J ≤
            globalOptimalGain ((d : ℝ) ^ 2) gamma) ∧
      (∀ J : CMatrix (GlobalThreeLeg (GlobalPaperIndex d)),
        IsGlobalCPTNChoi J →
          (globalSDPObjective
                (globalPaperHaarPerformanceOperator hd nu gamma) J =
              globalOptimalGain ((d : ℝ) ^ 2) gamma ↔
            J = globalOptimalChoi (x := GlobalPaperIndex d))) := by
  rw [globalPaperHaarPerformanceOperator_eq_raw]
  exact globalPaperRaw_optimal_and_unique hd hgamma0 hgamma1

/-- Map-level paper endpoint for the Haar-defined performance operator. -/
theorem globalPaperHaar_map_optimal_and_unique
    {d : ℕ} (hd : 2 ≤ d)
    (nu : PureVector (GlobalPaperIndex d))
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) :
    MatrixMap.TraceNonincreasingCP
        (MatrixMap.ofChoiMatrix
          (globalOptimalChoi (x := GlobalPaperIndex d))) ∧
      globalSDPObjective
          (globalPaperHaarPerformanceOperator hd nu gamma)
          (MatrixMap.choi
            (MatrixMap.ofChoiMatrix
              (globalOptimalChoi (x := GlobalPaperIndex d)))) =
        globalOptimalGain ((d : ℝ) ^ 2) gamma ∧
      (∀ Phi : MatrixMap
          (GlobalPaperIndex d × GlobalPaperIndex d) (GlobalPaperIndex d),
        MatrixMap.TraceNonincreasingCP Phi →
          globalSDPObjective
              (globalPaperHaarPerformanceOperator hd nu gamma)
              (MatrixMap.choi Phi) ≤
            globalOptimalGain ((d : ℝ) ^ 2) gamma) ∧
      (∀ Phi : MatrixMap
          (GlobalPaperIndex d × GlobalPaperIndex d) (GlobalPaperIndex d),
        MatrixMap.TraceNonincreasingCP Phi →
          (globalSDPObjective
                (globalPaperHaarPerformanceOperator hd nu gamma)
                (MatrixMap.choi Phi) =
              globalOptimalGain ((d : ℝ) ^ 2) gamma ↔
            Phi = MatrixMap.ofChoiMatrix
              (globalOptimalChoi (x := GlobalPaperIndex d)))) := by
  rw [globalPaperHaarPerformanceOperator_eq_raw]
  exact globalPaperRaw_map_optimal_and_unique hd hgamma0 hgamma1

end

end EntanglementPurification
