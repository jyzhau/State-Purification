import EntanglementPurification.PPTResourceEffect
import EntanglementPurification.PPTTestVectors
import Mathlib.Tactic

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

theorem pairwisePPT_auxiliaryResourceEffect_upper_bound
    {ra rb : Type*}
    [Fintype ra] [Fintype rb] [DecidableEq ra] [DecidableEq rb]
    (a0 a1 : ra) (b0 b1 : rb) (ha : a0 ≠ a1)
    (d : ℕ) (hd : 2 ≤ d) (eta : PureVector (ra × rb))
    {K : CMatrix (LocalMultiplicitySector × (ra × rb))}
    (hK : BranchPPT K)
    (hinsert : insertPureResourceBlock eta.amp K =
      rankOneMatrix (localOptimalMultiplicityVector d))
    (hPPupper : resourceSectorBlock K sectorPP sectorPP ≤
      (localContractionAlpha d) ^ 2 • (1 : CMatrix (ra × rb)))
    (hMMupper : resourceSectorBlock K sectorMM sectorMM ≤
      (localContractionBeta d) ^ 2 • (1 : CMatrix (ra × rb)))
    (Q : CMatrix (ra × rb)) (hQ0 : Q.PosSemidef)
    (hQeta : Q.mulVec eta.amp = 0)
    (hresidual :
      (Q - (1 / (localContractionAlpha d * localContractionBeta d) : ℝ) •
        (resourceSectorBlock K sectorPM sectorPM +
          resourceSectorBlock K sectorMP sectorMP)).PosSemidef)
    (hfailure :
      (QIT.partialTransposeB
        (realScalarIdentity (r := ra × rb) 2 - Q)).PosSemidef) :
    ((pureVectorPerpProjection eta *
          sectorPPTAuxiliaryResourceEffect eta d K Q *
          pureVectorPerpProjection eta)
        (a0, b0) (a1, b1)).re ≤ 1 / 3 := by
  let P : CMatrix (ra × rb) := pureVectorPerpProjection eta
  let R : CMatrix (ra × rb) := rankOneMatrix eta.amp
  let C : CMatrix (ra × rb) :=
    resourceSectorBlock K sectorPP sectorMM
  let H : CMatrix (ra × rb) := C + Matrix.conjTranspose C
  let D : CMatrix (ra × rb) :=
    resourceSectorBlock K sectorPM sectorPM +
      resourceSectorBlock K sectorMP sectorMP
  let t : ℝ := localContractionAlpha d * localContractionBeta d
  have hKpos : K.PosSemidef := hK.1
  have hKppt : (sectorResourcePartialTransposeB K).PosSemidef := hK.2
  have ht : 0 < t := by
    have haPos : 0 < localContractionAlpha d := by
      unfold localContractionAlpha
      positivity
    have hdR : (1 : ℝ) < d := by exact_mod_cast hd
    have hbPos : 0 < localContractionBeta d := by
      unfold localContractionBeta
      positivity
    exact mul_pos haPos hbPos
  have hPid : P * P = P := by
    simp [P]
  have hQstarEta : (Matrix.conjTranspose Q).mulVec eta.amp = 0 := by
    rw [hQ0.isHermitian.eq]
    exact hQeta
  have hQcomp : P * Q * P = Q := by
    have hQeta' : Q.mulVec eta.amp = (0 : ℂ) • eta.amp := by
      simpa using hQeta
    have hQstarEta' : (Matrix.conjTranspose Q).mulVec eta.amp =
        (0 : ℂ) • eta.amp := by
      simpa using hQstarEta
    have hdec := matrix_eq_eigen_rankOne_add_perp_compression
      eta Q 0 hQeta' hQstarEta'
    simpa [P] using hdec.symm
  have hCadj : Matrix.conjTranspose C =
      resourceSectorBlock K sectorMM sectorPP := by
    simpa [C] using
      (resourceSectorBlock_conjTranspose hKpos.isHermitian sectorPP sectorMM)
  rcases inserted_optimal_forces_off_diagonal_block_decompositions
      d hd eta hKpos hinsert hPPupper hMMupper with ⟨hCdec0, hCadjdec0⟩
  have hCdec : C = (t : ℂ) • R + P * C * P := by
    simpa [C, R, P, t] using hCdec0
  have hCadjdec : Matrix.conjTranspose C =
      (t : ℂ) • R + P * Matrix.conjTranspose C * P := by
    simpa [C, R, P, t, hCadj] using hCadjdec0
  have hHdec : H = (2 * t : ℝ) • R + P * H * P := by
    change C + Matrix.conjTranspose C =
      (2 * t : ℝ) • R + P * (C + Matrix.conjTranspose C) * P
    calc
      C + Matrix.conjTranspose C =
          ((t : ℂ) • R + P * C * P) +
            ((t : ℂ) • R + P * Matrix.conjTranspose C * P) :=
        congrArg₂ (· + ·) hCdec hCadjdec
      _ = (2 * t : ℝ) • R +
          P * (C + Matrix.conjTranspose C) * P := by
        simp only [Matrix.mul_add, Matrix.add_mul]
        module
  have hPHP : P * H * P = H - (2 * t : ℝ) • R := by
    exact eq_sub_of_add_eq' hHdec.symm
  let A : CMatrix (ra × rb) :=
    projectedNormalizedHermitianCross eta t C
  have hA : A = (1 / t : ℝ) • H - (2 : ℝ) • R := by
    change (1 / t : ℝ) • (P * H * P) =
      (1 / t : ℝ) • H - (2 : ℝ) • R
    rw [hPHP, smul_sub, smul_smul]
    have hcancel : (1 / t : ℝ) * (2 * t) = 2 := by
      field_simp [ne_of_gt ht]
    rw [hcancel]
  have hPHPsupp : P * (P * H * P) * P = P * H * P := by
    calc
      P * (P * H * P) * P = (P * P) * H * (P * P) := by
        noncomm_ring
      _ = P * H * P := by rw [hPid]
  have hAsupp : P * A * P = A := by
    change P * ((1 / t : ℝ) • (P * H * P)) * P =
      (1 / t : ℝ) • (P * H * P)
    rw [Matrix.mul_smul, Matrix.smul_mul]
    rw [hPHPsupp]
  have hPtwo : P * realScalarIdentity (r := ra × rb) 2 * P =
      (2 : ℝ) • P := by
    simp only [realScalarIdentity, Matrix.mul_smul, Matrix.smul_mul,
      Matrix.mul_one, hPid]
  have hPNP :
      P * sectorPPTAuxiliaryResourceEffect eta d K Q * P =
        (1 / 6 : ℝ) •
          (Q + realScalarIdentity (r := ra × rb) 2 - (1 / t : ℝ) • H) := by
    change P * auxiliaryResourceEffect Q A * P = _
    rw [auxiliaryResourceEffect, Matrix.mul_smul, Matrix.smul_mul]
    congr 1
    calc
      P * (Q + (realScalarIdentity (r := ra × rb) 2 - A)) * P =
          P * Q * P + P * realScalarIdentity (r := ra × rb) 2 * P -
            P * A * P := by noncomm_ring
      _ = Q + (2 : ℝ) • P - A := by rw [hQcomp, hPtwo, hAsupp]
      _ = Q + realScalarIdentity (r := ra × rb) 2 -
          (1 / t : ℝ) • H := by
        rw [hA]
        simp only [P, pureVectorPerpProjection, realScalarIdentity]
        module
  have hHherm : H.IsHermitian := by
    rw [Matrix.IsHermitian]
    simp [H, Matrix.conjTranspose_add, add_comm]
  have hHswap :
      (H (a1, b1) (a0, b0)).re = (H (a0, b0) (a1, b1)).re := by
    have hentry := congrFun (congrFun hHherm.eq (a0, b0)) (a1, b1)
    simpa [Matrix.conjTranspose_apply] using congrArg Complex.re hentry
  have hsuccessPlus := matrixQuadratic_re_nonneg hKppt
    (pairPPTTestVectorPlus a0 a1 b0 b1)
  have hsuccessMinus := matrixQuadratic_re_nonneg hKppt
    (pairPPTTestVectorMinus a0 a1 b0 b1)
  have hsuccessRaw :
      0 ≤ (matrixQuadratic (sectorResourcePartialTransposeB K)
            (pairPPTTestVectorPlus a0 a1 b0 b1) +
          matrixQuadratic (sectorResourcePartialTransposeB K)
            (pairPPTTestVectorMinus a0 a1 b0 b1)).re := by
    simpa using add_nonneg hsuccessPlus hsuccessMinus
  rw [pairPPTTestVectors_quadratic_sum] at hsuccessRaw
  have hsuccessExpanded :
      0 ≤ (2 *
        (D (a0, b1) (a0, b1) + D (a1, b0) (a1, b0) +
          H (a0, b0) (a1, b1) + H (a1, b1) (a0, b0))).re := by
    simpa [D, H, C, hCadj] using hsuccessRaw
  have hsuccess :
      0 ≤ (D (a0, b1) (a0, b1)).re +
        (D (a1, b0) (a1, b0)).re +
        2 * (H (a0, b0) (a1, b1)).re := by
    norm_num [Complex.mul_re, Complex.add_re] at hsuccessExpanded
    rw [hHswap] at hsuccessExpanded
    linarith
  have hQswap :
      (Q (a1, b1) (a0, b0)).re = (Q (a0, b0) (a1, b1)).re := by
    have hentry := congrFun (congrFun hQ0.isHermitian.eq (a0, b0)) (a1, b1)
    simpa [Matrix.conjTranspose_apply] using congrArg Complex.re hentry
  have h00ne11 : (a0, b0) ≠ (a1, b1) := by
    intro h
    exact ha (congrArg Prod.fst h)
  have hfailureRaw := matrixQuadratic_re_nonneg hfailure
    (resourceBellSignVector (1 : ℂ) a0 a1 b0 b1)
  rw [resourceBellSignVector_partialTransposeB_quadratic
    (realScalarIdentity (r := ra × rb) 2 - Q) (1 : ℂ)
      (by simp) (by norm_num) a0 a1 b0 b1] at hfailureRaw
  have hfailureIneq :
      0 ≤ 4 - (Q (a0, b1) (a0, b1)).re -
        (Q (a1, b0) (a1, b0)).re -
        2 * (Q (a0, b0) (a1, b1)).re := by
    simp [realScalarIdentity, h00ne11,
      Ne.symm h00ne11, hQswap, Complex.sub_re, Complex.add_re] at hfailureRaw
    linarith
  have hresidual' : (Q - (1 / t : ℝ) • D).PosSemidef := by
    simpa [t, D] using hresidual
  have hresU :
      0 ≤ (Q (a0, b1) (a0, b1)).re -
        (1 / t) * (D (a0, b1) (a0, b1)).re := by
    have hdiag := hresidual'.diag_nonneg (i := (a0, b1))
    have hre := (Complex.nonneg_iff.mp hdiag).1
    simpa [Complex.sub_re, Complex.real_smul, Complex.mul_re] using hre
  have hresV :
      0 ≤ (Q (a1, b0) (a1, b0)).re -
        (1 / t) * (D (a1, b0) (a1, b0)).re := by
    have hdiag := hresidual'.diag_nonneg (i := (a1, b0))
    have hre := (Complex.nonneg_iff.mp hdiag).1
    simpa [Complex.sub_re, Complex.real_smul, Complex.mul_re] using hre
  have hsuccessScaled :
      0 ≤ (1 / t) *
        ((D (a0, b1) (a0, b1)).re +
          (D (a1, b0) (a1, b0)).re +
          2 * (H (a0, b0) (a1, b1)).re) :=
    mul_nonneg (by positivity) hsuccess
  have hscalar :
      (Q (a0, b0) (a1, b1)).re -
          (1 / t) * (H (a0, b0) (a1, b1)).re ≤ 2 := by
    nlinarith [hfailureIneq, hresU, hresV, hsuccessScaled]
  have hentry := congrArg Complex.re
    (congrFun (congrFun hPNP (a0, b0)) (a1, b1))
  have hentryFormula :
      ((P * sectorPPTAuxiliaryResourceEffect eta d K Q * P)
          (a0, b0) (a1, b1)).re =
        (1 / 6 : ℝ) *
          ((Q (a0, b0) (a1, b1)).re -
            (1 / t) * (H (a0, b0) (a1, b1)).re) := by
    simpa [realScalarIdentity, h00ne11, Complex.sub_re, Complex.add_re,
      Complex.real_smul, Complex.mul_re] using hentry
  change ((P * sectorPPTAuxiliaryResourceEffect eta d K Q * P)
    (a0, b0) (a1, b1)).re ≤ 1 / 3
  rw [hentryFormula]
  nlinarith

end

end EntanglementPurification
