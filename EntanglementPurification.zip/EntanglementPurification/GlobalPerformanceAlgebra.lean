import EntanglementPurification.GlobalSectorOptimization
import Mathlib.Tactic

/-!
# Algebraic performance operator for the global CPTN problem

The Haar calculation in `main.tex` first writes the performance operator in
terms of the identity, input-copy swap, and the two contraction operators
`Cdiag` and `Ccross`.  This file records that formula and proves, by finite
algebra alone, that the four table identities turn it into the four-sector
spectral operator.
-/

namespace EntanglementPurification

open QIT

noncomputable section

/-- The explicit operator obtained after inserting the first three Haar
moments into equation `eq:gd_global_performance_operator`. -/
def globalRawPerformanceOperator
    {h : Type*} [Fintype h] [DecidableEq h]
    (D gamma : ℝ) (inputSwap Cdiag Ccross : CMatrix h) : CMatrix h :=
  (1 - gamma) ^ 2 •
      ((1 / (D * (D + 1) * (D + 2))) •
          ((1 : CMatrix h) + inputSwap + Cdiag + Ccross) -
        (globalNoiseFidelity D gamma / (D * (D + 1))) •
          ((1 : CMatrix h) + inputSwap)) +
    (gamma * (1 - gamma) / D) •
      ((1 / (D * (D + 1))) • ((2 : ℝ) • (1 : CMatrix h) + Cdiag) -
        ((2 / D) * globalNoiseFidelity D gamma) • (1 : CMatrix h)) -
    (gamma ^ 2 * (1 - gamma) / D ^ 2 * (1 - 1 / D)) •
      (1 : CMatrix h)

/-- The four projector table used in the paper, stated as concrete matrix
identities rather than through mixed Schur--Weyl labels. -/
structure GlobalPerformanceSectorTable
    {h : Type*} [Fintype h] [DecidableEq h]
    (D : ℝ) (inputSwap Cdiag Ccross
      PWPlus PWMinus PLPlus PLMinus : CMatrix h) : Prop where
  resolve : PWPlus + PWMinus + PLPlus + PLMinus = 1
  swap : inputSwap = PWPlus - PWMinus + PLPlus - PLMinus
  diag : Cdiag = (D + 1) • PWPlus + (D - 1) • PWMinus
  cross : Ccross = (D + 1) • PWPlus - (D - 1) • PWMinus

/-- The explicit Haar-moment formula and the four-sector spectral formula are
identical once the four elementary table identities have been checked. -/
theorem globalRawPerformanceOperator_eq_sectorPerformance
    {h : Type*} [Fintype h] [DecidableEq h]
    {D gamma : ℝ}
    {inputSwap Cdiag Ccross PWPlus PWMinus PLPlus PLMinus : CMatrix h}
    (hD : 4 ≤ D)
    (htable : GlobalPerformanceSectorTable D inputSwap Cdiag Ccross
      PWPlus PWMinus PLPlus PLMinus) :
    globalRawPerformanceOperator D gamma inputSwap Cdiag Ccross =
      globalSectorPerformanceOperator D gamma
        PWPlus PWMinus PLPlus PLMinus := by
  have hD0 : D ≠ 0 := by linarith
  have hD1 : D + 1 ≠ 0 := by linarith
  have hD2 : D + 2 ≠ 0 := by linarith
  have hD0c : (D : ℂ) ≠ 0 := by exact_mod_cast hD0
  have hD1c : (D : ℂ) + 1 ≠ 0 := by exact_mod_cast hD1
  have hD2c : (D : ℂ) + 2 ≠ 0 := by exact_mod_cast hD2
  rw [htable.swap, htable.diag, htable.cross]
  simp only [globalRawPerformanceOperator]
  rw [← htable.resolve]
  ext i j
  simp only [globalSectorPerformanceOperator,
    globalNoiseFidelity, lambdaWPlus, lambdaWMinus, lambdaLPlus,
    lambdaLMinus, Matrix.add_apply, Matrix.sub_apply, Matrix.smul_apply,
    Complex.real_smul]
  push_cast
  field_simp [hD0c, hD1c, hD2c]
  ring

end

end EntanglementPurification
