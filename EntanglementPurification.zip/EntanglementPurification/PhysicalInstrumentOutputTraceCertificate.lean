import EntanglementPurification.PhysicalPPTInstrument
import EntanglementPurification.PaperOutputTraceCertificate

/-!
# Output-trace certificates for a complete physical PPT instrument

This is the operational entrance to the previously proved D2 sector chain.
Branch positivity, branchwise physical Bob-PPT, and success/failure
completeness come from one `PhysicalPPTInstrument`.  The only separate premise
is local-unitary invariance, which is supplied by the paper's twirl rather than
by the definition of an arbitrary instrument.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b ra rb : Type*}
  [Fintype a] [Fintype b] [Fintype ra] [Fintype rb]
  [DecidableEq a] [DecidableEq b] [DecidableEq ra] [DecidableEq rb]
  [Nonempty a] [Nonempty b]

/-- The paired D2 conclusion for the success and failure outcomes of one
complete physical PPT instrument. -/
structure PhysicalPPTInstrumentD2Certificate
    (M : PhysicalPPTInstrument a b ra rb) : Prop where
  success : PaperOutputTraceD2Certificate M.success
  failure : PaperOutputTraceD2Certificate M.failure
  output_completeness :
    physicalBranchOutputTrace M.success +
        physicalBranchOutputTrace M.failure = 1
  raw_choi_pair :
    IsChoiSuccessFailurePair
      (MatrixMap.choi (M.instrument.branch true))
      (MatrixMap.choi (M.instrument.branch false))

/-- A locally twirled complete physical PPT instrument automatically supplies
all branch hypotheses and both D2 certificates. -/
theorem PhysicalPPTInstrument.d2_certificate
    (M : PhysicalPPTInstrument a b ra rb)
    (hcardA : 2 ≤ Fintype.card a) (hcardB : 2 ≤ Fintype.card b)
    (hcardEq : Fintype.card b = Fintype.card a)
    (hInvariant : M.IsLocallyInvariant) :
    PhysicalPPTInstrumentD2Certificate M := by
  have hSuccess := M.success_certificate_inputs hInvariant
  have hFailure := M.failure_certificate_inputs hInvariant
  exact
    { success :=
        physicalInvariantPPT_outputTrace_D2_certificate_paper
          hcardA hcardB hcardEq hSuccess.1 hSuccess.2.1 hSuccess.2.2
      failure :=
        physicalInvariantPPT_outputTrace_D2_certificate_paper
          hcardA hcardB hcardEq hFailure.1 hFailure.2.1 hFailure.2.2
      output_completeness := M.outputTrace_success_add_failure_eq_one
      raw_choi_pair := M.rawChoi_isChoiSuccessFailurePair }

end

end EntanglementPurification
