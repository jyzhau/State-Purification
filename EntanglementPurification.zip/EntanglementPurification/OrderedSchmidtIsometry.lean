import EntanglementPurification.PureSchmidtIsometry
import EntanglementPurification.FiniteMajorization
import EntanglementPurification.SchmidtEffect
import QIT.Channels.Diamond
import Mathlib.Tactic

/-!
# Ordered Schmidt isometry coordinates

The spectral theorem in Lean-QIT exposes eigenvalues on an arbitrary ambient
index type.  The underlying mathlib API also exposes the same eigenvalues on
`Fin (card a)` in nonincreasing order.  This module uses that ordered index in
the Schmidt-isometry construction.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder NNReal

noncomputable section

universe u v

/-- The equivalence used by mathlib to transport ordered `eigenvalues₀` back
to an arbitrary finite matrix index type. -/
def sortedStateIndexEquiv (a : Type u) [Fintype a] :
    Fin (Fintype.card a) ≃ a :=
  Fintype.equivOfCardEq (Fintype.card_fin _)

/-- A state's eigenvalue distribution in mathlib's nonincreasing `Fin` order. -/
def sortedStateEigenvalueProb
    {a : Type u} [Fintype a] [DecidableEq a]
    (rho : State a) : Fin (Fintype.card a) → ℝ≥0 :=
  fun i =>
    ⟨rho.pos.isHermitian.eigenvalues₀ i, by
      let e := sortedStateIndexEquiv a
      have hnonneg := rho.pos.eigenvalues_nonneg (e i)
      simpa [e, sortedStateIndexEquiv, Matrix.IsHermitian.eigenvalues] using
        hnonneg⟩

@[simp]
theorem sortedStateEigenvalueProb_eq_stateEigenvalueProb
    {a : Type u} [Fintype a] [DecidableEq a]
    (rho : State a) (i : Fin (Fintype.card a)) :
    sortedStateEigenvalueProb rho i =
      ProjectiveMeasurement.stateEigenvalueProb rho
        (sortedStateIndexEquiv a i) := by
  apply NNReal.coe_injective
  simp [sortedStateEigenvalueProb, ProjectiveMeasurement.stateEigenvalueProb,
    sortedStateIndexEquiv, Matrix.IsHermitian.eigenvalues]

theorem sortedStateEigenvalueProb_sum
    {a : Type u} [Fintype a] [DecidableEq a]
    (rho : State a) :
    ∑ i, sortedStateEigenvalueProb rho i = 1 := by
  let e := sortedStateIndexEquiv a
  calc
    ∑ i, sortedStateEigenvalueProb rho i =
        ∑ j : a, ProjectiveMeasurement.stateEigenvalueProb rho j := by
      refine Fintype.sum_equiv e
        (fun i : Fin (Fintype.card a) => sortedStateEigenvalueProb rho i)
        (fun j : a => ProjectiveMeasurement.stateEigenvalueProb rho j) ?_
      intro i
      exact sortedStateEigenvalueProb_eq_stateEigenvalueProb rho i
    _ = 1 := ProjectiveMeasurement.stateEigenvalueProb_sum rho

theorem sortedStateEigenvalueProb_antitone
    {a : Type u} [Fintype a] [DecidableEq a]
    (rho : State a) :
    Antitone (fun i => (sortedStateEigenvalueProb rho i : ℝ)) := by
  intro i j hij
  exact rho.pos.isHermitian.eigenvalues₀_antitone hij

/-- The ordered eigenvalue probabilities, coerced to reals, form an ordered
probability vector. -/
theorem sortedStateEigenvalueProb_isOrderedProbability
    {a : Type u} [Fintype a] [DecidableEq a]
    (rho : State a) :
    IsOrderedProbability
      (fun i => (sortedStateEigenvalueProb rho i : ℝ)) := by
  refine ⟨sortedStateEigenvalueProb_antitone rho, ?_, ?_⟩
  · intro i
    exact NNReal.zero_le_coe
  · rw [← FiniteSchmidtData.sum_univ_eq_sum_ofFn]
    exact_mod_cast sortedStateEigenvalueProb_sum rho

/-- Reindexing a diagonal matrix by the canonical ordered-index equivalence
recovers Lean-QIT's ambient eigenvalue diagonal. -/
theorem sortedEigenvalue_diagonal_conjugation
    {a : Type u} [Fintype a] [DecidableEq a]
    (rho : State a) :
    let E := ReferenceIsometry.ofEquiv (sortedStateIndexEquiv a)
    E.matrix *
          Matrix.diagonal
            (fun i => ((sortedStateEigenvalueProb rho i : ℝ≥0) : ℂ)) *
        Matrix.conjTranspose E.matrix =
      Matrix.diagonal
        (fun j =>
          ((ProjectiveMeasurement.stateEigenvalueProb rho j : ℝ≥0) : ℂ)) := by
  let e := sortedStateIndexEquiv a
  change
    (ReferenceIsometry.ofEquiv e).matrix *
          Matrix.diagonal
            (fun i => ((sortedStateEigenvalueProb rho i : ℝ≥0) : ℂ)) *
        Matrix.conjTranspose (ReferenceIsometry.ofEquiv e).matrix =
      Matrix.diagonal
        (fun j =>
          ((ProjectiveMeasurement.stateEigenvalueProb rho j : ℝ≥0) : ℂ))
  ext i j
  by_cases hij : i = j
  · subst j
    rw [Matrix.mul_apply]
    rw [Finset.sum_eq_single (e.symm i)]
    · rw [Matrix.mul_apply]
      rw [Finset.sum_eq_single (e.symm i)]
      · simp [ReferenceIsometry.ofEquiv, e]
      · intro x hx hne
        have hix : i ≠ e x := by
          intro h
          apply hne
          simp [h]
        simp [ReferenceIsometry.ofEquiv, hix]
      · exact fun h => False.elim (h (Finset.mem_univ _))
    · intro x hx hne
      have hix : i ≠ e x := by
        intro h
        apply hne
        simp [h]
      simp [ReferenceIsometry.ofEquiv, Matrix.conjTranspose_apply, hix]
    · exact fun h => False.elim (h (Finset.mem_univ _))
  · rw [Matrix.mul_apply]
    rw [Finset.sum_eq_single (e.symm j)]
    · rw [Matrix.mul_apply]
      rw [Finset.sum_eq_single (e.symm i)]
      · have hsymm : e.symm i ≠ e.symm j := by
          intro h
          exact hij (e.symm.injective h)
        simp [ReferenceIsometry.ofEquiv, hsymm, hij, e]
      · intro x hx hne
        have hix : i ≠ e x := by
          intro h
          apply hne
          simp [h]
        simp [ReferenceIsometry.ofEquiv, hix]
      · exact fun h => False.elim (h (Finset.mem_univ _))
    · intro x hx hne
      have hjx : j ≠ e x := by
        intro h
        apply hne
        simp [h]
      simp [ReferenceIsometry.ofEquiv, Matrix.conjTranspose_apply, hjx]
    · exact fun h => False.elim (h (Finset.mem_univ _))

/-- Eigenvector isometry with columns presented in the ordered `Fin` index. -/
def sortedStateEigenvectorIsometry
    {a : Type u} [Fintype a] [DecidableEq a]
    (rho : State a) :
    ReferenceIsometry (Fin (Fintype.card a)) a :=
  (stateEigenvectorIsometry rho).comp
    (ReferenceIsometry.ofEquiv (sortedStateIndexEquiv a))

/-- The ordered standard Schmidt vector, followed by the sorted eigenvector
isometry on its target half, purifies the original state. -/
theorem sortedStateEigenvectorIsometry_applyStandard_purifies
    {a : Type u} [Fintype a] [DecidableEq a]
    (rho : State a) :
    ((sortedStateEigenvectorIsometry rho).applyPureVectorRight
      (schmidtStandardVector (sortedStateEigenvalueProb rho)
        (sortedStateEigenvalueProb_sum rho))).Purifies rho := by
  rw [PureVector.purifies_iff]
  rw [(sortedStateEigenvectorIsometry rho).rankOne_applyPureVectorRight]
  rw [(sortedStateEigenvectorIsometry rho).partialTraceA_applyMatrixRight]
  rw [← State.marginalB_matrix]
  rw [schmidtStandardVector_marginalB]
  change
    ((stateEigenvectorIsometry rho).matrix *
          (ReferenceIsometry.ofEquiv (sortedStateIndexEquiv a)).matrix) *
        Matrix.diagonal
          (fun i => ((sortedStateEigenvalueProb rho i : ℝ≥0) : ℂ)) *
      Matrix.conjTranspose
        ((stateEigenvectorIsometry rho).matrix *
          (ReferenceIsometry.ofEquiv (sortedStateIndexEquiv a)).matrix) =
      rho.matrix
  rw [Matrix.conjTranspose_mul]
  simp only [Matrix.mul_assoc]
  rw [← Matrix.mul_assoc
    (Matrix.diagonal
      (fun i => ((sortedStateEigenvalueProb rho i : ℝ≥0) : ℂ)))
    (Matrix.conjTranspose
      (ReferenceIsometry.ofEquiv (sortedStateIndexEquiv a)).matrix)
    (Matrix.conjTranspose (stateEigenvectorIsometry rho).matrix)]
  rw [← Matrix.mul_assoc
    (ReferenceIsometry.ofEquiv (sortedStateIndexEquiv a)).matrix
    ((Matrix.diagonal
      (fun i => ((sortedStateEigenvalueProb rho i : ℝ≥0) : ℂ))) *
      Matrix.conjTranspose
        (ReferenceIsometry.ofEquiv (sortedStateIndexEquiv a)).matrix)
    (Matrix.conjTranspose (stateEigenvectorIsometry rho).matrix)]
  rw [← Matrix.mul_assoc
    (ReferenceIsometry.ofEquiv (sortedStateIndexEquiv a)).matrix
    (Matrix.diagonal
      (fun i => ((sortedStateEigenvalueProb rho i : ℝ≥0) : ℂ)))
    (Matrix.conjTranspose
      (ReferenceIsometry.ofEquiv (sortedStateIndexEquiv a)).matrix)]
  rw [sortedEigenvalue_diagonal_conjugation]
  simpa [stateEigenvectorIsometry, Matrix.star_eq_conjTranspose,
    Matrix.mul_assoc] using
    (ProjectiveMeasurement.state_matrix_eq_unitary_diagonalEigenvalueProb rho).symm

/-! ## Ordered Schmidt witnesses -/

/-- A Schmidt-isometry witness whose label is a concrete `Fin n` and whose
probabilities are nonincreasing in that order. -/
structure OrderedPureSchmidtIsometryWitness
    {a : Type u} {b : Type v}
    [Fintype a] [DecidableEq a] [Fintype b] [DecidableEq b]
    (psi : PureVector (a × b)) (n : ℕ) where
  probabilities : Fin n → ℝ≥0
  probabilities_sum : ∑ i, probabilities i = 1
  probabilities_antitone :
    Antitone (fun i => (probabilities i : ℝ))
  left : ReferenceIsometry (Fin n) a
  right : ReferenceIsometry (Fin n) b
  eq_localIsometries :
    psi = left.applyPureVector
      (right.applyPureVectorRight
        (schmidtStandardVector probabilities probabilities_sum))

namespace OrderedPureSchmidtIsometryWitness

variable {a : Type u} {b : Type v}
  [Fintype a] [DecidableEq a] [Fintype b] [DecidableEq b]
variable {psi : PureVector (a × b)} {n : ℕ}

/-- The real coercion of an ordered witness is exactly the ordered probability
interface used by the Appendix converse. -/
theorem isOrderedProbability
    (W : OrderedPureSchmidtIsometryWitness psi n) :
    IsOrderedProbability (fun i => (W.probabilities i : ℝ)) := by
  refine ⟨W.probabilities_antitone, ?_, ?_⟩
  · intro i
    exact NNReal.zero_le_coe
  · rw [← FiniteSchmidtData.sum_univ_eq_sum_ofFn]
    exact_mod_cast W.probabilities_sum

/-- The witness computes the actual pure-state entanglement entropy. -/
theorem entanglementEntropy_eq
    (W : OrderedPureSchmidtIsometryWitness psi n) :
    psi.entanglementEntropy =
      schmidtShannonEntropyBits W.probabilities := by
  calc
    psi.entanglementEntropy =
        (W.left.applyPureVector
          (W.right.applyPureVectorRight
            (schmidtStandardVector W.probabilities
              W.probabilities_sum))).entanglementEntropy :=
      congrArg PureVector.entanglementEntropy W.eq_localIsometries
    _ = schmidtShannonEntropyBits W.probabilities := by
      rw [entanglementEntropy_applyPureVector,
        entanglementEntropy_applyPureVectorRight,
        schmidtStandardVector_entanglementEntropy]

end OrderedPureSchmidtIsometryWitness

/-- If the right register is no larger, the spectral construction produces a
Schmidt witness directly in nonincreasing `Fin (card b)` order. -/
theorem exists_orderedPureSchmidtIsometryWitness_of_card_right_le_left
    {a : Type u} {b : Type v}
    [Fintype a] [DecidableEq a] [Fintype b] [DecidableEq b]
    (psi : PureVector (a × b))
    (hcard : Fintype.card b ≤ Fintype.card a) :
    Nonempty
      (OrderedPureSchmidtIsometryWitness psi (Fintype.card b)) := by
  let rho : State b := psi.state.marginalB
  let p : Fin (Fintype.card b) → ℝ≥0 := sortedStateEigenvalueProb rho
  let hp : ∑ i, p i = 1 := sortedStateEigenvalueProb_sum rho
  let U : ReferenceIsometry (Fin (Fintype.card b)) b :=
    sortedStateEigenvectorIsometry rho
  let standard : PureVector
      (Fin (Fintype.card b) × Fin (Fintype.card b)) :=
    schmidtStandardVector p hp
  let spectralPurification :
      PureVector (Fin (Fintype.card b) × b) :=
    U.applyPureVectorRight standard
  have hspectral : spectralPurification.Purifies rho := by
    simpa [spectralPurification, standard, U, p, hp, rho] using
      sortedStateEigenvectorIsometry_applyStandard_purifies rho
  have hpsi : psi.Purifies rho := by
    simp [rho]
  have hsourceCard :
      Fintype.card (Fin (Fintype.card b)) ≤ Fintype.card a := by
    simpa using hcard
  rcases
      PureVector.exists_referenceIsometry_applyPureVector_eq_of_purifies_same_state
        hspectral hpsi hsourceCard with
    ⟨V, hV⟩
  exact ⟨
    { probabilities := p
      probabilities_sum := hp
      probabilities_antitone := by
        simpa [p, rho] using sortedStateEigenvalueProb_antitone rho
      left := V
      right := U
      eq_localIsometries := by
        simpa [spectralPurification, standard] using hV }⟩

/-! ## Explicit symmetric positive Schmidt resource -/

/-- The basis-diagonal positive Schmidt amplitude for a real probability
vector.  Unlike the paper's later signed convention, this definition is
symmetric under exchanging the two local factors in every dimension. -/
def orderedPositiveSchmidtAmp {n : ℕ} (p : Fin n → ℝ) :
    Fin n × Fin n → ℂ :=
  fun ij => if ij.1 = ij.2 then (Real.sqrt (p ij.1) : ℂ) else 0

/-- Normalized positive Schmidt vector for an ordered probability. -/
def orderedPositiveSchmidtResource {n : ℕ}
    (p : Fin n → ℝ) (hp : IsOrderedProbability p) :
    PureVector (Fin n × Fin n) where
  amp := orderedPositiveSchmidtAmp p
  trace_rankOne_eq_one := by
    rw [Matrix.trace]
    simp only [Matrix.diag, rankOneMatrix_apply]
    rw [Fintype.sum_prod_type]
    have hsum : ∑ i, p i = 1 :=
      (FiniteSchmidtData.sum_univ_eq_sum_ofFn p).trans hp.2.2
    have hsumC : ((∑ i, p i : ℝ) : ℂ) = 1 := by
      exact_mod_cast hsum
    rw [← hsumC]
    push_cast
    apply Finset.sum_congr rfl
    intro i hi
    rw [Finset.sum_eq_single i]
    · simp [orderedPositiveSchmidtAmp]
      norm_cast
      simpa [pow_two] using Real.sq_sqrt (hp.2.1 i)
    · intro j hj hji
      have hij : i ≠ j := Ne.symm hji
      simp [orderedPositiveSchmidtAmp, hij]
    · exact fun h => False.elim (h (Finset.mem_univ i))

@[simp]
theorem orderedPositiveSchmidtAmp_swap {n : ℕ}
    (p : Fin n → ℝ) (i j : Fin n) :
    orderedPositiveSchmidtAmp p (j, i) =
      orderedPositiveSchmidtAmp p (i, j) := by
  by_cases hij : i = j
  · subst j
    rfl
  · simp [orderedPositiveSchmidtAmp, hij, Ne.symm hij]

/-- Both reduced density matrices of the explicit positive Schmidt vector are
the prescribed diagonal probability matrix. -/
theorem orderedPositiveSchmidtResource_marginalB_matrix
    {n : ℕ} (p : Fin n → ℝ) (hp : IsOrderedProbability p) :
    (orderedPositiveSchmidtResource p hp).state.marginalB.matrix =
      Matrix.diagonal (fun i => (p i : ℂ)) := by
  ext i j
  simp only [State.marginalB_matrix, QIT.partialTraceA,
    PureVector.state_matrix, rankOneMatrix_apply, Matrix.diagonal_apply]
  by_cases hij : i = j
  · subst j
    rw [Finset.sum_eq_single i]
    · simp [orderedPositiveSchmidtResource, orderedPositiveSchmidtAmp]
      norm_cast
      simpa [pow_two] using Real.sq_sqrt (hp.2.1 i)
    · intro k hk hki
      simp [orderedPositiveSchmidtResource, orderedPositiveSchmidtAmp,
        hki]
    · exact fun h => False.elim (h (Finset.mem_univ i))
  · rw [if_neg hij]
    apply Finset.sum_eq_zero
    intro k hk
    by_cases hki : k = i
    · subst k
      simp [orderedPositiveSchmidtResource, orderedPositiveSchmidtAmp, hij]
    · simp [orderedPositiveSchmidtResource, orderedPositiveSchmidtAmp, hki]

/-- Applying the ordered eigenvector isometry to the target half of the
explicit positive Schmidt vector purifies the original state. -/
theorem sortedStateEigenvectorIsometry_applyPositiveSchmidt_purifies
    {a : Type u} [Fintype a] [DecidableEq a]
    (rho : State a) :
    let p : Fin (Fintype.card a) → ℝ :=
      fun i => (sortedStateEigenvalueProb rho i : ℝ)
    let hp : IsOrderedProbability p :=
      sortedStateEigenvalueProb_isOrderedProbability rho
    ((sortedStateEigenvectorIsometry rho).applyPureVectorRight
      (orderedPositiveSchmidtResource p hp)).Purifies rho := by
  dsimp
  rw [PureVector.purifies_iff]
  rw [(sortedStateEigenvectorIsometry rho).rankOne_applyPureVectorRight]
  rw [(sortedStateEigenvectorIsometry rho).partialTraceA_applyMatrixRight]
  rw [← State.marginalB_matrix]
  rw [orderedPositiveSchmidtResource_marginalB_matrix]
  change
    ((stateEigenvectorIsometry rho).matrix *
          (ReferenceIsometry.ofEquiv (sortedStateIndexEquiv a)).matrix) *
        Matrix.diagonal
          (fun i => ((sortedStateEigenvalueProb rho i : ℝ) : ℂ)) *
      Matrix.conjTranspose
        ((stateEigenvectorIsometry rho).matrix *
          (ReferenceIsometry.ofEquiv (sortedStateIndexEquiv a)).matrix) =
      rho.matrix
  rw [Matrix.conjTranspose_mul]
  simp only [Matrix.mul_assoc]
  rw [← Matrix.mul_assoc
    (Matrix.diagonal
      (fun i => ((sortedStateEigenvalueProb rho i : ℝ) : ℂ)))
    (Matrix.conjTranspose
      (ReferenceIsometry.ofEquiv (sortedStateIndexEquiv a)).matrix)
    (Matrix.conjTranspose (stateEigenvectorIsometry rho).matrix)]
  rw [← Matrix.mul_assoc
    (ReferenceIsometry.ofEquiv (sortedStateIndexEquiv a)).matrix
    ((Matrix.diagonal
      (fun i => ((sortedStateEigenvalueProb rho i : ℝ) : ℂ))) *
      Matrix.conjTranspose
        (ReferenceIsometry.ofEquiv (sortedStateIndexEquiv a)).matrix)
    (Matrix.conjTranspose (stateEigenvectorIsometry rho).matrix)]
  rw [← Matrix.mul_assoc
    (ReferenceIsometry.ofEquiv (sortedStateIndexEquiv a)).matrix
    (Matrix.diagonal
      (fun i => ((sortedStateEigenvalueProb rho i : ℝ) : ℂ)))
    (Matrix.conjTranspose
      (ReferenceIsometry.ofEquiv (sortedStateIndexEquiv a)).matrix)]
  rw [sortedEigenvalue_diagonal_conjugation]
  simpa [stateEigenvectorIsometry, Matrix.star_eq_conjTranspose,
    Matrix.mul_assoc] using
    (ProjectiveMeasurement.state_matrix_eq_unitary_diagonalEigenvalueProb rho).symm

@[simp]
theorem orderedPositiveSchmidtResource_reindex_prodComm
    {n : ℕ} (p : Fin n → ℝ) (hp : IsOrderedProbability p) :
    (orderedPositiveSchmidtResource p hp).reindex
        (Equiv.prodComm (Fin n) (Fin n)) =
      orderedPositiveSchmidtResource p hp := by
  apply PureVector.ext_amp
  funext x
  rcases x with ⟨i, j⟩
  exact orderedPositiveSchmidtAmp_swap p i j

/-- Swapping the two output registers exchanges the two local isometry
actions. -/
theorem reindex_prodComm_applyPureVector_applyPureVectorRight
    {s : Type*} {a : Type u} {b : Type v}
    [Fintype s] [DecidableEq s]
    [Fintype a] [DecidableEq a] [Fintype b] [DecidableEq b]
    (VA : ReferenceIsometry s a) (VB : ReferenceIsometry s b)
    (phi : PureVector (s × s)) :
    (VA.applyPureVector (VB.applyPureVectorRight phi)).reindex
        (Equiv.prodComm a b) =
      VB.applyPureVector
        (VA.applyPureVectorRight
          (phi.reindex (Equiv.prodComm s s))) := by
  apply PureVector.ext_amp
  funext x
  rcases x with ⟨b₀, a₀⟩
  simp [ReferenceIsometry.applyPureVector_amp,
    ReferenceIsometry.applyPureVectorRight_amp,
    ReferenceIsometry.applyAmp, ReferenceIsometry.applyAmpRight,
    Matrix.mulVec, dotProduct]
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i hi
  apply Finset.sum_congr rfl
  intro j hj
  ring

/-- Ordered positive-coordinate Schmidt witness. -/
structure OrderedPositiveSchmidtIsometryWitness
    {a : Type u} {b : Type v}
    [Fintype a] [DecidableEq a] [Fintype b] [DecidableEq b]
    (psi : PureVector (a × b)) (n : ℕ) where
  probabilities : Fin n → ℝ
  isOrdered : IsOrderedProbability probabilities
  left : ReferenceIsometry (Fin n) a
  right : ReferenceIsometry (Fin n) b
  eq_localIsometries :
    psi = left.applyPureVector
      (right.applyPureVectorRight
        (orderedPositiveSchmidtResource probabilities isOrdered))

namespace OrderedPositiveSchmidtIsometryWitness

variable {a : Type u} {b : Type v}
  [Fintype a] [DecidableEq a] [Fintype b] [DecidableEq b]
variable {psi : PureVector (a × b)} {n : ℕ}

/-- Convert a witness for the factor-swapped vector into a witness for the
original vector. -/
def ofSwapped
    (W : OrderedPositiveSchmidtIsometryWitness
      (psi.reindex (Equiv.prodComm a b)) n) :
    OrderedPositiveSchmidtIsometryWitness psi n where
  probabilities := W.probabilities
  isOrdered := W.isOrdered
  left := W.right
  right := W.left
  eq_localIsometries := by
    calc
      psi = (psi.reindex (Equiv.prodComm a b)).reindex
          (Equiv.prodComm b a) := by
        apply PureVector.ext_amp
        funext x
        rcases x with ⟨i, j⟩
        rfl
      _ = (W.left.applyPureVector
          (W.right.applyPureVectorRight
            (orderedPositiveSchmidtResource W.probabilities
              W.isOrdered))).reindex (Equiv.prodComm b a) :=
        congrArg
          (fun phi : PureVector (b × a) =>
            phi.reindex (Equiv.prodComm b a)) W.eq_localIsometries
      _ = W.right.applyPureVector
          (W.left.applyPureVectorRight
            ((orderedPositiveSchmidtResource W.probabilities
              W.isOrdered).reindex
                (Equiv.prodComm (Fin n) (Fin n)))) :=
        reindex_prodComm_applyPureVector_applyPureVectorRight
          W.left W.right _
      _ = W.right.applyPureVector
          (W.left.applyPureVectorRight
            (orderedPositiveSchmidtResource W.probabilities
              W.isOrdered)) := by
        rw [orderedPositiveSchmidtResource_reindex_prodComm]

end OrderedPositiveSchmidtIsometryWitness

/-- Direct ordered positive-coordinate Schmidt witness when the right ambient
register is the smaller one. -/
theorem exists_orderedPositiveSchmidtIsometryWitness_of_card_right_le_left
    {a : Type u} {b : Type v}
    [Fintype a] [DecidableEq a] [Fintype b] [DecidableEq b]
    (psi : PureVector (a × b))
    (hcard : Fintype.card b ≤ Fintype.card a) :
    Nonempty
      (OrderedPositiveSchmidtIsometryWitness psi (Fintype.card b)) := by
  let rho : State b := psi.state.marginalB
  let p : Fin (Fintype.card b) → ℝ :=
    fun i => (sortedStateEigenvalueProb rho i : ℝ)
  let hp : IsOrderedProbability p :=
    sortedStateEigenvalueProb_isOrderedProbability rho
  let U : ReferenceIsometry (Fin (Fintype.card b)) b :=
    sortedStateEigenvectorIsometry rho
  let target : PureVector
      (Fin (Fintype.card b) × Fin (Fintype.card b)) :=
    orderedPositiveSchmidtResource p hp
  let spectralPurification :
      PureVector (Fin (Fintype.card b) × b) :=
    U.applyPureVectorRight target
  have hspectral : spectralPurification.Purifies rho := by
    simpa [spectralPurification, target, U, p, hp, rho] using
      sortedStateEigenvectorIsometry_applyPositiveSchmidt_purifies rho
  have hpsi : psi.Purifies rho := by
    simp [rho]
  have hsourceCard :
      Fintype.card (Fin (Fintype.card b)) ≤ Fintype.card a := by
    simpa using hcard
  rcases
      PureVector.exists_referenceIsometry_applyPureVector_eq_of_purifies_same_state
        hspectral hpsi hsourceCard with
    ⟨V, hV⟩
  exact ⟨
    { probabilities := p
      isOrdered := hp
      left := V
      right := U
      eq_localIsometries := by
        simpa [spectralPurification, target] using hV }⟩

/-- Every finite-dimensional bipartite pure vector has an ordered positive
Schmidt-coordinate local-isometry witness, with no orientation hypothesis. -/
theorem exists_orderedPositiveSchmidtIsometryWitness
    {a : Type u} {b : Type v}
    [Fintype a] [DecidableEq a] [Fintype b] [DecidableEq b]
    (psi : PureVector (a × b)) :
    ∃ n, Nonempty (OrderedPositiveSchmidtIsometryWitness psi n) := by
  by_cases hcard : Fintype.card b ≤ Fintype.card a
  · exact ⟨Fintype.card b,
      exists_orderedPositiveSchmidtIsometryWitness_of_card_right_le_left
        psi hcard⟩
  · have hcard' : Fintype.card a ≤ Fintype.card b :=
      Nat.le_of_lt (Nat.lt_of_not_ge hcard)
    rcases
        exists_orderedPositiveSchmidtIsometryWitness_of_card_right_le_left
          (psi.reindex (Equiv.prodComm a b)) hcard' with
      ⟨W⟩
    exact ⟨Fintype.card a, ⟨W.ofSwapped⟩⟩

end

end EntanglementPurification
