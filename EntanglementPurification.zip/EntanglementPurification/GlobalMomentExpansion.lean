import EntanglementPurification.GlobalHaarMoments
import EntanglementPurification.GlobalContractions
import EntanglementPurification.GlobalPerformanceAlgebra
import Mathlib.Tactic

/-!
# Reindexing the Haar moments into the global three-leg convention

Lean-QIT stores `TensorPower x n` as a right-associated product ending in
`PUnit`.  The global Choi calculation instead uses the concrete order
`((input₁, input₂), output)`.  This file gives the two explicit reindexings
and expands the second and third Haar moments in that convention.
-/

namespace EntanglementPurification

open QIT

noncomputable section

universe u

variable {x : Type u} [Fintype x] [DecidableEq x]

/-- Remove the terminal `PUnit` from Lean-QIT's two-fold tensor-power index. -/
def tensorPowerTwoEquiv : TensorPower x 2 ≃ x × x where
  toFun z :=
    (QIT.tensorPowerEquiv (a := x) 2 z 0,
      QIT.tensorPowerEquiv (a := x) 2 z 1)
  invFun z := QIT.twoCopyTensorWord (a := x) z.1 z.2
  left_inv z := QIT.twoCopyTensorWord_coords (a := x) z
  right_inv z := by
    rcases z with ⟨a, b⟩
    simp

/-- A three-copy QIT tensor word with the displayed ordered coordinates. -/
def tensorPowerThreeWord (a b c : x) : TensorPower x 3 :=
  (QIT.tensorPowerEquiv (a := x) 3).symm
    (fun r : Fin 3 => if r = 0 then a else if r = 1 then b else c)

/-- Remove the terminal `PUnit` and reassociate Lean-QIT's three-fold index
to the paper's `(input₁ × input₂) × output` order. -/
def tensorPowerThreeEquiv : TensorPower x 3 ≃ GlobalThreeLeg x where
  toFun z :=
    ((QIT.tensorPowerEquiv (a := x) 3 z 0,
        QIT.tensorPowerEquiv (a := x) 3 z 1),
      QIT.tensorPowerEquiv (a := x) 3 z 2)
  invFun z := tensorPowerThreeWord z.1.1 z.1.2 z.2
  left_inv z := by
    apply (QIT.tensorPowerEquiv (a := x) 3).injective
    ext i
    fin_cases i <;> simp [tensorPowerThreeWord]
  right_inv z := by
    rcases z with ⟨⟨a, b⟩, c⟩
    simp [tensorPowerThreeWord]

@[simp]
theorem tensorPowerTwoEquiv_symm_apply (a b : x) :
    tensorPowerTwoEquiv.symm (a, b) =
      QIT.twoCopyTensorWord (a := x) a b := by
  rfl

/-- Reindex a two-copy QIT matrix into the concrete input-pair convention. -/
def reindexTensorPowerTwo (M : CMatrix (TensorPower x 2)) : CMatrix (x × x) :=
  Matrix.reindex tensorPowerTwoEquiv tensorPowerTwoEquiv M

/-- Reindex a three-copy QIT matrix into the paper's three-leg convention. -/
def reindexTensorPowerThree
    (M : CMatrix (TensorPower x 3)) : CMatrix (GlobalThreeLeg x) :=
  Matrix.reindex tensorPowerThreeEquiv tensorPowerThreeEquiv M

/-- The QIT two-copy Reynolds projector becomes the concrete pair-space
symmetric projector after removing the terminal `PUnit`. -/
theorem reindex_symmetricProjectionMatrix_two_eq_globalInputPairPSym :
    reindexTensorPowerTwo
        (QIT.symmetricProjectionMatrix (a := x) 2) =
      globalInputPairPSym := by
  rw [QIT.symmetricProjectionMatrix_two_eq_half_one_add_swap]
  ext p q
  rcases p with ⟨a, b⟩
  rcases q with ⟨c, d⟩
  simp [reindexTensorPowerTwo, tensorPowerTwoEquiv_symm_apply,
    QIT.tensorPowerSwapMatrix_two, QIT.permutationMatrix,
    QIT.permEquiv_twoCopySwapPerm_twoCopyTensorWord,
    QIT.twoCopyTensorWord_eq_iff,
    globalInputPairPSym, globalInputPairSwap,
    Matrix.reindex_apply, Matrix.one_apply, PEquiv.toMatrix,
    eq_comm, mul_add]

/-- The normalized second Haar moment in the concrete two-input convention. -/
theorem reindex_pureHaarOrbitMoment_two
    [Nonempty x] (ν : PureVector x) :
    reindexTensorPowerTwo (pureHaarOrbitMoment 2 ν) =
      ((Nat.choose (Fintype.card x + 1) 2 : ℂ)⁻¹ : ℂ) •
        globalInputPairPSym := by
  rw [pureHaarOrbitMoment_two]
  change
    ((Nat.choose (Fintype.card x + 1) 2 : ℂ)⁻¹ : ℂ) •
        reindexTensorPowerTwo
          (QIT.symmetricProjectionMatrix (a := x) 2) = _
  rw [reindex_symmetricProjectionMatrix_two_eq_globalInputPairPSym]

/-- Conjugate a QIT tensor-factor permutation by the explicit three-leg
reindexing. -/
def globalThreeLegPerm (σ : Equiv.Perm (Fin 3)) : Equiv.Perm (GlobalThreeLeg x) :=
  tensorPowerThreeEquiv.symm.trans
    ((QIT.permEquiv (a := x) 3 σ).trans tensorPowerThreeEquiv)

/-- The reindexed matrix of a three-copy tensor-factor permutation. -/
def globalThreePermutationMatrix (σ : Equiv.Perm (Fin 3)) :
    CMatrix (GlobalThreeLeg x) :=
  reindexTensorPowerThree (QIT.permutationMatrix (a := x) 3 σ)

/-- Swap tensor coordinates zero and one. -/
def globalFinThreeSwap01 : Equiv.Perm (Fin 3) := Equiv.swap 0 1

/-- Swap tensor coordinates zero and two. -/
def globalFinThreeSwap02 : Equiv.Perm (Fin 3) := Equiv.swap 0 2

/-- Swap tensor coordinates one and two. -/
def globalFinThreeSwap12 : Equiv.Perm (Fin 3) := Equiv.swap 1 2

/-- One orientation of the three-cycle. -/
def globalFinThreeCycle012 : Equiv.Perm (Fin 3) :=
  globalFinThreeSwap01 * globalFinThreeSwap12

/-- The reverse three-cycle. -/
def globalFinThreeCycle021 : Equiv.Perm (Fin 3) :=
  globalFinThreeSwap12 * globalFinThreeSwap01

@[simp]
theorem globalThreeLegPerm_swap01_apply (a b c : x) :
    globalThreeLegPerm (x := x) globalFinThreeSwap01 ((a, b), c) =
      ((b, a), c) := by
  simp [globalThreeLegPerm, tensorPowerThreeEquiv, tensorPowerThreeWord,
    globalFinThreeSwap01, QIT.tensorPowerEquiv_permEquiv,
    Equiv.swap_apply_def]

@[simp]
theorem globalThreeLegPerm_swap02_apply (a b c : x) :
    globalThreeLegPerm (x := x) globalFinThreeSwap02 ((a, b), c) =
      ((c, b), a) := by
  simp [globalThreeLegPerm, tensorPowerThreeEquiv, tensorPowerThreeWord,
    globalFinThreeSwap02, QIT.tensorPowerEquiv_permEquiv,
    Equiv.swap_apply_def]

@[simp]
theorem globalThreeLegPerm_swap12_apply (a b c : x) :
    globalThreeLegPerm (x := x) globalFinThreeSwap12 ((a, b), c) =
      ((a, c), b) := by
  simp [globalThreeLegPerm, tensorPowerThreeEquiv, tensorPowerThreeWord,
    globalFinThreeSwap12, QIT.tensorPowerEquiv_permEquiv,
    Equiv.swap_apply_def]

@[simp]
theorem globalThreeLegPerm_cycle012_apply (a b c : x) :
    globalThreeLegPerm (x := x) globalFinThreeCycle012 ((a, b), c) =
      ((c, a), b) := by
  simp [globalThreeLegPerm, tensorPowerThreeEquiv, tensorPowerThreeWord,
    globalFinThreeCycle012, globalFinThreeSwap01, globalFinThreeSwap12,
    QIT.tensorPowerEquiv_permEquiv, Equiv.swap_apply_def]

@[simp]
theorem globalThreeLegPerm_cycle021_apply (a b c : x) :
    globalThreeLegPerm (x := x) globalFinThreeCycle021 ((a, b), c) =
      ((b, c), a) := by
  simp [globalThreeLegPerm, tensorPowerThreeEquiv, tensorPowerThreeWord,
    globalFinThreeCycle021, globalFinThreeSwap01, globalFinThreeSwap12,
    QIT.tensorPowerEquiv_permEquiv, Equiv.swap_apply_def]

/-- Diagonal contraction sum in the paper. -/
def globalMomentCdiag : CMatrix (GlobalThreeLeg x) :=
  globalGamma1 * Matrix.conjTranspose globalGamma1 +
    globalGamma2 * Matrix.conjTranspose globalGamma2

/-- Crossed contraction sum in the paper. -/
def globalMomentCcross : CMatrix (GlobalThreeLeg x) :=
  globalGamma1 * Matrix.conjTranspose globalGamma2 +
    globalGamma2 * Matrix.conjTranspose globalGamma1

/-- The diagonal contraction has the two range-projector eigenvalues from
the paper's four-sector table. -/
theorem globalMomentCdiag_eq_rangeProjectors
    (hcard : 2 ≤ Fintype.card x) :
    globalMomentCdiag (x := x) =
      ((Fintype.card x : ℝ) + 1) • globalPWPlus (x := x) +
        ((Fintype.card x : ℝ) - 1) • globalPWMinus (x := x) := by
  have hplus :
      ((Fintype.card x : ℝ) + 1) • globalPWPlus (x := x) =
        (1 / 2 : ℝ) •
          (globalGammaPlus (x := x) *
            Matrix.conjTranspose (globalGammaPlus (x := x))) := by
    rw [globalPWPlus_eq_scaledGammaPlus, smul_smul]
    congr 1
    have hne : (Fintype.card x : ℝ) + 1 ≠ 0 := by positivity
    field_simp [hne]
  have hminus :
      ((Fintype.card x : ℝ) - 1) • globalPWMinus (x := x) =
        (1 / 2 : ℝ) •
          (globalGammaMinus (x := x) *
            Matrix.conjTranspose (globalGammaMinus (x := x))) := by
    rw [globalPWMinus_eq_scaledGammaMinus hcard, smul_smul]
    congr 1
    have hcardReal : (1 : ℝ) < Fintype.card x := by exact_mod_cast hcard
    have hne : (Fintype.card x : ℝ) - 1 ≠ 0 := by positivity
    field_simp [hne]
  rw [hplus, hminus]
  simp only [globalMomentCdiag, globalGammaPlus, globalGammaMinus,
    Matrix.conjTranspose_add, Matrix.conjTranspose_sub, Matrix.add_mul,
    Matrix.sub_mul, Matrix.mul_add, Matrix.mul_sub]
  module

/-- The crossed contraction has opposite signs on the odd range projector. -/
theorem globalMomentCcross_eq_rangeProjectors
    (hcard : 2 ≤ Fintype.card x) :
    globalMomentCcross (x := x) =
      ((Fintype.card x : ℝ) + 1) • globalPWPlus (x := x) -
        ((Fintype.card x : ℝ) - 1) • globalPWMinus (x := x) := by
  have hplus :
      ((Fintype.card x : ℝ) + 1) • globalPWPlus (x := x) =
        (1 / 2 : ℝ) •
          (globalGammaPlus (x := x) *
            Matrix.conjTranspose (globalGammaPlus (x := x))) := by
    rw [globalPWPlus_eq_scaledGammaPlus, smul_smul]
    congr 1
    have hne : (Fintype.card x : ℝ) + 1 ≠ 0 := by positivity
    field_simp [hne]
  have hminus :
      ((Fintype.card x : ℝ) - 1) • globalPWMinus (x := x) =
        (1 / 2 : ℝ) •
          (globalGammaMinus (x := x) *
            Matrix.conjTranspose (globalGammaMinus (x := x))) := by
    rw [globalPWMinus_eq_scaledGammaMinus hcard, smul_smul]
    congr 1
    have hcardReal : (1 : ℝ) < Fintype.card x := by exact_mod_cast hcard
    have hne : (Fintype.card x : ℝ) - 1 ≠ 0 := by positivity
    field_simp [hne]
  rw [hplus, hminus]
  simp only [globalMomentCcross, globalGammaPlus, globalGammaMinus,
    Matrix.conjTranspose_add, Matrix.conjTranspose_sub, Matrix.add_mul,
    Matrix.sub_mul, Matrix.mul_add, Matrix.mul_sub]
  module

@[simp]
theorem globalThreePermutationMatrix_apply
    (σ : Equiv.Perm (Fin 3)) (p q : GlobalThreeLeg x) :
    globalThreePermutationMatrix (x := x) σ p q =
      if q = globalThreeLegPerm (x := x) σ p then 1 else 0 := by
  have hiff :
      QIT.permEquiv (a := x) 3 σ (tensorPowerThreeEquiv.symm p) =
          tensorPowerThreeEquiv.symm q ↔
        q = tensorPowerThreeEquiv
          (QIT.permEquiv (a := x) 3 σ (tensorPowerThreeEquiv.symm p)) := by
    constructor
    · intro h
      simpa using (congrArg tensorPowerThreeEquiv h).symm
    · intro h
      simpa using (congrArg tensorPowerThreeEquiv.symm h).symm
  simp [globalThreePermutationMatrix, reindexTensorPowerThree,
    globalThreeLegPerm, QIT.permutationMatrix, PEquiv.toMatrix,
    Matrix.reindex_apply, hiff]

/-- The identity tensor-factor permutation reindexes to the identity matrix. -/
theorem globalThreePermutationMatrix_one :
    globalThreePermutationMatrix (x := x) 1 = 1 := by
  ext p q
  rw [globalThreePermutationMatrix_apply]
  simp [globalThreeLegPerm, Matrix.one_apply, eq_comm]

/-- Swapping the first two tensor factors is the paper's input-copy swap. -/
theorem globalThreePermutationMatrix_swap01 :
    globalThreePermutationMatrix (x := x) globalFinThreeSwap01 =
      globalInputSwap := by
  ext p q
  rcases p with ⟨⟨a, b⟩, c⟩
  rcases q with ⟨⟨d, e⟩, f⟩
  rw [globalThreePermutationMatrix_apply,
    globalThreeLegPerm_swap01_apply]
  rfl

/-- Partial transpose over both input copies fixes the identity permutation. -/
theorem partialTransposeA_globalThreePermutationMatrix_one :
    QIT.partialTransposeA (a := x × x) (b := x)
        (globalThreePermutationMatrix (x := x) 1) =
      1 := by
  rw [globalThreePermutationMatrix_one]
  ext p q
  rcases p with ⟨⟨a, b⟩, c⟩
  rcases q with ⟨⟨d, e⟩, f⟩
  simp [QIT.partialTransposeA, Matrix.one_apply, eq_comm, and_comm]

/-- Partial transpose over both input copies fixes their swap. -/
theorem partialTransposeA_globalThreePermutationMatrix_swap01 :
    QIT.partialTransposeA (a := x × x) (b := x)
        (globalThreePermutationMatrix (x := x) globalFinThreeSwap01) =
      globalInputSwap := by
  rw [globalThreePermutationMatrix_swap01]
  ext p q
  rcases p with ⟨⟨a, b⟩, c⟩
  rcases q with ⟨⟨d, e⟩, f⟩
  simp [QIT.partialTransposeA, globalInputSwap, globalSwapIndex,
    eq_comm, and_comm]

/-- The first input/output transposition becomes `Gamma₁ Gamma₁†`. -/
theorem partialTransposeA_globalThreePermutationMatrix_swap02 :
    QIT.partialTransposeA (a := x × x) (b := x)
        (globalThreePermutationMatrix (x := x) globalFinThreeSwap02) =
      globalGamma1 * Matrix.conjTranspose globalGamma1 := by
  ext p q
  rcases p with ⟨⟨a, b⟩, c⟩
  rcases q with ⟨⟨d, e⟩, f⟩
  simp [QIT.partialTransposeA, globalThreePermutationMatrix_apply,
    globalThreeLegPerm_swap02_apply, Matrix.mul_apply, globalGamma1,
    eq_comm, and_assoc]
  split_ifs <;> simp_all

/-- The second input/output transposition becomes `Gamma₂ Gamma₂†`. -/
theorem partialTransposeA_globalThreePermutationMatrix_swap12 :
    QIT.partialTransposeA (a := x × x) (b := x)
        (globalThreePermutationMatrix (x := x) globalFinThreeSwap12) =
      globalGamma2 * Matrix.conjTranspose globalGamma2 := by
  ext p q
  rcases p with ⟨⟨a, b⟩, c⟩
  rcases q with ⟨⟨d, e⟩, f⟩
  simp [QIT.partialTransposeA, globalThreePermutationMatrix_apply,
    globalThreeLegPerm_swap12_apply, Matrix.mul_apply, globalGamma2,
    eq_comm, and_comm, and_assoc]
  split_ifs <;> simp_all

/-- One three-cycle becomes the first crossed contraction. -/
theorem partialTransposeA_globalThreePermutationMatrix_cycle012 :
    QIT.partialTransposeA (a := x × x) (b := x)
        (globalThreePermutationMatrix (x := x) globalFinThreeCycle012) =
      globalGamma1 * Matrix.conjTranspose globalGamma2 := by
  ext p q
  rcases p with ⟨⟨a, b⟩, c⟩
  rcases q with ⟨⟨d, e⟩, f⟩
  simp [QIT.partialTransposeA, globalThreePermutationMatrix_apply,
    globalThreeLegPerm_cycle012_apply, Matrix.mul_apply,
    globalGamma1, globalGamma2, eq_comm, and_assoc]
  split_ifs <;> simp_all

/-- The reverse three-cycle becomes the reverse crossed contraction. -/
theorem partialTransposeA_globalThreePermutationMatrix_cycle021 :
    QIT.partialTransposeA (a := x × x) (b := x)
        (globalThreePermutationMatrix (x := x) globalFinThreeCycle021) =
      globalGamma2 * Matrix.conjTranspose globalGamma1 := by
  ext p q
  rcases p with ⟨⟨a, b⟩, c⟩
  rcases q with ⟨⟨d, e⟩, f⟩
  simp [QIT.partialTransposeA, globalThreePermutationMatrix_apply,
    globalThreeLegPerm_cycle021_apply, Matrix.mul_apply,
    globalGamma1, globalGamma2, eq_comm, and_comm, and_assoc]
  split_ifs <;> simp_all

private theorem globalFinThreePerm_univ :
    (Finset.univ : Finset (Equiv.Perm (Fin 3))) =
      {1, globalFinThreeSwap01, globalFinThreeSwap02,
        globalFinThreeSwap12, globalFinThreeCycle012,
        globalFinThreeCycle021} := by
  decide

/-- The reindexed three-copy Reynolds projector is the average of the six
explicit tensor-factor permutation matrices. -/
theorem reindex_symmetricProjectionMatrix_three_eq_six_permutations :
    reindexTensorPowerThree
        (QIT.symmetricProjectionMatrix (a := x) 3) =
      (1 / 6 : ℂ) •
        (globalThreePermutationMatrix (x := x) 1 +
          globalThreePermutationMatrix (x := x) globalFinThreeSwap01 +
          globalThreePermutationMatrix (x := x) globalFinThreeSwap02 +
          globalThreePermutationMatrix (x := x) globalFinThreeSwap12 +
          globalThreePermutationMatrix (x := x) globalFinThreeCycle012 +
          globalThreePermutationMatrix (x := x) globalFinThreeCycle021) := by
  rw [QIT.symmetricProjectionMatrix_eq_perm_average]
  have hcard : Fintype.card (Equiv.Perm (Fin 3)) = 6 := by decide
  rw [hcard]
  have hreindexSum :
      reindexTensorPowerThree
          (∑ σ : Equiv.Perm (Fin 3),
            QIT.permutationMatrix (a := x) 3 σ) =
        ∑ σ : Equiv.Perm (Fin 3),
          globalThreePermutationMatrix (x := x) σ := by
    ext p q
    change
      (∑ σ : Equiv.Perm (Fin 3),
          QIT.permutationMatrix (a := x) 3 σ
            (tensorPowerThreeEquiv.symm p)
            (tensorPowerThreeEquiv.symm q)) = _
    rfl
  change
    (6 : ℂ)⁻¹ •
        reindexTensorPowerThree
          (∑ σ : Equiv.Perm (Fin 3),
            QIT.permutationMatrix (a := x) 3 σ) = _
  rw [hreindexSum]
  have hsum :
      (∑ σ : Equiv.Perm (Fin 3),
          globalThreePermutationMatrix (x := x) σ) =
        globalThreePermutationMatrix (x := x) 1 +
          globalThreePermutationMatrix (x := x) globalFinThreeSwap01 +
          globalThreePermutationMatrix (x := x) globalFinThreeSwap02 +
          globalThreePermutationMatrix (x := x) globalFinThreeSwap12 +
          globalThreePermutationMatrix (x := x) globalFinThreeCycle012 +
          globalThreePermutationMatrix (x := x) globalFinThreeCycle021 := by
    rw [globalFinThreePerm_univ]
    have h1 :
        (1 : Equiv.Perm (Fin 3)) ∉
          ({globalFinThreeSwap01, globalFinThreeSwap02,
            globalFinThreeSwap12, globalFinThreeCycle012,
            globalFinThreeCycle021} : Finset (Equiv.Perm (Fin 3))) := by
      decide
    have h2 :
        globalFinThreeSwap01 ∉
          ({globalFinThreeSwap02, globalFinThreeSwap12,
            globalFinThreeCycle012, globalFinThreeCycle021} :
            Finset (Equiv.Perm (Fin 3))) := by
      decide
    have h3 :
        globalFinThreeSwap02 ∉
          ({globalFinThreeSwap12, globalFinThreeCycle012,
            globalFinThreeCycle021} : Finset (Equiv.Perm (Fin 3))) := by
      decide
    have h4 :
        globalFinThreeSwap12 ∉
          ({globalFinThreeCycle012, globalFinThreeCycle021} :
            Finset (Equiv.Perm (Fin 3))) := by
      decide
    have h5 :
        globalFinThreeCycle012 ∉
          ({globalFinThreeCycle021} : Finset (Equiv.Perm (Fin 3))) := by
      decide
    rw [Finset.sum_insert h1, Finset.sum_insert h2,
      Finset.sum_insert h3, Finset.sum_insert h4,
      Finset.sum_insert h5, Finset.sum_singleton]
    module
  rw [hsum]
  norm_num

/-- Partial transpose on the two-input subsystem preserves matrix addition. -/
@[simp]
theorem partialTransposeA_add_globalThreeLeg
    (A B : CMatrix (GlobalThreeLeg x)) :
    QIT.partialTransposeA (a := x × x) (b := x) (A + B) =
      QIT.partialTransposeA A + QIT.partialTransposeA B := by
  rfl

/-- Partial transpose on the two-input subsystem preserves complex scaling. -/
@[simp]
theorem partialTransposeA_smul_globalThreeLeg
    (c : ℂ) (A : CMatrix (GlobalThreeLeg x)) :
    QIT.partialTransposeA (a := x × x) (b := x) (c • A) =
      c • QIT.partialTransposeA A := by
  rfl

/-- Reindexing the three-copy tensor convention preserves complex scaling. -/
@[simp]
theorem reindexTensorPowerThree_smul
    (c : ℂ) (A : CMatrix (TensorPower x 3)) :
    reindexTensorPowerThree (c • A) =
      c • reindexTensorPowerThree A := by
  rfl

/-- After reindexing and transposing the two input legs, the three-copy
Reynolds projector is the six-permutation average grouped into the four
operators used in the paper. -/
theorem partialTransposeA_reindex_symmetricProjectionMatrix_three :
    QIT.partialTransposeA (a := x × x) (b := x)
        (reindexTensorPowerThree
          (QIT.symmetricProjectionMatrix (a := x) 3)) =
      (1 / 6 : ℂ) •
        (1 + globalInputSwap + globalMomentCdiag + globalMomentCcross) := by
  rw [reindex_symmetricProjectionMatrix_three_eq_six_permutations]
  simp only [partialTransposeA_smul_globalThreeLeg,
    partialTransposeA_add_globalThreeLeg,
    partialTransposeA_globalThreePermutationMatrix_one,
    partialTransposeA_globalThreePermutationMatrix_swap01,
    partialTransposeA_globalThreePermutationMatrix_swap02,
    partialTransposeA_globalThreePermutationMatrix_swap12,
    partialTransposeA_globalThreePermutationMatrix_cycle012,
    partialTransposeA_globalThreePermutationMatrix_cycle021,
    globalMomentCdiag, globalMomentCcross]
  module

private theorem two_mul_choose_add_one_two (D : ℕ) :
    2 * Nat.choose (D + 1) 2 = D * (D + 1) := by
  have h :=
    Nat.descFactorial_eq_factorial_mul_choose (D + 1) 2
  norm_num [Nat.descFactorial_succ] at h
  nlinarith

private theorem six_mul_choose_add_two_three (D : ℕ) :
    6 * Nat.choose (D + 2) 3 = D * (D + 1) * (D + 2) := by
  have h :=
    Nat.descFactorial_eq_factorial_mul_choose (D + 2) 3
  norm_num [Nat.descFactorial_succ] at h
  nlinarith

private theorem inv_choose_two_mul_half
    (D : ℕ) :
    (Nat.choose (D + 1) 2 : ℂ)⁻¹ * (1 / 2 : ℂ) =
      ((D : ℂ) * ((D : ℂ) + 1))⁻¹ := by
  have hNat := two_mul_choose_add_one_two D
  have hComplex :
      (Nat.choose (D + 1) 2 : ℂ) * 2 =
        (D : ℂ) * ((D : ℂ) + 1) := by
    exact_mod_cast (by simpa [Nat.mul_comm] using hNat)
  rw [← hComplex, mul_inv]
  norm_num

private theorem inv_choose_three_mul_sixth
    (D : ℕ) :
    (Nat.choose (D + 2) 3 : ℂ)⁻¹ * (1 / 6 : ℂ) =
      ((D : ℂ) * ((D : ℂ) + 1) * ((D : ℂ) + 2))⁻¹ := by
  have hNat := six_mul_choose_add_two_three D
  have hComplex :
      (Nat.choose (D + 2) 3 : ℂ) * 6 =
        (D : ℂ) * ((D : ℂ) + 1) * ((D : ℂ) + 2) := by
    exact_mod_cast (by simpa [Nat.mul_comm] using hNat)
  rw [← hComplex, mul_inv]
  norm_num

/-- Paper-facing form of the normalized second Haar moment:
the identity-plus-swap numerator divided by `D(D+1)`. -/
theorem reindex_pureHaarOrbitMoment_two_eq_one_add_swap
    [Nonempty x] (ν : PureVector x) :
    reindexTensorPowerTwo (pureHaarOrbitMoment 2 ν) =
      (((Fintype.card x : ℂ) *
          ((Fintype.card x : ℂ) + 1))⁻¹ : ℂ) •
        (1 + globalInputPairSwap) := by
  rw [reindex_pureHaarOrbitMoment_two, globalInputPairPSym, smul_smul,
    inv_choose_two_mul_half]

/-- Paper-facing form of the normalized third Haar moment after partial
transpose on the two input copies: the four contraction terms divided by
`D(D+1)(D+2)`. -/
theorem partialTransposeA_reindex_pureHaarOrbitMoment_three
    [Nonempty x] (ν : PureVector x) :
    QIT.partialTransposeA (a := x × x) (b := x)
        (reindexTensorPowerThree (pureHaarOrbitMoment 3 ν)) =
      (((Fintype.card x : ℂ) *
          ((Fintype.card x : ℂ) + 1) *
          ((Fintype.card x : ℂ) + 2))⁻¹ : ℂ) •
        (1 + globalInputSwap + globalMomentCdiag + globalMomentCcross) := by
  rw [pureHaarOrbitMoment_three, reindexTensorPowerThree_smul,
    partialTransposeA_smul_globalThreeLeg,
    partialTransposeA_reindex_symmetricProjectionMatrix_three,
    smul_smul, inv_choose_three_mul_sixth]

end

end EntanglementPurification
