import EntanglementPurification.GlobalEq986Performance
import QIT.Util.CMatrixCLM
import Mathlib.Tactic

/-!
# Haar integration of the original equation-986 operator

This file proves the analytic bridge from the unexpanded noisy-channel
integral in equation 986 to the second- and third-moment performance operator
used by the global SDP proof.  Integrability is established explicitly before
linearity of the Bochner integral is used.
-/

namespace EntanglementPurification

open QIT
open MeasureTheory
open scoped ComplexOrder MatrixOrder Matrix.Norms.L2Operator

noncomputable section

universe u

variable {x : Type u} [Fintype x] [DecidableEq x] [Nonempty x]

local instance {ι : Type*} [Fintype ι] [DecidableEq ι] :
    ContinuousENorm (CMatrix ι) := SeminormedAddGroup.toContinuousENorm

private def tensorPowerOneEquiv : TensorPower x 1 ≃ x where
  toFun z := z.1
  invFun i := (i, PUnit.unit)
  left_inv z := by
    rcases z with ⟨i, u⟩
    cases u
    rfl
  right_inv i := rfl

private def reindexTensorPowerOne (M : CMatrix (TensorPower x 1)) : CMatrix x :=
  Matrix.reindex tensorPowerOneEquiv tensorPowerOneEquiv M

private def tensorPowerKroneckerOne (P : CMatrix x) :
    CMatrix (TensorPower x 1) :=
  fun p q => P p.1 q.1

private theorem reindex_tensorPowerKroneckerOne (P : CMatrix x) :
    reindexTensorPowerOne (tensorPowerKroneckerOne P) = P := by
  ext i j
  rfl

private theorem unitaryTensorPowerMatrix_one_eq
    (U : Matrix.unitaryGroup x ℂ) :
    (unitaryTensorPowerMatrix U 1 : CMatrix (TensorPower x 1)) =
      tensorPowerKroneckerOne (U : CMatrix x) := by
  ext p q
  rw [unitaryTensorPowerMatrix_apply_eq_fin_prod, Fin.prod_univ_one]
  rfl

private theorem rankOne_tensorPower_one_eq (nu : PureVector x) :
    rankOneMatrix (nu.tensorPower 1).amp =
      tensorPowerKroneckerOne (rankOneMatrix nu.amp) := by
  ext p q
  rw [rankOneMatrix_apply,
    PureVector.tensorPower_amp_eq_fin_prod nu 1 p,
    PureVector.tensorPower_amp_eq_fin_prod nu 1 q,
    Fin.prod_univ_one, Fin.prod_univ_one]
  rfl

private theorem star_tensorPowerKroneckerOne (P : CMatrix x) :
    star (tensorPowerKroneckerOne P) =
      tensorPowerKroneckerOne (star P) := by
  ext p q
  simp [tensorPowerKroneckerOne]

private theorem tensorPowerKroneckerOne_mul (P Q : CMatrix x) :
    tensorPowerKroneckerOne P * tensorPowerKroneckerOne Q =
      tensorPowerKroneckerOne (P * Q) := by
  ext p q
  change (∑ z : x × PUnit, P p.1 z.1 * Q z.1 q.1) =
    ∑ z : x, P p.1 z * Q z q.1
  rw [Fintype.sum_prod_type]
  simp

private theorem orbit_one_eq_reindex_renner
    (nu : PureVector x) (U : Matrix.unitaryGroup x ℂ) :
    globalHaarOrbitPureMatrix nu U =
      reindexTensorPowerOne
        (rennerMIIDProjectorZero (a := x) 1 nu U) := by
  rw [rennerMIIDProjectorZero_eq_unitary_rankOneTensorPower,
    unitaryTensorPowerMatrix_one_eq, rankOne_tensorPower_one_eq,
    star_tensorPowerKroneckerOne,
    tensorPowerKroneckerOne_mul, tensorPowerKroneckerOne_mul,
    reindex_tensorPowerKroneckerOne]
  rfl

private noncomputable def oneMomentCLM :
    CMatrix (TensorPower x 1) →L[ℝ] CMatrix x :=
  LinearMap.toContinuousLinearMap
    ({ toFun := reindexTensorPowerOne
       map_add' := by
         intro A B
         ext i j
         rfl
       map_smul' := by
         intro c A
         ext i j
         simp [reindexTensorPowerOne, Matrix.reindex_apply] } :
      CMatrix (TensorPower x 1) →ₗ[ℝ] CMatrix x)

private theorem renner_zero_integrable (n : ℕ) (nu : PureVector x) :
    Integrable (fun U : Matrix.unitaryGroup x ℂ =>
      rennerMIIDProjectorZero (a := x) n nu U)
      (unitaryHaarMeasure (a := x)) := by
  simpa only [rennerMIIDProjectorZero_eq_unitaryTwirlIntegrand] using
    unitaryTwirl_integrand_integrable (a := x) n
      (rankOneMatrix (nu.tensorPower n).amp)

private theorem symmetricProjectionMatrix_one_eq_one :
    symmetricProjectionMatrix (a := x) 1 = 1 := by
  rw [symmetricProjectionMatrix_eq_perm_average]
  ext p q
  simp [permutationMatrix, permEquiv_one, Matrix.one_apply]

private theorem reindex_symmetricProjectionMatrix_one_eq_one :
    reindexTensorPowerOne (symmetricProjectionMatrix (a := x) 1) = 1 := by
  rw [symmetricProjectionMatrix_one_eq_one]
  ext i j
  simp [reindexTensorPowerOne, Matrix.reindex_apply, Matrix.one_apply]

private theorem integral_orbit_one (nu : PureVector x) :
    (∫ U : Matrix.unitaryGroup x ℂ,
        globalHaarOrbitPureMatrix nu U
        ∂unitaryHaarMeasure (a := x)) =
      ((Fintype.card x : ℂ)⁻¹ : ℂ) • (1 : CMatrix x) := by
  calc
    _ = ∫ U : Matrix.unitaryGroup x ℂ,
        reindexTensorPowerOne
          (rennerMIIDProjectorZero (a := x) 1 nu U)
        ∂unitaryHaarMeasure (a := x) := by
      congr 1
      funext U
      exact orbit_one_eq_reindex_renner nu U
    _ = oneMomentCLM (x := x) (pureHaarOrbitMoment 1 nu) := by
      symm
      simpa [pureHaarOrbitMoment, oneMomentCLM] using
        ((oneMomentCLM (x := x)).integral_comp_comm
          (renner_zero_integrable 1 nu)).symm
    _ = _ := by
      rw [pureHaarOrbitMoment_one,
        show oneMomentCLM (x := x)
            (((Fintype.card x : ℂ)⁻¹ : ℂ) •
              symmetricProjectionMatrix (a := x) 1) =
            ((Fintype.card x : ℂ)⁻¹ : ℂ) •
              reindexTensorPowerOne
                (symmetricProjectionMatrix (a := x) 1) by
          ext i j
          simp [oneMomentCLM, reindexTensorPowerOne,
            Matrix.reindex_apply]]
      rw [reindex_symmetricProjectionMatrix_one_eq_one]

private theorem eq986_reindex_tensorPowerKroneckerTwo (P : CMatrix x) :
    reindexTensorPowerTwo (tensorPowerKroneckerTwo (a := x) P) =
      Matrix.kronecker P P := by
  ext p q
  rcases p with ⟨i, j⟩
  rcases q with ⟨k, l⟩
  simp [reindexTensorPowerTwo, Matrix.reindex_apply,
    tensorPowerTwoEquiv_symm_apply, Matrix.kronecker]

private theorem eq986_unitaryTensorPowerMatrix_two_eq
    (U : Matrix.unitaryGroup x ℂ) :
    (unitaryTensorPowerMatrix U 2 : CMatrix (TensorPower x 2)) =
      tensorPowerKroneckerTwo (a := x) (U : CMatrix x) := by
  ext p q
  simp [unitaryTensorPowerMatrix_apply_eq_fin_prod,
    tensorPowerKroneckerTwo]

private theorem eq986_rankOne_tensorPower_two_eq (nu : PureVector x) :
    rankOneMatrix (nu.tensorPower 2).amp =
      tensorPowerKroneckerTwo (a := x) (rankOneMatrix nu.amp) := by
  ext p q
  rw [rankOneMatrix_apply,
    PureVector.tensorPower_amp_eq_fin_prod nu 2 p,
    PureVector.tensorPower_amp_eq_fin_prod nu 2 q]
  simp [tensorPowerKroneckerTwo, rankOneMatrix_apply]
  ring

private theorem eq986_star_tensorPowerKroneckerTwo (P : CMatrix x) :
    star (tensorPowerKroneckerTwo (a := x) P) =
      tensorPowerKroneckerTwo (a := x) (star P) := by
  ext p q
  simp [tensorPowerKroneckerTwo]

private theorem eq986_orbit_pair_eq_reindex_renner
    (nu : PureVector x) (U : Matrix.unitaryGroup x ℂ) :
    Matrix.kronecker (globalHaarOrbitPureMatrix nu U)
        (globalHaarOrbitPureMatrix nu U) =
      reindexTensorPowerTwo
        (rennerMIIDProjectorZero (a := x) 2 nu U) := by
  rw [rennerMIIDProjectorZero_eq_unitary_rankOneTensorPower,
    eq986_unitaryTensorPowerMatrix_two_eq,
    eq986_rankOne_tensorPower_two_eq,
    eq986_star_tensorPowerKroneckerTwo,
    tensorPowerKroneckerTwo_mul, tensorPowerKroneckerTwo_mul,
    eq986_reindex_tensorPowerKroneckerTwo]
  rfl

private def scratchTensorPowerKroneckerThree (P : CMatrix x) :
    CMatrix (TensorPower x 3) :=
  fun p q =>
    P (tensorPowerEquiv 3 p 0) (tensorPowerEquiv 3 q 0) *
      P (tensorPowerEquiv 3 p 1) (tensorPowerEquiv 3 q 1) *
      P (tensorPowerEquiv 3 p 2) (tensorPowerEquiv 3 q 2)

private theorem eq986_reindex_tensorPowerKroneckerThree (P : CMatrix x) :
    (Matrix.reindexAlgEquiv ℂ ℂ tensorPowerThreeEquiv)
        (scratchTensorPowerKroneckerThree P) =
      Matrix.kronecker (Matrix.kronecker P P) P := by
  ext p q
  rcases p with ⟨⟨i, j⟩, k⟩
  rcases q with ⟨⟨l, m⟩, n⟩
  simp [Matrix.reindex_apply, tensorPowerThreeEquiv,
    tensorPowerThreeWord, scratchTensorPowerKroneckerThree,
    Matrix.kronecker]

private theorem eq986_unitaryTensorPowerMatrix_three_eq
    (U : Matrix.unitaryGroup x ℂ) :
    (unitaryTensorPowerMatrix U 3 : CMatrix (TensorPower x 3)) =
      scratchTensorPowerKroneckerThree (U : CMatrix x) := by
  ext p q
  rw [unitaryTensorPowerMatrix_apply_eq_fin_prod, Fin.prod_univ_three]
  rfl

private theorem eq986_rankOne_tensorPower_three_eq (nu : PureVector x) :
    rankOneMatrix (nu.tensorPower 3).amp =
      scratchTensorPowerKroneckerThree (rankOneMatrix nu.amp) := by
  ext p q
  rw [rankOneMatrix_apply,
    PureVector.tensorPower_amp_eq_fin_prod nu 3 p,
    PureVector.tensorPower_amp_eq_fin_prod nu 3 q]
  rw [Fin.prod_univ_three, Fin.prod_univ_three]
  rw [star_mul', star_mul']
  simp only [scratchTensorPowerKroneckerThree, rankOneMatrix_apply]
  ring

private theorem eq986_star_tensorPowerKroneckerThree (P : CMatrix x) :
    star (scratchTensorPowerKroneckerThree P) =
      scratchTensorPowerKroneckerThree (star P) := by
  ext p q
  simp [scratchTensorPowerKroneckerThree]

private theorem eq986_orbit_triple_eq_reindex_renner
    (nu : PureVector x) (U : Matrix.unitaryGroup x ℂ) :
    Matrix.kronecker
        (Matrix.kronecker (globalHaarOrbitPureMatrix nu U)
          (globalHaarOrbitPureMatrix nu U))
        (globalHaarOrbitPureMatrix nu U) =
      reindexTensorPowerThree
        (rennerMIIDProjectorZero (a := x) 3 nu U) := by
  rw [rennerMIIDProjectorZero_eq_unitary_rankOneTensorPower,
    eq986_unitaryTensorPowerMatrix_three_eq,
    eq986_rankOne_tensorPower_three_eq,
    eq986_star_tensorPowerKroneckerThree]
  change _ = (Matrix.reindexAlgEquiv ℂ ℂ tensorPowerThreeEquiv)
    (scratchTensorPowerKroneckerThree (U : CMatrix x) *
      scratchTensorPowerKroneckerThree (rankOneMatrix nu.amp) *
      scratchTensorPowerKroneckerThree (star (U : CMatrix x)))
  rw [map_mul, map_mul, eq986_reindex_tensorPowerKroneckerThree,
    eq986_reindex_tensorPowerKroneckerThree,
    eq986_reindex_tensorPowerKroneckerThree]
  have hmul1 :
      Matrix.kronecker (Matrix.kronecker (U : CMatrix x) (U : CMatrix x))
          (U : CMatrix x) *
        Matrix.kronecker
          (Matrix.kronecker (rankOneMatrix nu.amp) (rankOneMatrix nu.amp))
          (rankOneMatrix nu.amp) =
      Matrix.kronecker
          (Matrix.kronecker ((U : CMatrix x) * rankOneMatrix nu.amp)
            ((U : CMatrix x) * rankOneMatrix nu.amp))
          ((U : CMatrix x) * rankOneMatrix nu.amp) := by
    calc
      _ = Matrix.kronecker
          (Matrix.kronecker (U : CMatrix x) (U : CMatrix x) *
            Matrix.kronecker (rankOneMatrix nu.amp) (rankOneMatrix nu.amp))
          ((U : CMatrix x) * rankOneMatrix nu.amp) :=
        (Matrix.mul_kronecker_mul
          (Matrix.kronecker (U : CMatrix x) (U : CMatrix x))
          (Matrix.kronecker (rankOneMatrix nu.amp) (rankOneMatrix nu.amp))
          (U : CMatrix x) (rankOneMatrix nu.amp)).symm
      _ = _ := by
        congr 1
        exact (Matrix.mul_kronecker_mul
          (U : CMatrix x) (rankOneMatrix nu.amp)
          (U : CMatrix x) (rankOneMatrix nu.amp)).symm
  rw [hmul1]
  symm
  calc
    _ = Matrix.kronecker
        ((Matrix.kronecker
            ((U : CMatrix x) * rankOneMatrix nu.amp)
            ((U : CMatrix x) * rankOneMatrix nu.amp)) *
          Matrix.kronecker (star (U : CMatrix x)) (star (U : CMatrix x)))
        (((U : CMatrix x) * rankOneMatrix nu.amp) *
          star (U : CMatrix x)) :=
      (Matrix.mul_kronecker_mul
        (Matrix.kronecker
          ((U : CMatrix x) * rankOneMatrix nu.amp)
          ((U : CMatrix x) * rankOneMatrix nu.amp))
        (Matrix.kronecker (star (U : CMatrix x)) (star (U : CMatrix x)))
        ((U : CMatrix x) * rankOneMatrix nu.amp)
        (star (U : CMatrix x))).symm
    _ = _ := by
      congr 1
      exact (Matrix.mul_kronecker_mul
        ((U : CMatrix x) * rankOneMatrix nu.amp) (star (U : CMatrix x))
        ((U : CMatrix x) * rankOneMatrix nu.amp) (star (U : CMatrix x))).symm

private noncomputable def threeMomentCLM :
    CMatrix (TensorPower x 3) →L[ℂ] CMatrix (GlobalThreeLeg x) :=
  LinearMap.toContinuousLinearMap
    ({ toFun := fun M => QIT.partialTransposeA (a := x × x) (b := x)
          (reindexTensorPowerThree M)
       map_add' := by intro A B; rfl
       map_smul' := by intro c A; rfl } :
      CMatrix (TensorPower x 3) →ₗ[ℂ] CMatrix (GlobalThreeLeg x))

private noncomputable def pair12MomentCLM :
    CMatrix (TensorPower x 2) →L[ℂ] CMatrix (GlobalThreeLeg x) :=
  LinearMap.toContinuousLinearMap
    ({ toFun := fun M => QIT.partialTransposeA (a := x × x) (b := x)
          (globalEmbedPair12 (reindexTensorPowerTwo M))
       map_add' := by
         intro A B
         ext p q
         simp [QIT.partialTransposeA, globalEmbedPair12,
           reindexTensorPowerTwo, Matrix.reindex_apply]
         ring
       map_smul' := by
         intro c A
         ext p q
         simp [QIT.partialTransposeA, globalEmbedPair12,
           reindexTensorPowerTwo, Matrix.reindex_apply]
         ring } :
      CMatrix (TensorPower x 2) →ₗ[ℂ] CMatrix (GlobalThreeLeg x))

private noncomputable def pair13MomentCLM :
    CMatrix (TensorPower x 2) →L[ℂ] CMatrix (GlobalThreeLeg x) :=
  LinearMap.toContinuousLinearMap
    ({ toFun := fun M => QIT.partialTransposeA (a := x × x) (b := x)
          (globalEmbedPair13 (reindexTensorPowerTwo M))
       map_add' := by
         intro A B
         ext p q
         simp [QIT.partialTransposeA, globalEmbedPair13,
           reindexTensorPowerTwo, Matrix.reindex_apply]
         ring
       map_smul' := by
         intro c A
         ext p q
         simp [QIT.partialTransposeA, globalEmbedPair13,
           reindexTensorPowerTwo, Matrix.reindex_apply]
         ring } :
      CMatrix (TensorPower x 2) →ₗ[ℂ] CMatrix (GlobalThreeLeg x))

private noncomputable def pair23MomentCLM :
    CMatrix (TensorPower x 2) →L[ℂ] CMatrix (GlobalThreeLeg x) :=
  LinearMap.toContinuousLinearMap
    ({ toFun := fun M => QIT.partialTransposeA (a := x × x) (b := x)
          (globalEmbedPair23 (reindexTensorPowerTwo M))
       map_add' := by
         intro A B
         ext p q
         simp [QIT.partialTransposeA, globalEmbedPair23,
           reindexTensorPowerTwo, Matrix.reindex_apply]
         ring
       map_smul' := by
         intro c A
         ext p q
         simp [QIT.partialTransposeA, globalEmbedPair23,
           reindexTensorPowerTwo, Matrix.reindex_apply]
         ring } :
      CMatrix (TensorPower x 2) →ₗ[ℂ] CMatrix (GlobalThreeLeg x))

private theorem integral_threeMoment (nu : PureVector x) :
    (∫ U : Matrix.unitaryGroup x ℂ,
        threeMomentCLM
          (rennerMIIDProjectorZero (a := x) 3 nu U)
        ∂unitaryHaarMeasure (a := x)) =
      globalHaarMomentThreeTerm nu := by
  have h := (threeMomentCLM (x := x)).integral_comp_comm
    (renner_zero_integrable 3 nu)
  simpa [threeMomentCLM, pureHaarOrbitMoment,
    globalHaarMomentThreeTerm] using h

private theorem integral_pair12Moment (nu : PureVector x) :
    (∫ U : Matrix.unitaryGroup x ℂ,
        pair12MomentCLM
          (rennerMIIDProjectorZero (a := x) 2 nu U)
        ∂unitaryHaarMeasure (a := x)) =
      globalHaarMomentPair12Term nu := by
  have h := (pair12MomentCLM (x := x)).integral_comp_comm
    (renner_zero_integrable 2 nu)
  simpa [pair12MomentCLM, pureHaarOrbitMoment,
    globalHaarMomentPair12Term] using h

private theorem integral_pair13Moment (nu : PureVector x) :
    (∫ U : Matrix.unitaryGroup x ℂ,
        pair13MomentCLM
          (rennerMIIDProjectorZero (a := x) 2 nu U)
        ∂unitaryHaarMeasure (a := x)) =
      globalHaarMomentPair13Term nu := by
  have h := (pair13MomentCLM (x := x)).integral_comp_comm
    (renner_zero_integrable 2 nu)
  simpa [pair13MomentCLM, pureHaarOrbitMoment,
    globalHaarMomentPair13Term] using h

private theorem integral_pair23Moment (nu : PureVector x) :
    (∫ U : Matrix.unitaryGroup x ℂ,
        pair23MomentCLM
          (rennerMIIDProjectorZero (a := x) 2 nu U)
        ∂unitaryHaarMeasure (a := x)) =
      globalHaarMomentPair23Term nu := by
  have h := (pair23MomentCLM (x := x)).integral_comp_comm
    (renner_zero_integrable 2 nu)
  simpa [pair23MomentCLM, pureHaarOrbitMoment,
    globalHaarMomentPair23Term] using h

private theorem integral_orbit_triple (nu : PureVector x) :
    (∫ U : Matrix.unitaryGroup x ℂ,
        Matrix.kronecker
          (Matrix.kronecker (globalHaarOrbitPureMatrix nu U)
            (globalHaarOrbitPureMatrix nu U)).transpose
          (globalHaarOrbitPureMatrix nu U)
        ∂unitaryHaarMeasure (a := x)) =
      globalHaarMomentThreeTerm nu := by
  calc
    _ = ∫ U : Matrix.unitaryGroup x ℂ,
        threeMomentCLM
          (rennerMIIDProjectorZero (a := x) 3 nu U)
        ∂unitaryHaarMeasure (a := x) := by
      congr 1
      funext U
      change _ = QIT.partialTransposeA (a := x × x) (b := x)
        (reindexTensorPowerThree
          (rennerMIIDProjectorZero (a := x) 3 nu U))
      rw [← eq986_orbit_triple_eq_reindex_renner nu U]
      ext p q
      rfl
    _ = _ := integral_threeMoment nu

private theorem integral_orbit_pair12 (nu : PureVector x) :
    (∫ U : Matrix.unitaryGroup x ℂ,
        Matrix.kronecker
          (Matrix.kronecker (globalHaarOrbitPureMatrix nu U)
            (globalHaarOrbitPureMatrix nu U)).transpose
          (1 : CMatrix x)
        ∂unitaryHaarMeasure (a := x)) =
      globalHaarMomentPair12Term nu := by
  calc
    _ = ∫ U : Matrix.unitaryGroup x ℂ,
        pair12MomentCLM
          (rennerMIIDProjectorZero (a := x) 2 nu U)
        ∂unitaryHaarMeasure (a := x) := by
      congr 1
      funext U
      change _ = QIT.partialTransposeA (a := x × x) (b := x)
        (globalEmbedPair12
          (reindexTensorPowerTwo
            (rennerMIIDProjectorZero (a := x) 2 nu U)))
      rw [← eq986_orbit_pair_eq_reindex_renner nu U]
      ext p q
      rfl
    _ = _ := integral_pair12Moment nu

private theorem integral_orbit_pair13 (nu : PureVector x) :
    (∫ U : Matrix.unitaryGroup x ℂ,
        Matrix.kronecker
          (Matrix.kronecker (globalHaarOrbitPureMatrix nu U)
            (1 : CMatrix x)).transpose
          (globalHaarOrbitPureMatrix nu U)
        ∂unitaryHaarMeasure (a := x)) =
      globalHaarMomentPair13Term nu := by
  calc
    _ = ∫ U : Matrix.unitaryGroup x ℂ,
        pair13MomentCLM
          (rennerMIIDProjectorZero (a := x) 2 nu U)
        ∂unitaryHaarMeasure (a := x) := by
      congr 1
      funext U
      change _ = QIT.partialTransposeA (a := x × x) (b := x)
        (globalEmbedPair13
          (reindexTensorPowerTwo
            (rennerMIIDProjectorZero (a := x) 2 nu U)))
      rw [← eq986_orbit_pair_eq_reindex_renner nu U]
      ext p q
      rcases p with ⟨⟨i, j⟩, k⟩
      rcases q with ⟨⟨l, m⟩, n⟩
      simp [QIT.partialTransposeA,
        globalEmbedPair13, Matrix.kronecker, Matrix.one_apply]
    _ = _ := integral_pair13Moment nu

private theorem integral_orbit_pair23 (nu : PureVector x) :
    (∫ U : Matrix.unitaryGroup x ℂ,
        Matrix.kronecker
          (Matrix.kronecker (1 : CMatrix x)
            (globalHaarOrbitPureMatrix nu U)).transpose
          (globalHaarOrbitPureMatrix nu U)
        ∂unitaryHaarMeasure (a := x)) =
      globalHaarMomentPair23Term nu := by
  calc
    _ = ∫ U : Matrix.unitaryGroup x ℂ,
        pair23MomentCLM
          (rennerMIIDProjectorZero (a := x) 2 nu U)
        ∂unitaryHaarMeasure (a := x) := by
      congr 1
      funext U
      change _ = QIT.partialTransposeA (a := x × x) (b := x)
        (globalEmbedPair23
          (reindexTensorPowerTwo
            (rennerMIIDProjectorZero (a := x) 2 nu U)))
      rw [← eq986_orbit_pair_eq_reindex_renner nu U]
      ext p q
      rcases p with ⟨⟨i, j⟩, k⟩
      rcases q with ⟨⟨l, m⟩, n⟩
      simp [QIT.partialTransposeA,
        globalEmbedPair23, Matrix.kronecker, Matrix.one_apply]
    _ = _ := integral_pair23Moment nu

private theorem orbit_one_integrable (nu : PureVector x) :
    Integrable (globalHaarOrbitPureMatrix nu)
      (unitaryHaarMeasure (a := x)) := by
  exact (show Continuous (globalHaarOrbitPureMatrix nu) by
      unfold globalHaarOrbitPureMatrix
      fun_prop).integrable_of_hasCompactSupport
        (HasCompactSupport.of_compactSpace _)

private noncomputable def single1CLM :
    CMatrix x →L[ℂ] CMatrix (GlobalThreeLeg x) :=
  LinearMap.toContinuousLinearMap
    ({ toFun := fun A => Matrix.kronecker
          (Matrix.kronecker A (1 : CMatrix x)).transpose
          (1 : CMatrix x)
       map_add' := by
         intro A B
         ext p q
         simp [Matrix.kronecker]
         ring
       map_smul' := by
         intro c A
         ext p q
         simp [Matrix.kronecker]
         ring } : CMatrix x →ₗ[ℂ] CMatrix (GlobalThreeLeg x))

private noncomputable def single2CLM :
    CMatrix x →L[ℂ] CMatrix (GlobalThreeLeg x) :=
  LinearMap.toContinuousLinearMap
    ({ toFun := fun A => Matrix.kronecker
          (Matrix.kronecker (1 : CMatrix x) A).transpose
          (1 : CMatrix x)
       map_add' := by
         intro A B
         ext p q
         simp [Matrix.kronecker]
         ring
       map_smul' := by
         intro c A
         ext p q
         simp [Matrix.kronecker]
         ring } : CMatrix x →ₗ[ℂ] CMatrix (GlobalThreeLeg x))

private noncomputable def single3CLM :
    CMatrix x →L[ℂ] CMatrix (GlobalThreeLeg x) :=
  LinearMap.toContinuousLinearMap
    ({ toFun := fun A => Matrix.kronecker
          (Matrix.kronecker (1 : CMatrix x) (1 : CMatrix x)).transpose A
       map_add' := by
         intro A B
         ext p q
         simp [Matrix.kronecker]
         ring
       map_smul' := by
         intro c A
         ext p q
         simp [Matrix.kronecker]
         ring } : CMatrix x →ₗ[ℂ] CMatrix (GlobalThreeLeg x))

private theorem single1CLM_one :
    single1CLM (x := x) (1 : CMatrix x) = 1 := by
  ext p q
  rcases p with ⟨⟨i, j⟩, k⟩
  rcases q with ⟨⟨l, m⟩, n⟩
  simp [single1CLM, Matrix.kronecker, Matrix.one_apply,
    Prod.ext_iff, and_assoc]
  split_ifs <;> simp_all

private theorem single2CLM_one :
    single2CLM (x := x) (1 : CMatrix x) = 1 := by
  ext p q
  rcases p with ⟨⟨i, j⟩, k⟩
  rcases q with ⟨⟨l, m⟩, n⟩
  simp [single2CLM, Matrix.kronecker, Matrix.one_apply,
    Prod.ext_iff, and_assoc]
  split_ifs <;> simp_all

private theorem single3CLM_one :
    single3CLM (x := x) (1 : CMatrix x) = 1 := by
  ext p q
  rcases p with ⟨⟨i, j⟩, k⟩
  rcases q with ⟨⟨l, m⟩, n⟩
  simp [single3CLM, Matrix.kronecker, Matrix.one_apply,
    Prod.ext_iff, and_assoc]
  split_ifs <;> simp_all

private theorem integral_orbit_single1 (nu : PureVector x) :
    (∫ U : Matrix.unitaryGroup x ℂ,
        single1CLM (globalHaarOrbitPureMatrix nu U)
        ∂unitaryHaarMeasure (a := x)) =
      ((Fintype.card x : ℂ)⁻¹ : ℂ) •
        (1 : CMatrix (GlobalThreeLeg x)) := by
  calc
    _ = single1CLM (x := x)
        (∫ U : Matrix.unitaryGroup x ℂ, globalHaarOrbitPureMatrix nu U
          ∂unitaryHaarMeasure (a := x)) := by
      simpa using
        (single1CLM (x := x)).integral_comp_comm (orbit_one_integrable nu)
    _ = _ := by
      rw [integral_orbit_one nu, map_smul, single1CLM_one]

private theorem integral_orbit_single2 (nu : PureVector x) :
    (∫ U : Matrix.unitaryGroup x ℂ,
        single2CLM (globalHaarOrbitPureMatrix nu U)
        ∂unitaryHaarMeasure (a := x)) =
      ((Fintype.card x : ℂ)⁻¹ : ℂ) •
        (1 : CMatrix (GlobalThreeLeg x)) := by
  calc
    _ = single2CLM (x := x)
        (∫ U : Matrix.unitaryGroup x ℂ, globalHaarOrbitPureMatrix nu U
          ∂unitaryHaarMeasure (a := x)) := by
      simpa using
        (single2CLM (x := x)).integral_comp_comm (orbit_one_integrable nu)
    _ = _ := by
      rw [integral_orbit_one nu, map_smul, single2CLM_one]

private theorem integral_orbit_single3 (nu : PureVector x) :
    (∫ U : Matrix.unitaryGroup x ℂ,
        single3CLM (globalHaarOrbitPureMatrix nu U)
        ∂unitaryHaarMeasure (a := x)) =
      ((Fintype.card x : ℂ)⁻¹ : ℂ) •
        (1 : CMatrix (GlobalThreeLeg x)) := by
  calc
    _ = single3CLM (x := x)
        (∫ U : Matrix.unitaryGroup x ℂ, globalHaarOrbitPureMatrix nu U
          ∂unitaryHaarMeasure (a := x)) := by
      simpa using
        (single3CLM (x := x)).integral_comp_comm (orbit_one_integrable nu)
    _ = _ := by
      rw [integral_orbit_one nu, map_smul, single3CLM_one]

private def eq986Three (nu : PureVector x) (U : Matrix.unitaryGroup x ℂ) :
    CMatrix (GlobalThreeLeg x) :=
  Matrix.kronecker
    (Matrix.kronecker (globalHaarOrbitPureMatrix nu U)
      (globalHaarOrbitPureMatrix nu U)).transpose
    (globalHaarOrbitPureMatrix nu U)

private def eq986Pair12 (nu : PureVector x) (U : Matrix.unitaryGroup x ℂ) :
    CMatrix (GlobalThreeLeg x) :=
  Matrix.kronecker
    (Matrix.kronecker (globalHaarOrbitPureMatrix nu U)
      (globalHaarOrbitPureMatrix nu U)).transpose (1 : CMatrix x)

private def eq986Pair13 (nu : PureVector x) (U : Matrix.unitaryGroup x ℂ) :
    CMatrix (GlobalThreeLeg x) :=
  Matrix.kronecker
    (Matrix.kronecker (globalHaarOrbitPureMatrix nu U)
      (1 : CMatrix x)).transpose (globalHaarOrbitPureMatrix nu U)

private def eq986Pair23 (nu : PureVector x) (U : Matrix.unitaryGroup x ℂ) :
    CMatrix (GlobalThreeLeg x) :=
  Matrix.kronecker
    (Matrix.kronecker (1 : CMatrix x)
      (globalHaarOrbitPureMatrix nu U)).transpose
    (globalHaarOrbitPureMatrix nu U)

private def eq986Single1 (nu : PureVector x) (U : Matrix.unitaryGroup x ℂ) :
    CMatrix (GlobalThreeLeg x) :=
  Matrix.kronecker
    (Matrix.kronecker (globalHaarOrbitPureMatrix nu U)
      (1 : CMatrix x)).transpose (1 : CMatrix x)

private def eq986Single2 (nu : PureVector x) (U : Matrix.unitaryGroup x ℂ) :
    CMatrix (GlobalThreeLeg x) :=
  Matrix.kronecker
    (Matrix.kronecker (1 : CMatrix x)
      (globalHaarOrbitPureMatrix nu U)).transpose (1 : CMatrix x)

private def eq986Single3 (nu : PureVector x) (U : Matrix.unitaryGroup x ℂ) :
    CMatrix (GlobalThreeLeg x) :=
  Matrix.kronecker
    (Matrix.kronecker (1 : CMatrix x) (1 : CMatrix x)).transpose
    (globalHaarOrbitPureMatrix nu U)

private theorem globalEq986Integrand_eq_expanded
    (nu : PureVector x) (gamma : ℝ) (U : Matrix.unitaryGroup x ℂ) :
    globalEq986Integrand nu gamma U =
      (1 - gamma) ^ 2 •
        (eq986Three nu U -
          globalNoiseFidelity (Fintype.card x : ℝ) gamma • eq986Pair12 nu U) +
      (gamma * (1 - gamma) / (Fintype.card x : ℝ)) •
        ((eq986Pair13 nu U + eq986Pair23 nu U) -
          globalNoiseFidelity (Fintype.card x : ℝ) gamma •
            (eq986Single1 nu U + eq986Single2 nu U)) +
      (gamma / (Fintype.card x : ℝ)) ^ 2 •
        (eq986Single3 nu U -
          globalNoiseFidelity (Fintype.card x : ℝ) gamma •
            (1 : CMatrix (GlobalThreeLeg x))) := by
  ext p q
  rcases p with ⟨⟨i, j⟩, k⟩
  rcases q with ⟨⟨l, m⟩, n⟩
  simp [globalEq986Integrand, globalDepolarizedOrbitMatrix,
    eq986Three, eq986Pair12, eq986Pair13, eq986Pair23,
    eq986Single1, eq986Single2, eq986Single3,
    Matrix.kronecker, Matrix.kroneckerMap_apply,
    Matrix.transpose_apply, Matrix.add_apply,
    Matrix.sub_apply, Matrix.smul_apply, Complex.real_smul]
  by_cases hli : i = l <;> by_cases hmj : j = m <;>
    by_cases hkn : k = n
  all_goals
    have hli' : (l = i) ↔ (i = l) := eq_comm
    have hmj' : (m = j) ↔ (j = m) := eq_comm
    simp_all [Matrix.one_apply, Prod.ext_iff] ; ring

private theorem eq986Three_eq_clm (nu : PureVector x)
    (U : Matrix.unitaryGroup x ℂ) :
    eq986Three nu U =
      threeMomentCLM (rennerMIIDProjectorZero (a := x) 3 nu U) := by
  unfold eq986Three
  change _ = QIT.partialTransposeA (a := x × x) (b := x)
    (reindexTensorPowerThree (rennerMIIDProjectorZero (a := x) 3 nu U))
  rw [← eq986_orbit_triple_eq_reindex_renner nu U]
  ext p q
  rfl

private theorem eq986Pair12_eq_clm (nu : PureVector x)
    (U : Matrix.unitaryGroup x ℂ) :
    eq986Pair12 nu U =
      pair12MomentCLM (rennerMIIDProjectorZero (a := x) 2 nu U) := by
  unfold eq986Pair12
  change _ = QIT.partialTransposeA (a := x × x) (b := x)
    (globalEmbedPair12
      (reindexTensorPowerTwo (rennerMIIDProjectorZero (a := x) 2 nu U)))
  rw [← eq986_orbit_pair_eq_reindex_renner nu U]
  ext p q
  rfl

private theorem eq986Pair13_eq_clm (nu : PureVector x)
    (U : Matrix.unitaryGroup x ℂ) :
    eq986Pair13 nu U =
      pair13MomentCLM (rennerMIIDProjectorZero (a := x) 2 nu U) := by
  unfold eq986Pair13
  change _ = QIT.partialTransposeA (a := x × x) (b := x)
    (globalEmbedPair13
      (reindexTensorPowerTwo (rennerMIIDProjectorZero (a := x) 2 nu U)))
  rw [← eq986_orbit_pair_eq_reindex_renner nu U]
  ext p q
  rcases p with ⟨⟨i, j⟩, k⟩
  rcases q with ⟨⟨l, m⟩, n⟩
  simp [QIT.partialTransposeA, globalEmbedPair13,
    Matrix.kronecker, Matrix.one_apply]

private theorem eq986Pair23_eq_clm (nu : PureVector x)
    (U : Matrix.unitaryGroup x ℂ) :
    eq986Pair23 nu U =
      pair23MomentCLM (rennerMIIDProjectorZero (a := x) 2 nu U) := by
  unfold eq986Pair23
  change _ = QIT.partialTransposeA (a := x × x) (b := x)
    (globalEmbedPair23
      (reindexTensorPowerTwo (rennerMIIDProjectorZero (a := x) 2 nu U)))
  rw [← eq986_orbit_pair_eq_reindex_renner nu U]
  ext p q
  rcases p with ⟨⟨i, j⟩, k⟩
  rcases q with ⟨⟨l, m⟩, n⟩
  simp [QIT.partialTransposeA, globalEmbedPair23,
    Matrix.kronecker, Matrix.one_apply]

private theorem eq986Three_integrable (nu : PureVector x) :
    Integrable (eq986Three nu) (unitaryHaarMeasure (a := x)) := by
  exact ((threeMomentCLM (x := x)).integrable_comp
    (renner_zero_integrable 3 nu)).congr
      (ae_of_all _ fun U => (eq986Three_eq_clm nu U).symm)

private theorem eq986Pair12_integrable (nu : PureVector x) :
    Integrable (eq986Pair12 nu) (unitaryHaarMeasure (a := x)) := by
  exact ((pair12MomentCLM (x := x)).integrable_comp
    (renner_zero_integrable 2 nu)).congr
      (ae_of_all _ fun U => (eq986Pair12_eq_clm nu U).symm)

private theorem eq986Pair13_integrable (nu : PureVector x) :
    Integrable (eq986Pair13 nu) (unitaryHaarMeasure (a := x)) := by
  exact ((pair13MomentCLM (x := x)).integrable_comp
    (renner_zero_integrable 2 nu)).congr
      (ae_of_all _ fun U => (eq986Pair13_eq_clm nu U).symm)

private theorem eq986Pair23_integrable (nu : PureVector x) :
    Integrable (eq986Pair23 nu) (unitaryHaarMeasure (a := x)) := by
  exact ((pair23MomentCLM (x := x)).integrable_comp
    (renner_zero_integrable 2 nu)).congr
      (ae_of_all _ fun U => (eq986Pair23_eq_clm nu U).symm)

private theorem eq986Single1_integrable (nu : PureVector x) :
    Integrable (eq986Single1 nu) (unitaryHaarMeasure (a := x)) := by
  exact ((single1CLM (x := x)).integrable_comp
    (orbit_one_integrable nu)).congr (ae_of_all _ fun U => by rfl)

private theorem eq986Single2_integrable (nu : PureVector x) :
    Integrable (eq986Single2 nu) (unitaryHaarMeasure (a := x)) := by
  exact ((single2CLM (x := x)).integrable_comp
    (orbit_one_integrable nu)).congr (ae_of_all _ fun U => by rfl)

private theorem eq986Single3_integrable (nu : PureVector x) :
    Integrable (eq986Single3 nu) (unitaryHaarMeasure (a := x)) := by
  exact ((single3CLM (x := x)).integrable_comp
    (orbit_one_integrable nu)).congr (ae_of_all _ fun U => by
      ext p q
      rfl)

private theorem eq986GroupA_integrable (nu : PureVector x) (gamma : ℝ) :
    Integrable (fun U : Matrix.unitaryGroup x ℂ =>
      (1 - gamma) ^ 2 •
        (eq986Three nu U -
          globalNoiseFidelity (Fintype.card x : ℝ) gamma •
            eq986Pair12 nu U))
      (unitaryHaarMeasure (a := x)) := by
  let F := globalNoiseFidelity (Fintype.card x : ℝ) gamma
  have hCore := (eq986Three_integrable nu).sub
    ((eq986Pair12_integrable nu).smul F)
  have hScaled := hCore.smul ((1 - gamma) ^ 2)
  simpa only [F, Pi.sub_apply, Pi.smul_apply] using hScaled

private theorem eq986GroupB_integrable (nu : PureVector x) (gamma : ℝ) :
    Integrable (fun U : Matrix.unitaryGroup x ℂ =>
      (gamma * (1 - gamma) / (Fintype.card x : ℝ)) •
        ((eq986Pair13 nu U + eq986Pair23 nu U) -
          globalNoiseFidelity (Fintype.card x : ℝ) gamma •
            (eq986Single1 nu U + eq986Single2 nu U)))
      (unitaryHaarMeasure (a := x)) := by
  let F := globalNoiseFidelity (Fintype.card x : ℝ) gamma
  have hPairs := (eq986Pair13_integrable nu).sub'
    (eq986Pair23_integrable nu).neg
  have hSingles := (eq986Single1_integrable nu).sub'
    (eq986Single2_integrable nu).neg
  have hCore := hPairs.sub (hSingles.smul F)
  have hScaled := hCore.smul
    (gamma * (1 - gamma) / (Fintype.card x : ℝ))
  simpa only [F, Pi.neg_apply, Pi.sub_apply, Pi.smul_apply,
    sub_neg_eq_add] using hScaled

private theorem eq986GroupC_integrable (nu : PureVector x) (gamma : ℝ) :
    Integrable (fun U : Matrix.unitaryGroup x ℂ =>
      (gamma / (Fintype.card x : ℝ)) ^ 2 •
        (eq986Single3 nu U -
          globalNoiseFidelity (Fintype.card x : ℝ) gamma •
            (1 : CMatrix (GlobalThreeLeg x))))
      (unitaryHaarMeasure (a := x)) := by
  let F := globalNoiseFidelity (Fintype.card x : ℝ) gamma
  have hI : Integrable (fun _ : Matrix.unitaryGroup x ℂ =>
      (1 : CMatrix (GlobalThreeLeg x)))
      (unitaryHaarMeasure (a := x)) := integrable_const _
  have hCore := (eq986Single3_integrable nu).sub (hI.smul F)
  have hScaled := hCore.smul
    ((gamma / (Fintype.card x : ℝ)) ^ 2)
  simpa only [F, Pi.sub_apply, Pi.smul_apply] using hScaled

private theorem integral_eq986_groupA (nu : PureVector x) (gamma : ℝ) :
    (∫ U : Matrix.unitaryGroup x ℂ,
        (1 - gamma) ^ 2 •
          (eq986Three nu U -
            globalNoiseFidelity (Fintype.card x : ℝ) gamma •
              eq986Pair12 nu U)
        ∂unitaryHaarMeasure (a := x)) =
      (1 - gamma) ^ 2 •
        (globalHaarMomentThreeTerm nu -
          globalNoiseFidelity (Fintype.card x : ℝ) gamma •
            globalHaarMomentPair12Term nu) := by
  have hT3 := eq986Three_integrable nu
  have hT12 := eq986Pair12_integrable nu
  rw [integral_smul]
  rw [show (∫ U : Matrix.unitaryGroup x ℂ,
      eq986Three nu U -
        globalNoiseFidelity (Fintype.card x : ℝ) gamma • eq986Pair12 nu U
      ∂unitaryHaarMeasure (a := x)) =
      (∫ U, eq986Three nu U ∂unitaryHaarMeasure (a := x)) -
        ∫ U, globalNoiseFidelity (Fintype.card x : ℝ) gamma •
          eq986Pair12 nu U ∂unitaryHaarMeasure (a := x) by
    simpa only [Pi.smul_apply] using integral_sub hT3
      (hT12.smul (globalNoiseFidelity (Fintype.card x : ℝ) gamma))]
  rw [integral_smul]
  have h3 := integral_orbit_triple nu
  have h12 := integral_orbit_pair12 nu
  simpa [eq986Three, eq986Pair12] using congrArg
    (fun z => (1 - gamma) ^ 2 • z) (congrArg₂ (· - ·) h3
      (congrArg (fun z =>
        globalNoiseFidelity (Fintype.card x : ℝ) gamma • z) h12))

private theorem integral_eq986_groupB (nu : PureVector x) (gamma : ℝ) :
    (∫ U : Matrix.unitaryGroup x ℂ,
        (gamma * (1 - gamma) / (Fintype.card x : ℝ)) •
          ((eq986Pair13 nu U + eq986Pair23 nu U) -
            globalNoiseFidelity (Fintype.card x : ℝ) gamma •
              (eq986Single1 nu U + eq986Single2 nu U))
        ∂unitaryHaarMeasure (a := x)) =
      (gamma * (1 - gamma) / (Fintype.card x : ℝ)) •
        ((globalHaarMomentPair13Term nu + globalHaarMomentPair23Term nu) -
          globalNoiseFidelity (Fintype.card x : ℝ) gamma •
            ((2 / (Fintype.card x : ℝ)) •
              (1 : CMatrix (GlobalThreeLeg x)))) := by
  have h13 := eq986Pair13_integrable nu
  have h23 := eq986Pair23_integrable nu
  have hS1 := eq986Single1_integrable nu
  have hS2 := eq986Single2_integrable nu
  rw [integral_smul]
  rw [show (∫ U : Matrix.unitaryGroup x ℂ,
      (eq986Pair13 nu U + eq986Pair23 nu U) -
        globalNoiseFidelity (Fintype.card x : ℝ) gamma •
          (eq986Single1 nu U + eq986Single2 nu U)
      ∂unitaryHaarMeasure (a := x)) =
      (∫ U, eq986Pair13 nu U + eq986Pair23 nu U
        ∂unitaryHaarMeasure (a := x)) -
      ∫ U, globalNoiseFidelity (Fintype.card x : ℝ) gamma •
        (eq986Single1 nu U + eq986Single2 nu U)
        ∂unitaryHaarMeasure (a := x) by
    simpa only [Pi.smul_apply] using integral_sub (h13.add h23)
      ((hS1.add hS2).smul
        (globalNoiseFidelity (Fintype.card x : ℝ) gamma))]
  rw [integral_add h13 h23, integral_smul, integral_add hS1 hS2]
  rw [show (∫ U, eq986Pair13 nu U ∂unitaryHaarMeasure (a := x)) =
      globalHaarMomentPair13Term nu by
        simpa [eq986Pair13] using integral_orbit_pair13 nu]
  rw [show (∫ U, eq986Pair23 nu U ∂unitaryHaarMeasure (a := x)) =
      globalHaarMomentPair23Term nu by
        simpa [eq986Pair23] using integral_orbit_pair23 nu]
  rw [show (∫ U, eq986Single1 nu U ∂unitaryHaarMeasure (a := x)) =
      ((Fintype.card x : ℂ)⁻¹ : ℂ) •
        (1 : CMatrix (GlobalThreeLeg x)) by
        simpa [eq986Single1, single1CLM] using integral_orbit_single1 nu]
  rw [show (∫ U, eq986Single2 nu U ∂unitaryHaarMeasure (a := x)) =
      ((Fintype.card x : ℂ)⁻¹ : ℂ) •
        (1 : CMatrix (GlobalThreeLeg x)) by
        simpa [eq986Single2, single2CLM] using integral_orbit_single2 nu]
  ext p q
  simp only [Matrix.add_apply, Matrix.sub_apply, Matrix.smul_apply,
    Complex.real_smul, Matrix.one_apply]
  push_cast
  ring

private theorem integral_eq986_groupC (nu : PureVector x) (gamma : ℝ) :
    (∫ U : Matrix.unitaryGroup x ℂ,
        (gamma / (Fintype.card x : ℝ)) ^ 2 •
          (eq986Single3 nu U -
            globalNoiseFidelity (Fintype.card x : ℝ) gamma •
              (1 : CMatrix (GlobalThreeLeg x)))
        ∂unitaryHaarMeasure (a := x)) =
      (gamma / (Fintype.card x : ℝ)) ^ 2 •
        ((1 / (Fintype.card x : ℝ)) •
            (1 : CMatrix (GlobalThreeLeg x)) -
          globalNoiseFidelity (Fintype.card x : ℝ) gamma •
            (1 : CMatrix (GlobalThreeLeg x))) := by
  have hS3 := eq986Single3_integrable nu
  have hI : Integrable
      (fun _ : Matrix.unitaryGroup x ℂ =>
        (1 : CMatrix (GlobalThreeLeg x)))
      (unitaryHaarMeasure (a := x)) := integrable_const _
  rw [integral_smul]
  rw [show (∫ U : Matrix.unitaryGroup x ℂ,
      eq986Single3 nu U -
        globalNoiseFidelity (Fintype.card x : ℝ) gamma •
          (1 : CMatrix (GlobalThreeLeg x))
      ∂unitaryHaarMeasure (a := x)) =
      (∫ U, eq986Single3 nu U ∂unitaryHaarMeasure (a := x)) -
      ∫ U, globalNoiseFidelity (Fintype.card x : ℝ) gamma •
        (1 : CMatrix (GlobalThreeLeg x))
        ∂unitaryHaarMeasure (a := x) by
    simpa only [Pi.smul_apply] using integral_sub hS3
      (hI.smul (globalNoiseFidelity (Fintype.card x : ℝ) gamma))]
  rw [integral_smul]
  rw [show (∫ U, eq986Single3 nu U ∂unitaryHaarMeasure (a := x)) =
      ((Fintype.card x : ℂ)⁻¹ : ℂ) •
        (1 : CMatrix (GlobalThreeLeg x)) by
        simpa [eq986Single3, single3CLM] using integral_orbit_single3 nu]
  simp only [integral_const, measureReal_def, measure_univ,
    ENNReal.toReal_one, one_smul]
  ext p q
  simp only [Matrix.sub_apply, Matrix.smul_apply, Complex.real_smul,
    Matrix.one_apply]
  push_cast
  ring

set_option maxHeartbeats 1200000 in
private theorem globalEq986PerformanceOperator_eq_integrated_moments
    (nu : PureVector x) (gamma : ℝ) :
    globalEq986PerformanceOperator nu gamma =
      (1 - gamma) ^ 2 •
        (globalHaarMomentThreeTerm nu -
          globalNoiseFidelity (Fintype.card x : ℝ) gamma •
            globalHaarMomentPair12Term nu) +
      (gamma * (1 - gamma) / (Fintype.card x : ℝ)) •
        ((globalHaarMomentPair13Term nu +
            globalHaarMomentPair23Term nu) -
          globalNoiseFidelity (Fintype.card x : ℝ) gamma •
            ((2 / (Fintype.card x : ℝ)) •
              (1 : CMatrix (GlobalThreeLeg x)))) +
      (gamma / (Fintype.card x : ℝ)) ^ 2 •
        ((1 / (Fintype.card x : ℝ)) •
            (1 : CMatrix (GlobalThreeLeg x)) -
          globalNoiseFidelity (Fintype.card x : ℝ) gamma •
            (1 : CMatrix (GlobalThreeLeg x))) := by
  have hA := eq986GroupA_integrable nu gamma
  have hB := eq986GroupB_integrable nu gamma
  have hC := eq986GroupC_integrable nu gamma
  rw [globalEq986PerformanceOperator]
  calc
    _ = ∫ U : Matrix.unitaryGroup x ℂ,
        ((1 - gamma) ^ 2 •
            (eq986Three nu U -
              globalNoiseFidelity (Fintype.card x : ℝ) gamma •
                eq986Pair12 nu U) +
          (gamma * (1 - gamma) / (Fintype.card x : ℝ)) •
            ((eq986Pair13 nu U + eq986Pair23 nu U) -
              globalNoiseFidelity (Fintype.card x : ℝ) gamma •
                (eq986Single1 nu U + eq986Single2 nu U)) +
          (gamma / (Fintype.card x : ℝ)) ^ 2 • (eq986Single3 nu U -
            globalNoiseFidelity (Fintype.card x : ℝ) gamma •
              (1 : CMatrix (GlobalThreeLeg x))))
          ∂unitaryHaarMeasure (a := x) := by
      apply integral_congr_ae
      exact ae_of_all _ fun U => by
        exact globalEq986Integrand_eq_expanded nu gamma U
    _ = _ := by
      have hOuter := integral_add (hA.add hB) hC
      have hInner := integral_add hA hB
      calc
        _ =
            (∫ U : Matrix.unitaryGroup x ℂ,
              (1 - gamma) ^ 2 •
                  (eq986Three nu U -
                    globalNoiseFidelity (Fintype.card x : ℝ) gamma •
                      eq986Pair12 nu U) +
                (gamma * (1 - gamma) / (Fintype.card x : ℝ)) •
                  ((eq986Pair13 nu U + eq986Pair23 nu U) -
                    globalNoiseFidelity (Fintype.card x : ℝ) gamma •
                      (eq986Single1 nu U + eq986Single2 nu U))
              ∂unitaryHaarMeasure (a := x)) +
            (∫ U : Matrix.unitaryGroup x ℂ,
              (gamma / (Fintype.card x : ℝ)) ^ 2 •
                (eq986Single3 nu U -
                  globalNoiseFidelity (Fintype.card x : ℝ) gamma •
                    (1 : CMatrix (GlobalThreeLeg x)))
              ∂unitaryHaarMeasure (a := x)) := by
          simpa only [Pi.add_apply] using hOuter
        _ =
            ((∫ U : Matrix.unitaryGroup x ℂ,
              (1 - gamma) ^ 2 •
                (eq986Three nu U -
                  globalNoiseFidelity (Fintype.card x : ℝ) gamma •
                    eq986Pair12 nu U)
              ∂unitaryHaarMeasure (a := x)) +
            (∫ U : Matrix.unitaryGroup x ℂ,
              (gamma * (1 - gamma) / (Fintype.card x : ℝ)) •
                ((eq986Pair13 nu U + eq986Pair23 nu U) -
                  globalNoiseFidelity (Fintype.card x : ℝ) gamma •
                    (eq986Single1 nu U + eq986Single2 nu U))
              ∂unitaryHaarMeasure (a := x))) +
            (∫ U : Matrix.unitaryGroup x ℂ,
              (gamma / (Fintype.card x : ℝ)) ^ 2 •
                (eq986Single3 nu U -
                  globalNoiseFidelity (Fintype.card x : ℝ) gamma •
                    (1 : CMatrix (GlobalThreeLeg x)))
              ∂unitaryHaarMeasure (a := x)) := by
          rw [show
            (∫ U : Matrix.unitaryGroup x ℂ,
              (1 - gamma) ^ 2 •
                  (eq986Three nu U -
                    globalNoiseFidelity (Fintype.card x : ℝ) gamma •
                      eq986Pair12 nu U) +
                (gamma * (1 - gamma) / (Fintype.card x : ℝ)) •
                  ((eq986Pair13 nu U + eq986Pair23 nu U) -
                    globalNoiseFidelity (Fintype.card x : ℝ) gamma •
                      (eq986Single1 nu U + eq986Single2 nu U))
              ∂unitaryHaarMeasure (a := x)) = _ by
                simpa only [Pi.add_apply] using hInner]
        _ = _ := by
          rw [integral_eq986_groupA, integral_eq986_groupB,
            integral_eq986_groupC]

/-- Integrating the equation-(986) orbit expression gives the genuine
three-copy Haar performance operator. -/
theorem globalEq986PerformanceOperator_eq_globalHaarPerformanceOperator
    (nu : PureVector x) (gamma : ℝ) :
    globalEq986PerformanceOperator nu gamma =
      globalHaarPerformanceOperator nu gamma := by
  rw [globalEq986PerformanceOperator_eq_integrated_moments,
    globalHaarPerformanceOperator]
  ext p q
  simp only [Matrix.add_apply, Matrix.sub_apply, Matrix.smul_apply,
    Complex.real_smul]
  unfold globalNoiseFidelity
  push_cast
  ring

end

end EntanglementPurification
