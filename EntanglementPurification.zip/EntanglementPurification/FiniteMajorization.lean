import EntanglementPurification.ScalarBounds
import QIT.Util.Order.Majorization
import Mathlib.Tactic

/-!
# Finite ordered-prefix majorization

This file isolates the finite probability-vector part of the Schmidt-spectrum
converse.  `QIT.Majorizes q p` sorts both vectors internally.  The vectors in
the paper are already presented in nonincreasing order, so we first expose the
corresponding explicit ordered-prefix relation.  The final interface theorem
records exactly what is needed to pass to `QIT.Majorizes` once the two sorting
identities are available.
-/

namespace EntanglementPurification

noncomputable section

/-- Sum of the first `k` coordinates in their given `Fin` order. -/
def orderedPrefixSum {n : ℕ} (p : Fin n → ℝ) (k : ℕ) : ℝ :=
  ((List.ofFn p).take k).sum

/-- `PrefixMajorizedBy p q` is the paper's relation `p ≺ q`, for vectors whose
coordinates are already in nonincreasing order. -/
def PrefixMajorizedBy {n : ℕ} (p q : Fin n → ℝ) : Prop :=
  (∀ k : ℕ, orderedPrefixSum p k ≤ orderedPrefixSum q k) ∧
    (List.ofFn p).sum = (List.ofFn q).sum

/-- A finite probability vector written in nonincreasing coordinate order. -/
def IsOrderedProbability {n : ℕ} (p : Fin n → ℝ) : Prop :=
  Antitone p ∧ (∀ i, 0 ≤ p i) ∧ (List.ofFn p).sum = 1

/-- Mass in coordinates `2, 3, ...`. -/
def tailFromTwo {n : ℕ} (p : Fin n → ℝ) : ℝ :=
  ((List.ofFn p).drop 2).sum

/-- The zero-padded comparison vector `(1/2, 1/2, 0, ...)`. -/
def twoPointComparison (m : ℕ) : Fin (m + 2) → ℝ :=
  Fin.cons (1 / 2) (Fin.cons (1 / 2) (fun _ => 0))

/-- The zero-padded comparison vector `(x, 1-x-z, z, 0, ...)`. -/
def threePointComparison (m : ℕ) (x z : ℝ) : Fin (m + 3) → ℝ :=
  Fin.cons x (Fin.cons (1 - x - z) (Fin.cons z (fun _ => 0)))

@[simp]
theorem orderedPrefixSum_zero {n : ℕ} (p : Fin n → ℝ) :
    orderedPrefixSum p 0 = 0 := by
  simp [orderedPrefixSum]

theorem list_sum_nonneg_of_forall_nonneg {l : List ℝ}
    (h : ∀ x ∈ l, 0 ≤ x) :
    0 ≤ l.sum := by
  induction l with
  | nil => simp
  | cons a l ih =>
      simp only [List.sum_cons]
      have ha : 0 ≤ a := h a (by simp)
      have hl : 0 ≤ l.sum := ih (by
        intro x hx
        exact h x (by simp [hx]))
      linarith

/-- A prefix of an entrywise nonnegative list has sum at most the total sum. -/
theorem orderedPrefixSum_le_total {n : ℕ} {p : Fin n → ℝ}
    (hp : ∀ i, 0 ≤ p i) (k : ℕ) :
    orderedPrefixSum p k ≤ (List.ofFn p).sum := by
  let l := List.ofFn p
  have hdrop : 0 ≤ (l.drop k).sum := by
    apply list_sum_nonneg_of_forall_nonneg
    intro x hx
    have hxmem : x ∈ l := List.mem_of_mem_drop hx
    rcases List.mem_ofFn.mp hxmem with ⟨i, rfl⟩
    exact hp i
  have hsplit : (l.take k).sum + (l.drop k).sum = l.sum := by
    rw [← List.sum_append, List.take_append_drop]
  dsimp [orderedPrefixSum, l] at hsplit ⊢
  linarith

@[simp]
theorem orderedPrefixSum_twoPoint_zero (m : ℕ) :
    orderedPrefixSum (twoPointComparison m) 0 = 0 := by
  simp

@[simp]
theorem orderedPrefixSum_twoPoint_one (m : ℕ) :
    orderedPrefixSum (twoPointComparison m) 1 = 1 / 2 := by
  simp [orderedPrefixSum, twoPointComparison]

theorem orderedPrefixSum_twoPoint_of_two_le (m k : ℕ) (hk : 2 ≤ k) :
    orderedPrefixSum (twoPointComparison m) k = 1 := by
  obtain ⟨r, rfl⟩ := Nat.exists_eq_add_of_le hk
  rw [orderedPrefixSum, List.take_add]
  simp [twoPointComparison]
  norm_num

@[simp]
theorem orderedPrefixSum_threePoint_one (m : ℕ) (x z : ℝ) :
    orderedPrefixSum (threePointComparison m x z) 1 = x := by
  simp [orderedPrefixSum, threePointComparison]

@[simp]
theorem orderedPrefixSum_threePoint_two (m : ℕ) (x z : ℝ) :
    orderedPrefixSum (threePointComparison m x z) 2 = 1 - z := by
  simp [orderedPrefixSum, threePointComparison]
  ring

theorem orderedPrefixSum_threePoint_of_three_le
    (m k : ℕ) (x z : ℝ) (hk : 3 ≤ k) :
    orderedPrefixSum (threePointComparison m x z) k = 1 := by
  obtain ⟨r, rfl⟩ := Nat.exists_eq_add_of_le hk
  rw [orderedPrefixSum, List.take_add]
  simp [threePointComparison]

@[simp]
theorem twoPointComparison_total (m : ℕ) :
    (List.ofFn (twoPointComparison m)).sum = 1 := by
  simp [twoPointComparison]
  norm_num

@[simp]
theorem threePointComparison_total (m : ℕ) (x z : ℝ) :
    (List.ofFn (threePointComparison m x z)).sum = 1 := by
  simp [threePointComparison]

theorem orderedPrefixSum_one {m : ℕ} (p : Fin (m + 2) → ℝ) :
    orderedPrefixSum p 1 = p 0 := by
  simp [orderedPrefixSum]

theorem orderedPrefixSum_one_three {m : ℕ} (p : Fin (m + 3) → ℝ) :
    orderedPrefixSum p 1 = p 0 := by
  simp [orderedPrefixSum]

theorem orderedPrefixSum_two_three {m : ℕ} (p : Fin (m + 3) → ℝ) :
    orderedPrefixSum p 2 = p 0 + p 1 := by
  simp [orderedPrefixSum]

theorem prefix_two_add_tail {m : ℕ} (p : Fin (m + 3) → ℝ) :
    orderedPrefixSum p 2 + tailFromTwo p = (List.ofFn p).sum := by
  rw [orderedPrefixSum, tailFromTwo, ← List.sum_append,
    List.take_append_drop]

/-- An ordered probability vector with largest entry at most `1/2` is
majorized by `(1/2,1/2,0,...)`. -/
theorem prefixMajorizedBy_twoPoint_of_head_le_half
    {m : ℕ} {p : Fin (m + 2) → ℝ}
    (hp : IsOrderedProbability p) (hhead : p 0 ≤ 1 / 2) :
    PrefixMajorizedBy p (twoPointComparison m) := by
  refine ⟨?_, ?_⟩
  · intro k
    rcases k with _ | k
    · simp
    rcases k with _ | k
    · rw [orderedPrefixSum_one, orderedPrefixSum_twoPoint_one]
      exact hhead
    · rw [orderedPrefixSum_twoPoint_of_two_le m (k + 2) (by omega)]
      calc
        orderedPrefixSum p (k + 2) ≤ (List.ofFn p).sum :=
          orderedPrefixSum_le_total hp.2.1 _
        _ = 1 := hp.2.2
  · rw [hp.2.2, twoPointComparison_total]

/-- Generic three-point endpoint together with the scalar certificate that the
three displayed entries occur in nonincreasing, nonnegative order.  The tail
lower bound is exactly the second nontrivial prefix inequality. -/
theorem threePointOrderAndPrefixMajorization_of_tail_ge
    {m : ℕ} {p : Fin (m + 3) → ℝ} {x z : ℝ}
    (hp : IsOrderedProbability p)
    (hhead : p 0 = x)
    (htail : z ≤ tailFromTwo p)
    (hz : 0 ≤ z)
    (hzy : z ≤ 1 - x - z)
    (hyx : 1 - x - z ≤ x) :
    (0 ≤ z ∧ z ≤ 1 - x - z ∧ 1 - x - z ≤ x) ∧
      PrefixMajorizedBy p (threePointComparison m x z) := by
  refine ⟨⟨hz, hzy, hyx⟩, ?_⟩
  refine ⟨?_, ?_⟩
  · intro k
    rcases k with _ | k
    · simp
    rcases k with _ | k
    · rw [orderedPrefixSum_one_three, orderedPrefixSum_threePoint_one, hhead]
    rcases k with _ | k
    · rw [orderedPrefixSum_two_three, orderedPrefixSum_threePoint_two]
      have hsplit := prefix_two_add_tail p
      rw [hp.2.2] at hsplit
      rw [orderedPrefixSum_two_three] at hsplit
      linarith
    · rw [orderedPrefixSum_threePoint_of_three_le m (k + 3) x z (by omega)]
      calc
        orderedPrefixSum p (k + 3) ≤ (List.ofFn p).sum :=
          orderedPrefixSum_le_total hp.2.1 _
        _ = 1 := hp.2.2
  · rw [hp.2.2, threePointComparison_total]

/-- The prefix-majorization projection of
`threePointOrderAndPrefixMajorization_of_tail_ge`. -/
theorem prefixMajorizedBy_threePoint_of_tail_ge
    {m : ℕ} {p : Fin (m + 3) → ℝ} {x z : ℝ}
    (hp : IsOrderedProbability p)
    (hhead : p 0 = x)
    (htail : z ≤ tailFromTwo p)
    (hz : 0 ≤ z)
    (hzy : z ≤ 1 - x - z)
    (hyx : 1 - x - z ≤ x) :
    PrefixMajorizedBy p (threePointComparison m x z) :=
  (threePointOrderAndPrefixMajorization_of_tail_ge
    hp hhead htail hz hzy hyx).2

/-- The paper's `zStar` endpoint, with the scalar ordering properties supplied
as hypotheses so this module does not depend on unfinished scalar proofs. -/
theorem prefixMajorizedBy_zStar_of_tail_ge
    {m : ℕ} {p : Fin (m + 3) → ℝ}
    (hp : IsOrderedProbability p)
    (hx_lower : 1 / 2 < p 0)
    (hx_upper : p 0 ≤ 2 / 3)
    (htail : zStar (p 0) ≤ tailFromTwo p) :
    PrefixMajorizedBy p
      (threePointComparison m (p 0) (zStar (p 0))) := by
  have hboundary := boundary_spectrum_is_probability_on_interval
    (le_of_lt hx_lower) hx_upper
  exact prefixMajorizedBy_threePoint_of_tail_ge hp rfl htail
    hboundary.1.2.2 hboundary.2.1.2 hboundary.2.1.1

/-- Exact interface to the current `QIT.Majorizes` definition.  QIT sorts
internally, so equality of its descending-entry lists with the explicit `Fin`
order is the only additional bridge required for ordered vectors. -/
theorem prefixMajorizedBy_iff_qitMajorizes_of_descEntries_eq
    {n : ℕ} {p q : Fin n → ℝ}
    (hp : QIT.descEntries p = List.ofFn p)
    (hq : QIT.descEntries q = List.ofFn q) :
    PrefixMajorizedBy p q ↔ QIT.Majorizes q p := by
  simp only [PrefixMajorizedBy, QIT.Majorizes, QIT.descPrefixSum,
    QIT.descTotalSum, orderedPrefixSum, hp, hq]

/-- QIT's descending sorter leaves a vector unchanged when its `Fin`
coordinates are already nonincreasing. -/
theorem qit_descEntries_eq_of_antitone
    {n : ℕ} {p : Fin n → ℝ} (hp : Antitone p) :
    QIT.descEntries p = List.ofFn p := by
  have hindices :
      (Finset.univ.toList : List (Fin n)).Perm (List.finRange n) := by
    simpa using List.toFinset_toList (List.nodup_finRange n)
  have hentries :
      (Finset.univ.toList.map p).Perm (List.ofFn p) := by
    simpa [List.ofFn_eq_map] using hindices.map p
  have hperm :
      (QIT.descEntries p).Perm (List.ofFn p) := by
    exact (List.mergeSort_perm _ _).trans hentries
  exact List.Perm.eq_of_sortedGE
    (QIT.descEntries_sortedGE p) hp.sortedGE_ofFn hperm

/-- For vectors already presented in nonincreasing order, the explicit paper
relation is exactly Lean-QIT's `Majorizes` relation (with QIT's argument
direction `q` majorizes `p`). -/
theorem prefixMajorizedBy_iff_qitMajorizes_of_antitone
    {n : ℕ} {p q : Fin n → ℝ}
    (hp : Antitone p) (hq : Antitone q) :
    PrefixMajorizedBy p q ↔ QIT.Majorizes q p :=
  prefixMajorizedBy_iff_qitMajorizes_of_descEntries_eq
    (qit_descEntries_eq_of_antitone hp)
    (qit_descEntries_eq_of_antitone hq)

end

end EntanglementPurification
