import EntanglementPurification.PhysicalResourceInsertion

/-!
# The global optimizer in local contraction coordinates

This file proves the local multiplicity block obtained by regrouping the
explicit global optimizer and pulling it back through the two local
contraction isometries.  All scalar coefficients are calculated from the
displayed `globalWPlus` and local `W₊/W₋` definitions.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b : Type*}
  [Fintype a] [Fintype b] [DecidableEq a] [DecidableEq b]
  [Nonempty a] [Nonempty b]

/-- The overlap of a normalized local parity contraction with `Γ₁`. -/
private def localGamma1Overlap (d : ℕ) : LocalParity → ℝ
  | .plus => (1 / Real.sqrt (2 * ((d : ℝ) + 1))) * ((d : ℝ) + 1)
  | .minus => (1 / Real.sqrt (2 * ((d : ℝ) - 1))) * (1 - (d : ℝ))

/-- The overlap of a normalized local parity contraction with `Γ₂`. -/
private def localGamma2Overlap (d : ℕ) : LocalParity → ℝ
  | .plus => (1 / Real.sqrt (2 * ((d : ℝ) + 1))) * ((d : ℝ) + 1)
  | .minus => (1 / Real.sqrt (2 * ((d : ℝ) - 1))) * ((d : ℝ) - 1)

private theorem localWByParity_conjTranspose_mul_globalGamma1
    (s : LocalParity) :
    Matrix.conjTranspose (localWByParity (x := a) s) * globalGamma1 =
      ((localGamma1Overlap (Fintype.card a) s : ℝ) : ℂ) •
        (1 : CMatrix a) := by
  cases s <;>
    simp only [localWByParity, localWPlus, localWMinus, globalWPlus,
      globalWMinus, globalGammaPlus, globalGammaMinus,
      Matrix.conjTranspose_smul, star_trivial, Matrix.smul_mul,
      Matrix.conjTranspose_add, Matrix.conjTranspose_sub, Matrix.add_mul,
      Matrix.sub_mul]
  · rw [globalGamma1_conjTranspose_mul_self,
      globalGamma2_conjTranspose_mul_globalGamma1]
    ext i j
    by_cases hij : i = j
    · subst j
      simp [localGamma1Overlap]
      ring_nf
    · simp [localGamma1Overlap, hij]
  · rw [globalGamma2_conjTranspose_mul_globalGamma1,
      globalGamma1_conjTranspose_mul_self]
    ext i j
    by_cases hij : i = j
    · subst j
      simp [localGamma1Overlap]
    · simp [localGamma1Overlap, hij]

private theorem localWByParity_conjTranspose_mul_globalGamma2
    (s : LocalParity) :
    Matrix.conjTranspose (localWByParity (x := a) s) * globalGamma2 =
      ((localGamma2Overlap (Fintype.card a) s : ℝ) : ℂ) •
        (1 : CMatrix a) := by
  cases s <;>
    simp only [localWByParity, localWPlus, localWMinus, globalWPlus,
      globalWMinus, globalGammaPlus, globalGammaMinus,
      Matrix.conjTranspose_smul, star_trivial, Matrix.smul_mul,
      Matrix.conjTranspose_add, Matrix.conjTranspose_sub, Matrix.add_mul,
      Matrix.sub_mul]
  · rw [globalGamma1_conjTranspose_mul_globalGamma2,
      globalGamma2_conjTranspose_mul_self]
    ext i j
    by_cases hij : i = j
    · subst j
      simp [localGamma2Overlap]
      ring_nf
    · simp [localGamma2Overlap, hij]
  · rw [globalGamma2_conjTranspose_mul_self,
      globalGamma1_conjTranspose_mul_globalGamma2]
    ext i j
    by_cases hij : i = j
    · subst j
      simp [localGamma2Overlap]
    · simp [localGamma2Overlap, hij]

/-- Product-space `Γ₁`, with its rows regrouped into Alice/Bob physical
coordinates. -/
private def physicalInsertedGlobalGamma1 :
    Matrix (JointContractionUnassistedPhysicalIndex a b) (a × b) ℂ :=
  fun p q =>
    globalGamma1 (x := a × b)
      ((physicalInsertedChoiEquiv (a := a) (b := b)).symm p) q

@[simp]
private theorem physicalInsertedGlobalGamma1_apply
    (uA : LocalMixedSchurSpace a) (uB : LocalMixedSchurSpace b)
    (i : a) (j : b) :
    physicalInsertedGlobalGamma1 (a := a) (b := b) (uA, uB) (i, j) =
      globalGamma1 uA i * globalGamma1 uB j := by
  rcases uA with ⟨⟨iA₁, iA₂⟩, oA⟩
  rcases uB with ⟨⟨iB₁, iB₂⟩, oB⟩
  simp only [physicalInsertedGlobalGamma1, physicalInsertedChoiEquiv,
    globalGamma1]
  by_cases hA₁ : iA₁ = oA <;> by_cases hB₁ : iB₁ = oB <;>
    by_cases hA₂ : iA₂ = i <;> by_cases hB₂ : iB₂ = j <;>
    simp [hA₁, hB₁, hA₂, hB₂]

/-- Product-space `Γ₂`, with its rows regrouped into Alice/Bob physical
coordinates. -/
private def physicalInsertedGlobalGamma2 :
    Matrix (JointContractionUnassistedPhysicalIndex a b) (a × b) ℂ :=
  fun p q =>
    globalGamma2 (x := a × b)
      ((physicalInsertedChoiEquiv (a := a) (b := b)).symm p) q

@[simp]
private theorem physicalInsertedGlobalGamma2_apply
    (uA : LocalMixedSchurSpace a) (uB : LocalMixedSchurSpace b)
    (i : a) (j : b) :
    physicalInsertedGlobalGamma2 (a := a) (b := b) (uA, uB) (i, j) =
      globalGamma2 uA i * globalGamma2 uB j := by
  rcases uA with ⟨⟨iA₁, iA₂⟩, oA⟩
  rcases uB with ⟨⟨iB₁, iB₂⟩, oB⟩
  simp only [physicalInsertedGlobalGamma2, physicalInsertedChoiEquiv,
    globalGamma2]
  by_cases hA₂ : iA₂ = oA <;> by_cases hB₂ : iB₂ = oB <;>
    by_cases hA₁ : iA₁ = i <;> by_cases hB₁ : iB₁ = j <;>
    simp [hA₁, hB₁, hA₂, hB₂]

/-- The regrouped product-space `Γ₊ = Γ₁ + Γ₂`. -/
private def physicalInsertedGlobalGammaPlus :
    Matrix (JointContractionUnassistedPhysicalIndex a b) (a × b) ℂ :=
  physicalInsertedGlobalGamma1 + physicalInsertedGlobalGamma2

private theorem sum_prod_separable
    {x y : Type*} [Fintype x] [Fintype y]
    (f : x → ℂ) (g : y → ℂ) :
    (∑ p : x × y, f p.1 * g p.2) =
      (∑ u : x, f u) * ∑ v : y, g v := by
  rw [Fintype.sum_prod_type, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro u _
  rw [Finset.mul_sum]

private theorem sum_sum_separable
    {x y : Type*} [Fintype x] [Fintype y]
    (f : x → ℂ) (g : y → ℂ) :
    (∑ u : x, ∑ v : y, f u * g v) =
      (∑ u : x, f u) * ∑ v : y, g v := by
  rw [Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro u _
  rw [Finset.mul_sum]

private theorem jointContractionUnassistedIsometry_conjTranspose_mul_gamma1_apply
    (sA sB : LocalParity) (i k : a) (j l : b) :
    (Matrix.conjTranspose
          (jointContractionUnassistedIsometry (a := a) (b := b)) *
        physicalInsertedGlobalGamma1 (a := a) (b := b))
        ((sA, sB), (i, j)) (k, l) =
      (Matrix.conjTranspose (localWByParity (x := a) sA) *
          globalGamma1 (x := a)) i k *
        (Matrix.conjTranspose (localWByParity (x := b) sB) *
          globalGamma1 (x := b)) j l := by
  rw [Matrix.mul_apply]
  rw [Fintype.sum_prod_type]
  simp_rw [Matrix.conjTranspose_apply,
    jointContractionUnassistedIsometry_apply,
    physicalInsertedGlobalGamma1_apply]
  rw [Matrix.mul_apply, Matrix.mul_apply]
  simp only [Matrix.conjTranspose_apply]
  calc
    (∑ uA : LocalMixedSchurSpace a, ∑ uB : LocalMixedSchurSpace b,
      star (localContractionCoordinates uA (sA, i) *
          localContractionCoordinates uB (sB, j)) *
        (globalGamma1 uA k * globalGamma1 uB l)) =
      ∑ uA : LocalMixedSchurSpace a, ∑ uB : LocalMixedSchurSpace b,
        (star (localContractionCoordinates uA (sA, i)) *
            globalGamma1 uA k) *
          (star (localContractionCoordinates uB (sB, j)) *
            globalGamma1 uB l) := by
              apply Finset.sum_congr rfl
              intro uA _
              apply Finset.sum_congr rfl
              intro uB _
              rw [star_mul]
              ring
    _ = _ := sum_sum_separable _ _

private theorem jointContractionUnassistedIsometry_conjTranspose_mul_gamma2_apply
    (sA sB : LocalParity) (i k : a) (j l : b) :
    (Matrix.conjTranspose
          (jointContractionUnassistedIsometry (a := a) (b := b)) *
        physicalInsertedGlobalGamma2 (a := a) (b := b))
        ((sA, sB), (i, j)) (k, l) =
      (Matrix.conjTranspose (localWByParity (x := a) sA) *
          globalGamma2 (x := a)) i k *
        (Matrix.conjTranspose (localWByParity (x := b) sB) *
          globalGamma2 (x := b)) j l := by
  rw [Matrix.mul_apply]
  rw [Fintype.sum_prod_type]
  simp_rw [Matrix.conjTranspose_apply,
    jointContractionUnassistedIsometry_apply,
    physicalInsertedGlobalGamma2_apply]
  rw [Matrix.mul_apply, Matrix.mul_apply]
  simp only [Matrix.conjTranspose_apply]
  calc
    (∑ uA : LocalMixedSchurSpace a, ∑ uB : LocalMixedSchurSpace b,
      star (localContractionCoordinates uA (sA, i) *
          localContractionCoordinates uB (sB, j)) *
        (globalGamma2 uA k * globalGamma2 uB l)) =
      ∑ uA : LocalMixedSchurSpace a, ∑ uB : LocalMixedSchurSpace b,
        (star (localContractionCoordinates uA (sA, i)) *
            globalGamma2 uA k) *
          (star (localContractionCoordinates uB (sB, j)) *
            globalGamma2 uB l) := by
              apply Finset.sum_congr rfl
              intro uA _
              apply Finset.sum_congr rfl
              intro uB _
              rw [star_mul]
              ring
    _ = _ := sum_sum_separable _ _

private theorem jointContractionUnassistedIsometry_conjTranspose_mul_gammaPlus_apply
    (sA sB : LocalParity) (i k : a) (j l : b) :
    (Matrix.conjTranspose
          (jointContractionUnassistedIsometry (a := a) (b := b)) *
        physicalInsertedGlobalGammaPlus (a := a) (b := b))
        ((sA, sB), (i, j)) (k, l) =
      (((localGamma1Overlap (Fintype.card a) sA : ℝ) : ℂ) *
          ((localGamma1Overlap (Fintype.card b) sB : ℝ) : ℂ) +
        ((localGamma2Overlap (Fintype.card a) sA : ℝ) : ℂ) *
          ((localGamma2Overlap (Fintype.card b) sB : ℝ) : ℂ)) *
        (1 : CMatrix (a × b)) (i, j) (k, l) := by
  calc
    (Matrix.conjTranspose
          (jointContractionUnassistedIsometry (a := a) (b := b)) *
        physicalInsertedGlobalGammaPlus (a := a) (b := b))
        ((sA, sB), (i, j)) (k, l) =
      (Matrix.conjTranspose (localWByParity (x := a) sA) *
          globalGamma1 (x := a)) i k *
          (Matrix.conjTranspose (localWByParity (x := b) sB) *
            globalGamma1 (x := b)) j l +
        (Matrix.conjTranspose (localWByParity (x := a) sA) *
          globalGamma2 (x := a)) i k *
          (Matrix.conjTranspose (localWByParity (x := b) sB) *
            globalGamma2 (x := b)) j l := by
        simp only [physicalInsertedGlobalGammaPlus, Matrix.mul_add,
          Matrix.add_apply,
          jointContractionUnassistedIsometry_conjTranspose_mul_gamma1_apply,
          jointContractionUnassistedIsometry_conjTranspose_mul_gamma2_apply]
    _ = _ := by
      rw [localWByParity_conjTranspose_mul_globalGamma1 (a := a),
        localWByParity_conjTranspose_mul_globalGamma1 (a := b),
        localWByParity_conjTranspose_mul_globalGamma2 (a := a),
        localWByParity_conjTranspose_mul_globalGamma2 (a := b)]
      simp [Matrix.one_apply, Prod.ext_iff]
      by_cases hik : i = k <;> by_cases hjl : j = l <;>
        simp [hik, hjl]

/-- The normalized global `W₊`, with its physical rows regrouped by party. -/
private def physicalInsertedGlobalWPlus :
    Matrix (JointContractionUnassistedPhysicalIndex a b) (a × b) ℂ :=
  fun p q =>
    globalWPlus (x := a × b)
      ((physicalInsertedChoiEquiv (a := a) (b := b)).symm p) q

private theorem physicalInsertedGlobalWPlus_eq_smul_gammaPlus :
    physicalInsertedGlobalWPlus (a := a) (b := b) =
      (1 / Real.sqrt
        (2 * ((Fintype.card (a × b) : ℝ) + 1))) •
        physicalInsertedGlobalGammaPlus := by
  rfl

private theorem physicalInsertedChoiMatrix_globalPWPlus :
    physicalInsertedChoiMatrix (a := a) (b := b)
        (globalPWPlus (x := a × b)) =
      physicalInsertedGlobalWPlus *
        Matrix.conjTranspose physicalInsertedGlobalWPlus := by
  ext p q
  simp [physicalInsertedChoiMatrix, Matrix.reindexAlgEquiv_apply,
    Matrix.reindex_apply, globalPWPlus, physicalInsertedGlobalWPlus,
    Matrix.mul_apply, Matrix.conjTranspose_apply]

private theorem physicalInsertedChoiMatrix_globalOptimalChoi :
    physicalInsertedChoiMatrix (a := a) (b := b)
        (globalOptimalChoi (x := a × b)) =
      (((Fintype.card (a × b) : ℝ) + 1) / 2) •
        (physicalInsertedGlobalWPlus *
          Matrix.conjTranspose physicalInsertedGlobalWPlus) := by
  ext p q
  simp [globalOptimalChoi, physicalInsertedChoiMatrix,
    Matrix.reindexAlgEquiv_apply, Matrix.reindex_apply,
    globalPWPlus, physicalInsertedGlobalWPlus, Matrix.mul_apply,
    Matrix.conjTranspose_apply]

private theorem globalLocal_inv_sqrt_sq_mul
    {x : ℝ} (hx : 0 < x) :
    (1 / Real.sqrt x) ^ 2 * x = 1 := by
  have hsqrtPos : 0 < Real.sqrt x := Real.sqrt_pos.2 hx
  have hsqrtNe : Real.sqrt x ≠ 0 := ne_of_gt hsqrtPos
  have hsquare : (Real.sqrt x) ^ 2 = x := Real.sq_sqrt hx.le
  field_simp
  nlinarith

/-- The unnormalized global even contraction seen in the four local parity
sectors. -/
private def globalLocalSectorAmplitude (d : ℕ) :
    LocalMultiplicitySector → ℝ
  | (.plus, .plus) => (d : ℝ) + 1
  | (.minus, .minus) => (d : ℝ) - 1
  | _ => 0

private theorem localGammaOverlap_pair_sum_eq_amplitude
    (d : ℕ) (hcard : 2 ≤ d) (sA sB : LocalParity) :
    localGamma1Overlap d sA * localGamma1Overlap d sB +
        localGamma2Overlap d sA * localGamma2Overlap d sB =
      globalLocalSectorAmplitude d (sA, sB) := by
  have hd : (1 : ℝ) < d := by exact_mod_cast hcard
  have hplus : 0 < 2 * ((d : ℝ) + 1) := by positivity
  have hminus : 0 < 2 * ((d : ℝ) - 1) := by positivity
  have hnplus := globalLocal_inv_sqrt_sq_mul hplus
  have hnminus := globalLocal_inv_sqrt_sq_mul hminus
  cases sA <;> cases sB
  · simp only [localGamma1Overlap, localGamma2Overlap,
      globalLocalSectorAmplitude]
    nlinarith
  · simp only [localGamma1Overlap, localGamma2Overlap,
      globalLocalSectorAmplitude]
    ring
  · simp only [localGamma1Overlap, localGamma2Overlap,
      globalLocalSectorAmplitude]
    ring
  · simp only [localGamma1Overlap, localGamma2Overlap,
      globalLocalSectorAmplitude]
    nlinarith

private theorem globalLocalSectorAmplitude_eq_two_optimal
    (d : ℕ) (z : LocalMultiplicitySector) :
    ((globalLocalSectorAmplitude d z : ℝ) : ℂ) =
      2 * localOptimalMultiplicityVector d z := by
  rcases z with ⟨sA, sB⟩
  cases sA <;> cases sB <;>
    simp [globalLocalSectorAmplitude, localOptimalMultiplicityVector,
      localContractionAlpha, localContractionBeta] <;>
    ring

private theorem localOptimalMultiplicityVector_eq_half_amplitude
    (d : ℕ) (z : LocalMultiplicitySector) :
    localOptimalMultiplicityVector d z =
      ((globalLocalSectorAmplitude d z / 2 : ℝ) : ℂ) := by
  rcases z with ⟨sA, sB⟩
  cases sA <;> cases sB <;>
    simp [globalLocalSectorAmplitude, localOptimalMultiplicityVector,
      localContractionAlpha, localContractionBeta]

private theorem globalOptimal_normalizer_amplitude
    (D u v : ℝ) (hD : 0 ≤ D) :
    ((D + 1) / 2) *
        ((1 / Real.sqrt (2 * (D + 1)) * u) *
          (1 / Real.sqrt (2 * (D + 1)) * v)) =
      (u / 2) * (v / 2) := by
  have harg : 0 < 2 * (D + 1) := by positivity
  have hn := globalLocal_inv_sqrt_sq_mul harg
  have hprefactor :
      ((D + 1) / 2) * (1 / Real.sqrt (2 * (D + 1))) ^ 2 =
        1 / 4 := by
    nlinarith
  calc
    ((D + 1) / 2) *
        ((1 / Real.sqrt (2 * (D + 1)) * u) *
          (1 / Real.sqrt (2 * (D + 1)) * v)) =
      (((D + 1) / 2) *
          (1 / Real.sqrt (2 * (D + 1))) ^ 2) * u * v := by ring
    _ = (1 / 4) * u * v := by rw [hprefactor]
    _ = (u / 2) * (v / 2) := by ring

private theorem jointContractionUnassistedIsometry_conjTranspose_mul_globalWPlus_apply
    (hcardA : 2 ≤ Fintype.card a)
    (hcardB : Fintype.card b = Fintype.card a)
    (sA sB : LocalParity) (i k : a) (j l : b) :
    (Matrix.conjTranspose
          (jointContractionUnassistedIsometry (a := a) (b := b)) *
        physicalInsertedGlobalWPlus (a := a) (b := b))
        ((sA, sB), (i, j)) (k, l) =
      (((1 / Real.sqrt
            (2 * ((Fintype.card (a × b) : ℝ) + 1))) *
          globalLocalSectorAmplitude (Fintype.card a) (sA, sB) : ℝ) : ℂ) *
        (1 : CMatrix (a × b)) (i, j) (k, l) := by
  rw [physicalInsertedGlobalWPlus_eq_smul_gammaPlus,
    Matrix.mul_smul, Matrix.smul_apply,
    jointContractionUnassistedIsometry_conjTranspose_mul_gammaPlus_apply]
  rw [hcardB]
  have hamp := congrArg (fun x : ℝ => (x : ℂ))
    (localGammaOverlap_pair_sum_eq_amplitude
      (Fintype.card a) hcardA sA sB)
  push_cast at hamp
  rw [hamp]
  push_cast
  rw [Complex.real_smul]
  rw [Complex.ofReal_div, Complex.ofReal_one]
  ring

private theorem jointContractionUnassistedPullback_globalOptimalChoi :
    jointContractionUnassistedPullback
        (physicalInsertedChoiMatrix (a := a) (b := b)
          (globalOptimalChoi (x := a × b))) =
      (((Fintype.card (a × b) : ℝ) + 1) / 2) •
        ((Matrix.conjTranspose
              (jointContractionUnassistedIsometry (a := a) (b := b)) *
            physicalInsertedGlobalWPlus (a := a) (b := b)) *
          Matrix.conjTranspose
            (Matrix.conjTranspose
                (jointContractionUnassistedIsometry (a := a) (b := b)) *
              physicalInsertedGlobalWPlus (a := a) (b := b))) := by
  unfold jointContractionUnassistedPullback
  rw [physicalInsertedChoiMatrix_globalOptimalChoi]
  rw [Matrix.mul_smul, Matrix.smul_mul]
  congr 1
  simp only [Matrix.conjTranspose_mul,
    Matrix.conjTranspose_conjTranspose, Matrix.mul_assoc]

private theorem pulledGlobalWPlus_gram_diagonal_apply
    (hcardA : 2 ≤ Fintype.card a)
    (hcardB : Fintype.card b = Fintype.card a)
    (z w : LocalMultiplicitySector) (i : a) (j : b) :
    ((Matrix.conjTranspose
            (jointContractionUnassistedIsometry (a := a) (b := b)) *
          physicalInsertedGlobalWPlus (a := a) (b := b)) *
        Matrix.conjTranspose
          (Matrix.conjTranspose
              (jointContractionUnassistedIsometry (a := a) (b := b)) *
            physicalInsertedGlobalWPlus (a := a) (b := b)))
        (z, (i, j)) (w, (i, j)) =
      (((1 / Real.sqrt
            (2 * ((Fintype.card (a × b) : ℝ) + 1))) *
          globalLocalSectorAmplitude (Fintype.card a) z : ℝ) : ℂ) *
        star (((1 / Real.sqrt
            (2 * ((Fintype.card (a × b) : ℝ) + 1))) *
          globalLocalSectorAmplitude (Fintype.card a) w : ℝ) : ℂ) := by
  rcases z with ⟨sA, sB⟩
  rcases w with ⟨tA, tB⟩
  rw [Matrix.mul_apply, Fintype.sum_prod_type]
  simp_rw [Matrix.conjTranspose_apply,
    jointContractionUnassistedIsometry_conjTranspose_mul_globalWPlus_apply
      hcardA hcardB]
  rw [Fintype.sum_eq_single i]
  · rw [Fintype.sum_eq_single j]
    · simp
    · intro l hlj
      simp [Ne.symm hlj]
  · intro k hik
    simp [Ne.symm hik]

/-- `lem:global_optimizer_local_block` in `main.tex`, in the canonical
four-sector coefficient coordinates.  The proof expands the displayed global
contraction and computes its local `W₊/W₋` overlaps explicitly. -/
theorem globalOptimizer_localBlock
    (hcardA : 2 ≤ Fintype.card a)
    (hcardB : Fintype.card b = Fintype.card a) :
    jointContractionUnassistedCoefficient
        (physicalInsertedChoiMatrix (a := a) (b := b)
          (globalOptimalChoi (x := a × b))) =
      rankOneMatrix
        (localOptimalMultiplicityVector (Fintype.card a)) := by
  ext z w
  unfold jointContractionUnassistedCoefficient
    productUnitaryCommutantCoefficient
  rw [jointContractionUnassistedPullback_globalOptimalChoi]
  rw [Matrix.smul_apply]
  rw [pulledGlobalWPlus_gram_diagonal_apply hcardA hcardB]
  rw [rankOneMatrix_apply]
  rw [localOptimalMultiplicityVector_eq_half_amplitude,
    localOptimalMultiplicityVector_eq_half_amplitude]
  have hpref := globalOptimal_normalizer_amplitude
    (Fintype.card (a × b) : ℝ)
    (globalLocalSectorAmplitude (Fintype.card a) z)
    (globalLocalSectorAmplitude (Fintype.card a) w)
    (by positivity)
  have hprefComplex := congrArg (fun x : ℝ => (x : ℂ)) hpref
  push_cast at hprefComplex
  simpa [Complex.real_smul] using hprefComplex

end

end EntanglementPurification
