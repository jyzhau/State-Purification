import EntanglementPurification.GlobalConcreteSDP
import Mathlib.Tactic

/-!
# Paper dimension specialization of the global CPTN SDP

The abstract concrete SDP is indexed by a finite one-leg type `x` and uses
`D = card x`.  In the paper that one-leg space is a pair of `d`-dimensional
indices, hence `x = Fin d × Fin d` and `D = d²`.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

/-- The paper's one-leg label type.  Its cardinality is `d²`. -/
abbrev GlobalPaperIndex (d : ℕ) := Fin d × Fin d

@[simp]
theorem card_globalPaperIndex (d : ℕ) :
    Fintype.card (GlobalPaperIndex d) = d ^ 2 := by
  simp [GlobalPaperIndex, pow_two]

/-- The abstract condition `4 ≤ D` follows from the paper assumption `d ≥ 2`
once `D = d²`. -/
theorem four_le_card_globalPaperIndex
    {d : ℕ} (hd : 2 ≤ d) :
    (4 : ℝ) ≤ (Fintype.card (GlobalPaperIndex d) : ℝ) := by
  rw [card_globalPaperIndex]
  have hnat : 4 ≤ d ^ 2 := by
    simpa [pow_two] using Nat.mul_self_le_mul_self hd
  exact_mod_cast hnat

/-- `globalConcreteRaw_optimal_and_unique` with the paper identification
`D = d²`: the displayed Choi matrix is feasible, has the stated value, bounds
every feasible Choi matrix, and is the unique optimizer. -/
theorem globalPaperRaw_optimal_and_unique
    {d : ℕ} (hd : 2 ≤ d)
    {gamma : ℝ} (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) :
    IsGlobalCPTNChoi
        (globalOptimalChoi (x := GlobalPaperIndex d)) ∧
      globalSDPObjective
          (globalConcreteRawPerformanceOperator
            (x := GlobalPaperIndex d) gamma)
          globalOptimalChoi =
        globalOptimalGain ((d : ℝ) ^ 2) gamma ∧
      (∀ J : CMatrix (GlobalThreeLeg (GlobalPaperIndex d)),
        IsGlobalCPTNChoi J →
          globalSDPObjective
              (globalConcreteRawPerformanceOperator
                (x := GlobalPaperIndex d) gamma) J ≤
            globalOptimalGain ((d : ℝ) ^ 2) gamma) ∧
      (∀ J : CMatrix (GlobalThreeLeg (GlobalPaperIndex d)),
        IsGlobalCPTNChoi J →
          (globalSDPObjective
                (globalConcreteRawPerformanceOperator
                  (x := GlobalPaperIndex d) gamma) J =
              globalOptimalGain ((d : ℝ) ^ 2) gamma ↔
            J = globalOptimalChoi (x := GlobalPaperIndex d))) := by
  simpa [GlobalPaperIndex, pow_two] using
    (globalConcreteRaw_optimal_and_unique
      (x := GlobalPaperIndex d)
      (four_le_card_globalPaperIndex hd) hgamma0 hgamma1)

end

end EntanglementPurification
