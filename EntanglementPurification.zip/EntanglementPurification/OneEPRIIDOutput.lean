import EntanglementPurification.OneEPRProjectorBridge
import Mathlib.Tactic

/-!
# IID output of the accepted one-EPR map

This file proves the direct output formula used after Algorithm 1 in the
appendix.  The slightly stronger first theorem does not assume that `rho` is
normalized: the two diagonal Kraus contractions contribute
`rho.trace * rho`, and the two crossed contractions contribute `rho * rho`.
For a density matrix, `rho.trace = 1`, giving the paper's formula

`Phi_acc (rho tensor rho) = (rho + rho^2) / 2`.
-/

namespace EntanglementPurification

open QIT

noncomputable section

private theorem mul_globalInputPairSwap_apply
    {x : Type*} [Fintype x] [DecidableEq x]
    (M : CMatrix (x × x)) (p q : x × x) :
    (M * globalInputPairSwap (x := x)) p q = M p (q.2, q.1) := by
  simp only [Matrix.mul_apply, globalInputPairSwap]
  rw [Fintype.sum_eq_single (q.2, q.1)]
  · simp
  · intro z hz
    have hneq : q ≠ (z.2, z.1) := by
      intro h
      apply hz
      apply Prod.ext
      · exact (congrArg Prod.snd h).symm
      · exact (congrArg Prod.fst h).symm
    simp [hneq]

/-- A complete-copy swap commutes with two identical tensor factors. -/
theorem globalInputPairSwap_comm_kronecker_self
    {x : Type*} [Fintype x] [DecidableEq x]
    (rho : CMatrix x) :
    globalInputPairSwap (x := x) * Matrix.kronecker rho rho =
      Matrix.kronecker rho rho * globalInputPairSwap := by
  ext p q
  rw [globalInputPairSwap_mul_apply, mul_globalInputPairSwap_apply]
  simp only [Matrix.kronecker, Matrix.kroneckerMap_apply]
  ring

/-- Expanding both symmetric projectors on an IID two-copy input leaves the
average of the unswapped and once-swapped terms. -/
theorem globalInputPairPSym_kronecker_self_sandwich
    {x : Type*} [Fintype x] [DecidableEq x]
    (rho : CMatrix x) :
    globalInputPairPSym (x := x) * Matrix.kronecker rho rho *
        globalInputPairPSym =
      (1 / 2 : ℂ) •
        (Matrix.kronecker rho rho +
          globalInputPairSwap * Matrix.kronecker rho rho) := by
  have hcomm := globalInputPairSwap_comm_kronecker_self rho
  have hsquare := globalInputPairSwap_sq (x := x)
  simp only [globalInputPairPSym, Matrix.smul_mul, Matrix.mul_smul,
    smul_smul]
  rw [Matrix.add_mul, Matrix.mul_add, Matrix.add_mul, Matrix.one_mul,
    Matrix.mul_one]
  rw [hcomm]
  simp only [Matrix.mul_one, Matrix.add_mul]
  rw [Matrix.mul_assoc, hsquare, Matrix.mul_one]
  module

/-- Partial trace of an IID tensor product, without normalizing `rho`. -/
theorem partialTraceB_kronecker_self
    {x : Type*} [Fintype x] [DecidableEq x]
    (rho : CMatrix x) :
    QIT.partialTraceB (Matrix.kronecker rho rho) = rho.trace • rho := by
  ext c d
  simp [QIT.partialTraceB, Matrix.kronecker, Matrix.kroneckerMap_apply,
    Matrix.trace, Matrix.smul_apply]
  rw [Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro i _
  ring

/-- The swapped partial trace contracts the two copies by matrix
multiplication. -/
theorem partialTraceB_swap_mul_kronecker_self
    {x : Type*} [Fintype x] [DecidableEq x]
    (rho : CMatrix x) :
    QIT.partialTraceB
        (globalInputPairSwap (x := x) * Matrix.kronecker rho rho) =
      rho * rho := by
  ext c d
  simp only [QIT.partialTraceB]
  simp_rw [globalInputPairSwap_mul_apply]
  simp [Matrix.kronecker, Matrix.kroneckerMap_apply, Matrix.mul_apply,
    mul_comm]

/-- Project, then discard the second IID copy.  This is the projector form
of the Appendix Algorithm 1 output calculation. -/
theorem partialTraceB_globalInputPairPSym_kronecker_self
    {x : Type*} [Fintype x] [DecidableEq x]
    (rho : CMatrix x) :
    QIT.partialTraceB
        (globalInputPairPSym (x := x) * Matrix.kronecker rho rho *
          globalInputPairPSym) =
      (1 / 2 : ℂ) • ((rho.trace • rho) + rho * rho) := by
  rw [globalInputPairPSym_kronecker_self_sandwich]
  rw [QIT.partialTraceB_smul, QIT.partialTraceB_add,
    partialTraceB_kronecker_self,
    partialTraceB_swap_mul_kronecker_self]

/-- Matrix form of the unnormalized IID-output identity. -/
theorem oneEPRAcceptedMap_kronecker_self
    {x : Type*} [Fintype x] [DecidableEq x]
    (rho : CMatrix x) :
    oneEPRAcceptedMap (Matrix.kronecker rho rho) =
      (1 / 2 : ℂ) • ((rho.trace • rho) + rho * rho) := by
  rw [← symmetricProjectorDiscardMap_eq_oneEPRAcceptedMap]
  rw [symmetricProjectorDiscardMap_apply]
  exact partialTraceB_globalInputPairPSym_kronecker_self rho

/-- Entrywise form of the accepted Algorithm 1 branch on two identical
inputs, without a trace-normalization assumption. -/
theorem oneEPRAcceptedMap_kronecker_self_apply
    {x : Type*} [Fintype x] [DecidableEq x]
    (rho : CMatrix x) (c d : x) :
    oneEPRAcceptedMap (Matrix.kronecker rho rho) c d =
      (1 / 2 : ℂ) * (rho.trace * rho c d + (rho * rho) c d) := by
  rw [oneEPRAcceptedMap_kronecker_self]
  simp [Matrix.smul_apply]

/-- Appendix Algorithm 1 IID formula for a trace-one input:
`Phi_acc (rho tensor rho) = (rho + rho^2) / 2`. -/
theorem oneEPRAcceptedMap_kronecker_self_of_trace_eq_one
    {x : Type*} [Fintype x] [DecidableEq x]
    (rho : CMatrix x) (htrace : rho.trace = 1) :
    oneEPRAcceptedMap (Matrix.kronecker rho rho) =
      (1 / 2 : ℂ) • (rho + rho * rho) := by
  rw [oneEPRAcceptedMap_kronecker_self, htrace, one_smul]

end

end EntanglementPurification
