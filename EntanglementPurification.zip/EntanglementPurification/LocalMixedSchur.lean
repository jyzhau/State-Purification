import EntanglementPurification.GlobalContractions
import EntanglementPurification.GlobalSDPRigidity
import Mathlib.Tactic

/-!
# Concrete local mixed-Schur coordinates

This file isolates the concrete part of the local mixed-Schur reduction used
in `main.tex`.  The one-side space `LocalMixedSchurSpace x` is the physical
three-leg space `x × x × x`, ordered as the two input legs followed by the
output leg.  The matrices called `globalWPlus` and `globalWMinus` in the
global calculation are dimension-polymorphic, so they are also exactly the
paper's local maps after replacing the one-leg dimension by `Fintype.card x`.

The new content here is the covariance calculation

`(bar U ⊗ bar U ⊗ U) W± = W± bar U`.

Together with the previously proved input-swap identities, this gives the
concrete structural identities stated in `eq:local_W_structural_identities`.
The final projection theorem is the finite-matrix form of the four-way
orthogonal decomposition used in `eq:local_mixed_schur_direct_sum`.

This file deliberately does **not** claim a general mixed Schur-Weyl theorem:
it does not prove irreducibility, identify Young-diagram labels or path
multiplicities, or characterize the full commutant of the representation.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

/-- The physical one-side space `H_X = X₁ ⊗ X₂ ⊗ X'`. -/
abbrev LocalMixedSchurSpace (x : Type*) := GlobalThreeLeg x

/-- The first local contraction, with `|a⟩ ↦ ∑ᵢ |i,a,i⟩`. -/
abbrev localGamma1
    {x : Type*} [DecidableEq x] :
    Matrix (LocalMixedSchurSpace x) x Complex :=
  globalGamma1

/-- The second local contraction, with `|a⟩ ↦ ∑ᵢ |a,i,i⟩`. -/
abbrev localGamma2
    {x : Type*} [DecidableEq x] :
    Matrix (LocalMixedSchurSpace x) x Complex :=
  globalGamma2

/-- Entrywise complex conjugation of a unitary matrix.  This is `bar U`, not
the conjugate transpose `U†`. -/
def localEntrywiseConjugate
    {x : Type*} [Fintype x] [DecidableEq x]
    (U : Matrix.unitaryGroup x Complex) : CMatrix x :=
  fun i j => star ((U : CMatrix x) i j)

/-- The local representation `π_X(U) = bar U ⊗ bar U ⊗ U`. -/
def localMixedSchurRepresentation
    {x : Type*} [Fintype x] [DecidableEq x]
    (U : Matrix.unitaryGroup x Complex) :
    CMatrix (LocalMixedSchurSpace x) :=
  Matrix.kronecker
    (Matrix.kronecker
      (localEntrywiseConjugate U)
      (localEntrywiseConjugate U))
    (U : CMatrix x)

/-- The first contraction intertwines the local representation with `bar U`. -/
theorem localGamma1_intertwines
    {x : Type*} [Fintype x] [DecidableEq x]
    (U : Matrix.unitaryGroup x Complex) :
    localMixedSchurRepresentation U * localGamma1 =
      localGamma1 * localEntrywiseConjugate U := by
  ext p a
  cases p with
  | mk rs t =>
    cases rs with
    | mk r s =>
      have hunit0 := congrFun (congrFun U.2.2 t) r
      simp only [Matrix.mul_apply, Matrix.one_apply] at hunit0
      have hunit :
          (Finset.univ.sum fun i =>
            (U : CMatrix x) t i * star ((U : CMatrix x) r i)) =
            if t = r then 1 else 0 := by
        simpa only [Matrix.star_apply] using hunit0
      simp [localMixedSchurRepresentation, localEntrywiseConjugate,
        Matrix.mul_apply, globalGamma1, Fintype.sum_prod_type]
      calc
        (Finset.univ.sum fun i =>
          starRingEnd Complex (U r i) *
            starRingEnd Complex (U s a) * U t i) =
            star (U s a) *
              (Finset.univ.sum fun i => U t i * star (U r i)) := by
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro i _
          simp only [starRingEnd_apply, mul_assoc, mul_comm]
        _ = star (U s a) * (if t = r then 1 else 0) := by rw [hunit]
        _ = if r = t then star (U s a) else 0 := by
          by_cases h : r = t
          · simp [h]
          · simp [h, Ne.symm h]

/-- The second contraction intertwines the local representation with `bar U`. -/
theorem localGamma2_intertwines
    {x : Type*} [Fintype x] [DecidableEq x]
    (U : Matrix.unitaryGroup x Complex) :
    localMixedSchurRepresentation U * localGamma2 =
      localGamma2 * localEntrywiseConjugate U := by
  ext p a
  cases p with
  | mk rs t =>
    cases rs with
    | mk r s =>
      have hunit0 := congrFun (congrFun U.2.2 t) s
      simp only [Matrix.mul_apply, Matrix.one_apply] at hunit0
      have hunit :
          (Finset.univ.sum fun i =>
            (U : CMatrix x) t i * star ((U : CMatrix x) s i)) =
            if t = s then 1 else 0 := by
        simpa only [Matrix.star_apply] using hunit0
      simp [localMixedSchurRepresentation, localEntrywiseConjugate,
        Matrix.mul_apply, globalGamma2, Fintype.sum_prod_type]
      calc
        (Finset.univ.sum fun i =>
          starRingEnd Complex (U r a) *
            starRingEnd Complex (U s i) * U t i) =
            star (U r a) *
              (Finset.univ.sum fun i => U t i * star (U s i)) := by
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro i _
          simp only [starRingEnd_apply]
          ring
        _ = star (U r a) * (if t = s then 1 else 0) := by rw [hunit]
        _ = if s = t then star (U r a) else 0 := by
          by_cases h : s = t
          · simp [h]
          · simp [h, Ne.symm h]

/-- The paper's normalized local even-parity map `W₊`. -/
abbrev localWPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    Matrix (LocalMixedSchurSpace x) x Complex :=
  globalWPlus

/-- The paper's normalized local odd-parity map `W₋`. -/
abbrev localWMinus
    {x : Type*} [Fintype x] [DecidableEq x] :
    Matrix (LocalMixedSchurSpace x) x Complex :=
  globalWMinus

/-- The local even-parity map intertwines `π_X(U)` with `bar U`. -/
theorem localWPlus_intertwines
    {x : Type*} [Fintype x] [DecidableEq x]
    (U : Matrix.unitaryGroup x Complex) :
    localMixedSchurRepresentation U * localWPlus =
      localWPlus * localEntrywiseConjugate U := by
  simp only [globalWPlus, globalGammaPlus, Matrix.mul_smul, Matrix.smul_mul,
    Matrix.mul_add, Matrix.add_mul, localGamma1_intertwines,
    localGamma2_intertwines]

/-- The local odd-parity map intertwines `π_X(U)` with `bar U`. -/
theorem localWMinus_intertwines
    {x : Type*} [Fintype x] [DecidableEq x]
    (U : Matrix.unitaryGroup x Complex) :
    localMixedSchurRepresentation U * localWMinus =
      localWMinus * localEntrywiseConjugate U := by
  simp only [globalWMinus, globalGammaMinus, Matrix.mul_smul, Matrix.smul_mul,
    Matrix.mul_sub, Matrix.sub_mul, localGamma1_intertwines,
    localGamma2_intertwines]

/-- The swap of the two local input legs, extended trivially on the output. -/
abbrev localInputSwap
    {x : Type*} [Fintype x] [DecidableEq x] :
    CMatrix (LocalMixedSchurSpace x) :=
  globalInputSwap

/-- The concrete matrix form of all identities in
`eq:local_W_structural_identities`, for one local side. -/
theorem localW_structural_identities
    {x : Type*} [Fintype x] [DecidableEq x]
    (hcard : 2 ≤ Fintype.card x)
    (U : Matrix.unitaryGroup x Complex) :
    Matrix.conjTranspose (localWPlus (x := x)) * localWPlus (x := x) =
      (1 : CMatrix x) ∧
    Matrix.conjTranspose (localWMinus (x := x)) * localWMinus (x := x) =
      (1 : CMatrix x) ∧
    Matrix.conjTranspose (localWPlus (x := x)) * localWMinus (x := x) =
      (0 : CMatrix x) ∧
    localMixedSchurRepresentation U * localWPlus (x := x) =
      localWPlus (x := x) * localEntrywiseConjugate U ∧
    localMixedSchurRepresentation U * localWMinus (x := x) =
      localWMinus (x := x) * localEntrywiseConjugate U ∧
    localInputSwap (x := x) * localWPlus (x := x) =
      localWPlus (x := x) ∧
    localInputSwap (x := x) * localWMinus (x := x) =
      -localWMinus (x := x) := by
  exact ⟨globalWPlus_conjTranspose_mul_self,
    globalWMinus_conjTranspose_mul_self hcard,
    globalWPlus_conjTranspose_mul_globalWMinus,
    localWPlus_intertwines U,
    localWMinus_intertwines U,
    globalInputSwap_mul_globalWPlus,
    globalInputSwap_mul_globalWMinus⟩

/-- Projector onto the local `W₊` range. -/
abbrev localPWPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    CMatrix (LocalMixedSchurSpace x) :=
  globalPWPlus

/-- Projector onto the local `W₋` range. -/
abbrev localPWMinus
    {x : Type*} [Fintype x] [DecidableEq x] :
    CMatrix (LocalMixedSchurSpace x) :=
  globalPWMinus

/-- Projector onto the residual local even-parity sector `L₊`. -/
abbrev localPLPlus
    {x : Type*} [Fintype x] [DecidableEq x] :
    CMatrix (LocalMixedSchurSpace x) :=
  globalPLPlus

/-- Projector onto the residual local odd-parity sector `L₋`. -/
abbrev localPLMinus
    {x : Type*} [Fintype x] [DecidableEq x] :
    CMatrix (LocalMixedSchurSpace x) :=
  globalPLMinus

/-- The four concrete local projectors are pairwise orthogonal. -/
theorem localMixedSchur_projectors_pairwise
    {x : Type*} [Fintype x] [DecidableEq x]
    (hcard : 2 ≤ Fintype.card x) :
    PairwiseOrthogonalFour
      (localPWPlus (x := x)) localPWMinus localPLPlus localPLMinus := by
  exact ⟨globalPWPlus_mul_globalPWMinus,
    globalPWPlus_mul_globalPLPlus,
    globalPWPlus_mul_globalPLMinus,
    globalPWMinus_mul_globalPLPlus,
    globalPWMinus_mul_globalPLMinus hcard,
    globalPLPlus_mul_globalPLMinus⟩

/-- The four concrete local range/residual projectors resolve the identity.
This is the projection-level content of the paper's local four-way orthogonal
direct sum; it makes no additional irreducibility claim. -/
theorem localMixedSchur_projection_resolution
    {x : Type*} [Fintype x] [DecidableEq x] :
    localPWPlus (x := x) + localPWMinus + localPLPlus + localPLMinus = 1 := by
  exact global_four_projectors_sum

end

end EntanglementPurification
