import EntanglementPurification.PhysicalLocalTwirl
import EntanglementPurification.PhysicalBranchOutputInvariant

/-!
# Output completeness of the physical local Haar twirl

This file proves that the genuine Alice/Bob Haar average preserves the
trace-preserving equation for a pair of physical branches.  The proof first
establishes the exact covariance of the physical output trace under a local
mixed-representation conjugation, then moves the output trace through the
Bochner integral.
-/

namespace EntanglementPurification

open QIT
open MeasureTheory
open scoped ComplexOrder MatrixOrder Matrix.Norms.L2Operator

noncomputable section

universe uA uB uR uX

variable {a : Type uA} {b : Type uB} {r : Type uR}
  [Fintype a] [Fintype b] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq r]

local instance physicalLocalTwirlCompletenessCMatrixContinuousENorm
    {i : Type*} [Fintype i] [DecidableEq i] :
    ContinuousENorm (CMatrix i) :=
  SeminormedAddGroup.toContinuousENorm

private def outputInputProductTwoCopyUnitaryForTwirl
    (U : Matrix.unitaryGroup a Complex)
    (V : Matrix.unitaryGroup b Complex) :
    Matrix.unitaryGroup (JointContractionInputResourceIndex a b r) Complex := by
  let hU : localEntrywiseConjugate U ∈ Matrix.unitaryGroup a Complex := by
    change (↑(Matrix.UnitaryGroup.map_star U) : CMatrix a) ∈
      Matrix.unitaryGroup a Complex
    exact SetLike.coe_mem (Matrix.UnitaryGroup.map_star U)
  let hV : localEntrywiseConjugate V ∈ Matrix.unitaryGroup b Complex := by
    change (↑(Matrix.UnitaryGroup.map_star V) : CMatrix b) ∈
      Matrix.unitaryGroup b Complex
    exact SetLike.coe_mem (Matrix.UnitaryGroup.map_star V)
  let hOne : (1 : CMatrix r) ∈ Matrix.unitaryGroup r Complex :=
    SetLike.coe_mem (1 : Matrix.unitaryGroup r Complex)
  exact ⟨outputInputProductTwoCopyRepresentation (r := r) U V,
    Matrix.kronecker_mem_unitary
      (Matrix.kronecker_mem_unitary
        (Matrix.kronecker_mem_unitary hU hU)
        (Matrix.kronecker_mem_unitary hV hV))
      hOne⟩

private def physicalOutputProductUnitaryForTwirl
    (U : Matrix.unitaryGroup a Complex)
    (V : Matrix.unitaryGroup b Complex) :
    Matrix.unitaryGroup (a × b) Complex :=
  ⟨Matrix.kronecker (U : CMatrix a) (V : CMatrix b),
    Matrix.kronecker_mem_unitary (SetLike.coe_mem U) (SetLike.coe_mem V)⟩

/-- Tracing out the physical outputs is covariant under the full local mixed
representation.  Only the two-copy input representation remains. -/
theorem physicalBranchOutputTrace_jointContractionPhysical_conj
    (K : CMatrix (JointContractionPhysicalIndex a b r))
    (U : Matrix.unitaryGroup a Complex)
    (V : Matrix.unitaryGroup b Complex) :
    physicalBranchOutputTrace
        (jointContractionPhysicalRepresentation (r := r) U V * K *
          Matrix.conjTranspose
            (jointContractionPhysicalRepresentation (r := r) U V)) =
      outputInputProductTwoCopyRepresentation (r := r) U V *
        physicalBranchOutputTrace K *
        Matrix.conjTranspose
          (outputInputProductTwoCopyRepresentation (r := r) U V) := by
  let e := jointPhysicalOutputGroupingEquiv (a := a) (b := b) (r := r)
  let E := Matrix.reindexAlgEquiv Complex Complex e
  let X : CMatrix
      (JointContractionInputResourceIndex a b r × (a × b)) := E K
  let P := outputInputProductTwoCopyRepresentation (r := r) U V
  let Q := Matrix.kronecker (U : CMatrix a) (V : CMatrix b)
  let Punit := outputInputProductTwoCopyUnitaryForTwirl (r := r) U V
  let Qunit := physicalOutputProductUnitaryForTwirl U V
  have hFactor :
      E (jointContractionPhysicalRepresentation (r := r) U V) =
        Matrix.kronecker P Q := by
    simpa [E, P, Q] using
      (reindex_jointContractionPhysicalRepresentation_outputGrouping
        (r := r) U V)
  have hPunit :
      (↑Punit : CMatrix (JointContractionInputResourceIndex a b r)) = P := by
    rfl
  have hQunit : (↑Qunit : CMatrix (a × b)) = Q := by
    rfl
  have hPunitInv :
      (↑(Punit⁻¹) : CMatrix (JointContractionInputResourceIndex a b r)) =
        Matrix.conjTranspose P := by
    simp [hPunit, Matrix.star_eq_conjTranspose]
  have hQunitInv :
      (↑(Qunit⁻¹) : CMatrix (a × b)) = Matrix.conjTranspose Q := by
    simp [hQunit, Matrix.star_eq_conjTranspose]
  have hTrace := QIT.partialTraceB_local_unitary_conj
    (a := JointContractionInputResourceIndex a b r) (b := a × b)
    X Punit⁻¹ Qunit⁻¹
  rw [hPunitInv, hQunitInv] at hTrace
  simp only [Matrix.star_eq_conjTranspose,
    Matrix.conjTranspose_conjTranspose] at hTrace
  have hRight :
      Matrix.kronecker (Matrix.conjTranspose P)
          (Matrix.conjTranspose Q) =
        Matrix.conjTranspose (Matrix.kronecker P Q) := by
    ext ⟨i, j⟩ ⟨k, l⟩
    simp [Matrix.conjTranspose_apply, Matrix.kronecker,
      Matrix.kroneckerMap_apply]
  have hLeft :
      Matrix.conjTranspose
          (Matrix.kronecker (Matrix.conjTranspose P)
            (Matrix.conjTranspose Q)) =
        Matrix.kronecker P Q := by
    rw [hRight, Matrix.conjTranspose_conjTranspose]
  rw [hLeft, hRight] at hTrace
  unfold physicalBranchOutputTrace
  change QIT.partialTraceB
      (E (jointContractionPhysicalRepresentation (r := r) U V * K *
        Matrix.conjTranspose
          (jointContractionPhysicalRepresentation (r := r) U V))) =
    P * QIT.partialTraceB X * Matrix.conjTranspose P
  simp only [map_mul]
  have hAdjoint :
      E (Matrix.conjTranspose
          (jointContractionPhysicalRepresentation (r := r) U V)) =
        Matrix.conjTranspose
          (E (jointContractionPhysicalRepresentation (r := r) U V)) := by
    rfl
  rw [hAdjoint, hFactor]
  exact hTrace

/-- The physical output trace, bundled as a continuous linear map so it can
be moved through a Bochner integral. -/
private noncomputable def physicalBranchOutputTraceCLM
    [Nonempty a] [Nonempty b] [Nonempty r] :
    CMatrix (JointContractionPhysicalIndex a b r) →L[Complex]
      CMatrix (JointContractionInputResourceIndex a b r) :=
  LinearMap.toContinuousLinearMap
    { toFun := physicalBranchOutputTrace
      map_add' := by
        intro X Y
        ext ⟨⟨iA, iB⟩, u⟩ ⟨⟨kA, kB⟩, v⟩
        simp [physicalBranchOutputTrace_apply, Finset.sum_add_distrib]
      map_smul' := by
        intro c X
        ext ⟨⟨iA, iB⟩, u⟩ ⟨⟨kA, kB⟩, v⟩
        simp [physicalBranchOutputTrace_apply, Finset.mul_sum] }

private theorem physicalBranchOutputTrace_integral
    [Nonempty a] [Nonempty b] [Nonempty r]
    {x : Type uX} [MeasurableSpace x] {mu : Measure x}
    {f : x → CMatrix (JointContractionPhysicalIndex a b r)}
    (hf : Integrable f mu) :
    physicalBranchOutputTrace (∫ t, f t ∂mu) =
      ∫ t, physicalBranchOutputTrace (f t) ∂mu := by
  simpa [physicalBranchOutputTraceCLM] using
    ((physicalBranchOutputTraceCLM (a := a) (b := b) (r := r)).integral_comp_comm hf).symm

private theorem outputInputProductTwoCopyRepresentation_mul_conjTranspose
    (U : Matrix.unitaryGroup a Complex)
    (V : Matrix.unitaryGroup b Complex) :
    outputInputProductTwoCopyRepresentation (r := r) U V *
        Matrix.conjTranspose
          (outputInputProductTwoCopyRepresentation (r := r) U V) = 1 := by
  let Punit := outputInputProductTwoCopyUnitaryForTwirl (r := r) U V
  have h := Unitary.coe_mul_star_self Punit
  simpa [Punit, Matrix.star_eq_conjTranspose] using h

theorem physicalBranchOutputTrace_physicalAliceTwirlIntegrand_eq_one
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hK : physicalBranchOutputTrace K = 1)
    (U : Matrix.unitaryGroup a Complex) :
    physicalBranchOutputTrace
        (physicalAliceTwirlIntegrand (b := b) (r := r) K U) = 1 := by
  rw [physicalAliceTwirlIntegrand]
  simp only [physicalAliceMixedRepresentation,
    Matrix.star_eq_conjTranspose]
  rw [physicalBranchOutputTrace_jointContractionPhysical_conj]
  rw [hK, Matrix.mul_one]
  exact outputInputProductTwoCopyRepresentation_mul_conjTranspose
    (r := r) U 1

theorem physicalBranchOutputTrace_physicalBobTwirlIntegrand_eq_one
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hK : physicalBranchOutputTrace K = 1)
    (V : Matrix.unitaryGroup b Complex) :
    physicalBranchOutputTrace
        (physicalBobTwirlIntegrand (a := a) (r := r) K V) = 1 := by
  rw [physicalBobTwirlIntegrand]
  simp only [physicalBobMixedRepresentation,
    Matrix.star_eq_conjTranspose]
  rw [physicalBranchOutputTrace_jointContractionPhysical_conj]
  rw [hK, Matrix.mul_one]
  exact outputInputProductTwoCopyRepresentation_mul_conjTranspose
    (r := r) 1 V

theorem physicalBranchOutputTrace_physicalAliceTwirl_eq_one
    [Nonempty a] [Nonempty b] [Nonempty r]
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hK : physicalBranchOutputTrace K = 1) :
    physicalBranchOutputTrace (physicalAliceTwirl K) = 1 := by
  rw [physicalAliceTwirl]
  rw [physicalBranchOutputTrace_integral
    (physicalAliceTwirlIntegrand_integrable K)]
  calc
    (∫ U : Matrix.unitaryGroup a Complex,
        physicalBranchOutputTrace
          (physicalAliceTwirlIntegrand K U)
        ∂unitaryHaarMeasure (a := a)) =
        ∫ _U : Matrix.unitaryGroup a Complex,
          (1 : CMatrix (JointContractionInputResourceIndex a b r))
          ∂unitaryHaarMeasure (a := a) := by
      apply integral_congr_ae
      filter_upwards [] with U
      exact physicalBranchOutputTrace_physicalAliceTwirlIntegrand_eq_one hK U
    _ = 1 := by simp

theorem physicalBranchOutputTrace_physicalBobTwirl_eq_one
    [Nonempty a] [Nonempty b] [Nonempty r]
    {K : CMatrix (JointContractionPhysicalIndex a b r)}
    (hK : physicalBranchOutputTrace K = 1) :
    physicalBranchOutputTrace (physicalBobTwirl K) = 1 := by
  rw [physicalBobTwirl]
  rw [physicalBranchOutputTrace_integral
    (physicalBobTwirlIntegrand_integrable K)]
  calc
    (∫ V : Matrix.unitaryGroup b Complex,
        physicalBranchOutputTrace
          (physicalBobTwirlIntegrand K V)
        ∂unitaryHaarMeasure (a := b)) =
        ∫ _V : Matrix.unitaryGroup b Complex,
          (1 : CMatrix (JointContractionInputResourceIndex a b r))
          ∂unitaryHaarMeasure (a := b) := by
      apply integral_congr_ae
      filter_upwards [] with V
      exact physicalBranchOutputTrace_physicalBobTwirlIntegrand_eq_one hK V
    _ = 1 := by simp

private theorem physicalBranchOutputTrace_add
    (S F : CMatrix (JointContractionPhysicalIndex a b r)) :
    physicalBranchOutputTrace (S + F) =
    physicalBranchOutputTrace S + physicalBranchOutputTrace F := by
  ext ⟨⟨iA, iB⟩, u⟩ ⟨⟨kA, kB⟩, v⟩
  simp [physicalBranchOutputTrace_apply, Finset.sum_add_distrib]

/-- Alice Haar averaging preserves the output-completeness equation for a
success/failure pair. -/
theorem physicalBranchOutputTrace_physicalAliceTwirl_add_eq_one
    [Nonempty a] [Nonempty b] [Nonempty r]
    {S F : CMatrix (JointContractionPhysicalIndex a b r)}
    (hcomplete : physicalBranchOutputTrace S +
      physicalBranchOutputTrace F = 1) :
    physicalBranchOutputTrace (physicalAliceTwirl S) +
        physicalBranchOutputTrace (physicalAliceTwirl F) = 1 := by
  rw [← physicalBranchOutputTrace_add, ← physicalAliceTwirl_add]
  apply physicalBranchOutputTrace_physicalAliceTwirl_eq_one
  rw [physicalBranchOutputTrace_add]
  exact hcomplete

/-- Bob Haar averaging preserves the output-completeness equation for a
success/failure pair. -/
theorem physicalBranchOutputTrace_physicalBobTwirl_add_eq_one
    [Nonempty a] [Nonempty b] [Nonempty r]
    {S F : CMatrix (JointContractionPhysicalIndex a b r)}
    (hcomplete : physicalBranchOutputTrace S +
      physicalBranchOutputTrace F = 1) :
    physicalBranchOutputTrace (physicalBobTwirl S) +
        physicalBranchOutputTrace (physicalBobTwirl F) = 1 := by
  rw [← physicalBranchOutputTrace_add, ← physicalBobTwirl_add]
  apply physicalBranchOutputTrace_physicalBobTwirl_eq_one
  rw [physicalBranchOutputTrace_add]
  exact hcomplete

/-- Headline feasibility statement: the genuine two-sided physical Haar
twirl preserves the trace-preserving equation of the two branches. -/
theorem physicalBranchOutputTrace_physicalLocalTwirl_add_eq_one
    [Nonempty a] [Nonempty b] [Nonempty r]
    {S F : CMatrix (JointContractionPhysicalIndex a b r)}
    (hcomplete : physicalBranchOutputTrace S +
      physicalBranchOutputTrace F = 1) :
    physicalBranchOutputTrace (physicalLocalTwirl S) +
        physicalBranchOutputTrace (physicalLocalTwirl F) = 1 := by
  unfold physicalLocalTwirl
  apply physicalBranchOutputTrace_physicalAliceTwirl_add_eq_one
  exact physicalBranchOutputTrace_physicalBobTwirl_add_eq_one hcomplete

end

end EntanglementPurification
