import EntanglementPurification.OneEPRInstrument
import EntanglementPurification.OneEPRLocalProtocol
import Mathlib.Tactic

/-!
# Full formal certificate for Algorithm 1

This module is the public interface for the formalized one-EPR protocol.  It
combines two independently checkable layers:

* a genuine Lean-QIT `FiniteInstrument` containing all four terminal outcomes,
  their success/failure coarse-graining, and a trace-preserving total channel;
* an explicit Alice/Bob tensor-factorization witness showing that every Kraus
  branch is obtained from local controlled swaps, local Hadamard outcomes, and
  the normalized shared EPR amplitudes.

Lean-QIT's current `OneWayLOCC` datatype does not expose a second terminal
measurement outcome from Bob.  Accordingly, the local layer is represented by
`ParallelLocalEPRCertificate`; this file does not claim a library-native
`OneWayLOCC` term and does not prove the general inclusion `LOCC ⇒ PPT`.
-/

namespace EntanglementPurification

open QIT

noncomputable section

/-- A single public object collecting the complete classical instrument and
the explicit local/EPR realization of its four branches. -/
structure OneEPRFullProtocolCertificate
    (a b : Type*) [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] where
  fourOutcomeInstrument :
    QIT.FiniteInstrument
      ((a × b) × (a × b)) ((a × b) × (a × b)) (Bool × Bool)
  successFailureInstrument :
    QIT.FiniteInstrument ((a × b) × (a × b)) (a × b) Bool
  localWitness : ParallelLocalEPRCertificate a b
  fourOutcomeInstrument_eq :
    fourOutcomeInstrument =
      oneEPRFourOutcomeTwoCopyInstrument (a := a) (b := b)
  successFailureInstrument_eq :
    successFailureInstrument =
      oneEPRSuccessFailureInstrument (a := a) (b := b)
  local_branch_eq : ∀ outcome : Bool × Bool,
    fourOutcomeInstrument.branch outcome =
      locallyFactoredOneEPROutcomeMap (a := a) (b := b) outcome
  success_branch_eq :
    successFailureInstrument.branch true =
      oneEPRAlgorithmAcceptedCircuitMap (a := a) (b := b)
  failure_branch_eq :
    successFailureInstrument.branch false =
      oneEPRAlgorithmRejectedCircuitMap (a := a) (b := b)
  branches_complete :
    successFailureInstrument.branch false +
        successFailureInstrument.branch true =
      successFailureInstrument.total.map
  total_tracePreserving :
    MatrixMap.IsTracePreserving successFailureInstrument.total.map

/-- The canonical complete certificate for Algorithm 1 in arbitrary finite
local dimensions. -/
def oneEPRFullProtocolCertificate
    (a b : Type*) [Fintype a] [Fintype b]
    [DecidableEq a] [DecidableEq b] :
    OneEPRFullProtocolCertificate a b where
  fourOutcomeInstrument :=
    oneEPRFourOutcomeTwoCopyInstrument (a := a) (b := b)
  successFailureInstrument :=
    oneEPRSuccessFailureInstrument (a := a) (b := b)
  localWitness := oneEPRParallelLocalCertificate a b
  fourOutcomeInstrument_eq := rfl
  successFailureInstrument_eq := rfl
  local_branch_eq outcome := by
    change oneEPRSingleOutcomeTwoCopyMap (a := a) (b := b) outcome =
      locallyFactoredOneEPROutcomeMap (a := a) (b := b) outcome
    exact
      (locallyFactoredOneEPROutcomeMap_eq_algorithmKrausMap
        (a := a) (b := b) outcome).symm
  success_branch_eq := oneEPRSuccessFailureInstrument_success
  failure_branch_eq := oneEPRSuccessFailureInstrument_failure
  branches_complete := oneEPRSuccessFailureInstrument_complete
  total_tracePreserving :=
    (oneEPRSuccessFailureInstrument (a := a) (b := b)).total.tracePreserving

/-- Final theorem wrapper for the paper-dimension protocol.  It exposes the
local realization of every terminal branch, complete success/failure
semantics, the optimal Choi matrix, and exact attainment of the paper gain in
one statement. -/
theorem oneEPRAlgorithm_fullProtocol_optimality_certificate
    {d : Nat} (hd : 2 ≤ d)
    (nu : PureVector (GlobalPaperIndex d))
    (gamma : Real) :
    let C := oneEPRFullProtocolCertificate (Fin d) (Fin d)
    (∀ outcome : Bool × Bool,
      C.fourOutcomeInstrument.branch outcome =
        locallyFactoredOneEPROutcomeMap
          (a := Fin d) (b := Fin d) outcome) ∧
    C.successFailureInstrument.branch false =
      oneEPRAlgorithmRejectedCircuitMap (a := Fin d) (b := Fin d) ∧
    C.successFailureInstrument.branch true =
      oneEPRAcceptedMap (x := GlobalPaperIndex d) ∧
    MatrixMap.TraceNonincreasingCP
      (C.successFailureInstrument.branch false) ∧
    MatrixMap.TraceNonincreasingCP
      (C.successFailureInstrument.branch true) ∧
    C.successFailureInstrument.branch false +
        C.successFailureInstrument.branch true =
      C.successFailureInstrument.total.map ∧
    MatrixMap.IsTracePreserving C.successFailureInstrument.total.map ∧
    MatrixMap.choi (C.successFailureInstrument.branch true) =
      globalOptimalChoi (x := GlobalPaperIndex d) ∧
    globalSDPObjective
        (globalPaperHaarPerformanceOperator hd nu gamma)
        (MatrixMap.choi (C.successFailureInstrument.branch true)) =
      globalOptimalGain ((d : Real) ^ 2) gamma := by
  dsimp only
  refine And.intro (oneEPRFullProtocolCertificate
    (Fin d) (Fin d)).local_branch_eq ?_
  refine And.intro oneEPRSuccessFailureInstrument_failure ?_
  refine And.intro
    oneEPRSuccessFailureInstrument_success_eq_oneEPRAcceptedMap ?_
  refine And.intro
    ((oneEPRSuccessFailureInstrument
      (a := Fin d) (b := Fin d)).branchTraceNonincreasingCP false) ?_
  refine And.intro
    ((oneEPRSuccessFailureInstrument
      (a := Fin d) (b := Fin d)).branchTraceNonincreasingCP true) ?_
  refine And.intro oneEPRSuccessFailureInstrument_complete ?_
  refine And.intro
    (oneEPRSuccessFailureInstrument
      (a := Fin d) (b := Fin d)).total.tracePreserving ?_
  refine And.intro ?_ ?_
  · change MatrixMap.choi
        ((oneEPRSuccessFailureInstrument
          (a := Fin d) (b := Fin d)).branch true) =
        globalOptimalChoi (x := GlobalPaperIndex d)
    rw [oneEPRSuccessFailureInstrument_success]
    exact choi_oneEPRAlgorithmAcceptedCircuitMap_eq_globalOptimalChoi
  · change globalSDPObjective
        (globalPaperHaarPerformanceOperator hd nu gamma)
        (MatrixMap.choi
          ((oneEPRSuccessFailureInstrument
            (a := Fin d) (b := Fin d)).branch true)) =
        globalOptimalGain ((d : Real) ^ 2) gamma
    rw [oneEPRSuccessFailureInstrument_success]
    exact oneEPRAlgorithmAcceptedCircuitMap_attains_globalPaperHaar_gain
      hd nu gamma

end

end EntanglementPurification
