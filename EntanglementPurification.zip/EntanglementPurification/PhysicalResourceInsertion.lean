import EntanglementPurification.PhysicalPPTInstrument
import EntanglementPurification.PPTSectorBlocks
import EntanglementPurification.GlobalConcreteSDP

/-!
# Resource insertion in physical and contraction coordinates

This file makes explicit the two register permutations suppressed in
`main.tex:3175--3215`.  A raw input-first Choi matrix is first regrouped into
the paper's physical order `H_A ⊗ H_B ⊗ R`.  Inserting a pure resource then
commutes with that regrouping.  The second half of the file proves the
corresponding square for the joint contraction pullback and hence for its
resource-valued Schur coefficient.
-/

namespace EntanglementPurification

open QIT
open scoped ComplexOrder MatrixOrder

noncomputable section

variable {a b ra rb r : Type*}
  [Fintype a] [Fintype b] [Fintype ra] [Fintype rb] [Fintype r]
  [DecidableEq a] [DecidableEq b] [DecidableEq ra] [DecidableEq rb]
  [DecidableEq r]

/-- The unassisted input of the two-copy protocol. -/
abbrev PhysicalUnassistedInput (a b : Type*) :=
  (a × b) × (a × b)

/-- The raw input-first Choi index after the resource has been inserted. -/
abbrev PhysicalUnassistedChoiIndex (a b : Type*) :=
  PhysicalUnassistedInput a b × PhysicalInstrumentOutput a b

/-- Physical Alice/Bob order after the resource register has been inserted. -/
abbrev JointContractionUnassistedPhysicalIndex (a b : Type*) :=
  LocalMixedSchurSpace a × LocalMixedSchurSpace b

/-- Regroup an unassisted input-first Choi index into `H_A ⊗ H_B`. -/
def physicalInsertedChoiEquiv :
    PhysicalUnassistedChoiIndex a b ≃
      JointContractionUnassistedPhysicalIndex a b where
  toFun p :=
    (((p.1.1.1, p.1.2.1), p.2.1),
      ((p.1.1.2, p.1.2.2), p.2.2))
  invFun p :=
    (((p.1.1.1, p.2.1.1), (p.1.1.2, p.2.1.2)),
      (p.1.2, p.2.2))
  left_inv _ := rfl
  right_inv _ := rfl

/-- Regroup a raw resource-assisted input-first Choi matrix into the paper's
physical order.  `physicalInstrumentChoi` is this operation applied to a
matrix map's Choi matrix. -/
def physicalInstrumentChoiMatrix
    (K : CMatrix
      (PhysicalInstrumentInput a b ra rb × PhysicalInstrumentOutput a b)) :
    CMatrix (JointContractionPhysicalIndex a b (ra × rb)) :=
  (Matrix.reindexAlgEquiv ℂ ℂ
    (physicalInstrumentChoiEquiv (a := a) (b := b) (ra := ra) (rb := rb))) K

/-- Regroup a raw Choi matrix after resource insertion into `H_A ⊗ H_B`. -/
def physicalInsertedChoiMatrix
    (J : CMatrix (PhysicalUnassistedChoiIndex a b)) :
    CMatrix (JointContractionUnassistedPhysicalIndex a b) :=
  (Matrix.reindexAlgEquiv ℂ ℂ
    (physicalInsertedChoiEquiv (a := a) (b := b))) J

@[simp]
theorem physicalInstrumentChoi_eq_physicalInstrumentChoiMatrix
    (Φ : MatrixMap (PhysicalInstrumentInput a b ra rb)
      (PhysicalInstrumentOutput a b)) :
    physicalInstrumentChoi Φ =
      physicalInstrumentChoiMatrix (MatrixMap.choi Φ) :=
  rfl

/-- Embed the unassisted physical space by tensoring every vector with the
resource vector. -/
def physicalResourceInsertionEmbedding (eta : r → ℂ) :
    Matrix (JointContractionPhysicalIndex a b r)
      (JointContractionUnassistedPhysicalIndex a b) ℂ :=
  fun p q => if p.1 = q then eta p.2 else 0

/-- Pure-resource insertion directly in the physical Alice/Bob register
order. -/
def physicalPureResourceInsert (eta : r → ℂ)
    (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    CMatrix (JointContractionUnassistedPhysicalIndex a b) :=
  Matrix.conjTranspose (physicalResourceInsertionEmbedding eta) * K *
    physicalResourceInsertionEmbedding eta

omit [DecidableEq r] in
/-- Entrywise physical resource sandwich. -/
theorem physicalPureResourceInsert_apply
    (eta : r → ℂ) (K : CMatrix (JointContractionPhysicalIndex a b r))
    (p q : JointContractionUnassistedPhysicalIndex a b) :
    physicalPureResourceInsert eta K p q =
      ∑ u : r, ∑ v : r,
        star (eta u) * K (p, u) (q, v) * eta v := by
  simp [physicalPureResourceInsert, physicalResourceInsertionEmbedding,
    Matrix.mul_apply, Matrix.conjTranspose_apply, apply_ite,
    Finset.sum_mul, Fintype.sum_prod_type]
  rw [Finset.sum_comm]

/-- Resource insertion commutes with the raw-Choi-to-physical register
permutation. -/
theorem physicalPureResourceInsert_physicalInstrumentChoiMatrix
    (eta : ra × rb → ℂ)
    (K : CMatrix
      (PhysicalInstrumentInput a b ra rb × PhysicalInstrumentOutput a b)) :
    physicalPureResourceInsert eta (physicalInstrumentChoiMatrix K) =
      physicalInsertedChoiMatrix (pureResourceInsert eta K) := by
  ext p q
  rw [physicalPureResourceInsert_apply]
  simp [physicalInstrumentChoiMatrix, physicalInsertedChoiMatrix,
    Matrix.reindexAlgEquiv_apply, Matrix.reindex_apply,
    physicalInstrumentChoiEquiv, physicalInsertedChoiEquiv,
    pureResourceInsert_apply]

/-- Map-level specialization of the preceding raw Choi identity. -/
theorem physicalPureResourceInsert_physicalInstrumentChoi
    (eta : ra × rb → ℂ)
    (Φ : MatrixMap (PhysicalInstrumentInput a b ra rb)
      (PhysicalInstrumentOutput a b)) :
    physicalPureResourceInsert eta (physicalInstrumentChoi Φ) =
      physicalInsertedChoiMatrix
        (pureResourceInsert eta (MatrixMap.choi Φ)) := by
  rw [physicalInstrumentChoi_eq_physicalInstrumentChoiMatrix]
  exact physicalPureResourceInsert_physicalInstrumentChoiMatrix eta _

/-! ## The contraction-coordinate resource-insertion square -/

/-- Contraction coordinates with no resource register. -/
abbrev JointContractionUnassistedCoordinateIndex (a b : Type*) :=
  LocalMultiplicitySector × (a × b)

/-- The joint local contraction isometry before a resource identity is adjoined. -/
def jointContractionUnassistedIsometry :
    Matrix (JointContractionUnassistedPhysicalIndex a b)
      (JointContractionUnassistedCoordinateIndex a b) ℂ :=
  fun p q =>
    localContractionCoordinates p.1 (q.1.1, q.2.1) *
      localContractionCoordinates p.2 (q.1.2, q.2.2)

@[simp]
theorem jointContractionUnassistedIsometry_apply
    (uA : LocalMixedSchurSpace a) (uB : LocalMixedSchurSpace b)
    (sA sB : LocalParity) (i : a) (j : b) :
    jointContractionUnassistedIsometry (uA, uB) ((sA, sB), (i, j)) =
      localContractionCoordinates uA (sA, i) *
        localContractionCoordinates uB (sB, j) :=
  rfl

/-- Insert the resource vector in contraction coordinates, preserving sector and `A × B`. -/
def jointContractionCoordinateResourceEmbedding (eta : r → ℂ) :
    Matrix (JointContractionCoordinateIndex a b r)
      (JointContractionUnassistedCoordinateIndex a b) ℂ :=
  fun p q =>
    if p.1.1 = q.1 then
      if p.2 = q.2 then eta p.1.2 else 0
    else 0

/-- Tensoring with the resource vector commutes with the joint local contraction. -/
theorem jointContraction_resourceEmbedding_square (eta : r → ℂ) :
    jointContractionIsometry (a := a) (b := b) (r := r) *
        jointContractionCoordinateResourceEmbedding eta =
      physicalResourceInsertionEmbedding eta *
        jointContractionUnassistedIsometry := by
  ext p q
  rcases p with ⟨⟨uA, uB⟩, z⟩
  rcases q with ⟨⟨sA, sB⟩, ⟨i, j⟩⟩
  simp [Matrix.mul_apply, jointContractionCoordinateResourceEmbedding,
    physicalResourceInsertionEmbedding, Fintype.sum_prod_type,
    apply_ite]
  ring

/-- Pull an unassisted physical operator back through `G_A ⊗ G_B`. -/
def jointContractionUnassistedPullback
    (J : CMatrix (JointContractionUnassistedPhysicalIndex a b)) :
    CMatrix (JointContractionUnassistedCoordinateIndex a b) :=
  Matrix.conjTranspose jointContractionUnassistedIsometry * J *
    jointContractionUnassistedIsometry

/-- Insert a pure resource in contraction coordinates. -/
def jointContractionCoordinatePureResourceInsert (eta : r → ℂ)
    (Q : CMatrix (JointContractionCoordinateIndex a b r)) :
    CMatrix (JointContractionUnassistedCoordinateIndex a b) :=
  Matrix.conjTranspose (jointContractionCoordinateResourceEmbedding eta) * Q *
    jointContractionCoordinateResourceEmbedding eta

omit [DecidableEq r] in
/-- Entrywise contraction-coordinate resource sandwich. -/
theorem jointContractionCoordinatePureResourceInsert_apply
    (eta : r → ℂ) (Q : CMatrix (JointContractionCoordinateIndex a b r))
    (p q : JointContractionUnassistedCoordinateIndex a b) :
    jointContractionCoordinatePureResourceInsert eta Q p q =
      ∑ u : r, ∑ v : r,
        star (eta u) * Q ((p.1, u), p.2) ((q.1, v), q.2) * eta v := by
  simp [jointContractionCoordinatePureResourceInsert,
    jointContractionCoordinateResourceEmbedding, Matrix.mul_apply,
    Matrix.conjTranspose_apply, apply_ite, Finset.sum_mul,
    Fintype.sum_prod_type]
  rw [Finset.sum_comm]

/-- Adjoint form of `jointContraction_resourceEmbedding_square`. -/
theorem jointContraction_resourceEmbedding_square_conjTranspose
    (eta : r → ℂ) :
    Matrix.conjTranspose jointContractionUnassistedIsometry *
        Matrix.conjTranspose (physicalResourceInsertionEmbedding eta) =
      Matrix.conjTranspose (jointContractionCoordinateResourceEmbedding eta) *
        Matrix.conjTranspose
          (jointContractionIsometry (a := a) (b := b) (r := r)) := by
  simpa only [Matrix.conjTranspose_mul] using
    (congrArg Matrix.conjTranspose
      (jointContraction_resourceEmbedding_square (a := a) (b := b) eta)).symm

/-- Pullback through the contraction isometry commutes with pure-resource insertion. -/
theorem jointContractionUnassistedPullback_physicalPureResourceInsert
    (eta : r → ℂ) (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    jointContractionUnassistedPullback (physicalPureResourceInsert eta K) =
      jointContractionCoordinatePureResourceInsert eta
        (jointContractionPullback K) := by
  let G := jointContractionIsometry (a := a) (b := b) (r := r)
  let G0 := jointContractionUnassistedIsometry (a := a) (b := b)
  let E := physicalResourceInsertionEmbedding (a := a) (b := b) eta
  let E0 := jointContractionCoordinateResourceEmbedding
    (a := a) (b := b) eta
  have h : G * E0 = E * G0 :=
    jointContraction_resourceEmbedding_square eta
  have hstar : Matrix.conjTranspose G0 * Matrix.conjTranspose E =
      Matrix.conjTranspose E0 * Matrix.conjTranspose G := by
    simpa only [Matrix.conjTranspose_mul] using
      (congrArg Matrix.conjTranspose h).symm
  change Matrix.conjTranspose G0 *
      (Matrix.conjTranspose E * K * E) * G0 =
    Matrix.conjTranspose E0 *
      (Matrix.conjTranspose G * K * G) * E0
  calc
    Matrix.conjTranspose G0 * (Matrix.conjTranspose E * K * E) * G0 =
        (Matrix.conjTranspose G0 * Matrix.conjTranspose E) * K *
          (E * G0) := by
            simp only [Matrix.mul_assoc]
    _ = (Matrix.conjTranspose E0 * Matrix.conjTranspose G) * K *
          (G * E0) := by rw [hstar, h]
    _ = Matrix.conjTranspose E0 *
          (Matrix.conjTranspose G * K * G) * E0 := by
            simp only [Matrix.mul_assoc]

/-- The four-sector coefficient of an unassisted contraction pullback. -/
def jointContractionUnassistedCoefficient
    [Nonempty a] [Nonempty b]
    (J : CMatrix (JointContractionUnassistedPhysicalIndex a b)) :
    CMatrix LocalMultiplicitySector :=
  productUnitaryCommutantCoefficient
    (jointContractionUnassistedPullback J)

/-- Extracting the product-unitary coefficient commutes with the coordinate
resource sandwich. -/
theorem productUnitaryCommutantCoefficient_coordinatePureResourceInsert
    [Nonempty a] [Nonempty b]
    (eta : r → ℂ) (Q : CMatrix (JointContractionCoordinateIndex a b r)) :
    productUnitaryCommutantCoefficient
        (jointContractionCoordinatePureResourceInsert eta Q) =
      insertPureResourceBlock eta
        (productUnitaryCommutantCoefficient Q) := by
  ext z w
  rw [insertPureResourceBlock_apply]
  simp only [productUnitaryCommutantCoefficient, resourceSectorBlock]
  rw [jointContractionCoordinatePureResourceInsert_apply]

/-- The physical resource sandwich and the resource-valued Schur coefficient
form a commuting square. -/
theorem jointContractionUnassistedCoefficient_physicalPureResourceInsert
    [Nonempty a] [Nonempty b]
    (eta : r → ℂ) (K : CMatrix (JointContractionPhysicalIndex a b r)) :
    jointContractionUnassistedCoefficient
        (physicalPureResourceInsert eta K) =
      insertPureResourceBlock eta (jointContractionSchurCoefficient K) := by
  unfold jointContractionUnassistedCoefficient
    jointContractionSchurCoefficient
  rw [jointContractionUnassistedPullback_physicalPureResourceInsert]
  exact
    productUnitaryCommutantCoefficient_coordinatePureResourceInsert eta _

/-- Raw input-first resource insertion implies the corresponding identity for
the compressed four-sector block, with both register permutations explicit. -/
theorem insertPureResourceBlock_jointContractionSchurCoefficient_of_raw
    [Nonempty a] [Nonempty b]
    (eta : ra × rb → ℂ)
    (K : CMatrix
      (PhysicalInstrumentInput a b ra rb × PhysicalInstrumentOutput a b))
    (J : CMatrix (PhysicalUnassistedChoiIndex a b))
    (hraw : pureResourceInsert eta K = J) :
    insertPureResourceBlock eta
        (jointContractionSchurCoefficient
          (physicalInstrumentChoiMatrix K)) =
      jointContractionUnassistedCoefficient
        (physicalInsertedChoiMatrix J) := by
  rw [← jointContractionUnassistedCoefficient_physicalPureResourceInsert]
  rw [physicalPureResourceInsert_physicalInstrumentChoiMatrix, hraw]

/-- Map-level form of the raw-to-compressed resource-insertion bridge. -/
theorem insertPureResourceBlock_jointContractionSchurCoefficient_of_choi
    [Nonempty a] [Nonempty b]
    (eta : ra × rb → ℂ)
    (Φ : MatrixMap (PhysicalInstrumentInput a b ra rb)
      (PhysicalInstrumentOutput a b))
    (J : CMatrix (PhysicalUnassistedChoiIndex a b))
    (hraw : pureResourceInsert eta (MatrixMap.choi Φ) = J) :
    insertPureResourceBlock eta
        (jointContractionSchurCoefficient (physicalInstrumentChoi Φ)) =
      jointContractionUnassistedCoefficient
        (physicalInsertedChoiMatrix J) := by
  rw [physicalInstrumentChoi_eq_physicalInstrumentChoiMatrix]
  exact
    insertPureResourceBlock_jointContractionSchurCoefficient_of_raw
      eta _ J hraw

end

end EntanglementPurification
